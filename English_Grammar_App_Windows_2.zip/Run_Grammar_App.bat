@echo off
echo ========================================
echo   English Grammar Practice App
echo   Grade 6 ICSE
echo ========================================
echo.
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found! Install from https://python.org
    pause
    exit /b 1
)
python -c "import PyQt5" >nul 2>&1
if errorlevel 1 (
    echo Installing PyQt5...
    pip install PyQt5
)
echo Launching app...
python english_grammar_app.py
pause
