"""
Biology — Grade 6 ICSE
Chapter 6: Circulatory System
Comprehensive Practice Questions
50 MCQ • 50 True/False • 40 Subjective
"""

CHAPTER_6_QUESTIONS = {

    "Chapter 6 — Circulatory System": [
        # ===== MCQ (50 questions) =====
        {
            "type": "mcq",
            "q": "What is the main function of the circulatory system?",
            "options": [
                "Digestion of food",
                "Transport of nutrients, gases, and wastes",
                "Production of energy",
                "Movement of body"
            ],
            "answer": "Transport of nutrients, gases, and wastes",
            "explanation": "The circulatory system transports nutrients, oxygen, carbon dioxide, hormones, and wastes throughout the body."
        },
        {
            "type": "mcq",
            "q": "The circulatory system in humans consists of:",
            "options": [
                "Heart only",
                "Blood and blood vessels only",
                "Heart, blood, and blood vessels",
                "Heart and lungs only"
            ],
            "answer": "Heart, blood, and blood vessels",
            "explanation": "The human circulatory system has three main components: blood, blood vessels, and the heart."
        },
        {
            "type": "mcq",
            "q": "How much blood does an average human adult have?",
            "options": [
                "2-3 litres",
                "4-6 litres",
                "7-8 litres",
                "10 litres"
            ],
            "answer": "4-6 litres",
            "explanation": "The human body on average has 4 to 6 litres of blood."
        },
        {
            "type": "mcq",
            "q": "Blood is a type of:",
            "options": [
                "Epithelial tissue",
                "Connective tissue",
                "Muscular tissue",
                "Nervous tissue"
            ],
            "answer": "Connective tissue",
            "explanation": "Blood is a fluid connective tissue."
        },
        {
            "type": "mcq",
            "q": "The liquid part of blood is called:",
            "options": [
                "Serum",
                "Plasma",
                "Cytoplasm",
                "Lymph"
            ],
            "answer": "Plasma",
            "explanation": "Plasma is the pale yellow liquid part of blood, constituting 55-60% of blood volume."
        },
        {
            "type": "mcq",
            "q": "What is the colour of plasma?",
            "options": [
                "Red",
                "Colourless",
                "Pale yellow",
                "White"
            ],
            "answer": "Pale yellow",
            "explanation": "Plasma is pale yellow in colour."
        },
        {
            "type": "mcq",
            "q": "What percentage of blood is plasma?",
            "options": [
                "40-45%",
                "55-60%",
                "70-75%",
                "80-85%"
            ],
            "answer": "55-60%",
            "explanation": "Plasma constitutes about 55-60% of total blood volume."
        },
        {
            "type": "mcq",
            "q": "Plasma consists of about what percentage of water?",
            "options": [
                "70-80%",
                "80-85%",
                "90-92%",
                "95-98%"
            ],
            "answer": "90-92%",
            "explanation": "Plasma consists of 90-92% water, along with proteins, inorganic salts, and other substances."
        },
        {
            "type": "mcq",
            "q": "The three types of blood cells are:",
            "options": [
                "RBCs, WBCs, and platelets",
                "RBCs, WBCs, and plasma",
                "Plasma, serum, and platelets",
                "RBCs, platelets, and serum"
            ],
            "answer": "RBCs, WBCs, and platelets",
            "explanation": "The three types of blood cells (corpuscles) are red blood cells (RBCs), white blood cells (WBCs), and blood platelets."
        },
        {
            "type": "mcq",
            "q": "What percentage of blood is made up of blood cells?",
            "options": [
                "40-45%",
                "55-60%",
                "30-35%",
                "20-25%"
            ],
            "answer": "40-45%",
            "explanation": "Blood cells (corpuscles) constitute 40-45% of total blood volume."
        },
        {
            "type": "mcq",
            "q": "Red blood cells are also called:",
            "options": [
                "Leucocytes",
                "Erythrocytes",
                "Thrombocytes",
                "Lymphocytes"
            ],
            "answer": "Erythrocytes",
            "explanation": "Red blood cells are scientifically called erythrocytes."
        },
        {
            "type": "mcq",
            "q": "White blood cells are also called:",
            "options": [
                "Erythrocytes",
                "Leucocytes",
                "Thrombocytes",
                "Granulocytes"
            ],
            "answer": "Leucocytes",
            "explanation": "White blood cells are scientifically called leucocytes."
        },
        {
            "type": "mcq",
            "q": "Blood platelets are also called:",
            "options": [
                "Erythrocytes",
                "Leucocytes",
                "Thrombocytes",
                "Lymphocytes"
            ],
            "answer": "Thrombocytes",
            "explanation": "Blood platelets are scientifically called thrombocytes."
        },
        {
            "type": "mcq",
            "q": "What is the shape of red blood cells?",
            "options": [
                "Spherical",
                "Biconcave disc-shaped",
                "Irregular",
                "Thread-like"
            ],
            "answer": "Biconcave disc-shaped",
            "explanation": "RBCs are biconcave, disc-shaped cells, as if pressed from the sides."
        },
        {
            "type": "mcq",
            "q": "Do mature red blood cells have a nucleus?",
            "options": [
                "Yes",
                "No",
                "Sometimes",
                "Only in some animals"
            ],
            "answer": "No",
            "explanation": "Mature red blood cells in humans do not have a nucleus, which provides more space for haemoglobin."
        },
        {
            "type": "mcq",
            "q": "Where are red blood cells produced?",
            "options": [
                "Liver",
                "Spleen",
                "Bone marrow",
                "Lymph nodes"
            ],
            "answer": "Bone marrow",
            "explanation": "RBCs are produced in the bone marrow."
        },
        {
            "type": "mcq",
            "q": "What is the average life span of a red blood cell?",
            "options": [
                "30 days",
                "60 days",
                "90 days",
                "120 days"
            ],
            "answer": "120 days",
            "explanation": "RBCs have an average life span of about 120 days (4 months)."
        },
        {
            "type": "mcq",
            "q": "How many RBCs are there in each cubic millimetre of blood?",
            "options": [
                "4-5 million",
                "5-6 million",
                "6-7 million",
                "7-8 million"
            ],
            "answer": "5-6 million",
            "explanation": "There are about 5-6 million RBCs in each mm³ of blood."
        },
        {
            "type": "mcq",
            "q": "The red colour of RBCs is due to:",
            "options": [
                "Iron",
                "Haemoglobin",
                "Oxygen",
                "Plasma"
            ],
            "answer": "Haemoglobin",
            "explanation": "RBCs are red due to the presence of haemoglobin, a red-coloured iron-containing protein."
        },
        {
            "type": "mcq",
            "q": "The function of haemoglobin is to:",
            "options": [
                "Fight infection",
                "Carry oxygen",
                "Clot blood",
                "Digest food"
            ],
            "answer": "Carry oxygen",
            "explanation": "Haemoglobin carries oxygen from lungs to all body cells."
        },
        {
            "type": "mcq",
            "q": "White blood cells are ________ than red blood cells.",
            "options": [
                "Smaller",
                "Larger",
                "Same size",
                "Half the size"
            ],
            "answer": "Larger",
            "explanation": "WBCs are larger than RBCs."
        },
        {
            "type": "mcq",
            "q": "Do white blood cells contain haemoglobin?",
            "options": [
                "Yes",
                "No",
                "Sometimes",
                "Only some types"
            ],
            "answer": "No",
            "explanation": "WBCs do not contain haemoglobin, so they are colourless."
        },
        {
            "type": "mcq",
            "q": "White blood cells have:",
            "options": [
                "No nucleus",
                "A nucleus",
                "Multiple nuclei",
                "No definite shape but have nucleus"
            ],
            "answer": "No definite shape but have nucleus",
            "explanation": "WBCs do not have a definite shape, change shape like Amoeba, and contain nuclei."
        },
        {
            "type": "mcq",
            "q": "Where are white blood cells produced?",
            "options": [
                "Bone marrow only",
                "Lymph nodes only",
                "Bone marrow and lymph nodes",
                "Spleen only"
            ],
            "answer": "Bone marrow and lymph nodes",
            "explanation": "WBCs are produced in the red bone marrow and lymph nodes."
        },
        {
            "type": "mcq",
            "q": "What is the life span of white blood cells?",
            "options": [
                "12 hours to 12 days",
                "30-40 days",
                "120 days",
                "1 year"
            ],
            "answer": "12 hours to 12 days",
            "explanation": "WBCs have a life span ranging from 12 hours to 12 days."
        },
        {
            "type": "mcq",
            "q": "How many WBCs are there in each cubic millimetre of blood?",
            "options": [
                "1000-2000",
                "4000-13000",
                "20000-30000",
                "50000-100000"
            ],
            "answer": "4000-13000",
            "explanation": "Normal WBC count is about 4000-13000 per mm³ of blood."
        },
        {
            "type": "mcq",
            "q": "An abnormal increase in WBC count above _______ indicates infection.",
            "options": [
                "10,000",
                "20,000",
                "50,000",
                "1,00,000"
            ],
            "answer": "50,000",
            "explanation": "WBC count above 50,000 per mm³ indicates infection in the body."
        },
        {
            "type": "mcq",
            "q": "The main function of white blood cells is to:",
            "options": [
                "Carry oxygen",
                "Clot blood",
                "Protect the body from infection",
                "Transport nutrients"
            ],
            "answer": "Protect the body from infection",
            "explanation": "WBCs protect the body by destroying germs and foreign bodies like bacteria and viruses."
        },
        {
            "type": "mcq",
            "q": "WBCs destroy germs by:",
            "options": [
                "Releasing chemicals",
                "Engulfing them",
                "Producing antibodies",
                "All of these"
            ],
            "answer": "All of these",
            "explanation": "WBCs can engulf germs (phagocytosis), produce antibodies, and release chemicals to fight infection."
        },
        {
            "type": "mcq",
            "q": "Blood platelets are:",
            "options": [
                "Colourless, nucleated cells",
                "Colourless, disc-shaped cells without nuclei",
                "Red, disc-shaped cells",
                "Irregular, coloured cells"
            ],
            "answer": "Colourless, disc-shaped cells without nuclei",
            "explanation": "Platelets are colourless, disc-shaped cells without nuclei."
        },
        {
            "type": "mcq",
            "q": "How many platelets are there in each cubic millimetre of blood?",
            "options": [
                "40,000-80,000",
                "1,00,000-2,00,000",
                "2,00,000-4,00,000",
                "5,00,000-10,00,000"
            ],
            "answer": "2,00,000-4,00,000",
            "explanation": "Platelet count is about 200,000-400,000 per mm³ of blood."
        },
        {
            "type": "mcq",
            "q": "What is the life span of blood platelets?",
            "options": [
                "1-2 days",
                "3-7 days",
                "10-15 days",
                "30 days"
            ],
            "answer": "3-7 days",
            "explanation": "Platelets have a life span of about 3-7 days."
        },
        {
            "type": "mcq",
            "q": "The main function of platelets is:",
            "options": [
                "Oxygen transport",
                "Immunity",
                "Blood clotting",
                "Nutrient transport"
            ],
            "answer": "Blood clotting",
            "explanation": "Platelets prevent blood loss by forming clots over wounds and cuts."
        },
        {
            "type": "mcq",
            "q": "About how many RBCs are destroyed every minute?",
            "options": [
                "1 million",
                "10 million",
                "20 million",
                "50 million"
            ],
            "answer": "20 million",
            "explanation": "About 20 million RBCs are destroyed every minute in the spleen and liver."
        },
        {
            "type": "mcq",
            "q": "Where are RBCs destroyed?",
            "options": [
                "Bone marrow",
                "Spleen and liver",
                "Kidneys",
                "Heart"
            ],
            "answer": "Spleen and liver",
            "explanation": "Old RBCs are destroyed in the spleen and liver."
        },
        {
            "type": "mcq",
            "q": "Granulocytes and agranulocytes are types of:",
            "options": [
                "RBCs",
                "WBCs",
                "Platelets",
                "Plasma proteins"
            ],
            "answer": "WBCs",
            "explanation": "WBCs are of two types: granulocytes (with granules) and agranulocytes (without granules)."
        },
        {
            "type": "mcq",
            "q": "Who developed the system of classification of blood groups?",
            "options": [
                "Robert Hooke",
                "Karl Landsteiner",
                "Louis Pasteur",
                "Alexander Fleming"
            ],
            "answer": "Karl Landsteiner",
            "explanation": "Karl Landsteiner developed the ABO blood group system and was awarded the Nobel Prize in 1930."
        },
        {
            "type": "mcq",
            "q": "Human blood is classified into four groups based on the presence of:",
            "options": [
                "Haemoglobin",
                "Antigens on RBCs",
                "Platelets",
                "White blood cells"
            ],
            "answer": "Antigens on RBCs",
            "explanation": "Blood groups are based on antigens (proteins) present on the surface of RBCs."
        },
        {
            "type": "mcq",
            "q": "The four blood groups are:",
            "options": [
                "A, B, C, D",
                "A, B, AB, O",
                "A, B, O, ABO",
                "Type 1, 2, 3, 4"
            ],
            "answer": "A, B, AB, O",
            "explanation": "The ABO blood group system has four types: A, B, AB, and O."
        },
        {
            "type": "mcq",
            "q": "Blood group A has:",
            "options": [
                "Antigen A and antibody B",
                "Antigen B and antibody A",
                "Both antigens A and B",
                "No antigens"
            ],
            "answer": "Antigen A and antibody B",
            "explanation": "Blood group A has antigen A on RBCs and antibody B in plasma."
        },
        {
            "type": "mcq",
            "q": "Blood group B has:",
            "options": [
                "Antigen A and antibody B",
                "Antigen B and antibody A",
                "Both antigens A and B",
                "No antibodies"
            ],
            "answer": "Antigen B and antibody A",
            "explanation": "Blood group B has antigen B on RBCs and antibody A in plasma."
        },
        {
            "type": "mcq",
            "q": "Blood group AB has:",
            "options": [
                "Antigen A and antibody B",
                "Antigen B and antibody A",
                "Both antigens A and B, no antibodies",
                "No antigens, both antibodies"
            ],
            "answer": "Both antigens A and B, no antibodies",
            "explanation": "Blood group AB has both antigens A and B on RBCs but no antibodies in plasma."
        },
        {
            "type": "mcq",
            "q": "Blood group O has:",
            "options": [
                "Both antigens, no antibodies",
                "No antigens, both antibodies A and B",
                "Antigen A only",
                "Antigen B only"
            ],
            "answer": "No antigens, both antibodies A and B",
            "explanation": "Blood group O has neither antigen A nor B, but both antibodies A and B in plasma."
        },
        {
            "type": "mcq",
            "q": "What is Rh-factor?",
            "options": [
                "A type of blood cell",
                "An antigen on RBCs",
                "A plasma protein",
                "A blood clotting factor"
            ],
            "answer": "An antigen on RBCs",
            "explanation": "Rh-factor is an antigen found on the surface of RBCs, first discovered in Rhesus monkeys."
        },
        {
            "type": "mcq",
            "q": "What percentage of people are Rh-positive?",
            "options": [
                "About 50%",
                "About 65%",
                "About 85%",
                "About 95%"
            ],
            "answer": "About 85%",
            "explanation": "About 85% of people have the Rh-factor and are Rh-positive."
        },
        {
            "type": "mcq",
            "q": "Blood vessels that carry blood away from the heart are called:",
            "options": [
                "Veins",
                "Arteries",
                "Capillaries",
                "Venules"
            ],
            "answer": "Arteries",
            "explanation": "Arteries carry blood away from the heart to different body parts."
        },
        {
            "type": "mcq",
            "q": "Blood vessels that carry blood towards the heart are called:",
            "options": [
                "Arteries",
                "Veins",
                "Capillaries",
                "Arterioles"
            ],
            "answer": "Veins",
            "explanation": "Veins carry blood towards the heart from different body parts."
        },
        {
            "type": "mcq",
            "q": "Which blood vessel carries blood from the heart to the lungs?",
            "options": [
                "Pulmonary vein",
                "Pulmonary artery",
                "Aorta",
                "Vena cava"
            ],
            "answer": "Pulmonary artery",
            "explanation": "The pulmonary artery carries deoxygenated (impure) blood from the heart to the lungs."
        },
        {
            "type": "mcq",
            "q": "Which blood vessel carries blood from the lungs to the heart?",
            "options": [
                "Pulmonary artery",
                "Pulmonary vein",
                "Aorta",
                "Coronary artery"
            ],
            "answer": "Pulmonary vein",
            "explanation": "The pulmonary vein carries oxygenated (pure) blood from the lungs to the heart."
        },
        {
            "type": "mcq",
            "q": "Which is the largest artery in the body?",
            "options": [
                "Pulmonary artery",
                "Coronary artery",
                "Aorta",
                "Carotid artery"
            ],
            "answer": "Aorta",
            "explanation": "The aorta is the largest artery in the body, arising from the left ventricle."
        },
        {
            "type": "mcq",
            "q": "Which blood vessels have valves to prevent backflow of blood?",
            "options": [
                "Arteries",
                "Veins",
                "Capillaries",
                "All blood vessels"
            ],
            "answer": "Veins",
            "explanation": "Veins have valves to prevent backflow of blood, especially in limbs against gravity."
        },
        {
            "type": "mcq",
            "q": "The walls of capillaries are:",
            "options": [
                "Thick and muscular",
                "Thin, one cell thick",
                "Elastic only",
                "Made of cartilage"
            ],
            "answer": "Thin, one cell thick",
            "explanation": "Capillary walls are only one cell thick to enable diffusion of gases and materials."
        },
        
        # ===== True/False (50 questions) =====
        {
            "type": "tf",
            "q": "The circulatory system transports only oxygen and carbon dioxide.",
            "answer": "False",
            "explanation": "It transports nutrients, hormones, wastes, and many other substances besides gases."
        },
        {
            "type": "tf",
            "q": "Blood is a solid tissue.",
            "answer": "False",
            "explanation": "Blood is a fluid connective tissue."
        },
        {
            "type": "tf",
            "q": "Plasma is the liquid part of blood and is red in colour.",
            "answer": "False",
            "explanation": "Plasma is pale yellow, not red. Red colour comes from RBCs."
        },
        {
            "type": "tf",
            "q": "Plasma contains digested nutrients, waste products, and chemicals.",
            "answer": "True",
            "explanation": "Plasma transports many substances including nutrients, wastes, and hormones."
        },
        {
            "type": "tf",
            "q": "Blood corpuscles make up 55-60% of blood volume.",
            "answer": "False",
            "explanation": "Plasma makes up 55-60%; blood corpuscles make up 40-45%."
        },
        {
            "type": "tf",
            "q": "Red blood cells are also called leucocytes.",
            "answer": "False",
            "explanation": "RBCs are erythrocytes; WBCs are leucocytes."
        },
        {
            "type": "tf",
            "q": "Mature red blood cells in humans have a nucleus.",
            "answer": "False",
            "explanation": "Mature human RBCs do not have a nucleus, providing more space for haemoglobin."
        },
        {
            "type": "tf",
            "q": "The biconcave shape of RBCs increases surface area for oxygen transport.",
            "answer": "True",
            "explanation": "The biconcave shape provides larger surface area for gas exchange."
        },
        {
            "type": "tf",
            "q": "Red blood cells are produced in the liver.",
            "answer": "False",
            "explanation": "RBCs are produced in the bone marrow, not the liver."
        },
        {
            "type": "tf",
            "q": "The average life span of an RBC is about 120 days.",
            "answer": "True",
            "explanation": "RBCs live for approximately 120 days before being destroyed."
        },
        {
            "type": "tf",
            "q": "Haemoglobin is an iron-containing protein.",
            "answer": "True",
            "explanation": "Haemoglobin contains iron, which binds to oxygen."
        },
        {
            "type": "tf",
            "q": "White blood cells are smaller than red blood cells.",
            "answer": "False",
            "explanation": "WBCs are larger than RBCs."
        },
        {
            "type": "tf",
            "q": "White blood cells have a definite shape like RBCs.",
            "answer": "False",
            "explanation": "WBCs are irregular and can change shape like Amoeba."
        },
        {
            "type": "tf",
            "q": "White blood cells contain haemoglobin.",
            "answer": "False",
            "explanation": "WBCs do not contain haemoglobin; they are colourless."
        },
        {
            "type": "tf",
            "q": "WBCs are produced in the bone marrow and lymph nodes.",
            "answer": "True",
            "explanation": "Both bone marrow and lymph nodes produce white blood cells."
        },
        {
            "type": "tf",
            "q": "The life span of WBCs is longer than that of RBCs.",
            "answer": "False",
            "explanation": "WBCs live 12 hours to 12 days, shorter than RBCs' 120 days."
        },
        {
            "type": "tf",
            "q": "Normal WBC count is about 4000-13000 per mm³ of blood.",
            "answer": "True",
            "explanation": "This is the normal range for WBC count."
        },
        {
            "type": "tf",
            "q": "A WBC count above 50,000 indicates infection.",
            "answer": "True",
            "explanation": "High WBC count (leukocytosis) indicates infection or inflammation."
        },
        {
            "type": "tf",
            "q": "WBCs protect the body by engulfing germs.",
            "answer": "True",
            "explanation": "This process is called phagocytosis."
        },
        {
            "type": "tf",
            "q": "Blood platelets are nucleated cells.",
            "answer": "False",
            "explanation": "Platelets are without nuclei."
        },
        {
            "type": "tf",
            "q": "Platelets are smaller than RBCs and WBCs.",
            "answer": "True",
            "explanation": "Platelets are the smallest blood cells."
        },
        {
            "type": "tf",
            "q": "Platelets are produced in the bone marrow.",
            "answer": "True",
            "explanation": "Platelets are formed from megakaryocytes in bone marrow."
        },
        {
            "type": "tf",
            "q": "The life span of platelets is about 3-7 days.",
            "answer": "True",
            "explanation": "Platelets have a short life span and are constantly replaced."
        },
        {
            "type": "tf",
            "q": "Platelets help in blood clotting.",
            "answer": "True",
            "explanation": "Platelets form clots to prevent blood loss."
        },
        {
            "type": "tf",
            "q": "About 20 million RBCs are destroyed every hour.",
            "answer": "False",
            "explanation": "About 20 million RBCs are destroyed every minute."
        },
        {
            "type": "tf",
            "q": "RBCs are destroyed in the spleen and liver.",
            "answer": "True",
            "explanation": "Old RBCs are broken down in the spleen and liver."
        },
        {
            "type": "tf",
            "q": "Karl Landsteiner discovered blood groups.",
            "answer": "True",
            "explanation": "He developed the ABO blood group system and won the Nobel Prize."
        },
        {
            "type": "tf",
            "q": "Blood group AB has both antibodies A and B.",
            "answer": "False",
            "explanation": "Blood group AB has no antibodies, but both antigens A and B."
        },
        {
            "type": "tf",
            "q": "Blood group O has both antibodies A and B.",
            "answer": "True",
            "explanation": "Group O has no antigens but both antibodies."
        },
        {
            "type": "tf",
            "q": "Rh-factor was first discovered in rabbits.",
            "answer": "False",
            "explanation": "It was discovered in Rhesus monkeys, hence the name Rh."
        },
        {
            "type": "tf",
            "q": "About 85% of people are Rh-positive.",
            "answer": "True",
            "explanation": "85% have Rh-factor; 15% are Rh-negative."
        },
        {
            "type": "tf",
            "q": "Arteries carry blood away from the heart.",
            "answer": "True",
            "explanation": "This is the definition of arteries."
        },
        {
            "type": "tf",
            "q": "Veins carry blood towards the heart.",
            "answer": "True",
            "explanation": "This is the definition of veins."
        },
        {
            "type": "tf",
            "q": "Arteries always carry oxygenated (pure) blood.",
            "answer": "False",
            "explanation": "Pulmonary artery carries deoxygenated blood to lungs."
        },
        {
            "type": "tf",
            "q": "Veins always carry deoxygenated (impure) blood.",
            "answer": "False",
            "explanation": "Pulmonary veins carry oxygenated blood from lungs to heart."
        },
        {
            "type": "tf",
            "q": "Arteries have thick, elastic, muscular walls.",
            "answer": "True",
            "explanation": "Arteries need thick walls to withstand high pressure."
        },
        {
            "type": "tf",
            "q": "Veins have valves to prevent backflow of blood.",
            "answer": "True",
            "explanation": "Valves are especially important in leg veins against gravity."
        },
        {
            "type": "tf",
            "q": "Capillaries have walls one cell thick.",
            "answer": "True",
            "explanation": "This thin wall allows diffusion of gases and nutrients."
        },
        {
            "type": "tf",
            "q": "The pulmonary artery carries pure blood.",
            "answer": "False",
            "explanation": "The pulmonary artery carries impure (deoxygenated) blood to lungs."
        },
        {
            "type": "tf",
            "q": "The pulmonary veins carry impure blood.",
            "answer": "False",
            "explanation": "Pulmonary veins carry pure (oxygenated) blood from lungs to heart."
        },
        {
            "type": "tf",
            "q": "The aorta is the largest artery in the body.",
            "answer": "True",
            "explanation": "The aorta arises from the left ventricle and supplies all body parts."
        },
        {
            "type": "tf",
            "q": "Blood transports hormones from their site of production to target organs.",
            "answer": "True",
            "explanation": "Blood carries chemical messengers (hormones) throughout the body."
        },
        {
            "type": "tf",
            "q": "Blood helps in regulating body temperature.",
            "answer": "True",
            "explanation": "Blood distributes heat from active organs to maintain constant temperature."
        },
        {
            "type": "tf",
            "q": "Granulocytes have granules in their cytoplasm.",
            "answer": "True",
            "explanation": "Granulocytes (neutrophils, basophils, eosinophils) contain visible granules."
        },
        {
            "type": "tf",
            "q": "Lymphocytes and monocytes are types of granulocytes.",
            "answer": "False",
            "explanation": "They are agranulocytes (without granules)."
        },
        {
            "type": "tf",
            "q": "Blood group AB is called the universal donor.",
            "answer": "False",
            "explanation": "Group O is universal donor; AB is universal recipient."
        },
        {
            "type": "tf",
            "q": "Blood group O can donate to any blood group.",
            "answer": "True",
            "explanation": "Group O has no antigens, so it can be given to anyone (universal donor)."
        },
        {
            "type": "tf",
            "q": "Blood group AB can receive from any blood group.",
            "answer": "True",
            "explanation": "Group AB has no antibodies, so it can receive from any type (universal recipient)."
        },
        {
            "type": "tf",
            "q": "Arteries are deep-seated in the body.",
            "answer": "True",
            "explanation": "Most arteries are deep for protection; veins are often superficial."
        },
        {
            "type": "tf",
            "q": "Veins are closer to the skin than arteries.",
            "answer": "True",
            "explanation": "This is why you can see veins through skin but not arteries."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "Describe the composition of blood with a labeled diagram.",
            "sample": "Blood is a fluid connective tissue composed of plasma and blood cells (corpuscles).\n\nComposition of blood:\n\n1. Plasma (55-60%):\n   - Pale yellow liquid\n   - 90-92% water\n   - 7-8% proteins (albumin, globulin, fibrinogen)\n   - 1% inorganic salts\n   - Traces of nutrients, wastes, hormones, enzymes\n\n2. Blood cells/corpuscles (40-45%):\n\n   A. Red Blood Cells (Erythrocytes):\n      - Biconcave, disc-shaped\n      - No nucleus in mature cells\n      - Contain haemoglobin (red colour)\n      - 5-6 million per mm³\n      - Life span: 120 days\n      - Produced in bone marrow\n      - Function: Transport oxygen\n\n   B. White Blood Cells (Leucocytes):\n      - Larger than RBCs\n      - Irregular shape\n      - Have nucleus\n      - No haemoglobin (colourless)\n      - 4000-13000 per mm³\n      - Life span: 12 hours to 12 days\n      - Produced in bone marrow and lymph nodes\n      - Function: Fight infection\n      - Types: Granulocytes and Agranulocytes\n\n   C. Blood Platelets (Thrombocytes):\n      - Smallest blood cells\n      - Colourless, disc-shaped\n      - No nucleus\n      - 200,000-400,000 per mm³\n      - Life span: 3-7 days\n      - Produced in bone marrow\n      - Function: Blood clotting\n\n[Students should draw a labeled diagram showing:\n- Test tube with blood (plasma at top, buffy coat of WBCs/platelets in middle, RBCs at bottom)\n- Individual diagrams of RBC (biconcave), WBC (irregular with nucleus), platelet (small disc)]"
        },
        {
            "type": "subjective",
            "q": "Explain the structure and function of red blood cells.",
            "sample": "Red blood cells (erythrocytes) are the most abundant cells in blood, specialized for oxygen transport.\n\nStructure of RBCs:\n\n1. Shape:\n   - Biconcave disc-shaped (depressed in centre, thick at edges)\n   - Like a doughnut without a hole\n   - This shape increases surface area\n\n2. Size:\n   - About 7-8 micrometres in diameter\n   - Smallest cells in human body\n\n3. Nucleus:\n   - Absent in mature human RBCs\n   - Lost during maturation\n   - Provides more space for haemoglobin\n\n4. Haemoglobin:\n   - Red, iron-containing protein\n   - About 250 million molecules per RBC\n   - Gives blood its red colour\n   - Binds reversibly with oxygen\n\n5. Cell membrane:\n   - Flexible and elastic\n   - Allows shape change to pass through capillaries\n\n6. Cytoplasm:\n   - Contains haemoglobin\n   - No other organelles\n   - Cannot divide or synthesize proteins\n\n7. Number:\n   - 5-6 million per mm³ of blood\n   - About 25 trillion in adult body\n\nProduction and destruction:\n- Produced in bone marrow at 2 million per second\n- Need iron, vitamin B12, folic acid for formation\n- Life span: about 120 days\n- Destroyed in spleen and liver\n- Iron recycled, haem converted to bilirubin\n\nFunctions of RBCs:\n\n1. Oxygen transport:\n   - Haemoglobin binds oxygen in lungs\n   - Forms oxyhaemoglobin (bright red)\n   - Releases oxygen in tissues\n   - Each RBC carries about 1 billion oxygen molecules\n\n2. Carbon dioxide transport:\n   - Carries about 20-30% of CO₂\n   - CO₂ binds to haemoglobin (carbaminohaemoglobin)\n   - Rest CO₂ transported as bicarbonate in plasma\n\n3. Buffer function:\n   - Haemoglobin helps maintain blood pH\n   - Acts as buffer against acid-base changes\n\nAdaptations for function:\n- Biconcave shape = large surface area\n- No nucleus = more space for haemoglobin\n- Flexible = can pass through narrow capillaries\n- Rich in haemoglobin = efficient oxygen binding\n\nDiseases related to RBCs:\n- Anaemia: Low haemoglobin or RBC count\n- Polycythemia: Too many RBCs\n- Sickle cell anaemia: Abnormal shaped RBCs\n\nThus, RBCs are perfectly adapted for their oxygen-carrying function."
        },
        {
            "type": "subjective",
            "q": "Explain the structure and function of white blood cells.",
            "sample": "White blood cells (leucocytes) are the defence cells of the body, protecting against infections and foreign materials.\n\nGeneral characteristics:\n- Larger than RBCs (10-18 micrometres)\n- Colourless (no haemoglobin)\n- Have nucleus\n- Irregular shape (can change shape like Amoeba)\n- Fewer in number (4000-13000 per mm³)\n- Shorter life span (hours to days)\n- Produced in bone marrow and lymph nodes\n- Can move like Amoeba (ameboid movement)\n- Can squeeze through capillary walls (diapedesis)\n\nTypes of WBCs:\n\nA. Granulocytes (with granules in cytoplasm):\n\n1. Neutrophils (60-70%):\n   - Multi-lobed nucleus\n   - Phagocytic (engulf bacteria)\n   - First to arrive at infection site\n   - Form pus\n\n2. Eosinophils (2-4%):\n   - Bilobed nucleus\n   - Fight parasitic infections\n   - Involved in allergic reactions\n\n3. Basophils (0.5-1%):\n   - Lobed nucleus\n   - Release histamine (inflammation)\n   - Involved in allergic responses\n\nB. Agranulocytes (without granules):\n\n4. Lymphocytes (20-30%):\n   - Large, round nucleus\n   - Produce antibodies (B-lymphocytes)\n   - Attack infected cells (T-lymphocytes)\n   - Provide immunity\n   - Memory cells provide long-term protection\n\n5. Monocytes (3-8%):\n   - Largest WBCs\n   - Kidney-shaped nucleus\n   - Become macrophages in tissues\n   - Phagocytic (engulf large particles)\n   - Clean up dead cells and debris\n\nFunctions of WBCs:\n\n1. Phagocytosis:\n   - Neutrophils and monocytes engulf bacteria\n   - Digest them with enzymes\n   - Form pus (dead WBCs + bacteria)\n\n2. Antibody production:\n   - B-lymphocytes produce antibodies\n   - Antibodies neutralize pathogens\n   - Mark them for destruction\n\n3. Cell-mediated immunity:\n   - T-lymphocytes kill infected cells\n   - Attack virus-infected cells\n   - Destroy cancer cells\n\n4. Allergic reactions:\n   - Basophils and eosinophils involved\n   - Release histamine\n\n5. Inflammation:\n   - Release chemicals that cause inflammation\n   - Increases blood flow to infected area\n   - Attracts more WBCs\n\n6. Memory:\n   - Some lymphocytes become memory cells\n   - Provide faster response to repeat infection\n\nWBC count indicates health:\n- High count (leukocytosis): Infection, inflammation\n- Very high count (leukemia): Blood cancer\n- Low count (leukopenia): Immunodeficiency\n\nThus, WBCs are essential for body's defence and immunity."
        },
        {
            "type": "subjective",
            "q": "Explain the structure and function of blood platelets.",
            "sample": "Blood platelets (thrombocytes) are tiny, disc-shaped cell fragments essential for blood clotting.\n\nStructure of platelets:\n\n1. Size and shape:\n   - Smallest blood cells (2-4 micrometres)\n   - Disc-shaped or oval\n   - No nucleus\n   - Colourless\n\n2. Origin:\n   - Formed from megakaryocytes in bone marrow\n   - Megakaryocytes fragment into thousands of platelets\n   - Released into blood\n\n3. Number:\n   - 200,000 to 400,000 per mm³ of blood\n   - Count varies with health\n\n4. Life span:\n   - About 3-7 days\n   - Constantly replaced\n   - Old platelets destroyed in spleen\n\n5. Contents:\n   - Contain granules with clotting factors\n   - Contain contractile proteins\n   - Have surface receptors for adhesion\n\nFunctions of platelets:\n\n1. Blood clotting (haemostasis):\n   - Primary function\n   - Prevent blood loss from injured vessels\n\nSteps in blood clotting:\n\nA. Platelet plug formation:\n   - Platelets adhere to exposed collagen at injury site\n   - Change shape (become spiky with pseudopods)\n   - Release chemicals (ADP, thromboxane)\n   - Attract more platelets (platelet aggregation)\n   - Form temporary platelet plug\n\nB. Coagulation (clotting):\n   - Platelets release clotting factors\n   - Activate clotting cascade\n   - Prothrombin → Thrombin\n   - Thrombin converts fibrinogen → fibrin\n   - Fibrin forms mesh that traps RBCs\n   - Forms stable clot\n\nC. Clot retraction:\n   - Platelet contractile proteins pull clot\n   - Squeezes out serum\n   - Brings wound edges together\n\nD. Clot dissolution:\n   - When healing complete, clot broken down\n   - Plasmin dissolves fibrin\n\n2. Vasoconstriction:\n   - Release serotonin\n   - Causes blood vessels to constrict\n   - Reduces blood flow to injured area\n\n3. Repair:\n   - Release growth factors\n   - Promote healing of damaged vessels\n   - Stimulate tissue repair\n\n4. Protection:\n   - Prevent entry of pathogens through wounds\n   - Maintain blood vessel integrity\n\nDisorders related to platelets:\n\n1. Thrombocytopenia (low platelets):\n   - Causes easy bruising\n   - Prolonged bleeding\n   - Petechiae (tiny red spots)\n\n2. Thrombocytosis (high platelets):\n   - Risk of inappropriate clotting\n   - May cause thrombosis\n\n3. Platelet function disorders:\n   - Platelets present but not working\n   - Bleeding tendency\n\nImportance of normal platelet count:\n- Too few: Bleeding risk\n- Too many: Clotting risk\n- Normal range essential for health\n\nThus, platelets are crucial for preventing blood loss and maintaining circulatory integrity."
        },
        {
            "type": "subjective",
            "q": "Differentiate between red blood cells, white blood cells, and platelets.",
            "sample": "Comparison of the three types of blood cells:\n\n| Feature | Red Blood Cells (Erythrocytes) | White Blood Cells (Leucocytes) | Platelets (Thrombocytes) |\n|---------|-------------------------------|-------------------------------|-------------------------|\n| Other name | Erythrocytes | Leucocytes | Thrombocytes |\n| Number per mm³ | 5-6 million | 4000-13000 | 200,000-400,000 |\n| Size | 7-8 micrometres | 10-18 micrometres | 2-4 micrometres |\n| Shape | Biconcave disc | Irregular, changes shape | Disc-shaped |\n| Nucleus | Absent (in mature) | Present | Absent |\n| Colour | Red (haemoglobin) | Colourless | Colourless |\n| Haemoglobin | Present | Absent | Absent |\n| Life span | 120 days | 12 hours to 12 days | 3-7 days |\n| Production site | Bone marrow | Bone marrow, lymph nodes | Bone marrow |\n| Destruction site | Spleen, liver | Spleen, tissues | Spleen |\n| Movement | Flow with blood | Amoeboid movement, can leave vessels | Flow with blood |\n| Main function | Oxygen transport | Immunity, fight infection | Blood clotting |\n| Types | One type | Several types (neutrophils, lymphocytes, etc.) | One type |\n| Can divide | No | Some can | No (fragments of megakaryocytes) |\n| Granules | No | Yes (in granulocytes) | Yes (clotting factors) |\n| Response to infection | No change in count | Count increases | Count may change |\n| In pus | Not present | Present (dead neutrophils) | Sometimes present |\n| In clot formation | Trapped in clot | May be involved | Essential for clot |\n\nSimilarities:\n- All formed in bone marrow\n- All circulate in blood\n- All essential for life\n- All have limited life span\n- All affected by diseases\n\nRelative abundance:\n- RBCs most numerous (about 1000:1 compared to WBCs)\n- Platelets second most numerous\n- WBCs least numerous\n\nBlood volume proportions:\n- RBCs: about 40-45% of blood volume\n- WBCs and platelets: about 1% (buffy coat)\n- Plasma: 55-60%\n\nWhen each is important:\n- RBCs: For oxygen delivery to tissues\n- WBCs: During infection, inflammation\n- Platelets: After injury, to prevent bleeding\n\nDisorders specific to each:\n- RBCs: Anaemia, polycythemia\n- WBCs: Leukemia, leukopenia\n- Platelets: Thrombocytopenia, thrombocytosis\n\nThus, each cell type has unique features perfectly suited to its specific function."
        },
        {
            "type": "subjective",
            "q": "List the functions of blood in the human body.",
            "sample": "Blood performs numerous vital functions in the human body:\n\n1. Transportation of nutrients:\n   - Carries digested food from small intestine to all cells\n   - Transports glucose, amino acids, fatty acids, vitamins, minerals\n   - Delivers building materials for growth and repair\n\n2. Transportation of respiratory gases:\n   - Carries oxygen from lungs to all body cells (via haemoglobin in RBCs)\n   - Carries carbon dioxide from tissues back to lungs for elimination\n   - About 97% of oxygen transported by RBCs\n\n3. Transportation of waste products:\n   - Carries metabolic wastes (urea, uric acid, creatinine) to kidneys\n   - Wastes excreted in urine\n   - Prevents toxic accumulation\n\n4. Distribution of hormones:\n   - Carries hormones from endocrine glands to target organs\n   - Enables chemical coordination of body functions\n   - Examples: Insulin to cells, adrenaline in emergencies\n\n5. Protection of body:\n   - WBCs destroy pathogens (bacteria, viruses)\n   - Antibodies in plasma neutralize toxins\n   - Memory cells provide immunity\n   - Phagocytes engulf germs and debris\n\n6. Blood clotting:\n   - Platelets form plugs at injury sites\n   - Clotting factors in plasma form fibrin mesh\n   - Prevents excessive blood loss\n   - Allows wound healing\n\n7. Regulation of body temperature:\n   - Blood distributes heat throughout body\n   - Carries heat from active organs (muscles, liver) to skin\n   - Heat lost through skin surface\n   - Maintains constant 37°C body temperature\n\n8. Maintenance of salt and water balance:\n   - Plasma proteins maintain osmotic pressure\n   - Balances fluid between blood and tissues\n   - Prevents oedema (swelling)\n   - Helps kidneys regulate water and electrolytes\n\n9. Maintenance of pH balance:\n   - Blood buffers (bicarbonate, haemoglobin, proteins) maintain pH 7.35-7.45\n   - Prevents acidosis or alkalosis\n   - Essential for enzyme function\n\n10. Communication:\n    - Transports chemical signals\n    - Carries hormones, cytokines, inflammatory mediators\n    - Coordinates body's response to stress, infection\n\n11. Storage:\n    - Carries some substances in bound form\n    - Iron stored as ferritin (in liver)\n    - Some vitamins transported\n\n12. Defence against foreign materials:\n    - Phagocytosis of debris\n    - Removal of old/damaged cells\n    - Inflammatory response\n\n13. Circulation maintenance:\n    - Blood volume maintains blood pressure\n    - Ensures continuous flow to all organs\n    - Prevents shock\n\nThus, blood is truly the 'river of life', essential for nearly all bodily functions."
        },
        {
            "type": "subjective",
            "q": "Explain the ABO blood group system. What are the four blood groups?",
            "sample": "The ABO blood group system, discovered by Karl Landsteiner, classifies human blood based on antigens present on red blood cells and antibodies in plasma.\n\nBasic concepts:\n- Antigens: Proteins on RBC surface (type A or B)\n- Antibodies: Proteins in plasma that react with foreign antigens\n- If incompatible blood is mixed, antibodies cause clumping (agglutination)\n\nFour blood groups:\n\n1. Blood group A:\n   - Antigen on RBC: A antigen\n   - Antibody in plasma: Anti-B antibody\n   - Can receive blood from: A and O\n   - Can donate blood to: A and AB\n   - Frequency: About 40% (varies by population)\n\n2. Blood group B:\n   - Antigen on RBC: B antigen\n   - Antibody in plasma: Anti-A antibody\n   - Can receive blood from: B and O\n   - Can donate blood to: B and AB\n   - Frequency: About 10%\n\n3. Blood group AB:\n   - Antigen on RBC: Both A and B antigens\n   - Antibody in plasma: No antibodies\n   - Can receive blood from: A, B, AB, and O (universal recipient)\n   - Can donate blood to: AB only\n   - Frequency: About 4%\n\n4. Blood group O:\n   - Antigen on RBC: No A or B antigens\n   - Antibody in plasma: Both anti-A and anti-B antibodies\n   - Can receive blood from: O only\n   - Can donate blood to: A, B, AB, and O (universal donor)\n   - Frequency: About 46%\n\nBlood transfusion compatibility:\n\n| Blood group | Can receive from | Can donate to |\n|-------------|------------------|---------------|\n| A | A, O | A, AB |\n| B | B, O | B, AB |\n| AB | A, B, AB, O (universal recipient) | AB |\n| O | O only | A, B, AB, O (universal donor) |\n\nWhy O is universal donor:\n- No A or B antigens on RBCs\n- Donor RBCs won't react with recipient's antibodies\n- But antibodies in donor plasma may cause minor reaction (washed RBCs used)\n\nWhy AB is universal recipient:\n- No anti-A or anti-B antibodies in plasma\n- Can receive any RBC type without reaction\n- But can only donate to AB\n\nAgglutination reaction:\n- If wrong blood type given:\n  * Recipient's antibodies attack donor RBCs\n  * RBCs clump together (agglutination)\n  * Clumps block blood vessels\n  * Haemoglobin released (haemolysis)\n  * Can cause kidney failure, shock, death\n\nImportance of blood typing:\n- Essential before transfusion\n- Prevents fatal reactions\n- Used in organ transplantation\n- Important in pregnancy (Rh factor)\n- Forensic medicine (blood at crime scenes)\n\nThus, ABO system ensures safe blood transfusion when properly matched."
        },
        {
            "type": "subjective",
            "q": "What is Rh-factor? Explain its importance in blood transfusion and pregnancy.",
            "sample": "Rh-factor (Rhesus factor) is an antigen present on the surface of red blood cells, first discovered in Rhesus monkeys.\n\nRh status:\n- Rh-positive: Have Rh antigen on RBCs (about 85% of people)\n- Rh-negative: Do not have Rh antigen (about 15%)\n- No natural antibodies against Rh in plasma (unlike ABO system)\n\nInheritance:\n- Rh-positive is dominant (Rh+ gene from either parent)\n- Rh-negative is recessive (needs two Rh- genes)\n- Child's Rh status depends on parents\n\nImportance in blood transfusion:\n\n1. First exposure:\n   - If Rh-negative person receives Rh-positive blood\n   - No immediate reaction (no pre-existing antibodies)\n   - But person becomes sensitized\n   - Develops anti-Rh antibodies\n\n2. Subsequent exposure:\n   - If same person receives Rh-positive blood again\n   - Anti-Rh antibodies attack donor RBCs\n   - Causes transfusion reaction\n   - Can be severe\n\n3. Compatibility:\n   - Rh-negative should receive Rh-negative blood\n   - Rh-positive can receive Rh-positive or Rh-negative\n   - But Rh-negative blood preferred for Rh-negative\n\nImportance in pregnancy:\n\n1. Rh incompatibility:\n   - Occurs when Rh-negative mother carries Rh-positive baby\n   - Father is Rh-positive\n   - Baby inherits Rh-positive from father\n\n2. Sensitization:\n   - During delivery, some baby's blood enters mother's circulation\n   - Mother's immune system develops anti-Rh antibodies\n   - Usually not a problem in first pregnancy\n\n3. Effect on subsequent pregnancies:\n   - In next pregnancy with Rh-positive baby\n   - Mother's anti-Rh antibodies cross placenta\n   - Attack baby's RBCs\n   - Causes haemolytic disease of newborn (HDN)\n   - Baby becomes anaemic, jaundiced\n   - Severe cases: brain damage, stillbirth\n\n4. Prevention:\n   - Anti-D immunoglobulin (RhoGAM) given to Rh-negative mother\n   - Given at 28 weeks pregnancy\n   - Given within 72 hours after delivery\n   - Also after miscarriage, abortion, amniocentesis\n   - Prevents mother from developing antibodies\n   - Protects future pregnancies\n\n5. Treatment of affected baby:\n   - Phototherapy for jaundice\n   - Exchange transfusion in severe cases\n   - Intrauterine transfusion for severe anaemia\n\nTesting for Rh-factor:\n- Simple blood test\n- Done routinely in pregnancy\n- Done before blood transfusion\n- Part of routine blood typing\n\nSummary table:\n\n| Situation | Compatibility |\n|-----------|---------------|\n| Blood transfusion | Rh-negative → Rh-negative preferred |\n| | Rh-positive → Rh-positive or Rh-negative |\n| Pregnancy (first) | Usually safe regardless |\n| Pregnancy (later with incompatibility) | Risk of HDN if mother sensitized |\n| Prevention | Anti-D immunoglobulin |\n\nThus, Rh-factor is crucial for safe transfusion and healthy pregnancies."
        },
        {
            "type": "subjective",
            "q": "Differentiate between arteries and veins.",
            "sample": "Arteries and veins are the two main types of blood vessels with distinct structures and functions.\n\n| Characteristic | Arteries | Veins |\n|----------------|----------|-------|\n| Direction of blood flow | Carry blood away from heart | Carry blood towards heart |\n| Blood type | Usually oxygenated (except pulmonary artery) | Usually deoxygenated (except pulmonary veins) |\n| Wall thickness | Thick, elastic, muscular | Thin, less muscular |\n| Lumen (cavity) | Narrow | Wide |\n| Valves | Absent | Present (to prevent backflow) |\n| Blood pressure | High, pulsatile | Low, steady |\n| Blood flow | Fast, with jerks | Slow, smooth |\n| Position in body | Deep-seated (for protection) | Superficial (closer to skin) |\n| Cross-section shape | Round (maintains shape) | Flatten when empty |\n| Ability to stretch | Highly elastic (withstand pressure) | Less elastic |\n| Pulse | Palpable | Not palpable |\n| Colour in diagrams | Usually red (oxygenated) | Usually blue (deoxygenated) |\n| Oxygen content | High (except pulmonary) | Low (except pulmonary) |\n| Carbon dioxide content | Low (except pulmonary) | High (except pulmonary) |\n| Major examples | Aorta, pulmonary artery | Vena cava, pulmonary veins |\n| Branching | Divide into smaller arteries (arterioles) | Formed from smaller veins (venules) |\n| Effect of gravity | Less affected | Affected (need valves in legs) |\n| Nutrient supply | Have their own vessels (vasa vasorum) in outer layer | Have vasa vasorum |\n| Tissue layers | Three layers: tunica intima, media, adventitia | Same three but thinner media |\n| Smooth muscle | Prominent in media | Sparse in media |\n| Elastic tissue | Abundant | Sparse |\n\nSimilarities:\n- Both are blood vessels\n- Both have three-layered walls\n- Both lined with endothelium\n- Both transport blood\n- Both can be affected by diseases\n\nExceptions to remember:\n- Pulmonary artery carries deoxygenated blood (only artery with impure blood)\n- Pulmonary veins carry oxygenated blood (only veins with pure blood)\n- Umbilical vessels in fetus have different patterns\n\nWhy arteries have thick walls:\n- Must withstand high pressure from heart pump\n- Need elasticity to expand with each heartbeat\n- Prevent bursting under pressure\n\nWhy veins have valves:\n- Low pressure cannot push blood upward against gravity\n- Valves prevent backflow in legs\n- Muscular contraction helps push blood\n\nClinical significance:\n- Arterial disease: Atherosclerosis (plaque buildup)\n- Arterial pulse: Used to measure heart rate\n- Venous disease: Varicose veins (valve failure)\n- Veins used for blood draw (superficial, lower pressure)\n\nThus, structure of each vessel type perfectly suits its function."
        },
        {
            "type": "subjective",
            "q": "Describe the structure and function of capillaries.",
            "sample": "Capillaries are the smallest and most numerous blood vessels that connect arteries to veins, forming networks throughout tissues.\n\nStructure of capillaries:\n\n1. Size:\n   - Extremely narrow (5-10 micrometres diameter)\n   - Just wide enough for RBCs to pass single file\n   - Length: about 0.5-1 mm each\n   - Total length in body: about 100,000 km!\n\n2. Wall thickness:\n   - Extremely thin (one cell thick)\n   - Single layer of endothelial cells\n   - No muscle or elastic tissue\n   - About 0.5 micrometres thick\n\n3. Basement membrane:\n   - Thin layer surrounding endothelium\n   - Provides support\n\n4. Pericytes:\n   - Cells wrapped around capillaries\n   - Help regulate blood flow\n   - Aid in repair\n\n5. Types of capillaries:\n   - Continuous: Most common, continuous lining\n   - Fenestrated: Have pores (in kidneys, intestines)\n   - Sinusoidal: Larger gaps (in liver, spleen)\n\n6. Network:\n   - Form capillary beds between arterioles and venules\n   - Dense networks in active tissues\n   - Precapillary sphincters control flow\n\nFunctions of capillaries:\n\n1. Exchange of materials (main function):\n   - Site of all exchange between blood and tissues\n   - Thin walls allow diffusion\n   - Slow blood flow allows time for exchange\n\n2. Oxygen delivery:\n   - Oxygen diffuses from RBCs to tissue cells\n   - Driven by concentration gradient\n   - Tissues have low O₂, blood has high O₂\n\n3. Carbon dioxide removal:\n   - CO₂ diffuses from tissues into blood\n   - Carried away to lungs\n\n4. Nutrient delivery:\n   - Glucose, amino acids diffuse to cells\n   - Small enough to pass through\n\n5. Waste pickup:\n   - Metabolic wastes (urea) enter blood\n   - Taken to kidneys\n\n6. Fluid exchange:\n   - Fluid filters out at arterial end (due to pressure)\n   - Fluid reabsorbed at venous end (due to osmotic pressure)\n   - Lymphatic system collects excess\n\n7. Hormone delivery:\n   - Hormones reach target cells via capillaries\n   - Diffuse out to bind receptors\n\n8. Temperature regulation:\n   - Blood flow through skin capillaries regulates heat loss\n   - Vasodilation (widen) = more heat loss\n   - Vasoconstriction (narrow) = conserve heat\n\n9. Immune surveillance:\n   - WBCs can leave through capillary walls (diapedesis)\n   - Reach sites of infection\n\nAdaptations for exchange:\n\n1. Large surface area:\n   - Billions of capillaries\n   - Total surface area about 600-1000 m²\n\n2. Slow blood flow:\n   - Blood slows down in capillaries\n   - More time for exchange\n\n3. Short diffusion distance:\n   - Wall one cell thick\n   - Cells close to capillaries\n\n4. Large number:\n   - Every cell near a capillary\n   - No cell more than 0.1 mm from capillary\n\nRegulation of capillary flow:\n- Precapillary sphincters open/close\n- Local factors (O₂, CO₂, pH) control flow\n- Active tissues get more blood\n\nThus, capillaries are the functional units of the circulatory system, where the real work of nutrient and gas exchange occurs."
        },
        {
            "type": "subjective",
            "q": "Explain the pulmonary circulation and systemic circulation.",
            "sample": "Blood circulates twice through the heart in one complete circuit - this is called double circulation, consisting of pulmonary and systemic circulation.\n\nPulmonary circulation (Heart → Lungs → Heart):\n\nDefinition: Circulation of blood between heart and lungs for oxygenation.\n\nPathway:\n1. Deoxygenated (impure) blood from body enters right atrium\n2. Right atrium → Right ventricle (through tricuspid valve)\n3. Right ventricle pumps blood to lungs through pulmonary artery\n4. Pulmonary artery divides into left and right branches to each lung\n5. In lung capillaries:\n   - CO₂ released from blood\n   - O₂ absorbed into blood\n   - Blood becomes oxygenated (pure)\n6. Oxygenated blood returns to heart through pulmonary veins\n7. Pulmonary veins enter left atrium\n\nFeatures:\n- Short circuit (only through lungs)\n- Low pressure (right ventricle thinner)\n- Only place where artery carries deoxygenated blood (pulmonary artery)\n- Only place where vein carries oxygenated blood (pulmonary veins)\n\nSystemic circulation (Heart → Body → Heart):\n\nDefinition: Circulation of blood between heart and all body tissues except lungs.\n\nPathway:\n1. Oxygenated blood from lungs enters left atrium\n2. Left atrium → Left ventricle (through bicuspid/mitral valve)\n3. Left ventricle pumps blood to body through aorta\n4. Aorta branches into arteries to all body parts\n5. Arteries → Arterioles → Capillaries in tissues:\n   - O₂ and nutrients delivered to cells\n   - CO₂ and wastes picked up\n   - Blood becomes deoxygenated (impure)\n6. Capillaries → Venules → Veins\n7. Veins collect into superior and inferior vena cava\n8. Venae cavae return blood to right atrium\n\nFeatures:\n- Long circuit (entire body)\n- High pressure (left ventricle thick-walled)\n- Supplies all organs and tissues\n\nComparison:\n\n| Feature | Pulmonary Circulation | Systemic Circulation |\n|---------|----------------------|---------------------|\n| Path | Heart → Lungs → Heart | Heart → Body → Heart |\n| Vessels involved | Pulmonary artery, pulmonary veins | Aorta, arteries, veins, vena cava |\n| Blood type in arteries | Deoxygenated | Oxygenated |\n| Blood type in veins | Oxygenated | Deoxygenated |\n| Pressure | Low (20-30 mmHg) | High (120/80 mmHg) |\n| Ventricle involved | Right ventricle | Left ventricle |\n| Ventricle wall | Thinner | Thicker |\n| Purpose | Gas exchange in lungs | Supply all tissues |\n| Distance | Short | Long |\n| Oxygenation | Blood becomes oxygenated | Blood becomes deoxygenated |\n| CO₂ removal | Yes, in lungs | No (picked up from tissues) |\n\nDouble circulation advantage:\n- Complete separation of oxygenated and deoxygenated blood\n- Higher pressure for systemic circulation\n- Efficient oxygen delivery\n- Maintains high metabolic rate\n\n[Students should draw a schematic diagram showing both circuits with heart, lungs, and body]"
        },
        {
            "type": "subjective",
            "q": "Describe the structure of the human heart with a labeled diagram.",
            "sample": "The heart is a pear-shaped muscular organ that pumps blood throughout the body.\n\nLocation and size:\n- Located in chest cavity, slightly towards left\n- Protected by rib cage\n- Size of a clenched fist (about 12 cm long, 9 cm wide)\n- Weighs about 250-350 grams\n\nExternal structure:\n\n1. Pericardium:\n   - Double-layered membrane enclosing heart\n   - Space between layers filled with pericardial fluid\n   - Fluid reduces friction during heartbeats\n\n2. Heart wall:\n   - Made of cardiac muscle (myocardium)\n   - Works tirelessly without fatigue\n   - Thickest in left ventricle\n\n3. Chambers (4):\n   - Two upper: Atria (auricles) - thin-walled\n   - Two lower: Ventricles - thick-walled\n\n4. Major blood vessels:\n   - Superior vena cava (brings blood from upper body)\n   - Inferior vena cava (brings blood from lower body)\n   - Pulmonary artery (takes blood to lungs)\n   - Pulmonary veins (bring blood from lungs)\n   - Aorta (takes blood to body)\n\nInternal structure:\n\n1. Right atrium:\n   - Receives deoxygenated blood from body via venae cavae\n   - Thin-walled\n   - Pumps blood to right ventricle\n\n2. Right ventricle:\n   - Receives blood from right atrium\n   - Pumps deoxygenated blood to lungs via pulmonary artery\n   - Wall thicker than atria, thinner than left ventricle\n\n3. Left atrium:\n   - Receives oxygenated blood from lungs via pulmonary veins\n   - Thin-walled\n   - Pumps blood to left ventricle\n\n4. Left ventricle:\n   - Receives blood from left atrium\n   - Thickest chamber (pumps to entire body)\n   - Pumps oxygenated blood to body via aorta\n\n5. Septum:\n   - Thick muscular wall dividing heart into left and right\n   - Prevents mixing of oxygenated and deoxygenated blood\n\nValves of the heart:\n\n6. Tricuspid valve:\n   - Between right atrium and right ventricle\n   - Three flaps (cusps)\n   - Prevents backflow into atrium\n\n7. Bicuspid (mitral) valve:\n   - Between left atrium and left ventricle\n   - Two flaps\n   - Prevents backflow into atrium\n\n8. Pulmonary semilunar valve:\n   - At exit of right ventricle into pulmonary artery\n   - Three half-moon shaped cusps\n   - Prevents backflow into ventricle\n\n9. Aortic semilunar valve:\n   - At exit of left ventricle into aorta\n   - Three cusps\n   - Prevents backflow into ventricle\n\nChordae tendineae:\n- Tendinous cords attaching valves to papillary muscles\n- Prevent valve inversion during ventricular contraction\n\nBlood flow through heart:\nBody → Venae cavae → Right atrium → Tricuspid valve → Right ventricle → Pulmonary valve → Pulmonary artery → Lungs → Pulmonary veins → Left atrium → Bicuspid valve → Left ventricle → Aortic valve → Aorta → Body\n\n[Students should draw a labeled diagram showing all chambers, valves, and major vessels]"
        },
        {
            "type": "subjective",
            "q": "Explain the flow of blood through the heart.",
            "sample": "Blood flows through the heart in a specific sequence, ensured by valves that prevent backflow.\n\nStep-by-step flow of blood:\n\nA. Deoxygenated blood returns to heart:\n\n1. Deoxygenated (impure) blood from all body parts collects into:\n   - Superior vena cava (from head, neck, arms, upper body)\n   - Inferior vena cava (from trunk, legs, lower body)\n\n2. Both venae cavae empty into right atrium\n   - Right atrium fills with deoxygenated blood\n\nB. Blood moves to right ventricle:\n\n3. Right atrium contracts (atrial systole)\n   - Tricuspid valve opens\n   - Blood flows into right ventricle\n\n4. Right ventricle fills\n   - Tricuspid valve closes after filling (prevents backflow)\n\nC. Blood pumped to lungs:\n\n5. Right ventricle contracts (ventricular systole)\n   - Pulmonary semilunar valve opens\n   - Blood pumped into pulmonary artery\n   - Pulmonary artery carries blood to lungs\n\n6. In lungs:\n   - Blood passes through lung capillaries\n   - CO₂ released, O₂ absorbed\n   - Blood becomes oxygenated (pure)\n\nD. Oxygenated blood returns to heart:\n\n7. Oxygenated blood returns via pulmonary veins\n   - Four pulmonary veins (two from each lung)\n   - Empty into left atrium\n\nE. Blood moves to left ventricle:\n\n8. Left atrium contracts\n   - Bicuspid (mitral) valve opens\n   - Blood flows into left ventricle\n\n9. Left ventricle fills\n   - Bicuspid valve closes after filling\n\nF. Blood pumped to body:\n\n10. Left ventricle contracts (powerful contraction)\n    - Aortic semilunar valve opens\n    - Blood pumped into aorta\n    - Aorta distributes blood to all body parts\n\n11. In body tissues:\n    - Oxygen and nutrients delivered\n    - CO₂ and wastes picked up\n    - Blood becomes deoxygenated again\n    - Cycle repeats\n\nSummary flow chart:\n\nBody → Venae cavae → Right atrium → Tricuspid valve → Right ventricle → Pulmonary valve → Pulmonary artery → Lungs (oxygenation) → Pulmonary veins → Left atrium → Bicuspid valve → Left ventricle → Aortic valve → Aorta → Body\n\nValve functions:\n- Tricuspid: Prevents backflow from right ventricle to right atrium\n- Bicuspid: Prevents backflow from left ventricle to left atrium\n- Pulmonary: Prevents backflow from pulmonary artery to right ventricle\n- Aortic: Prevents backflow from aorta to left ventricle\n\nTiming of events:\n- Atrial contraction: Both atria contract together\n- Ventricular contraction: Both ventricles contract together\n- Valves open/close based on pressure differences\n\nKey points:\n- Right side handles deoxygenated blood\n- Left side handles oxygenated blood\n- Septum prevents mixing\n- Valves ensure one-way flow\n- Left ventricle works hardest (pumps to entire body)\n\nThus, the heart's structure ensures efficient, one-way circulation of blood."
        },
        {
            "type": "subjective",
            "q": "What are heart valves? Name them and explain their functions.",
            "sample": "Heart valves are flap-like structures that ensure one-way flow of blood through the heart, preventing backflow.\n\nTypes of heart valves:\n\nA. Atrioventricular valves (between atria and ventricles):\n\n1. Tricuspid valve:\n   - Location: Between right atrium and right ventricle\n   - Structure: Three flaps or cusps\n   - Attached to papillary muscles by chordae tendineae\n   - Function: Prevents backflow of blood from right ventricle to right atrium during ventricular contraction\n\n2. Bicuspid (Mitral) valve:\n   - Location: Between left atrium and left ventricle\n   - Structure: Two flaps\n   - Also attached to chordae tendineae\n   - Function: Prevents backflow from left ventricle to left atrium\n   - Named 'mitral' because it resembles bishop's mitre (hat)\n\nB. Semilunar valves (at exits of ventricles):\n\n3. Pulmonary valve:\n   - Location: At exit of right ventricle into pulmonary artery\n   - Structure: Three half-moon shaped cusps\n   - No chordae tendineae\n   - Function: Prevents backflow of blood from pulmonary artery into right ventricle during ventricular relaxation\n\n4. Aortic valve:\n   - Location: At exit of left ventricle into aorta\n   - Structure: Three cusps (semilunar)\n   - Function: Prevents backflow from aorta into left ventricle\n\nSupporting structures:\n\nChordae tendineae:\n- Fibrous cords attached to valve flaps\n- Connect to papillary muscles in ventricles\n- Prevent valves from inverting into atria during ventricular contraction\n\nPapillary muscles:\n- Projections from ventricular wall\n- Contract during ventricular systole\n- Pull chordae tendineae to keep valves closed\n\nHow valves work:\n\nDuring atrial contraction (atrial systole):\n- Atrioventricular valves open\n- Blood flows from atria to ventricles\n- Semilunar valves closed (ventricles not contracting)\n\nDuring ventricular contraction (ventricular systole):\n- Pressure in ventricles rises\n- Atrioventricular valves close (prevent backflow to atria)\n- Chordae tendineae prevent valve inversion\n- Semilunar valves open\n- Blood ejected into arteries\n\nDuring ventricular relaxation (diastole):\n- Pressure in ventricles drops\n- Semilunar valves close (prevent backflow from arteries)\n- Atrioventricular valves open\n- Ventricles fill again\n\nHeart sounds:\n- 'Lub' sound: Closure of atrioventricular valves\n- 'Dub' sound: Closure of semilunar valves\n- Heard with stethoscope\n\nValve disorders:\n\n1. Stenosis:\n   - Valve opening narrowed\n   - Heart works harder to pump blood\n   - May need surgery\n\n2. Regurgitation/Incompetence:\n   - Valve doesn't close properly\n   - Blood leaks backward\n   - Causes heart murmur\n\n3. Prolapse:\n   - Valve flaps bulge backward\n   - May cause leakage\n\nTreatment:\n- Medications\n- Valve repair\n- Valve replacement (mechanical or tissue valves)\n\nThus, valves are essential for efficient, one-way circulation of blood through the heart."
        },
        {
            "type": "subjective",
            "q": "What is heartbeat? Explain the cardiac cycle.",
            "sample": "Heartbeat is the rhythmic contraction and relaxation of the heart muscles that pumps blood through the circulatory system.\n\nHeartbeat:\n- About 72 times per minute in resting adult\n- Faster in children, during exercise, emotion\n- Slower in athletes, during sleep\n- Each heartbeat = one cardiac cycle\n\nCardiac cycle:\nThe sequence of events in one complete heartbeat, lasting about 0.8 seconds.\n\nPhases of cardiac cycle:\n\n1. Atrial systole (0.1 seconds):\n   - Both atria contract simultaneously\n   - Blood forced into ventricles through open AV valves\n   - Ventricles already 70% filled from passive flow\n   - Atrial contraction adds final 30%\n   - AV valves open, semilunar valves closed\n\n2. Ventricular systole (0.3 seconds):\n   - Both ventricles contract\n   - Pressure in ventricles rises\n   - AV valves snap shut (prevents backflow to atria)\n   - Isovolumetric contraction (all valves closed, pressure rises)\n   - When ventricular pressure exceeds arterial pressure:\n     * Semilunar valves open\n     * Blood ejected into aorta and pulmonary artery\n   - Atria relax and start filling again\n\n3. Complete cardiac diastole (0.4 seconds):\n   - Both atria and ventricles relaxed\n   - Ventricular pressure drops below atrial\n   - Semilunar valves close (prevents backflow from arteries)\n   - AV valves open\n   - Ventricles fill passively from atria (70% filling)\n   - Cycle ready to repeat\n\nSummary of cardiac cycle:\n\n| Phase | Duration | Atria | Ventricles | AV valves | Semilunar valves | Blood flow |\n|-------|----------|-------|------------|-----------|------------------|------------|\n| Atrial systole | 0.1 sec | Contract | Relaxed | Open | Closed | Atria → Ventricles |\n| Ventricular systole | 0.3 sec | Relaxed | Contract | Closed | Open | Ventricles → Arteries |\n| Diastole | 0.4 sec | Relaxed | Relaxed | Open | Closed | Veins → Atria → Ventricles |\n\nTotal cycle: 0.1 + 0.3 + 0.4 = 0.8 seconds\n\nHeart sounds:\n\nFirst sound 'LUB':\n- Caused by closure of AV valves (tricuspid and bicuspid)\n- Occurs at beginning of ventricular systole\n- Longer, louder sound\n\nSecond sound 'DUB':\n- Caused by closure of semilunar valves (aortic and pulmonary)\n- Occurs at beginning of ventricular diastole\n- Shorter, sharper sound\n\nPressure changes:\n- Left ventricle: 120 mmHg (systole), 0-10 mmHg (diastole)\n- Aorta: 120/80 mmHg\n- Right ventricle: 25 mmHg (systole)\n- Pulmonary artery: 25/10 mmHg\n\nElectrical events:\n- SA node (pacemaker) initiates impulse\n- Spreads through atria → atrial contraction\n- AV node delays impulse\n- Conducts to ventricles via bundle of His\n- Ventricles contract from apex upward\n\nRegulation of heart rate:\n- Autonomic nervous system\n  * Sympathetic: Increases rate\n  * Parasympathetic: Decreases rate\n- Hormones (adrenaline)\n- Body temperature\n- Ions (Ca²⁺, K⁺)\n\nThus, the cardiac cycle ensures efficient, coordinated pumping of blood."
        },
        {
            "type": "subjective",
            "q": "What is pulse? How do you measure it?",
            "sample": "Pulse is the rhythmic expansion and contraction of an artery caused by the wave of pressure from each heartbeat.\n\nWhat causes pulse:\n- When left ventricle contracts (systole)\n- Blood forced into aorta under high pressure\n- Pressure wave travels along arteries\n- Arteries expand with each wave\n- Expansion felt as pulse\n- Between beats, arteries recoil\n\nCharacteristics of normal pulse:\n- Rate: 70-75 per minute in resting adult\n- Rhythm: Regular\n- Volume: Adequate\n- Character: Strong\n\nPulse rate varies with:\n- Age: Infants 100-160, children 70-120, adults 70-75\n- Gender: Slightly faster in females\n- Exercise: Increases\n- Emotions: Increases (fear, excitement)\n- Fever: Increases\n- Sleep: Decreases\n- Fitness: Athletes have slower resting pulse\n\nWhere to feel pulse:\n\nCommon sites (superficial arteries):\n\n1. Radial pulse (most common):\n   - At wrist, just below thumb\n   - Radial artery\n   - Easy to access\n\n2. Carotid pulse:\n   - At side of neck\n   - Carotid artery\n   - Strong pulse, used in emergencies\n\n3. Brachial pulse:\n   - Inner side of elbow\n   - Used for blood pressure measurement\n\n4. Temporal pulse:\n   - At temple, in front of ear\n\n5. Femoral pulse:\n   - In groin area\n\n6. Popliteal pulse:\n   - Behind knee\n\n7. Dorsalis pedis pulse:\n   - On top of foot\n\nHow to measure pulse:\n\nMaterials needed:\n- Stopwatch or clock with second hand\n- Your fingers (index and middle)\n\nProcedure:\n\n1. Find a quiet place, person should be relaxed\n\n2. Locate pulse site (radial is easiest):\n   - Turn hand palm up\n   - Place index and middle fingers on wrist below thumb\n   - Press gently until you feel pulse\n   - Do not use thumb (has its own pulse)\n\n3. Count beats:\n   - Count for 30 seconds\n   - Multiply by 2 for beats per minute\n   - Or count for full minute for accuracy\n\n4. Note regularity:\n   - Regular rhythm is normal\n   - Irregular rhythm may indicate problem\n\n5. Record:\n   - Rate: ___ beats per minute\n   - Rhythm: Regular/Irregular\n   - Character: Strong/Weak\n\n6. Repeat after exercise:\n   - Have person exercise (jog in place)\n   - Measure again immediately\n   - Note increase\n\nNormal pulse rates:\n\n| Age | Normal range (beats/min) |\n|-----|--------------------------|\n| Newborn | 100-160 |\n| 1-12 months | 80-140 |\n| 1-3 years | 80-130 |\n| 3-5 years | 80-120 |\n| 6-10 years | 70-110 |\n| 11-14 years | 60-105 |\n| Adults | 60-100 (typically 70-75) |\n| Athletes | 40-60 |\n\nAbnormal pulse:\n\nTachycardia: Rate > 100/min (resting)\n- Causes: Exercise, fever, anxiety, dehydration, heart conditions\n\nBradycardia: Rate < 60/min (resting)\n- Causes: Athletic training, hypothyroidism, heart block\n\nArrhythmia: Irregular rhythm\n- May indicate heart condition\n\nPulse deficit:\n- Difference between apical (heart) and peripheral pulse\n- May indicate inefficient heart contractions\n\nThus, pulse is a simple but important indicator of heart function and overall health."
        },
        {
            "type": "subjective",
            "q": "What is blood pressure? Explain systolic and diastolic pressure.",
            "sample": "Blood pressure is the force exerted by blood against the walls of arteries as the heart pumps it through the circulatory system.\n\nDefinition:\nBlood pressure = Cardiac output × Peripheral resistance\n\nMeasurement:\n- Measured in millimetres of mercury (mmHg)\n- Measured with sphygmomanometer\n- Two numbers recorded: Systolic/Diastolic\n- Normal adult: 120/80 mmHg\n\nSystolic pressure (upper number):\n\nDefinition:\n- Pressure in arteries when ventricles contract (systole)\n- Maximum pressure during cardiac cycle\n\nWhat happens:\n- Left ventricle contracts\n- Blood ejected into aorta\n- Arterial walls stretch to accommodate blood\n- Pressure peaks\n\nNormal range:\n- 100-140 mmHg (ideally around 120)\n- Varies with age, activity\n\nFactors affecting systolic pressure:\n- Force of ventricular contraction\n- Volume of blood ejected (stroke volume)\n- Elasticity of aorta\n- Age (increases with age as arteries stiffen)\n\nDiastolic pressure (lower number):\n\nDefinition:\n- Pressure in arteries when ventricles relax (diastole)\n- Minimum pressure during cardiac cycle\n- Maintained by elastic recoil of arteries\n\nWhat happens:\n- Ventricles relax\n- No blood pumped out\n- Arteries recoil, maintaining pressure\n- Blood continues to flow to tissues\n\nNormal range:\n- 60-90 mmHg (ideally around 80)\n- More stable than systolic\n\nFactors affecting diastolic pressure:\n- Peripheral resistance (arteriole diameter)\n- Elasticity of arteries\n- Blood volume\n- Heart rate (filling time)\n\nPulse pressure:\n- Difference between systolic and diastolic\n- Normal: 40 mmHg (120-80 = 40)\n- Indicates stroke volume and arterial compliance\n\nMean arterial pressure (MAP):\n- Average pressure driving blood to tissues\n- MAP = Diastolic + 1/3 (Systolic - Diastolic)\n- Normal: about 93 mmHg\n- Must be >60 for organ perfusion\n\nBlood pressure categories (adults):\n\n| Category | Systolic (mmHg) | Diastolic (mmHg) |\n|----------|-----------------|------------------|\n| Normal | <120 | <80 |\n| Elevated | 120-129 | <80 |\n| Hypertension Stage 1 | 130-139 | 80-89 |\n| Hypertension Stage 2 | ≥140 | ≥90 |\n| Hypertensive crisis | >180 | >120 |\n| Hypotension | <90 | <60 |\n\nFactors affecting blood pressure:\n\n1. Cardiac output:\n   - Increased heart rate = increased BP\n   - Increased stroke volume = increased BP\n\n2. Peripheral resistance:\n   - Vasoconstriction = increased BP\n   - Vasodilation = decreased BP\n\n3. Blood volume:\n   - Increased volume = increased BP\n   - Dehydration = decreased BP\n\n4. Blood viscosity:\n   - Thicker blood = higher BP\n\n5. Elasticity of arteries:\n   - Stiff arteries = higher BP (especially systolic)\n\n6. Age:\n   - BP tends to increase with age\n\n7. Emotions:\n   - Stress, anxiety increase BP\n\n8. Activity:\n   - Exercise increases BP temporarily\n\n9. Body position:\n   - Standing vs lying affects BP\n\n10. Time of day:\n    - Lowest during sleep, peaks in morning\n\nMeasurement technique:\n- Patient seated, arm at heart level\n- Cuff placed around arm\n- Inflate until artery compressed\n- Release slowly, listen with stethoscope\n- First sound heard = systolic\n- Last sound heard = diastolic\n\nThus, blood pressure is a vital sign indicating cardiovascular health."
        },
        {
            "type": "subjective",
            "q": "How can we keep our heart healthy? Suggest lifestyle and dietary measures.",
            "sample": "Keeping the heart healthy requires a combination of regular exercise, healthy diet, and good lifestyle habits.\n\nRegular physical activity:\n\n1. Aerobic exercise:\n   - Brisk walking (30 minutes daily)\n   - Jogging, running\n   - Swimming\n   - Cycling\n   - Dancing\n   - Benefits: Strengthens heart, lowers BP, improves cholesterol\n\n2. Strength training:\n   - Moderate weight training\n   - Builds muscle, improves metabolism\n   - 2-3 times per week\n\n3. Flexibility exercises:\n   - Stretching\n   - Yoga\n   - Improves circulation, reduces stress\n\n4. Daily activity:\n   - Take stairs instead of elevator\n   - Walk short distances instead of driving\n   - Garden, play with children\n   - Stand instead of sitting\n\nHealthy diet:\n\n5. Eat more fruits and vegetables:\n   - At least 5 servings daily\n   - Rich in vitamins, minerals, antioxidants\n   - Low in calories, high in fiber\n\n6. Choose whole grains:\n   - Whole wheat bread, brown rice\n   - Oats, quinoa, barley\n   - High fiber, lower cholesterol\n\n7. Include lean proteins:\n   - Fish (especially fatty fish like salmon)\n   - Skinless poultry\n   - Legumes, beans, lentils\n   - Nuts and seeds\n\n8. Healthy fats:\n   - Use olive oil, canola oil\n   - Avocados\n   - Nuts and seeds\n   - Limit saturated fats (red meat, butter)\n   - Avoid trans fats (fried foods, processed snacks)\n\n9. Limit salt intake:\n   - <5-6 grams per day\n   - Avoid processed foods\n   - Don't add salt at table\n   - Use herbs and spices for flavour\n\n10. Limit sugar:\n    - Reduce sugary drinks\n    - Limit sweets, desserts\n    - Choose water over soda\n\n11. Maintain healthy weight:\n    - BMI between 18.5-24.9\n    - Waist circumference: <90 cm (men), <80 cm (women)\n    - Prevents diabetes, hypertension\n\nLifestyle habits:\n\n12. No smoking:\n    - Smoking damages arteries\n    - Increases heart attack risk\n    - Quitting reduces risk rapidly\n\n13. Limit alcohol:\n    - Moderate: 1 drink/day (women), 2 drinks/day (men)\n    - Excessive alcohol damages heart\n\n14. Manage stress:\n    - Practice relaxation techniques\n    - Deep breathing, meditation\n    - Adequate sleep (7-8 hours)\n    - Hobbies, social connections\n\n15. Regular health checkups:\n    - Check blood pressure\n    - Check cholesterol levels\n    - Check blood sugar\n    - Detect problems early\n\n16. Know your numbers:\n    - Blood pressure: <120/80\n    - Total cholesterol: <200 mg/dL\n    - LDL (bad) cholesterol: <100 mg/dL\n    - HDL (good) cholesterol: >40 mg/dL (men), >50 mg/dL (women)\n    - Triglycerides: <150 mg/dL\n    - Blood sugar: <100 mg/dL fasting\n\n17. Take prescribed medications:\n    - If you have high BP, cholesterol, diabetes\n    - Take as directed\n    - Don't stop without consulting doctor\n\nWarning signs of heart problems:\n- Chest pain or discomfort\n- Shortness of breath\n- Pain in arm, jaw, back\n- Dizziness, lightheadedness\n- Irregular heartbeat\n- Swelling in legs, ankles\n- Seek medical help immediately\n\nFoods to limit/avoid:\n- Red meat (beef, pork, lamb)\n- Processed meats (bacon, sausage, ham)\n- Fried foods\n- Full-fat dairy\n- Bakery items (cookies, cakes, pastries)\n- Sugary drinks\n- Fast food\n- Excess salt\n\nHeart-healthy eating pattern:\n- Mediterranean diet\n- DASH diet (Dietary Approaches to Stop Hypertension)\n- Plant-based diets\n\nThus, heart health is largely within our control through daily choices."
        },
        {
            "type": "subjective",
            "q": "What is a stethoscope? How does it work?",
            "sample": "A stethoscope is a medical instrument used to listen to internal sounds of the body, especially heart and lung sounds.\n\nHistory:\n- Invented by René Laennec in 1816\n- Originally a rolled paper tube\n- Named from Greek: stethos (chest) + skopein (to examine)\n\nParts of a stethoscope:\n\n1. Chest piece (head):\n   - Contains diaphragm and/or bell\n   - Made of metal\n   - Placed on patient's body\n\n2. Diaphragm (flat side):\n   - Large flat disc\n   - Covered with thin plastic\n   - Picks up high-frequency sounds\n   - Used for: Heart sounds, lung sounds, bowel sounds\n\n3. Bell (cup-shaped side):\n   - Hollow cup\n   - Picks up low-frequency sounds\n   - Used for: Heart murmurs, bruits\n   - Requires light skin contact\n\n4. Tubing:\n   - Flexible rubber or vinyl tubes\n   - Conducts sound from chest piece to ears\n   - Usually double-lumen (two separate tubes)\n   - Length about 50-60 cm\n\n5. Ear tubes:\n   - Metal tubes connecting tubing to earpieces\n   - Angled to fit ear canals\n\n6. Earpieces:\n   - Soft tips that fit in ears\n   - Should seal well to block external noise\n   - Angled forward to match ear canal direction\n\n7. Spring:\n   - Metal piece connecting ear tubes\n   - Provides tension for comfortable fit\n\nHow a stethoscope works:\n\nPrinciple: Sound conduction through air in sealed tubes\n\n1. Sound production:\n   - Heartbeat creates vibrations\n   - Lungs create sounds during breathing\n   - Blood flow creates sounds in vessels\n\n2. Sound capture:\n   - Diaphragm or bell placed on skin\n   - Vibrations transmitted to air inside\n   - Diaphragm amplifies high frequencies\n   - Bell transmits low frequencies\n\n3. Sound transmission:\n   - Sound waves travel through air in tubing\n   - Minimal loss of energy\n   - Tubing sealed to prevent sound escape\n\n4. Sound delivery:\n   - Sound reaches earpieces\n   - Earpieces direct sound into ear canals\n   - Listener hears amplified internal sounds\n\nWhat can be heard:\n\nHeart sounds:\n- 'Lub-dub' normal heart sounds\n- Heart murmurs (abnormal flow)\n- Irregular rhythms\n- Valve problems\n\nLung sounds:\n- Normal breath sounds\n- Wheezing (asthma)\n- Crackles (pneumonia, fluid)\n- Absent sounds (collapse)\n\nBowel sounds:\n- Normal intestinal activity\n- Absent sounds (obstruction)\n- Hyperactive sounds (diarrhoea)\n\nBlood flow:\n- Bruits (turbulent flow in arteries)\n- In carotid, renal, femoral arteries\n\nBlood pressure measurement:\n- Used with sphygmomanometer\n- Listen for Korotkoff sounds\n- First sound = systolic pressure\n- Last sound = diastolic pressure\n\nTypes of stethoscopes:\n\n1. Acoustic (most common):\n   - No electronics\n   - Relies on sound conduction\n   - Affordable, durable\n\n2. Electronic:\n   - Amplifies sounds\n   - Can filter noise\n   - Can record sounds\n   - More expensive\n\n3. Fetal stethoscope (fetoscope):\n   - Used to hear fetal heartbeat\n   - Special design\n\n4. Doppler stethoscope:\n   - Uses ultrasound\n   - Detects blood flow\n   - Used for fetal heart, vascular exams\n\nCare of stethoscope:\n- Clean earpieces and diaphragm regularly\n- Avoid extreme temperatures\n- Don't bend tubing sharply\n- Store properly\n- Replace worn parts\n\nThus, the stethoscope is an essential diagnostic tool that allows doctors to 'hear' what's happening inside the body."
        },
        {
            "type": "subjective",
            "q": "What is a sphygmomanometer? How is blood pressure measured?",
            "sample": "A sphygmomanometer is a medical device used to measure blood pressure. The name comes from Greek: sphygmos (pulse) + manometer (pressure meter).\n\nTypes of sphygmomanometers:\n\n1. Mercury sphygmomanometer:\n   - Uses mercury column\n   - Most accurate, gold standard\n   - Being phased out due to mercury toxicity\n   - Reads in mmHg\n\n2. Aneroid sphygmomanometer:\n   - Uses mechanical gauge with dial\n   - No mercury\n   - Needs regular calibration\n   - Portable\n\n3. Digital/Electronic sphygmomanometer:\n   - Automatic inflation\n   - Digital display\n   - Easy to use at home\n   - May be less accurate\n\nParts of a sphygmomanometer:\n\n1. Cuff:\n   - Inflatable bladder inside cloth cover\n   - Wrapped around upper arm\n   - Various sizes (child, adult, large adult)\n   - Proper size essential for accuracy\n\n2. Inflation bulb:\n   - Rubber bulb with valve\n   - Used to pump air into cuff\n   - Valve controls release of air\n\n3. Pressure gauge:\n   - Mercury column or dial\n   - Shows pressure in mmHg\n   - Calibrated scale\n\n4. Tubing:\n   - Connects cuff to bulb and gauge\n\nMeasuring blood pressure (auscultatory method):\n\nEquipment needed:\n- Sphygmomanometer\n- Stethoscope\n- Patient resting comfortably\n\nProcedure:\n\nStep 1: Preparation\n- Patient seated, arm supported at heart level\n- No caffeine, smoking 30 minutes before\n- Rest for 5 minutes\n- Remove tight clothing from arm\n\nStep 2: Position cuff\n- Locate brachial artery (inner elbow)\n- Wrap cuff snugly around upper arm\n- Lower edge 2-3 cm above elbow crease\n- Center over brachial artery\n\nStep 3: Locate pulse\n- Palpate radial pulse at wrist\n- Inflate cuff while feeling pulse\n- Note pressure when pulse disappears\n- Deflate quickly\n- This estimates systolic pressure\n\nStep 4: Position stethoscope\n- Place stethoscope over brachial artery\n- Hold firmly but not too tight\n\nStep 5: Inflate cuff\n- Close valve on bulb\n- Inflate to 20-30 mmHg above estimated systolic\n- About 160-180 mmHg typically\n\nStep 6: Deflate slowly\n- Open valve slightly\n- Deflate at 2-3 mmHg per second\n- Listen carefully\n\nStep 7: Record systolic pressure\n- First sound heard (Korotkoff sound) = systolic\n- Sound is tapping, clear\n- Note pressure reading\n\nStep 8: Record diastolic pressure\n- Sounds become muffled then disappear\n- Point of disappearance = diastolic\n- Note pressure reading\n\nStep 9: Complete measurement\n- Continue deflating to zero\n- Remove cuff\n- Record as systolic/diastolic (e.g., 120/80)\n\nStep 10: Repeat if needed\n- Wait 1-2 minutes\n- Take second reading\n- Average if close\n\nKorotkoff sounds:\n\nPhase 1: First tapping sound (systolic)\nPhase 2: Swishing sound\nPhase 3: Crisper tapping\nPhase 4: Muffling\nPhase 5: Silence (diastolic)\n\nCommon errors in measurement:\n\n1. Cuff too small: Falsely high reading\n2. Cuff too large: Falsely low reading\n3. Arm not at heart level: Incorrect reading\n4. Deflating too fast: Inaccurate reading\n5. Talking during measurement: Increases BP\n6. Crossed legs: Increases BP\n7. Full bladder: Increases BP\n8. Recent exercise/smoking/caffeine: Increases BP\n\nHome BP monitoring tips:\n- Use validated device\n- Proper cuff size\n- Same time each day\n- Before medications\n- Empty bladder\n- Sit quietly 5 minutes before\n- Multiple readings, average\n- Keep log for doctor\n\nThus, accurate BP measurement is essential for diagnosing and managing hypertension."
        },
        {
            "type": "subjective",
            "q": "Why do veins have valves while arteries do not?",
            "sample": "Veins have valves while arteries do not because of differences in blood pressure, flow characteristics, and the need to overcome gravity.\n\nBlood pressure differences:\n\nArteries:\n- High pressure (about 120/80 mmHg in systemic arteries)\n- Pressure generated by heart pump\n- Blood flows with force\n- Pressure alone sufficient to push blood forward\n- No risk of backflow due to continuous forward pressure\n\nVeins:\n- Low pressure (about 2-10 mmHg)\n- Pressure drops after capillaries\n- By time blood reaches veins, pressure is very low\n- Not enough pressure to ensure forward flow\n- Especially in legs, must work against gravity\n\nWhy arteries don't need valves:\n\n1. High pressure:\n   - Heart generates enough force\n   - Blood always pushed forward\n   - Pressure pulse helps maintain flow\n\n2. Elastic walls:\n   - Arteries stretch and recoil\n   - Maintains pressure during diastole\n   - Continuous forward flow\n\n3. Position:\n   - Most arteries deep in body\n   - Protected from external compression\n   - Less affected by gravity\n\n4. Muscular walls:\n   - Can constrict and dilate\n   - Help regulate flow\n   - Maintain pressure\n\nWhy veins need valves:\n\n1. Low pressure:\n   - Insufficient to ensure forward flow\n   - Especially in veins against gravity (legs)\n\n2. Gravity:\n   - Blood must flow upward from legs to heart\n   - Without valves, blood would pool in feet\n\n3. Long distances:\n   - Leg veins long column of blood\n   - Pressure at bottom high due to gravity\n   - Valves break column into segments\n\n4. External compression:\n   - Veins squeezed by muscles during movement\n   - Valves ensure flow is toward heart\n   - Muscle pump works with valves\n\n5. Thin walls:\n   - Veins have thin walls, less muscle\n   - Cannot maintain pressure like arteries\n   - Need mechanical help from valves\n\nHow venous valves work:\n\nStructure:\n- Semilunar (half-moon shaped) folds of inner lining\n- Usually paired (two flaps)\n- Made of endothelium with fibrous tissue\n- Open toward heart, close away from heart\n\nMechanism:\n- Blood flowing toward heart pushes valves open\n- If blood tries to flow backward, valves fill with blood\n- Valve flaps meet, closing the lumen\n- Prevents backflow\n\nMuscle pump mechanism:\n1. Muscles contract during walking/exercise\n2. Compress veins\n3. Valves below contraction close (prevent backflow down)\n4. Valves above contraction open\n5. Blood squeezed upward toward heart\n6. When muscles relax, valves above close (prevent backflow)\n7. Valves below open, allowing more blood from below\n8. Cycle repeats with each step\n\nRespiratory pump:\n- Breathing creates pressure changes in chest\n- Inspiration decreases pressure in chest veins\n- Draws blood from abdominal veins\n- Valves ensure one-way flow\n\nConsequences of valve failure:\n\nVaricose veins:\n- Valves become incompetent (leaky)\n- Blood pools in veins\n- Veins become stretched, tortuous\n- Swelling, pain, heaviness in legs\n- More common in people who stand long hours\n\nVenous insufficiency:\n- Chronic valve failure\n- Blood pools in lower legs\n- Swelling (oedema)\n- Skin changes, ulcers\n\nDeep vein thrombosis risk:\n- Stagnant blood more likely to clot\n- Clots can travel to lungs (pulmonary embolism)\n\nThus, valves are essential adaptations in veins to ensure one-way blood flow back to heart against gravity."
        },
        {
            "type": "subjective",
            "q": "Describe an activity to measure pulse rate at rest and after exercise.",
            "sample": "Aim: To measure pulse rate at rest and after exercise, and observe the difference.\n\nMaterials required:\n- Stopwatch or clock with second hand\n- Partner to help\n- Comfortable clothing\n- Space for exercise\n\nProcedure:\n\nPart A: Measuring resting pulse\n\nStep 1: Prepare\n- Person should sit quietly for 5 minutes\n- Should be relaxed, not talking\n- Arm resting on table\n\nStep 2: Locate pulse\n- Turn hand palm up\n- Place index and middle fingers on wrist below thumb\n- Press gently until you feel pulse\n- Do not use thumb (has its own pulse)\n\nStep 3: Count beats\n- Once pulse is felt steadily, start stopwatch\n- Count beats for 30 seconds\n- Multiply by 2 for beats per minute\n- Or count for full 60 seconds for accuracy\n\nStep 4: Record\n- Resting pulse rate: _____ beats per minute\n- Note rhythm (regular/irregular)\n- Note character (strong/weak)\n\nPart B: Exercise\n\nStep 5: Perform exercise\n- Person jogs in place for 3-5 minutes\n- Or does jumping jacks\n- Or runs up and down stairs\n- Should exercise enough to breathe harder\n\nStep 6: Immediate post-exercise measurement\n- Immediately after stopping exercise\n- Find pulse again quickly\n- Count for 15 seconds\n- Multiply by 4 for beats per minute\n- (Because heart rate drops quickly after exercise)\n\nStep 7: Record\n- Exercise pulse rate: _____ beats per minute\n\nPart C: Recovery measurement\n\nStep 8: Measure recovery\n- Wait 2 minutes after exercise\n- Measure pulse again for 30 seconds\n- Multiply by 2\n\nStep 9: Wait another 2 minutes\n- Measure again\n- Continue until pulse returns to near resting rate\n\nObservations table:\n\n| Time | Pulse rate (beats/min) |\n|------|------------------------|\n| Resting | |\n| Immediately after exercise | |\n| 2 minutes after | |\n| 4 minutes after | |\n| 6 minutes after | |\n| Return to resting | |\n\nExpected results:\n- Resting pulse: 70-80 bpm (varies with age, fitness)\n- After exercise: Increases significantly (120-160 bpm)\n- Recovery: Gradually returns to resting\n- Fitter individuals recover faster\n\nCalculations:\n- Increase = Exercise rate - Resting rate\n- % increase = (Increase ÷ Resting rate) × 100\n- Recovery time = Time to return to resting\n\nInterpretation:\n\nNormal response:\n- Heart rate increases with exercise\n- Increase proportional to exercise intensity\n- Gradual return to resting (recovery)\n\nAbnormal responses:\n- Excessive increase (poor fitness)\n- Insufficient increase (heart problem, medications)\n- Very slow recovery (poor fitness)\n- Irregular rhythm during/after exercise\n\nFactors affecting pulse rate:\n- Age (younger = faster)\n- Gender (females slightly faster)\n- Fitness level (fitter = slower resting, faster recovery)\n- Emotions (stress increases rate)\n- Temperature (heat increases rate)\n- Medications (some slow heart rate)\n- Caffeine, nicotine increase rate\n\nConclusion:\n- Exercise increases heart rate to meet oxygen demand\n- Heart rate returns to normal as oxygen demand decreases\n- Regular exercise improves heart efficiency (lower resting rate, faster recovery)\n\nPrecautions:\n- Stop if feeling dizzy, chest pain, severe shortness of breath\n- Not suitable for people with certain heart conditions\n- Consult doctor before starting exercise program\n\nThis activity demonstrates how the heart responds to increased demand during exercise."
        },
        {
            "type": "subjective",
            "q": "What is the importance of iron in our diet? How is it related to blood?",
            "sample": "Iron is an essential mineral that plays a critical role in blood formation and oxygen transport throughout the body.\n\nWhat is iron?\n- Essential trace mineral\n- Required in small amounts (daily requirement: 8-18 mg)\n- Cannot be made by body, must come from diet\n- Stored in liver, spleen, bone marrow\n\nRole of iron in blood:\n\n1. Haemoglobin formation:\n   - Iron is core component of haemoglobin\n   - Each haemoglobin molecule has 4 iron atoms\n   - Iron binds oxygen reversibly\n   - Without iron, haemoglobin cannot form\n\n2. Oxygen transport:\n   - Iron in haemoglobin binds oxygen in lungs\n   - Forms oxyhaemoglobin\n   - Releases oxygen in tissues\n   - Enables all cells to receive oxygen\n\n3. Myoglobin:\n   - Iron-containing protein in muscles\n   - Stores oxygen in muscle cells\n   - Provides oxygen during intense activity\n\n4. RBC production:\n   - Iron essential for RBC formation in bone marrow\n   - Without iron, RBC production decreases\n\nIron deficiency effects on blood:\n\nIron deficiency anaemia:\n- Most common nutritional deficiency worldwide\n- Characterized by:\n  * Low haemoglobin levels\n  * Small, pale RBCs (microcytic, hypochromic)\n  * Reduced oxygen-carrying capacity\n\nSymptoms of iron deficiency anaemia:\n- Fatigue, weakness\n- Pale skin\n- Shortness of breath\n- Dizziness\n- Cold hands and feet\n- Brittle nails\n- Poor concentration\n- Restless legs\n- Pica (craving non-food items like ice, dirt)\n\nBlood tests for iron status:\n- Haemoglobin (Hb): Low in anaemia\n- Haematocrit (Hct): Low\n- RBC count: May be low\n- Serum iron: Low\n- Ferritin (storage iron): Low\n- Transferrin saturation: Low\n\nDaily iron requirements:\n\n| Group | Daily requirement |\n|-------|-------------------|\n| Infants (7-12 months) | 11 mg |\n| Children (1-3 years) | 7 mg |\n| Children (4-8 years) | 10 mg |\n| Children (9-13 years) | 8 mg |\n| Adolescent boys (14-18) | 11 mg |\n| Adolescent girls (14-18) | 15 mg |\n| Adult men | 8 mg |\n| Adult women (19-50) | 18 mg |\n| Pregnant women | 27 mg |\n| Lactating women | 9-10 mg |\n\nDietary sources of iron:\n\nHaem iron (better absorbed, 15-35%):\n- Red meat (beef, lamb)\n- Organ meats (liver, kidney)\n- Poultry (chicken, turkey)\n- Fish and shellfish\n\nNon-haem iron (less absorbed, 2-20%):\n- Dark leafy greens (spinach, kale)\n- Legumes (lentils, beans, chickpeas)\n- Fortified cereals\n- Nuts and seeds\n- Dried fruits (raisins, apricots)\n- Whole grains\n- Tofu\n- Blackstrap molasses\n\nFactors affecting iron absorption:\n\nEnhancers (increase absorption):\n- Vitamin C (citrus fruits, tomatoes, bell peppers)\n- Meat, fish, poultry (contain 'MFP factor')\n- Acidic foods\n- Cooking in cast iron pots\n\nInhibitors (decrease absorption):\n- Tannins in tea, coffee\n- Phytates in whole grains, legumes\n- Calcium in dairy\n- Oxalates in spinach\n- Antacids\n\nTips to improve iron absorption:\n- Eat iron foods with vitamin C (e.g., spinach with lemon)\n- Avoid tea/coffee with meals\n- Cook in iron pots\n- Combine haem and non-haem sources\n\nIron overload (haemochromatosis):\n- Too much iron can be toxic\n- Damages liver, heart, pancreas\n- Genetic condition\n- Treated by blood removal\n\nThus, iron is essential for healthy blood and preventing anaemia."
        },
        {
            "type": "subjective",
            "q": "Write a note on the discovery of blood groups by Karl Landsteiner.",
            "sample": "Karl Landsteiner (1868-1943) was an Austrian biologist and physician who discovered the ABO blood group system, revolutionizing blood transfusion medicine.\n\nEarly life and education:\n- Born in Vienna, Austria\n- Studied medicine at University of Vienna\n- Interested in chemistry and immunology\n- Worked at Vienna Pathological Institute\n\nBackground before discovery:\n- Blood transfusion often resulted in death\n- Doctors didn't know why some transfusions worked, others failed\n- Some patients had severe reactions, clumping of blood\n- Cause was unknown\n\nLandsteiner's key experiment (1900):\n\nHypothesis:\n- Blood of different people might have different properties\n- Mixing incompatible blood causes clumping (agglutination)\n\nMethod:\n- Collected blood samples from himself and colleagues\n- Separated red blood cells from serum\n- Mixed serum from one person with RBCs from another\n- Observed under microscope\n\nObservations:\n- Some mixtures showed clumping (agglutination)\n- Others remained smooth\n- Pattern emerged: People could be grouped\n\nDiscovery:\n- Identified three blood groups: A, B, and C (later called O)\n- Fourth group AB discovered later by colleagues\n- Named ABO system (A, B, AB, O)\n\nExplanation:\n- RBCs have antigens (A or B) on surface\n- Serum contains antibodies against opposite antigens\n- Incompatible mixing causes antibody-antigen reaction\n- Clumping blocks blood vessels, causes death\n\nPublication (1901):\n- Published findings in paper \"Agglutination phenomena of normal human blood\"\n- Showed that blood transfusions should match types\n- Explained why some transfusions succeeded, others failed\n\nLater discoveries:\n- 1902: Colleagues von Decastello and Sturli discovered AB group\n- 1930s: Landsteiner discovered Rh factor with Alexander Wiener\n- Rh named after Rhesus monkeys used in experiments\n\nImpact on medicine:\n\n1. Safe blood transfusion:\n   - Matching blood types before transfusion\n   - Prevents fatal reactions\n   - Enabled routine blood transfusion\n\n2. Blood banks:\n   - Blood could be stored and typed\n   - World War II: Saved countless lives\n   - Modern blood banking possible\n\n3. Organ transplantation:\n   - Blood typing essential for transplants\n   - Prevents rejection\n\n4. Forensic medicine:\n   - Blood typing at crime scenes\n   - Paternity testing\n\n5. Anthropology:\n   - Blood group distribution studied in populations\n   - Migration patterns traced\n\n6. Pregnancy:\n   - Rh incompatibility understood\n   - Prevention of haemolytic disease of newborn\n\nAwards and recognition:\n- 1930: Nobel Prize in Physiology or Medicine\n- For discovery of human blood groups\n- Lasker Award (1946, posthumous)\n\nLegacy:\n- Father of transfusion medicine\n- His birthday (June 14) is World Blood Donor Day\n- ABO system still used worldwide\n- Estimated 1 billion transfusions safely performed due to his work\n\nLater life:\n- Moved to USA (Rockefeller Institute)\n- Continued research on immunology\n- Worked on polio, discovered blood factors\n- Died 1943, but his work saves millions of lives annually\n\nThus, Landsteiner's simple but brilliant experiment transformed medicine and enabled safe blood transfusion."
        },
        {
            "type": "subjective",
            "q": "Explain why a person with blood group O is called a universal donor.",
            "sample": "A person with blood group O is called a universal donor because their red blood cells can be safely transfused to people of any ABO blood group.\n\nUnderstanding blood groups:\n\nBlood group antigens:\n- Type A: Has A antigen on RBCs\n- Type B: Has B antigen on RBCs\n- Type AB: Has both A and B antigens\n- Type O: Has neither A nor B antigens\n\nBlood group antibodies:\n- Type A: Has anti-B antibodies in plasma\n- Type B: Has anti-A antibodies in plasma\n- Type AB: Has no antibodies\n- Type O: Has both anti-A and anti-B antibodies\n\nTransfusion reaction:\n- If incompatible blood given:\n  * Recipient's antibodies attack donor's RBCs\n  * Causes agglutination (clumping)\n  * Blocks blood vessels\n  * Can cause kidney failure, shock, death\n\nWhy group O can donate to anyone:\n\n1. No antigens on RBCs:\n   - Group O RBCs have NO A or B antigens\n   - Therefore, they cannot be attacked by:\n     * Anti-A antibodies (in type B and O recipients)\n     * Anti-B antibodies (in type A and O recipients)\n   - RBCs are 'invisible' to recipient's immune system\n\n2. Safe for all recipients:\n   - Type A recipient: Anti-B antibodies (no B antigen in O blood)\n   - Type B recipient: Anti-A antibodies (no A antigen in O blood)\n   - Type AB recipient: No antibodies at all\n   - Type O recipient: Both antibodies, but O blood has no antigens\n\n3. RBCs only:\n   - In transfusion, packed RBCs are usually given\n   - Plasma (containing antibodies) is removed\n   - So donor antibodies don't affect recipient\n\nConsideration of antibodies in donor plasma:\n\nIf whole blood is given (not packed cells):\n- Group O blood contains anti-A and anti-B antibodies\n- These could attack recipient's RBCs if:\n  * Recipient is type A (has A antigens)\n  * Recipient is type B (has B antigens)\n  * Recipient is type AB (has both antigens)\n\nBut:\n- Donor antibodies get diluted in recipient's blood volume\n- Usually not a problem unless large volume given\n- Modern transfusion uses packed RBCs (plasma removed)\n- So group O packed RBCs are truly universal\n\nWhy other groups are not universal donors:\n\nGroup A:\n- Has A antigens on RBCs\n- Would be attacked by:\n  * Anti-A antibodies in type B recipients\n  * Anti-A antibodies in type O recipients\n- Can only donate to A and AB\n\nGroup B:\n- Has B antigens on RBCs\n- Would be attacked by:\n  * Anti-B antibodies in type A recipients\n  * Anti-B antibodies in type O recipients\n- Can only donate to B and AB\n\nGroup AB:\n- Has both A and B antigens\n- Would be attacked by both anti-A and anti-B antibodies\n- Can only donate to AB recipients\n\nUniversal recipient (group AB):\n- Has no antibodies in plasma\n- Can receive from any blood type\n- But can only donate to AB\n\nPractical applications:\n\nEmergency transfusions:\n- When blood type unknown\n- Group O negative blood used\n- 'Universal donor' saves lives in emergencies\n- Trauma, accidents, battlefield\n\nBlood banks:\n- Group O blood in high demand\n- Often in short supply\n- Donors encouraged to give regularly\n\nRh factor consideration:\n- O negative: Universal donor (no Rh antigen)\n- O positive: Can donate to Rh positive recipients only\n- O negative blood given to Rh negative or unknown\n\nSummary:\n\n| Blood group | Antigens on RBC | Antibodies in plasma | Can donate to | Can receive from |\n|-------------|-----------------|----------------------|---------------|------------------|\n| A | A | Anti-B | A, AB | A, O |\n| B | B | Anti-A | B, AB | B, O |\n| AB | A and B | None | AB | All (universal recipient) |\n| O | None | Anti-A and Anti-B | All (universal donor) | O |\n\nThus, group O is universal donor because their RBCs lack antigens that could trigger reactions in recipients."
        },
        {
            "type": "subjective",
            "q": "Draw a labeled diagram of the human heart showing all chambers and major blood vessels.",
            "sample": "The human heart is a four-chambered muscular organ that pumps blood throughout the body.\n\n[Students should draw a well-labeled diagram showing the following structures]\n\nExternal features to label:\n\n1. Right atrium:\n   - Upper right chamber\n   - Thin-walled\n   - Receives deoxygenated blood from body\n\n2. Right ventricle:\n   - Lower right chamber\n   - Thicker wall than atria\n   - Pumps blood to lungs\n\n3. Left atrium:\n   - Upper left chamber\n   - Thin-walled\n   - Receives oxygenated blood from lungs\n\n4. Left ventricle:\n   - Lower left chamber\n   - Thickest wall\n   - Pumps blood to body\n\n5. Superior vena cava:\n   - Large vein bringing blood from upper body\n   - Enters right atrium from above\n\n6. Inferior vena cava:\n   - Large vein bringing blood from lower body\n   - Enters right atrium from below\n\n7. Pulmonary artery:\n   - Takes blood from right ventricle to lungs\n   - Only artery carrying deoxygenated blood\n   - Branches to left and right lungs\n\n8. Pulmonary veins:\n   - Four veins (two from each lung)\n   - Bring oxygenated blood to left atrium\n   - Only veins carrying oxygenated blood\n\n9. Aorta:\n   - Largest artery\n   - Takes blood from left ventricle to body\n   - Arches then descends\n\n10. Coronary arteries:\n    - Supply blood to heart muscle itself\n    - Branch from aorta\n\nInternal structures to label:\n\n11. Tricuspid valve:\n    - Between right atrium and right ventricle\n    - Three flaps\n\n12. Bicuspid (mitral) valve:\n    - Between left atrium and left ventricle\n    - Two flaps\n\n13. Pulmonary semilunar valve:\n    - At exit of right ventricle into pulmonary artery\n    - Three half-moon shaped cusps\n\n14. Aortic semilunar valve:\n    - At exit of left ventricle into aorta\n    - Three cusps\n\n15. Chordae tendineae:\n    - Tendinous cords\n    - Attach valves to papillary muscles\n    - Prevent valve inversion\n\n16. Papillary muscles:\n    - Projections from ventricular wall\n    - Contract to pull chordae tendineae\n\n17. Septum:\n    - Muscular wall dividing left and right sides\n    - Prevents mixing of blood\n\n18. Pericardium:\n    - Double membrane covering heart\n    - Space with pericardial fluid\n\nDirection of blood flow (show with arrows):\n\nDeoxygenated blood (blue arrows):\nSuperior/Inferior vena cava → Right atrium → Tricuspid valve → Right ventricle → Pulmonary valve → Pulmonary artery → Lungs\n\nOxygenated blood (red arrows):\nPulmonary veins → Left atrium → Bicuspid valve → Left ventricle → Aortic valve → Aorta → Body\n\nKey features to emphasize:\n- Right side (blue) carries deoxygenated blood\n- Left side (red) carries oxygenated blood\n- Septum separates them\n- Valves ensure one-way flow\n- Left ventricle has thickest wall\n- Pulmonary vessels are exceptions (artery carries deoxygenated, veins carry oxygenated)\n\nColour coding:\n- Red: Oxygenated blood (left side, pulmonary veins, aorta)\n- Blue: Deoxygenated blood (right side, pulmonary artery, venae cavae)\n- Purple: Mixing (none - completely separated in healthy heart)\n\nLabel all parts clearly with leader lines.\n\nThis diagram helps visualize the heart's structure and understand how blood flows through it."
        }
    ]
}