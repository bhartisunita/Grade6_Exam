"""
Biology — Grade 6 ICSE
Chapter 7: Health and Hygiene
Comprehensive Practice Questions
50 MCQ • 50 True/False • 40 Subjective
"""

CHAPTER_7_QUESTIONS = {

    "Chapter 7 — Health and Hygiene": [
        # ===== MCQ (50 questions) =====
        {
            "type": "mcq",
            "q": "According to WHO, health is a state of complete physical, mental, and:",
            "options": [
                "Financial well-being",
                "Social well-being",
                "Educational well-being",
                "Spiritual well-being"
            ],
            "answer": "Social well-being",
            "explanation": "WHO defines health as 'a state of complete physical, mental and social well-being and not merely absence of disease'."
        },
        {
            "type": "mcq",
            "q": "Disease can be defined as:",
            "options": [
                "A state of complete well-being",
                "A deviation from normal state causing discomfort",
                "A state of fitness",
                "Absence of hunger"
            ],
            "answer": "A deviation from normal state causing discomfort",
            "explanation": "Disease is any physical or functional change from normal state that causes discomfort or affects health."
        },
        {
            "type": "mcq",
            "q": "Diseases present from birth are called:",
            "options": [
                "Acquired diseases",
                "Communicable diseases",
                "Congenital diseases",
                "Infectious diseases"
            ],
            "answer": "Congenital diseases",
            "explanation": "Congenital diseases are present from birth, caused by genetic abnormality or underdevelopment of organs."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a congenital disease?",
            "options": [
                "Cholera",
                "Colour-blindness",
                "Malaria",
                "Tuberculosis"
            ],
            "answer": "Colour-blindness",
            "explanation": "Colour-blindness is inherited from parents and present from birth, making it congenital."
        },
        {
            "type": "mcq",
            "q": "Haemophilia is also known as:",
            "options": [
                "Royal disease",
                "Common cold",
                "Fever",
                "Diabetes"
            ],
            "answer": "Royal disease",
            "explanation": "Haemophilia is called 'Royal disease' as Queen Victoria of England carried and passed the gene to descendants."
        },
        {
            "type": "mcq",
            "q": "Diseases that develop after birth are called:",
            "options": [
                "Congenital diseases",
                "Acquired diseases",
                "Hereditary diseases",
                "Genetic diseases"
            ],
            "answer": "Acquired diseases",
            "explanation": "Acquired diseases develop after birth and can be communicable or non-communicable."
        },
        {
            "type": "mcq",
            "q": "Diseases that can be passed from an infected person to a healthy person are called:",
            "options": [
                "Non-communicable diseases",
                "Congenital diseases",
                "Communicable diseases",
                "Hereditary diseases"
            ],
            "answer": "Communicable diseases",
            "explanation": "Communicable (infectious) diseases can be transmitted directly or indirectly from infected to healthy persons."
        },
        {
            "type": "mcq",
            "q": "Diseases that cannot be transmitted from one person to another are called:",
            "options": [
                "Communicable diseases",
                "Infectious diseases",
                "Non-communicable diseases",
                "Contagious diseases"
            ],
            "answer": "Non-communicable diseases",
            "explanation": "Non-communicable diseases are not caused by pathogens and cannot spread between people."
        },
        {
            "type": "mcq",
            "q": "Microorganisms that cause diseases are called:",
            "options": [
                "Antibodies",
                "Pathogens",
                "Vectors",
                "Vaccines"
            ],
            "answer": "Pathogens",
            "explanation": "Pathogens are disease-causing microorganisms like bacteria, viruses, fungi, and protozoa."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a bacterial disease?",
            "options": [
                "Measles",
                "Cholera",
                "Influenza",
                "Polio"
            ],
            "answer": "Cholera",
            "explanation": "Cholera is caused by bacterium Vibrio cholerae, while measles, influenza, and polio are viral diseases."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a viral disease?",
            "options": [
                "Tuberculosis",
                "Cholera",
                "Measles",
                "Tetanus"
            ],
            "answer": "Measles",
            "explanation": "Measles is caused by a virus; tuberculosis, cholera, and tetanus are bacterial diseases."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a protozoal disease?",
            "options": [
                "Ringworm",
                "Malaria",
                "Typhoid",
                "Diphtheria"
            ],
            "answer": "Malaria",
            "explanation": "Malaria is caused by protozoan Plasmodium; ringworm is fungal, typhoid and diphtheria are bacterial."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a fungal disease?",
            "options": [
                "Cholera",
                "Malaria",
                "Ringworm",
                "Polio"
            ],
            "answer": "Ringworm",
            "explanation": "Ringworm is a fungal infection of the skin; others are bacterial, protozoal, and viral respectively."
        },
        {
            "type": "mcq",
            "q": "Tuberculosis affects which part of the body?",
            "options": [
                "Intestine",
                "Lungs",
                "Liver",
                "Skin"
            ],
            "answer": "Lungs",
            "explanation": "Tuberculosis primarily affects the lungs, though it can affect other body parts."
        },
        {
            "type": "mcq",
            "q": "Typhoid spreads through:",
            "options": [
                "Air droplets",
                "Contaminated food and water",
                "Insect bite",
                "Direct contact"
            ],
            "answer": "Contaminated food and water",
            "explanation": "Typhoid spreads through contaminated food and water, or direct contact with infected faeces."
        },
        {
            "type": "mcq",
            "q": "Cholera causes:",
            "options": [
                "Cough and fever",
                "Acute diarrhoea and vomiting",
                "Skin rashes",
                "Paralysis"
            ],
            "answer": "Acute diarrhoea and vomiting",
            "explanation": "Cholera causes severe diarrhoea, vomiting, and dehydration due to bacterial infection."
        },
        {
            "type": "mcq",
            "q": "Botulism affects which body system?",
            "options": [
                "Digestive system",
                "Respiratory system",
                "Nervous system",
                "Circulatory system"
            ],
            "answer": "Nervous system",
            "explanation": "Botulism affects the nervous system, causing fatigue, dizziness, muscular weakness, and paralysis."
        },
        {
            "type": "mcq",
            "q": "Diphtheria affects the:",
            "options": [
                "Intestine",
                "Throat and upper trachea",
                "Skin",
                "Liver"
            ],
            "answer": "Throat and upper trachea",
            "explanation": "Diphtheria causes sore throat, pain, fever, and nasal discharge, affecting throat and upper trachea."
        },
        {
            "type": "mcq",
            "q": "Polio affects which body system?",
            "options": [
                "Digestive system",
                "Respiratory system",
                "Nervous system",
                "Circulatory system"
            ],
            "answer": "Nervous system",
            "explanation": "Polio attacks the nervous system, causing irreversible paralysis in limbs."
        },
        {
            "type": "mcq",
            "q": "Hepatitis affects which organ?",
            "options": [
                "Heart",
                "Lungs",
                "Liver",
                "Kidneys"
            ],
            "answer": "Liver",
            "explanation": "Hepatitis is inflammation of the liver, causing jaundice, fever, nausea, and pain in liver region."
        },
        {
            "type": "mcq",
            "q": "Chickenpox is characterized by:",
            "options": [
                "High fever only",
                "Itchy rashes with pink spots and blisters",
                "Persistent cough",
                "Joint pain"
            ],
            "answer": "Itchy rashes with pink spots and blisters",
            "explanation": "Chickenpox causes fever followed by itchy rashes with pink spots that become blisters and then scabs."
        },
        {
            "type": "mcq",
            "q": "Measles first shows:",
            "options": [
                "Red rashes all over body",
                "Small whitish spots on inner cheeks",
                "Blisters on skin",
                "Yellowing of eyes"
            ],
            "answer": "Small whitish spots on inner cheeks",
            "explanation": "Measles first shows small whitish spots on inner walls of cheeks before red rashes appear."
        },
        {
            "type": "mcq",
            "q": "Ringworm causes:",
            "options": [
                "Red, itchy, scaly patches",
                "High fever",
                "Vomiting",
                "Paralysis"
            ],
            "answer": "Red, itchy, scaly patches",
            "explanation": "Ringworm causes red, itchy, scaly patches that may develop blisters and resemble a ring."
        },
        {
            "type": "mcq",
            "q": "Diseases that spread through air are called:",
            "options": [
                "Waterborne diseases",
                "Vector-borne diseases",
                "Droplet infections",
                "Contagious diseases"
            ],
            "answer": "Droplet infections",
            "explanation": "Air-borne diseases spread through droplets from coughs and sneezes, e.g., cold, influenza, tuberculosis."
        },
        {
            "type": "mcq",
            "q": "Diseases that spread through contaminated water are called:",
            "options": [
                "Air-borne diseases",
                "Waterborne diseases",
                "Vector-borne diseases",
                "Contagious diseases"
            ],
            "answer": "Waterborne diseases",
            "explanation": "Waterborne diseases like cholera and typhoid spread through contaminated drinking water."
        },
        {
            "type": "mcq",
            "q": "Insects and animals that carry disease-causing germs are called:",
            "options": [
                "Pathogens",
                "Vectors",
                "Hosts",
                "Carriers"
            ],
            "answer": "Vectors",
            "explanation": "Vectors like mosquitoes, flies, rats carry and transmit disease-causing germs."
        },
        {
            "type": "mcq",
            "q": "Malaria is caused by the bite of:",
            "options": [
                "Male Anopheles mosquito",
                "Female Anopheles mosquito",
                "Housefly",
                "Rat flea"
            ],
            "answer": "Female Anopheles mosquito",
            "explanation": "Female Anopheles mosquito transmits Plasmodium protozoan causing malaria."
        },
        {
            "type": "mcq",
            "q": "Dengue is spread by:",
            "options": [
                "Anopheles mosquito",
                "Aedes mosquito",
                "Culex mosquito",
                "Housefly"
            ],
            "answer": "Aedes mosquito",
            "explanation": "Aedes mosquito transmits dengue virus, causing high fever and haemorrhage."
        },
        {
            "type": "mcq",
            "q": "Plague is spread by:",
            "options": [
                "Mosquito",
                "Rat flea",
                "Housefly",
                "Tse-tse fly"
            ],
            "answer": "Rat flea",
            "explanation": "Rat flea transmits Yersinia pestis bacteria causing plague."
        },
        {
            "type": "mcq",
            "q": "Sleeping sickness is spread by:",
            "options": [
                "Mosquito",
                "Rat flea",
                "Tse-tse fly",
                "Housefly"
            ],
            "answer": "Tse-tse fly",
            "explanation": "Tse-tse fly transmits Trypanosoma protozoan causing sleeping sickness."
        },
        {
            "type": "mcq",
            "q": "Filariasis is caused by:",
            "options": [
                "Virus",
                "Bacteria",
                "Roundworm",
                "Protozoan"
            ],
            "answer": "Roundworm",
            "explanation": "Filariasis is caused by roundworm Wuchereria bancrofti transmitted by Culex mosquito."
        },
        {
            "type": "mcq",
            "q": "Diseases spread by direct contact are called:",
            "options": [
                "Air-borne diseases",
                "Waterborne diseases",
                "Contagious diseases",
                "Vector-borne diseases"
            ],
            "answer": "Contagious diseases",
            "explanation": "Contagious diseases like conjunctivitis and scabies spread through direct contact or sharing personal items."
        },
        {
            "type": "mcq",
            "q": "Scabies is caused by:",
            "options": [
                "Bacteria",
                "Virus",
                "Mite",
                "Fungus"
            ],
            "answer": "Mite",
            "explanation": "Scabies is caused by a tiny mite that burrows into skin, causing intense itching."
        },
        {
            "type": "mcq",
            "q": "BCG vaccine is for:",
            "options": [
                "Polio",
                "Tuberculosis",
                "Measles",
                "Tetanus"
            ],
            "answer": "Tuberculosis",
            "explanation": "BCG (Bacillus Calmette-Guérin) vaccine provides immunity against tuberculosis."
        },
        {
            "type": "mcq",
            "q": "DPT vaccine protects against:",
            "options": [
                "Diphtheria, Polio, Tetanus",
                "Diphtheria, Pertussis, Tetanus",
                "Diphtheria, Pertussis, Typhoid",
                "Diphtheria, Polio, Typhoid"
            ],
            "answer": "Diphtheria, Pertussis, Tetanus",
            "explanation": "DPT vaccine protects against Diphtheria, Pertussis (whooping cough), and Tetanus."
        },
        {
            "type": "mcq",
            "q": "MMR vaccine protects against:",
            "options": [
                "Measles, Mumps, Rubella",
                "Measles, Malaria, Rabies",
                "Mumps, Measles, Rickets",
                "Mumps, Malaria, Rubella"
            ],
            "answer": "Measles, Mumps, Rubella",
            "explanation": "MMR vaccine protects against Measles, Mumps, and Rubella (German measles)."
        },
        {
            "type": "mcq",
            "q": "Kwashiorkor is caused by deficiency of:",
            "options": [
                "Carbohydrates",
                "Fats",
                "Proteins",
                "Vitamins"
            ],
            "answer": "Proteins",
            "explanation": "Kwashiorkor is protein deficiency disease in young children, causing stunted growth and swollen belly."
        },
        {
            "type": "mcq",
            "q": "Marasmus is caused by deficiency of:",
            "options": [
                "Proteins only",
                "Carbohydrates only",
                "Proteins and carbohydrates",
                "Fats only"
            ],
            "answer": "Proteins and carbohydrates",
            "explanation": "Marasmus occurs due to deficiency of both proteins and carbohydrates in children under one year."
        },
        {
            "type": "mcq",
            "q": "Night blindness is caused by deficiency of vitamin:",
            "options": [
                "A",
                "B",
                "C",
                "D"
            ],
            "answer": "A",
            "explanation": "Vitamin A deficiency causes night blindness, where person cannot see in dim light."
        },
        {
            "type": "mcq",
            "q": "Beriberi is caused by deficiency of vitamin:",
            "options": [
                "A",
                "B",
                "C",
                "D"
            ],
            "answer": "B",
            "explanation": "Vitamin B1 (thiamine) deficiency causes beriberi, affecting nerves and heart."
        },
        {
            "type": "mcq",
            "q": "Scurvy is caused by deficiency of vitamin:",
            "options": [
                "A",
                "B",
                "C",
                "D"
            ],
            "answer": "C",
            "explanation": "Vitamin C deficiency causes scurvy, with symptoms like bleeding gums and swollen joints."
        },
        {
            "type": "mcq",
            "q": "Rickets is caused by deficiency of vitamin:",
            "options": [
                "A",
                "B",
                "C",
                "D"
            ],
            "answer": "D",
            "explanation": "Vitamin D deficiency causes rickets, where bones become soft and bent."
        },
        {
            "type": "mcq",
            "q": "Goitre is caused by deficiency of:",
            "options": [
                "Iron",
                "Iodine",
                "Calcium",
                "Phosphorus"
            ],
            "answer": "Iodine",
            "explanation": "Iodine deficiency causes goitre - enlargement of thyroid gland in neck."
        },
        {
            "type": "mcq",
            "q": "Anaemia is caused by deficiency of:",
            "options": [
                "Iodine",
                "Calcium",
                "Iron",
                "Phosphorus"
            ],
            "answer": "Iron",
            "explanation": "Iron deficiency causes anaemia - low haemoglobin and reduced RBC count."
        },
        {
            "type": "mcq",
            "q": "Diabetes is caused by insufficient secretion of:",
            "options": [
                "Insulin",
                "Glucagon",
                "Adrenaline",
                "Thyroxine"
            ],
            "answer": "Insulin",
            "explanation": "Diabetes mellitus results from inadequate insulin production by pancreas, causing high blood sugar."
        },
        {
            "type": "mcq",
            "q": "Type 1 diabetes is also called:",
            "options": [
                "Insulin-dependent diabetes",
                "Non-insulin-dependent diabetes",
                "Gestational diabetes",
                "Diabetes insipidus"
            ],
            "answer": "Insulin-dependent diabetes",
            "explanation": "Type 1 diabetes requires insulin injections as pancreas produces little or no insulin."
        },
        {
            "type": "mcq",
            "q": "Arthritis is a disease of the:",
            "options": [
                "Bones",
                "Muscles",
                "Joints",
                "Nerves"
            ],
            "answer": "Joints",
            "explanation": "Arthritis causes inflammation, pain, and stiffness in joints."
        },
        {
            "type": "mcq",
            "q": "Osteoarthritis is caused by:",
            "options": [
                "Autoimmune reaction",
                "Breakdown of cartilage at joints",
                "Bacterial infection",
                "Viral infection"
            ],
            "answer": "Breakdown of cartilage at joints",
            "explanation": "Osteoarthritis results from degeneration of cartilage due to ageing, heredity, or injury."
        },
        {
            "type": "mcq",
            "q": "Cancer is:",
            "options": [
                "Controlled growth of cells",
                "Uncontrolled growth of abnormal cells",
                "Death of cells",
                "Inflammation of cells"
            ],
            "answer": "Uncontrolled growth of abnormal cells",
            "explanation": "Cancer involves uncontrolled division of abnormal cells that invade other tissues."
        },
        {
            "type": "mcq",
            "q": "Normal human body temperature is:",
            "options": [
                "37°C or 98.4°F",
                "40°C or 104°F",
                "35°C or 95°F",
                "42°C or 107.6°F"
            ],
            "answer": "37°C or 98.4°F",
            "explanation": "Normal body temperature is 37°C or 98.4°F; fever is rise above this."
        },
        
        # ===== True/False (50 questions) =====
        {
            "type": "tf",
            "q": "Health means only absence of disease.",
            "answer": "False",
            "explanation": "Health includes complete physical, mental, and social well-being, not just absence of disease."
        },
        {
            "type": "tf",
            "q": "Congenital diseases are present from birth.",
            "answer": "True",
            "explanation": "Congenital diseases are inherited or caused by underdevelopment at birth."
        },
        {
            "type": "tf",
            "q": "Haemophilia is an acquired disease.",
            "answer": "False",
            "explanation": "Haemophilia is a congenital (inherited) bleeding disorder."
        },
        {
            "type": "tf",
            "q": "Communicable diseases can be passed from one person to another.",
            "answer": "True",
            "explanation": "Communicable diseases spread through air, water, food, vectors, or direct contact."
        },
        {
            "type": "tf",
            "q": "Non-communicable diseases are caused by pathogens.",
            "answer": "False",
            "explanation": "Non-communicable diseases are not caused by pathogens but by deficiencies, organ malfunction, etc."
        },
        {
            "type": "tf",
            "q": "All bacteria are harmful and cause diseases.",
            "answer": "False",
            "explanation": "Many bacteria are beneficial (e.g., gut flora, in food production); only some are pathogenic."
        },
        {
            "type": "tf",
            "q": "Viruses can reproduce only inside living cells.",
            "answer": "True",
            "explanation": "Viruses are obligate parasites that need host cells to multiply."
        },
        {
            "type": "tf",
            "q": "Tuberculosis is caused by a virus.",
            "answer": "False",
            "explanation": "Tuberculosis is caused by bacterium Mycobacterium tuberculosis."
        },
        {
            "type": "tf",
            "q": "Polio causes irreversible paralysis.",
            "answer": "True",
            "explanation": "Polio virus attacks nervous system, causing permanent paralysis in limbs."
        },
        {
            "type": "tf",
            "q": "Chickenpox rashes appear as small whitish spots on inner cheeks first.",
            "answer": "False",
            "explanation": "That is measles; chickenpox has itchy rashes with pink spots and blisters."
        },
        {
            "type": "tf",
            "q": "Ringworm is caused by a bacterium.",
            "answer": "False",
            "explanation": "Ringworm is a fungal infection of the skin."
        },
        {
            "type": "tf",
            "q": "Droplet infection spreads through coughs and sneezes.",
            "answer": "True",
            "explanation": "Air-borne diseases spread via droplets from respiratory tract of infected person."
        },
        {
            "type": "tf",
            "q": "Cholera is a waterborne disease.",
            "answer": "True",
            "explanation": "Cholera spreads through contaminated drinking water."
        },
        {
            "type": "tf",
            "q": "Malaria is spread by male Anopheles mosquito.",
            "answer": "False",
            "explanation": "Female Anopheles mosquito transmits malaria; males don't bite."
        },
        {
            "type": "tf",
            "q": "Aedes mosquito spreads dengue and yellow fever.",
            "answer": "True",
            "explanation": "Aedes mosquito transmits viruses causing dengue and yellow fever."
        },
        {
            "type": "tf",
            "q": "Plague is spread by rat flea.",
            "answer": "True",
            "explanation": "Rat flea transmits Yersinia pestis bacteria causing plague."
        },
        {
            "type": "tf",
            "q": "Contagious diseases spread through direct contact.",
            "answer": "True",
            "explanation": "Contagious diseases like conjunctivitis spread by touching infected person or sharing items."
        },
        {
            "type": "tf",
            "q": "Vaccines are made from weakened or killed pathogens.",
            "answer": "True",
            "explanation": "Vaccines contain weakened or killed germs to stimulate immunity without causing disease."
        },
        {
            "type": "tf",
            "q": "BCG vaccine protects against polio.",
            "answer": "False",
            "explanation": "BCG protects against tuberculosis; polio has separate oral vaccine."
        },
        {
            "type": "tf",
            "q": "Kwashiorkor is caused by protein deficiency.",
            "answer": "True",
            "explanation": "Kwashiorkor results from protein deficiency in young children."
        },
        {
            "type": "tf",
            "q": "Marasmus occurs in children over 5 years.",
            "answer": "False",
            "explanation": "Marasmus affects children under one year due to protein-calorie deficiency."
        },
        {
            "type": "tf",
            "q": "Night blindness is caused by vitamin A deficiency.",
            "answer": "True",
            "explanation": "Vitamin A deficiency impairs vision in dim light (night blindness)."
        },
        {
            "type": "tf",
            "q": "Scurvy causes bleeding gums.",
            "answer": "True",
            "explanation": "Vitamin C deficiency causes scurvy with bleeding gums and swollen joints."
        },
        {
            "type": "tf",
            "q": "Rickets causes softening of bones.",
            "answer": "True",
            "explanation": "Vitamin D deficiency causes rickets with soft, bent bones."
        },
        {
            "type": "tf",
            "q": "Goitre is enlargement of thyroid gland.",
            "answer": "True",
            "explanation": "Iodine deficiency causes thyroid gland enlargement (goitre)."
        },
        {
            "type": "tf",
            "q": "Anaemia is caused by iodine deficiency.",
            "answer": "False",
            "explanation": "Anaemia is caused by iron deficiency; iodine deficiency causes goitre."
        },
        {
            "type": "tf",
            "q": "Diabetes is caused by insulin deficiency.",
            "answer": "True",
            "explanation": "Diabetes mellitus results from insufficient insulin production or ineffective use."
        },
        {
            "type": "tf",
            "q": "Type 2 diabetes is related to obesity and inactivity.",
            "answer": "True",
            "explanation": "Type 2 diabetes is often linked to lifestyle factors like obesity and physical inactivity."
        },
        {
            "type": "tf",
            "q": "Atherosclerosis is plaque buildup in arteries.",
            "answer": "True",
            "explanation": "Atherosclerosis involves fatty plaque deposition in artery walls, narrowing them."
        },
        {
            "type": "tf",
            "q": "Rheumatoid arthritis affects joints of fingers.",
            "answer": "True",
            "explanation": "Rheumatoid arthritis causes swelling, pain, and deformity in finger joints."
        },
        {
            "type": "tf",
            "q": "Osteoarthritis affects knees and hips.",
            "answer": "True",
            "explanation": "Osteoarthritis commonly affects weight-bearing joints like knees and hips."
        },
        {
            "type": "tf",
            "q": "Cancer is always caused by smoking.",
            "answer": "False",
            "explanation": "Cancer has many causes including genetics, radiation, chemicals, viruses; smoking is one risk factor."
        },
        {
            "type": "tf",
            "q": "Malignant tumor is cancerous growth.",
            "answer": "True",
            "explanation": "Malignant tumors are cancerous, invading nearby tissues and spreading."
        },
        {
            "type": "tf",
            "q": "Allergy is normal response to allergens.",
            "answer": "False",
            "explanation": "Allergy is an unusual hypersensitivity to normally harmless substances."
        },
        {
            "type": "tf",
            "q": "Fever itself is a disease.",
            "answer": "False",
            "explanation": "Fever is a symptom indicating disease or infection, not a disease itself."
        },
        {
            "type": "tf",
            "q": "Temperature above 105°F is dangerous.",
            "answer": "True",
            "explanation": "Very high fever (above 105°F) can be dangerous and requires medical attention."
        },
        {
            "type": "tf",
            "q": "Personal hygiene includes bathing regularly.",
            "answer": "True",
            "explanation": "Personal hygiene involves keeping body clean through regular bathing, clean clothes, etc."
        },
        {
            "type": "tf",
            "q": "Washing hands prevents infections.",
            "answer": "True",
            "explanation": "Hand washing removes germs and is most effective way to prevent infection spread."
        },
        {
            "type": "tf",
            "q": "Teeth should be brushed once daily.",
            "answer": "False",
            "explanation": "Teeth should be brushed twice daily (morning and before bed) for good oral hygiene."
        },
        {
            "type": "tf",
            "q": "Crunchy vegetables like carrot clean teeth naturally.",
            "answer": "True",
            "explanation": "Crunchy vegetables help scrub teeth and stimulate saliva production."
        },
        {
            "type": "tf",
            "q": "Myopia is difficulty seeing nearby objects.",
            "answer": "False",
            "explanation": "Myopia (nearsightedness) is difficulty seeing distant objects; hypermetropia is difficulty seeing nearby."
        },
        {
            "type": "tf",
            "q": "Reading in dim light harms eyes.",
            "answer": "True",
            "explanation": "Reading in dim light strains eyes and can cause headaches and fatigue."
        },
        {
            "type": "tf",
            "q": "Community hygiene is individual responsibility only.",
            "answer": "False",
            "explanation": "Community hygiene involves collective efforts and civic bodies for public health."
        },
        {
            "type": "tf",
            "q": "Boiling water kills germs.",
            "answer": "True",
            "explanation": "Boiling water for 15 minutes kills most disease-causing microorganisms."
        },
        {
            "type": "tf",
            "q": "Chlorine tablets purify water.",
            "answer": "True",
            "explanation": "Chlorine tablets kill microorganisms in water, making it safe for drinking."
        },
        {
            "type": "tf",
            "q": "Sedimentation removes suspended impurities.",
            "answer": "True",
            "explanation": "Sedimentation allows heavy particles to settle at bottom, clarifying water."
        },
        {
            "type": "tf",
            "q": "Composting uses microorganisms to decompose waste.",
            "answer": "True",
            "explanation": "Composting is natural decomposition of organic waste into manure by microorganisms."
        },
        {
            "type": "tf",
            "q": "Vermicomposting uses earthworms.",
            "answer": "True",
            "explanation": "Earthworms speed up decomposition in vermicomposting, producing nutrient-rich compost."
        },
        {
            "type": "tf",
            "q": "Sewage should flow directly into water bodies.",
            "answer": "False",
            "explanation": "Sewage must be treated before release to prevent water pollution and disease spread."
        },
        {
            "type": "tf",
            "q": "Garbage dumps should be away from human habitation.",
            "answer": "True",
            "explanation": "Proper disposal away from homes prevents disease spread and nuisance."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "Define health according to WHO. Explain the difference between congenital and acquired diseases with examples.",
            "sample": "According to WHO (World Health Organization), 'Health is a state of complete physical, mental and social well-being and not merely an absence of disease or infirmity.'\n\nThis means:\n- Physical well-being: Body functions properly, no illness\n- Mental well-being: Healthy mind, able to cope with stress\n- Social well-being: Good relationships, ability to function in society\n\nCongenital diseases:\n- Present from birth\n- Caused by genetic abnormalities or underdevelopment of organs\n- Cannot be transmitted to others\n- Examples:\n  * Colour-blindness: Inability to distinguish certain colours\n  * Thalassemia: Blood disorder affecting haemoglobin production\n  * Haemophilia: Bleeding disorder due to clotting factor deficiency\n\nAcquired diseases:\n- Develop after birth\n- Can be communicable or non-communicable\n- Examples:\n  * Communicable: Cholera, malaria, tuberculosis\n  * Non-communicable: Diabetes, heart disease, deficiency diseases\n\nKey difference:\nCongenital diseases are inherited or present at birth; acquired diseases develop during lifetime due to various factors."
        },
        {
            "type": "subjective",
            "q": "What are pathogens? Name the different types of pathogens with examples of diseases caused by each.",
            "sample": "Pathogens are disease-causing microorganisms that invade the body and cause infections.\n\nTypes of pathogens with examples:\n\n1. Bacteria:\n   - Single-celled organisms\n   - Diseases caused:\n     * Cholera: Vibrio cholerae (severe diarrhoea)\n     * Tuberculosis: Mycobacterium tuberculosis (lung infection)\n     * Typhoid: Salmonella typhi (fever, intestinal issues)\n     * Diphtheria: Corynebacterium diphtheriae (throat infection)\n     * Tetanus: Clostridium tetani (muscle stiffness)\n     * Plague: Yersinia pestis (spread by rat fleas)\n\n2. Viruses:\n   - Smaller than bacteria, need host cells to multiply\n   - Diseases caused:\n     * Measles: (rash, fever)\n     * Chickenpox: (itchy blisters)\n     * Polio: (paralysis)\n     * Hepatitis: (liver inflammation)\n     * Influenza: (flu)\n     * Common cold\n     * AIDS: (immune deficiency)\n     * Rabies: (fatal neurological disease)\n\n3. Fungi:\n   - Can cause skin infections\n   - Diseases caused:\n     * Ringworm: (circular itchy patches)\n     * Athlete's foot: (foot infection)\n     * Food poisoning (some fungi)\n\n4. Protozoa:\n   - Single-celled, more complex than bacteria\n   - Diseases caused:\n     * Malaria: Plasmodium (spread by mosquitoes)\n     * Amoebic dysentery: Entamoeba (diarrhoea)\n     * Sleeping sickness: Trypanosoma (spread by tse-tse fly)\n\n5. Worms (Helminths):\n   - Multicellular parasites\n   - Diseases caused:\n     * Filariasis (elephantiasis)\n     * Taeniasis (tapeworm infection)\n     * Ascariasis (roundworm)"
        },
        {
            "type": "subjective",
            "q": "Explain the different modes of transmission of communicable diseases with examples.",
            "sample": "Communicable diseases spread through various modes:\n\n1. Through air (Droplet infection):\n   - Germs released through coughs, sneezes, talking\n   - Inhaled by healthy persons\n   - Examples:\n     * Common cold\n     * Influenza\n     * Tuberculosis\n     * Measles\n     * Diphtheria\n\n2. Through water (Waterborne diseases):\n   - Contaminated drinking water\n   - Water contaminated with infected faeces\n   - Swimming in infected water\n   - Examples:\n     * Cholera\n     * Typhoid\n     * Dysentery\n     * Hepatitis A\n\n3. Through food (Food-borne diseases):\n   - Contaminated or improperly cooked food\n   - Food handled by infected persons\n   - Stale or spoiled food\n   - Examples:\n     * Food poisoning\n     * Botulism\n     * Typhoid\n\n4. Through vectors (Vector-borne diseases):\n   - Insects and animals carry germs\n   - Transfer through bites or contact\n   - Examples:\n     * Malaria (Anopheles mosquito)\n     * Dengue (Aedes mosquito)\n     * Plague (rat flea)\n     * Sleeping sickness (tse-tse fly)\n     * Filariasis (Culex mosquito)\n\n5. Through direct contact (Contagious diseases):\n   - Direct physical contact with infected person\n   - Sharing personal items (towels, combs, glasses)\n   - Examples:\n     * Conjunctivitis\n     * Scabies\n     * Ringworm\n     * Chickenpox\n     * Measles\n\n6. Through blood and body fluids:\n   - Blood transfusion with infected blood\n   - Sharing needles\n   - Mother to baby during pregnancy/birth\n   - Examples:\n     * Hepatitis B and C\n     * HIV/AIDS\n\nPrevention depends on understanding these transmission modes and taking appropriate precautions."
        },
        {
            "type": "subjective",
            "q": "What are vectors? Name five vector-borne diseases, their pathogens, and the vectors that transmit them.",
            "sample": "Vectors are insects and animals that carry disease-causing germs from infected to healthy persons without getting sick themselves.\n\nCommon vector-borne diseases:\n\n| Disease | Pathogen | Vector |\n|---------|----------|--------|\n| Malaria | Plasmodium (protozoan) | Female Anopheles mosquito |\n| Dengue | DENV virus | Aedes mosquito |\n| Yellow fever | Yellow fever virus | Aedes mosquito |\n| Chikungunya | CHIKV virus | Aedes mosquito |\n| Filariasis (Elephantiasis) | Wuchereria bancrofti (roundworm) | Culex mosquito |\n| Plague | Yersinia pestis (bacteria) | Rat flea |\n| Sleeping sickness | Trypanosoma (protozoan) | Tse-tse fly |\n| Typhus | Rickettsia bacteria | Louse, flea, mite |\n| Japanese encephalitis | JE virus | Culex mosquito |\n| Lyme disease | Borrelia bacteria | Tick |\n\nDetailed information on major vector-borne diseases:\n\n1. Malaria:\n   - Pathogen: Plasmodium protozoan\n   - Vector: Female Anopheles mosquito\n   - Symptoms: Periodic fever with chills, anaemia\n   - Prevention: Mosquito nets, repellents, eliminate breeding\n\n2. Dengue:\n   - Pathogen: Dengue virus\n   - Vector: Aedes mosquito (day-biting)\n   - Symptoms: High fever, severe joint pain, bleeding, drop in platelets\n   - Prevention: Prevent water stagnation, use repellents\n\n3. Filariasis:\n   - Pathogen: Wuchereria bancrofti (roundworm)\n   - Vector: Culex mosquito\n   - Symptoms: Swelling of limbs, genitals (elephantiasis)\n   - Prevention: Mosquito control, anti-helminthic drugs\n\n4. Plague:\n   - Pathogen: Yersinia pestis bacteria\n   - Vector: Rat flea (Xenopsylla cheopis)\n   - Symptoms: Swollen lymph nodes, fever, pneumonia\n   - Prevention: Rodent control, flea control\n\n5. Yellow fever:\n   - Pathogen: Yellow fever virus\n   - Vector: Aedes mosquito\n   - Symptoms: Fever, jaundice, vomiting\n   - Prevention: Vaccination, mosquito control\n\nControl of vectors:\n- Eliminate breeding sites (stagnant water)\n- Use mosquito nets and repellents\n- Insecticide spraying\n- Biological control (Gambusia fish eat mosquito larvae)\n- Proper waste management\n- Community participation"
        },
        {
            "type": "subjective",
            "q": "Differentiate between communicable and non-communicable diseases with examples.",
            "sample": "Differences between communicable and non-communicable diseases:\n\n| Aspect | Communicable Diseases | Non-communicable Diseases |\n|--------|----------------------|--------------------------|\n| Definition | Diseases that can spread from infected to healthy person | Diseases that cannot spread from person to person |\n| Cause | Pathogens (bacteria, viruses, fungi, protozoa, worms) | Deficiencies, organ malfunction, genetic factors, lifestyle, allergies |\n| Transmission | Through air, water, food, vectors, contact | Not transmitted |\n| Prevention | Hygiene, vaccination, vector control | Balanced diet, healthy lifestyle, regular checkups |\n| Treatment | Antibiotics, antivirals, antifungals | Diet management, medication, surgery, lifestyle changes |\n| Contagiousness | Highly contagious | Not contagious |\n| Onset | Often sudden | Often gradual |\n| Duration | Usually acute (short duration) | Often chronic (long duration) |\n| Examples | Cholera, TB, malaria, cold, flu | Diabetes, heart disease, cancer, arthritis |\n\nExamples of communicable diseases:\n1. Cholera: Bacterial, waterborne, causes severe diarrhoea\n2. Tuberculosis: Bacterial, airborne, affects lungs\n3. Malaria: Protozoal, mosquito-borne, causes fever with chills\n4. Measles: Viral, airborne, causes rash and fever\n5. Ringworm: Fungal, contact, causes itchy skin patches\n\nExamples of non-communicable diseases:\n1. Diabetes: Insulin deficiency or resistance\n2. Heart disease: Atherosclerosis, hypertension\n3. Cancer: Uncontrolled cell growth\n4. Arthritis: Joint inflammation\n5. Deficiency diseases: Scurvy (vitamin C), rickets (vitamin D)\n6. Allergies: Hypersensitivity to allergens\n\nBoth types require different approaches for prevention and management.\n\nSimilarities:\n- Both affect health and well-being\n- Both may require medical attention\n- Both can be prevented with appropriate measures\n- Both can be acute or chronic"
        },
        {
            "type": "subjective",
            "q": "Explain the importance of vaccination in preventing communicable diseases.",
            "sample": "Vaccination is one of the most effective methods to prevent communicable diseases by building immunity.\n\nWhat is a vaccine?\n- Biological preparation made from weakened or killed pathogens\n- Stimulates body's immune system\n- Creates memory cells without causing disease\n- Provides long-term protection\n\nHow vaccines work:\n\n1. Vaccine introduced into body:\n   - Contains antigens (weakened/killed germs)\n   - Safe, cannot cause disease\n\n2. Immune response:\n   - Body produces antibodies against antigens\n   - Creates memory B-cells and T-cells\n   - Builds immunity without suffering from disease\n\n3. Future exposure:\n   - If actual pathogen enters body\n   - Memory cells recognize it quickly\n   - Rapid antibody production\n   - Pathogen destroyed before causing illness\n\nTypes of vaccines:\n1. Killed/inactivated vaccines (polio injection)\n2. Live attenuated (weakened) vaccines (MMR, oral polio)\n3. Toxoid vaccines (tetanus, diphtheria)\n4. Subunit vaccines (Hepatitis B)\n5. mRNA vaccines (some COVID-19 vaccines)\n\nCommon vaccines and diseases prevented:\n\n| Vaccine | Diseases prevented |\n|---------|-------------------|\n| BCG | Tuberculosis |\n| DPT | Diphtheria, Pertussis, Tetanus |\n| MMR | Measles, Mumps, Rubella |\n| OPV/IPV | Polio |\n| Hepatitis B | Hepatitis B |\n| TT | Tetanus |\n| Typhoid | Typhoid fever |\n| Chickenpox | Varicella |\n| HPV | Cervical cancer |\n| COVID-19 | Coronavirus disease |\n\nBenefits of vaccination:\n\n1. Individual protection:\n   - Prevents serious illness\n   - Reduces complications\n   - Saves lives\n\n2. Herd immunity:\n   - When enough people vaccinated\n   - Protects vulnerable who cannot vaccinate\n   - Breaks disease transmission chain\n\n3. Disease eradication:\n   - Smallpox eradicated globally (1980)\n   - Polio nearly eradicated\n   - Measles, rubella targeted\n\n4. Economic benefits:\n   - Reduces healthcare costs\n   - Prevents lost work/school days\n   - More cost-effective than treatment\n\n5. Safe:\n   - Rigorously tested\n   - Monitored for safety\n   - Side effects usually mild\n\nVaccination schedule (India):\n- Birth: BCG, OPV, Hepatitis B\n- 6 weeks: DPT, OPV, Hepatitis B\n- 10 weeks: DPT, OPV\n- 14 weeks: DPT, OPV\n- 9 months: Measles, Vitamin A\n- 16-24 months: DPT, OPV booster\n- 5-6 years: DT booster\n- 10 years: TT\n- 16 years: TT\n\nThus, vaccination is a safe, effective way to protect individuals and communities from deadly diseases."
        },
        {
            "type": "subjective",
            "q": "What are deficiency diseases? Explain protein-energy malnutrition (PEM) with its two types.",
            "sample": "Deficiency diseases are conditions caused by lack of one or more essential nutrients in the diet over a period of time.\n\nCauses:\n- Inadequate food intake\n- Poor quality diet lacking specific nutrients\n- Malabsorption of nutrients\n- Increased nutrient requirements (growth, pregnancy)\n\nProtein-Energy Malnutrition (PEM):\n- Most common nutritional deficiency worldwide\n- Affects mainly infants and young children (1-5 years)\n- Deficiency of proteins, carbohydrates, and fats\n- Two main forms: Kwashiorkor and Marasmus\n\nKwashiorkor:\n\nCause:\n- Primarily protein deficiency\n- Carbohydrate intake may be adequate\n- Usually occurs after weaning\n\nSymptoms:\n- Stunted growth\n- Swollen belly (oedema due to fluid retention)\n- Thin, stick-like legs\n- Bulging eyes\n- Mental retardation\n- Discoloured, thinning hair\n- Skin lesions and peeling\n- Frequent diarrhoea\n- Irritability, apathy\n- Fatty liver\n\nAge group: Usually 1-3 years\n\nMarasmus:\n\nCause:\n- Deficiency of both proteins and calories\n- Severe malnutrition\n- Often in infants under one year\n- Due to starvation or chronic illness\n\nSymptoms:\n- Severe wasting (skin and bones appearance)\n- Prominent ribs and bones\n- Dry, thin, wrinkled skin (old man appearance)\n- Lean and weak body\n- No oedema (no swelling)\n- Mental retardation\n- Constant hunger\n- Weak cry\n- Low body temperature\n\nAge group: Usually under 1 year\n\nComparison of Kwashiorkor and Marasmus:\n\n| Feature | Kwashiorkor | Marasmus |\n|---------|-------------|----------|\n| Main deficiency | Protein | Protein and calories |\n| Age | 1-3 years | Under 1 year |\n| Oedema | Present (swollen belly) | Absent |\n| Subcutaneous fat | Some present | Absent |\n| Muscle wasting | Moderate | Severe |\n| Appetite | Poor | Often good |\n| Skin changes | Present | Minimal |\n| Hair changes | Present | May be normal |\n| Fatty liver | Present | Absent |\n\nPrevention of PEM:\n- Adequate nutrition during pregnancy\n- Exclusive breastfeeding for 6 months\n- Proper complementary feeding after 6 months\n- Balanced diet with proteins, carbs, fats\n- Regular growth monitoring\n- Education on nutrition\n- Food supplementation programs\n\nTreatment:\n- Gradual nutritional rehabilitation\n- High-protein, high-energy foods\n- Vitamin and mineral supplements\n- Treat infections\n- Long-term follow-up"
        },
        {
            "type": "subjective",
            "q": "List the vitamins, their deficiency diseases, and sources in a table.",
            "sample": "Vitamins are essential nutrients required in small amounts for proper body functioning.\n\n| Vitamin | Deficiency Disease | Symptoms | Major Sources |\n|---------|-------------------|----------|---------------|\n| Vitamin A (Retinol) | Night blindness, Xerophthalmia | Poor vision in dim light, dry eyes, dry skin | Carrots, papaya, mango, spinach, fish, egg, milk |\n| Vitamin B1 (Thiamine) | Beriberi | Weakness, fatigue, nerve damage, heart problems | Yeast, unpolished rice, whole grains, eggs, pork |\n| Vitamin B2 (Riboflavin) | Ariboflavinosis | Cracks at mouth corners, sore throat, red tongue | Milk, eggs, green vegetables, liver |\n| Vitamin B3 (Niacin) | Pellagra | Diarrhoea, dermatitis, dementia | Meat, fish, peanuts, whole grains |\n| Vitamin B5 (Pantothenic acid) | Rare (burning feet syndrome) | Fatigue, numbness | Almost all foods |\n| Vitamin B6 (Pyridoxine) | Anaemia, skin disorders | Irritability, depression, confusion | Meat, fish, poultry, bananas, potatoes |\n| Vitamin B7 (Biotin) | Rare | Hair loss, skin rash | Eggs, liver, yeast |\n| Vitamin B9 (Folic acid) | Anaemia (megaloblastic) | Weakness, fatigue, birth defects | Green leafy vegetables, legumes, nuts |\n| Vitamin B12 (Cobalamin) | Pernicious anaemia | Weakness, nerve damage, memory loss | Meat, fish, eggs, dairy (not in plants) |\n| Vitamin C (Ascorbic acid) | Scurvy | Bleeding gums, swollen joints, poor wound healing | Citrus fruits (orange, lemon), amla, tomato, leafy veg |\n| Vitamin D (Calciferol) | Rickets (children), Osteomalacia (adults) | Soft, bent bones, bone pain | Sunlight, milk, eggs, liver, fish |\n| Vitamin E (Tocopherol) | Rare (nerve problems) | Muscle weakness, reproductive issues | Wheat germ, vegetable oils, nuts, seeds |\n| Vitamin K | Bleeding disorders | Excessive bleeding, haemorrhage | Green leafy veg (cabbage, spinach), soybean, liver |\n\nFat-soluble vitamins (A, D, E, K):\n- Stored in body (especially liver)\n- Excess can be toxic\n- Need fat for absorption\n\nWater-soluble vitamins (B-complex, C):\n- Not stored (excreted in urine)\n- Need regular intake\n- Excess usually not toxic\n\nGeneral symptoms of vitamin deficiencies:\n- Fatigue, weakness\n- Poor growth\n- Skin problems\n- Nerve issues\n- Anaemia\n- Weakened immunity\n\nPrevention:\n- Balanced diet with variety\n- Include fruits, vegetables, whole grains\n- Adequate sunlight for vitamin D\n- Fortified foods when needed\n- Supplements if deficient (under medical advice)"
        },
        {
            "type": "subjective",
            "q": "List the minerals, their functions, deficiency diseases, and sources in a table.",
            "sample": "Minerals are inorganic nutrients essential for various body functions.\n\n| Mineral | Functions | Deficiency Disease/Symptoms | Sources |\n|---------|-----------|----------------------------|---------|\n| Calcium | Bones and teeth formation, blood clotting, muscle contraction, nerve function | Rickets (children), Osteomalacia (adults), osteoporosis, muscle cramps | Milk, cheese, yoghurt, eggs, fish, green leafy veg |\n| Phosphorus | Bones and teeth, energy metabolism, cell membranes | Weak bones, poor teeth, weakness | Milk, meat, nuts, beans, grains, fish |\n| Iron | Haemoglobin formation, oxygen transport | Anaemia: fatigue, weakness, pale skin, shortness of breath | Green leafy veg, egg yolk, liver, meat, beans, fortified cereals |\n| Iodine | Thyroid hormone (thyroxine) production, metabolism | Goitre (enlarged thyroid), cretinism in children | Iodized salt, seafood, fish, seaweed |\n| Sodium | Nerve function, muscle contraction, water balance | Muscle cramps, weakness, dehydration (rare) | Table salt, processed foods, seafood |\n| Potassium | Nerve function, muscle contraction, heart rhythm | Muscle weakness, paralysis, irregular heartbeat | Bananas, potatoes, vegetables, milk, meat |\n| Chlorine | Fluid balance, stomach acid (HCl) production | Weakness, dehydration (rare) | Table salt, seafood |\n| Magnesium | Enzyme activation, muscle function, bone health | Muscle cramps, weakness, irregular heartbeat | Nuts, seeds, whole grains, green veg |\n| Zinc | Immunity, wound healing, growth, enzyme function | Poor growth, delayed healing, hair loss | Meat, shellfish, nuts, seeds, legumes |\n| Fluorine | Tooth enamel strength, prevents cavities | Tooth decay, weak bones | Fluoridated water, tea, seafood |\n| Copper | Iron metabolism, RBC formation, nerve function | Anaemia, bone abnormalities | Liver, nuts, seeds, whole grains |\n| Selenium | Antioxidant, thyroid function | Muscle weakness, heart problems | Brazil nuts, fish, meat, eggs |\n\nMajor minerals (required >100mg/day):\n- Calcium, Phosphorus, Sodium, Potassium, Chlorine, Magnesium\n\nTrace minerals (required <100mg/day):\n- Iron, Iodine, Zinc, Copper, Fluorine, Selenium, Manganese, etc.\n\nImportance of minerals:\n\n1. Structural:\n   - Calcium, phosphorus: Bones and teeth\n   - Sulphur: Hair, skin, nails\n\n2. Regulatory:\n   - Sodium, potassium: Fluid balance, nerve impulses\n   - Calcium: Muscle contraction, blood clotting\n\n3. Component of essential molecules:\n   - Iron: Haemoglobin\n   - Iodine: Thyroid hormone\n   - Zinc: Enzymes\n\nDeficiency effects:\n- Impaired growth and development\n- Weakened immunity\n- Metabolic disorders\n- Specific disease conditions\n\nPrevention:\n- Balanced diet with variety\n- Include dairy, vegetables, fruits\n- Use iodized salt\n- Fortified foods when needed\n- Supplements if deficient (medical advice)\n\nInteractions:\n- Vitamin D helps calcium absorption\n- Vitamin C helps iron absorption\n- Calcium and phosphorus need proper ratio\n- Excess of one mineral can affect another"
        },
        {
            "type": "subjective",
            "q": "What is diabetes? Explain its types, causes, symptoms, and management.",
            "sample": "Diabetes mellitus is a metabolic disorder characterized by high blood sugar levels due to problems with insulin production or action.\n\nWhat is insulin?\n- Hormone produced by pancreas (beta cells of Islets of Langerhans)\n- Regulates blood glucose level\n- Helps cells take up glucose from blood\n- Converts excess glucose to glycogen in liver\n\nTypes of diabetes:\n\n1. Type 1 Diabetes (Insulin-dependent):\n   Cause:\n   - Autoimmune destruction of insulin-producing cells\n   - Body produces little or no insulin\n   - Usually develops in childhood/adolescence\n   - Accounts for 5-10% of cases\n   \n   Treatment:\n   - Requires daily insulin injections\n   - Cannot be prevented\n   - Blood sugar monitoring essential\n\n2. Type 2 Diabetes (Non-insulin-dependent):\n   Cause:\n   - Insulin resistance (cells don't respond properly)\n   - Relative insulin deficiency\n   - Linked to obesity, inactivity, genetics\n   - Usually develops in adults (increasing in youth)\n   - Accounts for 90-95% of cases\n   \n   Treatment:\n   - Lifestyle changes (diet, exercise)\n   - Oral medications\n   - May need insulin eventually\n   - Can be prevented or delayed\n\n3. Gestational Diabetes:\n   - Develops during pregnancy\n   - Usually resolves after delivery\n   - Increases risk of type 2 later\n\n4. Other types:\n   - Genetic defects\n   - Drug-induced\n   - Pancreatic disease\n\nSymptoms of diabetes:\n- Frequent urination (polyuria)\n- Excessive thirst (polydipsia)\n- Excessive hunger (polyphagia)\n- Unexplained weight loss\n- Fatigue, weakness\n- Blurred vision\n- Slow wound healing\n- Frequent infections\n- Numbness or tingling in hands/feet\n\nComplications (long-term):\n- Cardiovascular disease\n- Kidney disease (nephropathy)\n- Nerve damage (neuropathy)\n- Eye damage (retinopathy) - blindness\n- Foot problems (amputation risk)\n- Skin conditions\n- Hearing impairment\n- Alzheimer's risk increased\n\nDiagnosis:\n- Fasting blood sugar: ≥126 mg/dL\n- Random blood sugar: ≥200 mg/dL with symptoms\n- HbA1c: ≥6.5% (average 3-month sugar)\n- Oral glucose tolerance test\n\nManagement of diabetes:\n\n1. Diet:\n   - Balanced meals\n   - Control carbohydrate intake\n   - High fiber foods\n   - Limit sugar, sweets\n   - Regular meal timing\n   - Portion control\n\n2. Exercise:\n   - Regular physical activity\n   - At least 30 minutes daily\n   - Helps insulin sensitivity\n   - Weight management\n\n3. Medications:\n   - Insulin injections (Type 1, some Type 2)\n   - Oral hypoglycaemic drugs (Type 2)\n   - As prescribed by doctor\n\n4. Blood sugar monitoring:\n   - Regular self-monitoring\n   - Keep records\n   - Adjust treatment accordingly\n\n5. Weight management:\n   - Maintain healthy weight\n   - Especially important in Type 2\n\n6. Education:\n   - Learn about condition\n   - Recognize symptoms of high/low sugar\n   - Know what to do in emergencies\n\n7. Regular checkups:\n   - HbA1c every 3-6 months\n   - Eye exams\n   - Foot exams\n   - Kidney function tests\n   - Cholesterol checks\n\nPrevention of Type 2 diabetes:\n- Healthy weight\n- Regular exercise\n- Balanced diet\n- Avoid sugary drinks\n- Don't smoke\n- Limit alcohol\n- Regular screening if at risk"
        },
        {
            "type": "subjective",
            "q": "What are heart diseases? Explain atherosclerosis, coronary heart disease, and heart attack.",
            "sample": "Heart diseases (cardiovascular diseases) are disorders of the heart and blood vessels, often related to atherosclerosis.\n\nAtherosclerosis:\n\nDefinition:\n- Build-up of plaque inside arteries\n- Plaque consists of fat, cholesterol, calcium, and other substances\n- Arteries become hard, thick, and narrow\n\nProcess:\n1. Damage to artery lining (from smoking, high BP, high cholesterol)\n2. Cholesterol and fats accumulate at damage site\n3. Inflammatory cells gather\n4. Plaque forms and grows\n5. Artery narrows, blood flow reduced\n6. Plaque may rupture, causing clot\n\nRisk factors:\n- High cholesterol\n- High blood pressure\n- Smoking\n- Diabetes\n- Obesity\n- Physical inactivity\n- Unhealthy diet\n- Family history\n- Age\n\nCoronary Heart Disease (CHD):\n\nDefinition:\n- Atherosclerosis in coronary arteries (arteries supplying heart muscle)\n- Reduced blood flow to heart muscle\n\nEffects:\n- Angina (chest pain):\n  * Temporary chest pain or pressure\n  * Occurs when heart works harder (exercise, stress)\n  * Relieved by rest or medication\n- Shortness of breath\n- Fatigue\n- May lead to heart attack\n\nHeart Attack (Myocardial Infarction):\n\nDefinition:\n- Complete blockage of coronary artery\n- Part of heart muscle deprived of oxygen\n- Heart muscle begins to die\n\nCause:\n- Plaque rupture in coronary artery\n- Blood clot forms at rupture site\n- Artery completely blocked\n- No blood flow to heart muscle beyond blockage\n\nSymptoms:\n- Chest pain or discomfort (pressure, squeezing, fullness)\n- Pain spreading to shoulder, arm, back, neck, jaw\n- Shortness of breath\n- Cold sweat\n- Nausea, vomiting\n- Lightheadedness, dizziness\n- Women may have atypical symptoms\n\nEmergency: Call for help immediately\n\nTreatment:\n- Emergency angioplasty (open blocked artery)\n- Clot-busting drugs\n- Aspirin\n- Oxygen\n- Pain relief\n- Long-term medications\n\nOther heart conditions:\n\n1. Heart failure:\n   - Heart can't pump enough blood\n   - Not sudden stop, but gradual weakening\n   - Causes shortness of breath, swelling in legs\n\n2. Arrhythmias:\n   - Irregular heartbeat\n   - Too fast (tachycardia), too slow (bradycardia)\n   - May cause palpitations, dizziness\n\n3. Valve problems:\n   - Stenosis (narrowing)\n   - Regurgitation (leaking)\n   - May need repair or replacement\n\nPrevention of heart disease:\n\n1. Healthy diet:\n   - Low in saturated fats, trans fats\n   - High in fruits, vegetables, whole grains\n   - Limit salt, sugar\n   - Omega-3 fatty acids (fish)\n\n2. Regular exercise:\n   - At least 150 minutes moderate activity weekly\n   - Aerobic exercise\n\n3. No smoking:\n   - Single most important preventable risk factor\n\n4. Healthy weight:\n   - Maintain BMI <25\n   - Waist circumference control\n\n5. Manage conditions:\n   - Control blood pressure\n   - Control cholesterol\n   - Control diabetes\n\n6. Limit alcohol\n\n7. Manage stress\n\n8. Regular checkups\n\nStatistics:\n- Leading cause of death worldwide\n- About 45 million Indians affected by CHD\n- India projected to have highest number by 2020"
        },
        {
            "type": "subjective",
            "q": "What is arthritis? Explain the two main types: rheumatoid arthritis and osteoarthritis.",
            "sample": "Arthritis is inflammation of one or more joints, causing pain, swelling, stiffness, and reduced movement.\n\nTypes of arthritis:\n\n1. Osteoarthritis:\n   - Most common type\n   - Degenerative joint disease\n   - 'Wear and tear' arthritis\n\n   Cause:\n   - Breakdown of cartilage (cushioning at joints)\n   - Cartilage wears away over time\n   - Bone rubs against bone\n   - Risk factors: Ageing, obesity, injury, genetics, overuse\n\n   Affected joints:\n   - Weight-bearing joints: knees, hips, spine\n   - Hands (especially fingers)\n\n   Symptoms:\n   - Pain during movement, better with rest\n   - Stiffness, especially morning or after inactivity\n   - Swelling\n   - Grating sensation (crepitus)\n   - Bone spurs (osteophytes)\n   - Limited range of motion\n\n   Progression:\n   - Gradual onset\n   - Worsens over years\n   - Not symmetrical (may affect one knee more)\n\n2. Rheumatoid Arthritis:\n   - Autoimmune disease\n   - Body's immune system attacks joint lining\n   - Chronic inflammatory condition\n\n   Cause:\n   - Immune system attacks synovium (joint lining)\n   - Inflammation damages cartilage and bone\n   - Exact trigger unknown (genetic + environmental)\n   - Autoantibodies (rheumatoid factor)\n\n   Affected joints:\n   - Small joints of hands and feet first\n   - Usually symmetrical (both sides)\n   - Wrists, elbows, shoulders, knees, ankles\n\n   Symptoms:\n   - Swollen, tender, warm joints\n   - Morning stiffness lasting >30 minutes\n   - Fatigue, fever, weight loss\n   - Rheumatoid nodules (under skin)\n   - Joint deformity over time\n   - Fingers may become twisted\n\n   Systemic effects:\n   - Can affect other organs: eyes, lungs, heart, blood vessels\n\nComparison:\n\n| Feature | Osteoarthritis | Rheumatoid Arthritis |\n|---------|----------------|----------------------|\n| Type | Degenerative | Autoimmune |\n| Cause | Wear and tear | Immune attack on joints |\n| Age onset | Usually older (>50) | Any age (30-50 common) |\n| Onset | Gradual | Can be sudden |\n| Joints affected | Weight-bearing, hands | Small joints, symmetrical |\n| Morning stiffness | Brief (<30 min) | Prolonged (>30 min) |\n| Swelling | Mild, bony | Soft, inflammatory |\n| Systemic symptoms | No | Yes (fatigue, fever) |\n| Blood tests | Normal | Rheumatoid factor, anti-CCP |\n| X-ray findings | Joint space narrowing, bone spurs | Erosions, joint damage |\n\nOther types of arthritis:\n\n3. Gout:\n   - Caused by uric acid crystals in joints\n   - Sudden, severe pain (often big toe)\n   - Related to diet, genetics\n\n4. Psoriatic arthritis:\n   - Associated with psoriasis (skin condition)\n\n5. Ankylosing spondylitis:\n   - Affects spine\n   - Causes fusion of vertebrae\n\n6. Juvenile arthritis:\n   - Arthritis in children\n\nTreatment:\n\n1. Medications:\n   - Pain relievers (paracetamol)\n   - NSAIDs (ibuprofen, naproxen)\n   - Disease-modifying drugs (for rheumatoid)\n   - Biologics\n   - Corticosteroids\n\n2. Physical therapy:\n   - Exercises to maintain mobility\n   - Strengthen muscles around joints\n   - Range of motion exercises\n\n3. Lifestyle:\n   - Weight management (reduces joint stress)\n   - Low-impact exercise (swimming, walking)\n   - Assistive devices (canes, splints)\n   - Heat/cold therapy\n\n4. Surgery:\n   - Joint replacement (knee, hip)\n   - Joint fusion\n   - Synovectomy (remove inflamed lining)\n\n5. Alternative therapies:\n   - Acupuncture\n   - Supplements (glucosamine - controversial)\n   - Always consult doctor first\n\nThus, arthritis is a common but manageable condition with proper treatment and lifestyle adjustments."
        },
        {
            "type": "subjective",
            "q": "What is cancer? Explain the causes, types, and warning signs.",
            "sample": "Cancer is a disease characterized by uncontrolled growth and spread of abnormal cells in the body.\n\nWhat is cancer?\n- Normal cells grow, divide, and die in controlled manner\n- Cancer cells lose this control\n- They divide uncontrollably\n- Can invade nearby tissues\n- Can spread to other parts (metastasis)\n\nHow cancer develops:\n\n1. Initiation:\n   - Genetic mutation in a cell\n   - DNA damage from various causes\n   - Cell begins to divide abnormally\n\n2. Promotion:\n   - Mutated cells multiply\n   - Form mass of abnormal cells\n\n3. Progression:\n   - Cells become more abnormal\n   - Acquire ability to invade\n   - Can spread (metastasize)\n\nTypes of tumors:\n\n1. Benign tumors:\n   - Not cancerous\n   - Grow slowly\n   - Do not invade nearby tissue\n   - Do not spread\n   - Usually not life-threatening\n   - Can be removed, rarely recur\n\n2. Malignant tumors:\n   - Cancerous\n   - Grow rapidly\n   - Invade nearby tissues\n   - Can spread through blood/lymph\n   - Life-threatening\n   - May recur after removal\n\nTypes of cancer (named by origin):\n\n1. Carcinoma:\n   - Most common type\n   - Originates in skin or lining of organs\n   - Examples: Lung, breast, colon, prostate cancer\n\n2. Sarcoma:\n   - Originates in bone, cartilage, fat, muscle, blood vessels\n   - Less common\n   - Examples: Osteosarcoma (bone), liposarcoma (fat)\n\n3. Leukaemia:\n   - Cancer of blood-forming tissues (bone marrow)\n   - Abnormal white blood cells\n   - Not solid tumors\n   - Types: Acute lymphoblastic, acute myeloid, etc.\n\n4. Lymphoma:\n   - Originates in lymphatic system\n   - Affects lymphocytes\n   - Types: Hodgkin lymphoma, Non-Hodgkin lymphoma\n\n5. Myeloma:\n   - Cancer of plasma cells in bone marrow\n\nCauses and risk factors:\n\n1. Genetic factors:\n   - Inherited gene mutations\n   - Family history\n   - Only 5-10% of cancers\n\n2. Lifestyle factors:\n   - Tobacco use (leading cause): lung, mouth, throat, bladder\n   - Alcohol: liver, oesophagus, breast\n   - Diet: processed meats, low fiber\n   - Obesity: several cancers\n   - Physical inactivity\n\n3. Environmental exposures:\n   - UV radiation: skin cancer\n   - Ionizing radiation: various cancers\n   - Chemicals: asbestos (lung), benzene (leukaemia)\n   - Air pollution\n\n4. Infections:\n   - HPV: cervical cancer\n   - Hepatitis B/C: liver cancer\n   - H. pylori: stomach cancer\n   - Epstein-Barr: lymphoma\n\n5. Age:\n   - Risk increases with age\n   - Most cancers in older adults\n\nCommon warning signs (CAUTION):\n\nC - Change in bowel or bladder habits\nA - A sore that does not heal\nU - Unusual bleeding or discharge\nT - Thickening or lump in breast or elsewhere\nI - Indigestion or difficulty swallowing\nO - Obvious change in wart or mole\nN - Nagging cough or hoarseness\n\nOther signs:\n- Unexplained weight loss\n- Persistent fatigue\n- Persistent pain\n- Night sweats\n- Fever without infection\n\nPrevention:\n\n1. Avoid tobacco (smoking, chewing)\n2. Healthy diet: fruits, vegetables, whole grains\n3. Maintain healthy weight\n4. Regular physical activity\n5. Limit alcohol\n6. Protect skin from sun (sunscreen, clothing)\n7. Avoid carcinogens when possible\n8. Vaccination (HPV, Hepatitis B)\n9. Regular screenings:\n   - Breast: mammogram\n   - Cervical: Pap smear\n   - Colon: colonoscopy\n   - Skin: skin checks\n10. Know family history\n\nTreatment:\n\n1. Surgery: Remove tumor\n2. Radiation therapy: High-energy rays kill cancer cells\n3. Chemotherapy: Drugs kill cancer cells\n4. Immunotherapy: Boost immune system to fight cancer\n5. Targeted therapy: Drugs target specific cancer genes\n6. Hormone therapy: For hormone-sensitive cancers\n7. Stem cell transplant: For blood cancers\n\nPrognosis depends on:\n- Type and stage of cancer\n- Early detection\n- Patient's overall health\n- Response to treatment\n\nThus, cancer is a complex group of diseases, but early detection and modern treatments improve outcomes."
        },
        {
            "type": "subjective",
            "q": "What is an allergy? Name common allergens and their effects.",
            "sample": "An allergy is an abnormal or hypersensitive reaction of the body's immune system to normally harmless substances called allergens.\n\nWhat happens in an allergic reaction?\n\n1. First exposure:\n   - Immune system mistakenly identifies allergen as harmful\n   - Produces specific antibodies (IgE)\n   - Antibodies attach to mast cells\n   - Person becomes sensitized (no symptoms yet)\n\n2. Subsequent exposure:\n   - Allergen binds to IgE on mast cells\n   - Mast cells release chemicals (histamine, etc.)\n   - These chemicals cause allergic symptoms\n   - Reaction occurs within minutes to hours\n\nCommon allergens and their effects:\n\n| Allergen Type | Examples | Effects/Symptoms |\n|---------------|----------|------------------|\n| Foods | Peanuts, tree nuts, milk, eggs, wheat, soy, shellfish, fish | Hives, swelling, vomiting, diarrhoea, anaphylaxis |\n| Pollen | Grass, tree, weed pollen (hay fever) | Sneezing, runny nose, itchy eyes, congestion |\n| Dust mites | Microscopic mites in house dust | Sneezing, runny nose, asthma, eczema |\n| Animal dander | Cats, dogs, horses, rodents | Sneezing, wheezing, itchy eyes, skin rash |\n| Moulds | Fungal spores indoors/outdoors | Nasal congestion, wheezing, itchy eyes |\n| Insect stings | Bee, wasp, hornet, ant | Local swelling, hives, anaphylaxis |\n| Medications | Penicillin, aspirin, sulfa drugs | Rash, hives, fever, anaphylaxis |\n| Latex | Gloves, balloons, medical devices | Skin rash, hives, wheezing |\n| Cosmetics | Perfumes, makeup, hair products | Contact dermatitis (rash, itching) |\n| Metals | Nickel (jewellery), cobalt | Contact dermatitis |\n\nTypes of allergic reactions:\n\n1. Respiratory allergies:\n   - Allergic rhinitis (hay fever): sneezing, runny nose, itchy eyes\n   - Asthma: wheezing, coughing, shortness of breath\n\n2. Skin allergies:\n   - Eczema (atopic dermatitis): itchy, red, dry skin\n   - Urticaria (hives): raised, itchy welts\n   - Contact dermatitis: rash from skin contact with allergen\n\n3. Food allergies:\n   - Can affect skin, breathing, digestion\n   - Symptoms: hives, swelling, vomiting, diarrhoea\n   - Severe: anaphylaxis\n\n4. Drug allergies:\n   - Rash, hives, fever\n   - Severe: anaphylaxis, Stevens-Johnson syndrome\n\n5. Insect sting allergies:\n   - Local swelling, pain\n   - Severe: anaphylaxis\n\nSevere allergic reaction: Anaphylaxis\n\nSymptoms:\n- Difficulty breathing\n- Swelling of throat, tongue\n- Drop in blood pressure\n- Rapid pulse\n- Dizziness, fainting\n- Loss of consciousness\n\nEmergency: Life-threatening, requires immediate epinephrine injection and medical attention\n\nDiagnosis of allergies:\n- Medical history\n- Skin prick test: small amount of allergen placed on skin, pricked, observe reaction\n- Blood test: measure specific IgE antibodies\n- Elimination diet: remove suspected foods, then reintroduce\n- Patch test: for contact dermatitis\n\nTreatment and management:\n\n1. Avoidance:\n   - Best approach - avoid known allergens\n   - Read food labels carefully\n   - Keep home clean, reduce dust mites\n   - Use air purifiers\n   - Avoid pets if allergic\n\n2. Medications:\n   - Antihistamines: block histamine (cetirizine, loratadine)\n   - Decongestants: relieve nasal congestion\n   - Nasal corticosteroids: reduce inflammation\n   - Eye drops: for allergic conjunctivitis\n   - Bronchodilators: for asthma\n   - Epinephrine (adrenaline): for anaphylaxis (EpiPen)\n\n3. Immunotherapy (allergy shots):\n   - Gradual exposure to increasing allergen doses\n   - Builds tolerance over time\n   - Effective for pollen, dust mites, insect stings\n\n4. Emergency plan:\n   - People with severe allergies carry epinephrine auto-injector\n   - Wear medical alert bracelet\n   - Inform friends, family, school\n\nThus, allergies are common but manageable with proper identification and treatment."
        },
        {
            "type": "subjective",
            "q": "Explain the importance of personal hygiene in preventing diseases.",
            "sample": "Personal hygiene refers to practices that keep our body clean and healthy, preventing the spread of diseases.\n\nImportance of personal hygiene:\n- Prevents infections\n- Reduces disease transmission\n- Promotes overall health\n- Improves self-esteem\n- Social acceptance\n\nKey aspects of personal hygiene:\n\n1. Skin hygiene (Bathing):\n   - Bathe daily with soap and water\n   - Removes sweat, dirt, dead skin cells\n   - Prevents body odour\n   - Removes germs from skin surface\n   - Prevents skin infections\n   - Keeps skin healthy\n\n2. Hand hygiene:\n   - Most important for preventing infection spread\n   - Wash hands:\n     * Before and after meals\n     * After using toilet\n     * After touching animals\n     * After coughing/sneezing\n     * After touching garbage\n     * After playing outdoors\n     * Before preparing food\n   - Scrub for at least 20 seconds with soap\n   - Cover all surfaces: palms, back, between fingers, nails\n   - Rinse well, dry with clean towel\n   - Hand sanitizer when soap not available\n\n3. Oral hygiene:\n   - Brush teeth twice daily (morning and before bed)\n   - Use fluoride toothpaste\n   - Brush for 2-3 minutes\n   - Clean all tooth surfaces\n   - Floss daily to remove food between teeth\n   - Rinse mouth after meals\n   - Visit dentist regularly\n   - Prevents tooth decay, gum disease, bad breath\n\n4. Hair hygiene:\n   - Wash hair with shampoo at least weekly\n   - Removes dirt, oil, dandruff\n   - Prevents lice infestation\n   - Comb hair daily\n   - Keep hair clean and tidy\n   - Massage scalp with oil for health\n\n5. Nail hygiene:\n   - Keep nails short and clean\n   - Trim regularly\n   - Clean under nails\n   - Prevent dirt and germ accumulation\n   - Avoid biting nails\n\n6. Foot hygiene:\n   - Wash feet daily\n   - Dry thoroughly, especially between toes\n   - Wear clean socks\n   - Change socks daily\n   - Wear breathable footwear\n   - Prevents fungal infections (athlete's foot)\n\n7. Clothing hygiene:\n   - Wear clean clothes daily\n   - Change undergarments daily\n   - Wash clothes regularly\n   - Especially important for socks and underwear\n   - Prevents skin infections\n\n8. Toilet hygiene:\n   - Use clean toilets\n   - Flush after use\n   - Wash hands thoroughly after\n   - Keep toilet area clean\n\nHow poor hygiene leads to disease:\n\n1. Direct transmission:\n   - Germs on hands contaminate food\n   - Enter body through mouth\n   - Causes diarrhoea, typhoid, etc.\n\n2. Skin infections:\n   - Dirty skin allows bacterial/fungal growth\n   - Causes boils, rashes, ringworm\n\n3. Respiratory infections:\n   - Coughing/sneezing without covering mouth\n   - Spreads droplets to others\n\n4. Dental problems:\n   - Poor oral hygiene causes cavities\n   - Gum disease, tooth loss\n\n5. Parasitic infections:\n   - Dirty hair can have lice\n   - Dirty feet can get fungal infections\n\nDiseases prevented by good hygiene:\n- Diarrhoea, cholera, typhoid\n- Common cold, flu\n- Conjunctivitis\n- Skin infections\n- Tooth decay\n- Lice infestation\n- Food poisoning\n- Hepatitis A\n- Many others\n\nThus, personal hygiene is the first line of defence against many infectious diseases."
        },
        {
            "type": "subjective",
            "q": "What is oral hygiene? Explain how to maintain healthy teeth and gums.",
            "sample": "Oral hygiene is the practice of keeping the mouth, teeth, and gums clean and healthy to prevent dental problems.\n\nWhy oral hygiene is important:\n- Prevents tooth decay (cavities)\n- Prevents gum disease (gingivitis, periodontitis)\n- Prevents bad breath (halitosis)\n- Maintains ability to eat properly\n- Affects overall health\n- Saves money on dental treatment\n- Improves appearance and confidence\n\nDaily oral hygiene routine:\n\n1. Brushing teeth:\n   - Brush twice daily (morning and before bed)\n   - Use soft-bristled toothbrush\n   - Use fluoride toothpaste\n   - Brush for at least 2-3 minutes\n   - Correct technique:\n     * Hold brush at 45° angle to gums\n     * Use gentle circular motions\n     * Brush outer surfaces of all teeth\n     * Brush inner surfaces\n     * Brush chewing surfaces\n     * Brush tongue to remove bacteria\n   - Don't brush too hard (damages gums)\n   - Replace toothbrush every 3-4 months\n\n2. Flossing:\n   - Floss once daily\n   - Removes plaque and food between teeth\n   - Where brush cannot reach\n   - Prevents gum disease\n   - Correct technique:\n     * Use about 45 cm floss\n     * Gently slide between teeth\n     * Curve around tooth, go below gumline\n     * Use clean section for each gap\n\n3. Mouthwash:\n   - Use antiseptic mouthwash\n   - Kills bacteria\n   - Freshens breath\n   - Reaches areas brush misses\n   - Not a substitute for brushing/flossing\n\n4. Rinse after meals:\n   - Swish water in mouth after eating\n   - Removes loose food particles\n   - Dilutes acids\n   - Especially important after sugary foods\n\nDietary habits for healthy teeth:\n\n5. Limit sugary foods:\n   - Reduce sweets, candies, chocolates\n   - Avoid sticky sweets that cling to teeth\n   - Limit sugary drinks (soda, juice)\n   - If eating sweets, have with meals not between\n   - Sugar feeds bacteria that cause decay\n\n6. Eat tooth-friendly foods:\n   - Crunchy vegetables (carrot, celery, apple) clean teeth\n   - Cheese and milk (calcium for strong teeth)\n   - Water (washes away food)\n   - Fiber-rich foods stimulate saliva\n   - Green tea (contains fluoride)\n\n7. Avoid frequent snacking:\n   - Each snack = acid attack on teeth\n   - Constant eating = constant acid\n   - Better to eat at meal times\n   - Saliva needs time to neutralize acid\n\nProfessional dental care:\n\n8. Regular dental checkups:\n   - Visit dentist every 6 months\n   - Professional cleaning removes tartar\n   - Early detection of cavities\n   - X-rays if needed\n   - Gum health assessment\n\n9. Fluoride treatments:\n   - Fluoride strengthens enamel\n   - In toothpaste, water, or professional application\n   - Makes teeth more resistant to acid\n   - Can reverse early decay\n\n10. Dental sealants:\n    - Protective coating on chewing surfaces\n    - Prevents food trapping in grooves\n    - Especially for children\n    - Lasts several years\n\nWhat is tooth decay?\n- Caused by bacteria acting on sugars\n- Produces acid that dissolves enamel\n- Forms cavities (holes)\n- Can reach pulp, cause pain\n- If untreated, tooth may be lost\n\nWhat is gum disease?\n- Gingivitis: early stage, gums red, swollen, bleed\n- Periodontitis: advanced, gums pull away, bone loss\n- Can lead to tooth loss\n- Linked to heart disease, diabetes\n\nSigns of dental problems:\n- Toothache\n- Bleeding gums when brushing\n- Persistent bad breath\n- Loose teeth\n- Mouth sores\n- Sensitivity to hot/cold\n- See dentist promptly\n\nAdditional tips:\n\n- Don't use teeth as tools (opening bottles)\n- Don't bite nails or pens\n- Use mouthguard for sports\n- Don't smoke (stains teeth, causes gum disease)\n- Limit coffee/tea (staining)\n- Chew sugar-free gum after meals (stimulates saliva)\n\nThus, good oral hygiene = healthy teeth for lifetime = proper chewing = good digestion"
        },
        {
            "type": "subjective",
            "q": "Explain the dos and don'ts for eye care.",
            "sample": "Eyes are delicate sense organs that need proper care to maintain good vision and prevent infections.\n\nDos for eye care:\n\n1. Splash eyes with clean water:\n   - 2-3 times daily\n   - Removes dust and irritants\n   - Keeps eyes moist\n\n2. Maintain proper distance:\n   - When reading: 25-30 cm from book\n   - When using computer: 50-60 cm from screen\n   - TV: at least 3 metres away\n\n3. Take regular breaks:\n   - Follow 20-20-20 rule\n   - Every 20 minutes, look at something 20 feet away for 20 seconds\n   - Reduces eye strain\n\n4. Wear sunglasses:\n   - On bright sunny days\n   - Protects from UV rays\n   - Prevents cataract, macular degeneration\n   - Choose sunglasses that block 100% UV\n\n5. Look at distant objects:\n   - Periodically look outside\n   - Relaxes eye muscles\n   - Reduces strain from near work\n\n6. Eat eye-healthy foods:\n   - Vitamin A: carrots, papaya, mango, spinach\n   - Vitamin C: citrus fruits, amla\n   - Vitamin E: nuts, seeds\n   - Lutein: green leafy vegetables\n   - Omega-3: fish\n\n7. Have adequate lighting:\n   - Read in good light\n   - Light should come from behind\n   - Avoid glare\n\n8. Blink frequently:\n   - Keeps eyes moist\n   - Especially important when using screens\n   - Prevents dry eyes\n\n9. Use protective eyewear:\n   - Safety glasses when playing sports\n   - Goggles when swimming\n   - Safety glasses for hazardous work\n\n10. Visit eye specialist regularly:\n    - If you have problem reading blackboard\n    - If you get headaches after reading\n    - For regular checkups\n    - Especially if family history of eye problems\n\n11. Remove contact lenses properly:\n    - Wash hands before handling\n    - Clean as directed\n    - Don't wear longer than recommended\n    - Don't sleep in contacts\n\n12. Use prescribed glasses:\n    - If prescribed, wear regularly\n    - Get power checked periodically\n\nDon'ts for eye care:\n\n1. Don't rub eyes:\n   - Can damage cornea\n   - Transfers germs from hands\n   - Can worsen irritation\n   - If itchy, wash with clean water\n\n2. Don't read in dim light:\n   - Strains eyes\n   - Causes headaches\n   - Can't see properly\n\n3. Don't read in moving vehicles:\n   - Constant focusing and refocusing\n   - Causes eye strain, headache\n   - Motion sickness\n\n4. Don't lie down while reading:\n   - Wrong angle for eyes\n   - Uneven lighting\n   - Neck strain\n\n5. Don't watch TV/computer for long periods:\n   - Take breaks every 20-30 minutes\n   - Don't sit too close\n   - Ensure proper lighting\n\n6. Don't see eclipse directly:\n   - Can cause permanent retinal damage\n   - Use proper filters or pinhole projection\n   - Never look directly at sun\n\n7. Don't try to clean eyes with objects:\n   - Never put sharp objects near eyes\n   - Don't use dirty cloth\n   - If something gets in, ask adult for help\n   - Blink quickly to start tears\n\n8. Don't share eye makeup:\n   - Can spread infections\n   - Replace mascara regularly\n   - Don't use expired products\n\n9. Don't ignore symptoms:\n   - Redness, pain, discharge\n   - Blurred vision\n   - Floaters, flashes\n   - Seek medical help promptly\n\n10. Don't use others' glasses:\n    - Each prescription is different\n    - Can cause headaches, strain\n\nCommon eye problems:\n- Myopia (nearsightedness): can't see distant objects\n- Hypermetropia (farsightedness): can't see nearby objects\n- Conjunctivitis: pink eye (infection)\n- Cataract: cloudy lens\n- Glaucoma: increased eye pressure\n- Dry eyes\n\nThus, proper eye care from childhood helps maintain good vision throughout life."
        },
        {
            "type": "subjective",
            "q": "What is community hygiene? Explain the importance of safe drinking water and waste disposal.",
            "sample": "Community hygiene (community health) refers to all programmes and activities aimed at improving public health through collective efforts and civic amenities.\n\nImportance of community hygiene:\n- Prevents spread of infectious diseases\n- Provides clean environment\n- Ensures safe water supply\n- Proper waste management\n- Reduces disease burden\n- Improves quality of life\n\nKey components of community hygiene:\n\n1. Safe drinking water supply:\n\nWhy safe water is essential:\n- Water is basic necessity\n- Contaminated water causes many diseases\n- Over 80% diseases in developing countries linked to unsafe water\n\nDiseases from unsafe water:\n- Cholera: severe diarrhoea\n- Typhoid: fever, intestinal issues\n- Hepatitis A: liver infection\n- Dysentery: bloody diarrhoea\n- Diarrhoea: leading cause of child death\n- Polio (water-borne transmission)\n\nMethods to make water safe:\n\nA. Boiling:\n   - Most reliable method\n   - Boil for at least 15 minutes\n   - Kills all germs\n   - Cool and store in clean container\n\nB. Chlorination:\n   - Add chlorine tablets to water\n   - Kills microorganisms\n   - Residual chlorine protects from recontamination\n   - Follow proper dosage\n\nC. Filtration:\n   - Water filters with porous candles\n   - Remove suspended impurities\n   - Some remove bacteria\n   - RO systems remove dissolved impurities\n\nD. Sedimentation:\n   - Store water in tanks/pots\n   - Suspended impurities settle down\n   - Decant clear water\n   - Alum crystals speed up settling\n\nE. UV treatment:\n   - Ultraviolet radiation kills germs\n   - Used in modern water purifiers\n   - No chemicals added\n\nF. Reverse Osmosis (RO):\n   - Removes dissolved salts and impurities\n   - Good for high TDS water\n   - Wastes some water\n\nStorage of water:\n- Store in clean, covered containers\n- Use narrow-mouthed vessels\n- Clean containers regularly\n- Use long-handled dipper to avoid hand contact\n- Don't store for too long\n\n2. Waste disposal and treatment:\n\nTypes of waste:\n- Solid waste: garbage, rubbish\n- Liquid waste: sewage, wastewater\n- Hazardous waste: medical, industrial\n\nProper waste disposal methods:\n\nA. Sewage disposal:\n   - Wastewater from kitchens, toilets\n   - Carried through underground sewers\n   - Treated at sewage treatment plants\n   - Before release into water bodies\n   - Treatment removes pollutants\n\nB. Garbage collection:\n   - Civic bodies collect household waste\n   - Regular collection schedules\n   - Segregation at source (biodegradable, non-biodegradable)\n   - Dustbins with covers\n\nC. Landfills:\n   - Garbage dumped in low-lying areas\n   - Away from human habitation\n   - Covered with soil when full\n   - Prevents scattering by animals\n   - After years, land can be used for parks\n\nD. Composting:\n   - Kitchen and garden waste\n   - Dumped in pits, covered with soil\n   - Microorganisms decompose waste\n   - Produces manure-rich compost\n   - Environmentally friendly\n\nE. Vermicomposting:\n   - Earthworms added to compost pits\n   - Speed up decomposition\n   - Produce nutrient-rich compost\n   - Worms eat organic waste\n\nF. Recycling:\n   - Separate recyclable materials\n   - Paper, plastic, glass, metal\n   - Sent for recycling\n   - Reduces landfill burden\n\nG. Incineration:\n   - Burning waste at high temperature\n   - For medical, hazardous waste\n   - Reduces volume\n   - Requires pollution control\n\nCommunity participation:\n- Keep surroundings clean\n- Don't litter\n- Use dustbins\n- Segregate waste at home\n- Don't allow stagnant water (mosquito breeding)\n- Report broken drains\n- Participate in cleanliness drives\n- Educate others\n\nRole of civic bodies:\n- Panchayats in villages\n- Municipalities in towns\n- Provide safe drinking water\n- Collect and dispose waste\n- Maintain drainage systems\n- Control disease vectors\n- Health education\n\nThus, community hygiene requires collective effort for public health."
        },
        {
            "type": "subjective",
            "q": "What is composting? Explain vermicomposting and its advantages.",
            "sample": "Composting is a natural process of decomposing organic waste into nutrient-rich manure by microorganisms.\n\nWhat is composting?\n- Method of recycling organic waste\n- Kitchen waste, garden waste decomposed\n- Microorganisms break down material\n- Produces compost (humus)\n- Used as fertilizer\n- Environmentally friendly\n\nMaterials that can be composted:\n- Fruit and vegetable peels\n- Eggshells\n- Tea leaves, coffee grounds\n- Leaves, grass clippings\n- Twigs, small branches\n- Paper (non-glossy)\n- Sawdust\n- Cow dung\n\nMaterials NOT to compost:\n- Meat, fish, bones (attract pests)\n- Dairy products\n- Oily, fatty foods\n- Diseased plants\n- Weed seeds\n- Pet waste\n- Glossy paper\n- Non-biodegradable items\n\nTraditional composting process:\n\n1. Dig a pit in ground\n2. Layer green waste (nitrogen-rich) and brown waste (carbon-rich)\n3. Add some soil\n4. Keep moist but not wet\n5. Turn occasionally for aeration\n6. Microorganisms decompose material\n7. In 2-3 months, compost ready\n8. Dark, crumbly, earthy-smelling\n\nVermicomposting:\n\nDefinition:\n- Composting using earthworms\n- Worms accelerate decomposition\n- Produce superior quality compost\n\nWorms used:\n- Red wiggler (Eisenia fetida)\n- African nightcrawler\n- Not regular earthworms\n\nProcess of vermicomposting:\n\n1. Container:\n   - Use bin with holes for aeration\n   - Keep in shady place\n   - Add bedding (coconut coir, shredded paper)\n\n2. Add worms:\n   - Introduce composting worms\n   - About 1 kg worms per bin\n\n3. Add waste:\n   - Kitchen waste (vegetable peels, fruit scraps)\n   - Avoid citrus, onion, garlic in excess\n   - Bury waste in bedding\n\n4. Maintain conditions:\n   - Keep moist (like wrung-out sponge)\n   - Maintain temperature 20-30°C\n   - Avoid direct sunlight\n   - Cover to protect from rain\n\n5. Harvesting:\n   - Worms convert waste into castings\n   - After 2-3 months, compost ready\n   - Separate worms from compost\n   - Compost is dark, granular, odorless\n\nAdvantages of vermicomposting:\n\n1. Faster decomposition:\n   - Worms eat organic waste\n   - Speed up process (2-3 months vs 6 months)\n   - More efficient than traditional composting\n\n2. Superior compost quality:\n   - Worm castings are nutrient-rich\n   - Higher NPK (nitrogen, phosphorus, potassium)\n   - Contains beneficial microbes\n   - Plant growth hormones\n   - Improves soil structure\n\n3. Waste reduction:\n   - Reduces kitchen waste going to landfill\n   - Up to 50% household waste can be composted\n   - Decreases methane from landfills\n\n4. Environmentally friendly:\n   - No chemicals\n   - Reduces need for chemical fertilizers\n   - Lowers carbon footprint\n   - Sustainable practice\n\n5. Cost-effective:\n   - Free fertilizer for garden\n   - Saves money on buying compost\n   - Low setup cost\n\n6. Improves soil:\n   - Adds organic matter\n   - Improves water retention\n   - Enhances soil aeration\n   - Prevents soil erosion\n   - Promotes root growth\n\n7. Safe and easy:\n   - Can be done at home\n   - No foul smell if done properly\n   - Children can participate\n   - Educational\n\n8. Worms multiply:\n   - Population increases\n   - Can share with others\n   - Sustainable system\n\nUses of compost/vermicompost:\n- Garden fertilizer\n- Potting mix\n- Soil amendment\n- Organic farming\n- Lawn dressing\n- Plant nursery\n\nThus, vermicomposting is an excellent way to manage waste and produce organic fertilizer."
        }
    ]
}