
#Biology — Grade 6 ICSE
#Chapter 8: Adaptations in Plants and Animals
#Comprehensive Practice Questions
#50 MCQ • 50 True/False • 40 Subjective


       "Chapter 8 — Adaptations in Plants and Animals": [
        # ===== MCQ (50 questions) =====
        {
            "type": "mcq",
            "q": "The natural home of an organism is called its:",
            "options": [
                "Habitat",
                "Ecosystem",
                "Environment",
                "Community"
            ],
            "answer": "Habitat",
            "explanation": "Habitat is the natural home of an organism where it gets food, shelter, and suitable climatic conditions."
        },
        {
            "type": "mcq",
            "q": "The ability of an organism to change for better adjustment with the environment is called:",
            "options": [
                "Habitat",
                "Adaptation",
                "Evolution",
                "Modification"
            ],
            "answer": "Adaptation",
            "explanation": "Adaptation helps an organism live successfully in its habitat through changes in body structure and behaviour."
        },
        {
            "type": "mcq",
            "q": "Habitat consists of:",
            "options": [
                "Only living components",
                "Only non-living components",
                "Both biotic (living) and abiotic (non-living) components",
                "Only plants and animals"
            ],
            "answer": "Both biotic (living) and abiotic (non-living) components",
            "explanation": "Habitat includes biotic (plants, animals) and abiotic (water, soil, temperature, sunlight) components."
        },
        {
            "type": "mcq",
            "q": "Plants that live in water are called:",
            "options": [
                "Xerophytes",
                "Mesophytes",
                "Hydrophytes",
                "Halophytes"
            ],
            "answer": "Hydrophytes",
            "explanation": "Hydrophytes are aquatic plants that live in water, e.g., water hyacinth, Hydrilla, lotus."
        },
        {
            "type": "mcq",
            "q": "Plants that live on land with sufficient water are called:",
            "options": [
                "Xerophytes",
                "Mesophytes",
                "Hydrophytes",
                "Epiphytes"
            ],
            "answer": "Mesophytes",
            "explanation": "Mesophytes grow in terrestrial habitats with good moisture, e.g., rose, sunflower, mango."
        },
        {
            "type": "mcq",
            "q": "Plants that live in dry and hot environments are called:",
            "options": [
                "Hydrophytes",
                "Mesophytes",
                "Xerophytes",
                "Halophytes"
            ],
            "answer": "Xerophytes",
            "explanation": "Xerophytes are adapted to dry, hot conditions with water scarcity, e.g., cactus, Acacia."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a free-floating hydrophyte?",
            "options": [
                "Lotus",
                "Hydrilla",
                "Water hyacinth",
                "Vallisneria"
            ],
            "answer": "Water hyacinth",
            "explanation": "Water hyacinth floats freely on water surface, not attached to soil."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a rooted floating hydrophyte?",
            "options": [
                "Water hyacinth",
                "Duckweed",
                "Lotus",
                "Hydrilla"
            ],
            "answer": "Lotus",
            "explanation": "Lotus has roots fixed in soil but leaves float on water surface due to long petioles."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a submerged rooted hydrophyte?",
            "options": [
                "Water hyacinth",
                "Lotus",
                "Hydrilla",
                "Duckweed"
            ],
            "answer": "Hydrilla",
            "explanation": "Hydrilla remains completely submerged in water and is rooted to the soil."
        },
        {
            "type": "mcq",
            "q": "The submerged parts of hydrophytes are covered with ________ to prevent decay.",
            "options": [
                "Wax",
                "Mucilage",
                "Cuticle",
                "Spines"
            ],
            "answer": "Mucilage",
            "explanation": "Mucilage coating protects aquatic plants from decaying in water."
        },
        {
            "type": "mcq",
            "q": "The stems of aquatic plants like lotus have:",
            "options": [
                "Solid structure",
                "Large tunnels and holes for air",
                "No air spaces",
                "Thick waxy coating"
            ],
            "answer": "Large tunnels and holes for air",
            "explanation": "Air spaces in stems help aquatic plants float and exchange gases."
        },
        {
            "type": "mcq",
            "q": "Leaves of submerged plants like Hydrilla are:",
            "options": [
                "Broad and flat",
                "Long, narrow, and ribbon-shaped",
                "Reduced to spines",
                "Thick and fleshy"
            ],
            "answer": "Long, narrow, and ribbon-shaped",
            "explanation": "Ribbon-shaped leaves allow water to pass through easily, preventing damage."
        },
        {
            "type": "mcq",
            "q": "Floating leaves like those of lotus have stomata on:",
            "options": [
                "Lower surface",
                "Upper surface",
                "Both surfaces",
                "No stomata"
            ],
            "answer": "Upper surface",
            "explanation": "Stomata on upper surface of floating leaves are exposed to air for gas exchange."
        },
        {
            "type": "mcq",
            "q": "The special tissue that provides buoyancy to aquatic plants is called:",
            "options": [
                "Parenchyma",
                "Collenchyma",
                "Aerenchyma",
                "Sclerenchyma"
            ],
            "answer": "Aerenchyma",
            "explanation": "Aerenchyma has large air spaces that provide buoyancy and flexibility to aquatic plants."
        },
        {
            "type": "mcq",
            "q": "In xerophytes like cactus, leaves are reduced to:",
            "options": [
                "Thorns",
                "Spines",
                "Scales",
                "Buds"
            ],
            "answer": "Spines",
            "explanation": "Leaves reduced to spines prevent water loss through transpiration."
        },
        {
            "type": "mcq",
            "q": "In cactus, the ________ becomes green and takes up the function of leaves.",
            "options": [
                "Root",
                "Stem",
                "Flower",
                "Spine"
            ],
            "answer": "Stem",
            "explanation": "Cactus stem is green and performs photosynthesis since leaves are reduced to spines."
        },
        {
            "type": "mcq",
            "q": "Cactus stems become fleshy to:",
            "options": [
                "Store water",
                "Store food",
                "Absorb sunlight",
                "Reduce transpiration"
            ],
            "answer": "Store water",
            "explanation": "Fleshy stems store water for survival in dry conditions."
        },
        {
            "type": "mcq",
            "q": "Stomata in xerophytes are:",
            "options": [
                "Numerous and raised",
                "Few and sunken",
                "Absent",
                "Only on upper surface"
            ],
            "answer": "Few and sunken",
            "explanation": "Fewer, sunken stomata reduce water loss in dry conditions."
        },
        {
            "type": "mcq",
            "q": "The surface of xerophytes becomes shiny and glazed to:",
            "options": [
                "Attract insects",
                "Reflect light and heat",
                "Absorb more water",
                "Store food"
            ],
            "answer": "Reflect light and heat",
            "explanation": "Shiny surface reflects sunlight, reducing heat absorption and water loss."
        },
        {
            "type": "mcq",
            "q": "Plants growing in mountains are ________ shaped with sloping branches.",
            "options": [
                "Cone",
                "Round",
                "Spreading",
                "Irregular"
            ],
            "answer": "Cone",
            "explanation": "Cone shape with sloping branches helps snow slide off easily without damaging branches."
        },
        {
            "type": "mcq",
            "q": "Mountain plants like pine have ________ leaves.",
            "options": [
                "Broad",
                "Needle-like",
                "Fleshy",
                "Ribbon-shaped"
            ],
            "answer": "Needle-like",
            "explanation": "Needle-like leaves reduce surface area and help snow slide off."
        },
        {
            "type": "mcq",
            "q": "Plants that grow on other plants for support are called:",
            "options": [
                "Parasites",
                "Epiphytes",
                "Xerophytes",
                "Hydrophytes"
            ],
            "answer": "Epiphytes",
            "explanation": "Epiphytes like orchids grow on other plants for support, not nutrition."
        },
        {
            "type": "mcq",
            "q": "Orchids obtain water and nutrients from:",
            "options": [
                "Soil",
                "Host plant",
                "Moisture in air and debris on host",
                "Rainwater only"
            ],
            "answer": "Moisture in air and debris on host",
            "explanation": "Orchids absorb moisture and nutrients from air and organic debris accumulating on host plants."
        },
        {
            "type": "mcq",
            "q": "The body of fish is ________ to offer least resistance to water.",
            "options": [
                "Flat",
                "Streamlined",
                "Round",
                "Irregular"
            ],
            "answer": "Streamlined",
            "explanation": "Streamlined body reduces water resistance and helps in swimming."
        },
        {
            "type": "mcq",
            "q": "Fish respire through:",
            "options": [
                "Lungs",
                "Gills",
                "Skin",
                "Trachea"
            ],
            "answer": "Gills",
            "explanation": "Gills extract oxygen dissolved in water."
        },
        {
            "type": "mcq",
            "q": "The ________ fin in fish acts as a rudder for changing direction.",
            "options": [
                "Tail",
                "Dorsal",
                "Pectoral",
                "Pelvic"
            ],
            "answer": "Tail",
            "explanation": "Tail fin (caudal fin) helps change direction while swimming."
        },
        {
            "type": "mcq",
            "q": "Some fish have ________ to help in buoyancy.",
            "options": [
                "Gills",
                "Air bladder",
                "Scales",
                "Fins"
            ],
            "answer": "Air bladder",
            "explanation": "Air bladder helps fish maintain buoyancy at different depths."
        },
        {
            "type": "mcq",
            "q": "Animals that live on land are called:",
            "options": [
                "Aquatic animals",
                "Terrestrial animals",
                "Aerial animals",
                "Amphibians"
            ],
            "answer": "Terrestrial animals",
            "explanation": "Terrestrial animals live on land, e.g., humans, tigers, deer."
        },
        {
            "type": "mcq",
            "q": "Terrestrial animals have ________ claws for walking and running.",
            "options": [
                "Pentadactyl (five digits)",
                "Three digits",
                "Webbed",
                "Hoofed"
            ],
            "answer": "Pentadactyl (five digits)",
            "explanation": "Most terrestrial animals have five-toed (pentadactyl) limbs."
        },
        {
            "type": "mcq",
            "q": "The ability to stand and move on two legs is called:",
            "options": [
                "Quadrupedal locomotion",
                "Bipedal locomotion",
                "Arboreal locomotion",
                "Aquatic locomotion"
            ],
            "answer": "Bipedal locomotion",
            "explanation": "Bipedal animals like humans walk on two legs."
        },
        {
            "type": "mcq",
            "q": "Desert animals that come out at night to avoid heat are called:",
            "options": [
                "Diurnal",
                "Nocturnal",
                "Crepuscular",
                "Hibernating"
            ],
            "answer": "Nocturnal",
            "explanation": "Nocturnal animals are active at night when temperatures are cooler."
        },
        {
            "type": "mcq",
            "q": "The camel is often called the:",
            "options": [
                "King of desert",
                "Ship of the desert",
                "Desert horse",
                "Desert runner"
            ],
            "answer": "Ship of the desert",
            "explanation": "Camel is called 'ship of the desert' because it can travel long distances in desert."
        },
        {
            "type": "mcq",
            "q": "The hump of a camel stores:",
            "options": [
                "Water",
                "Fat",
                "Food",
                "Air"
            ],
            "answer": "Fat",
            "explanation": "Camel's hump stores fat, which can be converted to energy and water when needed."
        },
        {
            "type": "mcq",
            "q": "A camel can go without food and water for up to:",
            "options": [
                "2-3 days",
                "5-7 days",
                "10 days",
                "15 days"
            ],
            "answer": "10 days",
            "explanation": "Camel can survive up to 10 days without food and water due to adaptations."
        },
        {
            "type": "mcq",
            "q": "A camel's large fleshy soles help it to:",
            "options": [
                "Run fast",
                "Walk on hot, slippery sand",
                "Dig burrows",
                "Climb rocks"
            ],
            "answer": "Walk on hot, slippery sand",
            "explanation": "Broad, fleshy soles prevent sinking in sand and protect from heat."
        },
        {
            "type": "mcq",
            "q": "Long eyelashes in camel protect from:",
            "options": [
                "Sunlight",
                "Wind-blown sand",
                "Predators",
                "Cold"
            ],
            "answer": "Wind-blown sand",
            "explanation": "Long eyelashes keep sand out of eyes during sandstorms."
        },
        {
            "type": "mcq",
            "q": "Mountain goats have ________ to help them climb rocky slopes.",
            "options": [
                "Webbed feet",
                "Strong hooves",
                "Padded paws",
                "Claws"
            ],
            "answer": "Strong hooves",
            "explanation": "Strong hooves provide grip on rocky mountain slopes."
        },
        {
            "type": "mcq",
            "q": "Mountain animals have thick fur to:",
            "options": [
                "Protect from cold",
                "Camouflage",
                "Attract mates",
                "Store food"
            ],
            "answer": "Protect from cold",
            "explanation": "Thick fur insulates against low temperatures in mountains."
        },
        {
            "type": "mcq",
            "q": "Birds have ________ bones to make their body light for flight.",
            "options": [
                "Solid",
                "Hollow with air cavities",
                "Heavy",
                "Cartilaginous"
            ],
            "answer": "Hollow with air cavities",
            "explanation": "Hollow, air-filled bones reduce weight for flight."
        },
        {
            "type": "mcq",
            "q": "Forelimbs of birds are modified into:",
            "options": [
                "Legs",
                "Wings",
                "Fins",
                "Claws"
            ],
            "answer": "Wings",
            "explanation": "Forelimbs are modified into wings for flying."
        },
        {
            "type": "mcq",
            "q": "Birds have ________ lungs with air sacs for efficient breathing.",
            "options": [
                "Simple",
                "Balloon-like",
                "Spongy",
                "Small"
            ],
            "answer": "Balloon-like",
            "explanation": "Air sacs increase breathing efficiency and make body lighter."
        },
        {
            "type": "mcq",
            "q": "Hibernation is a deep sleep during:",
            "options": [
                "Summer",
                "Winter",
                "Rainy season",
                "Spring"
            ],
            "answer": "Winter",
            "explanation": "Animals hibernate during winter to save energy when food is scarce."
        },
        {
            "type": "mcq",
            "q": "Which animal hibernates during winter?",
            "options": [
                "Camel",
                "Frog",
                "Fish",
                "Bird"
            ],
            "answer": "Frog",
            "explanation": "Frogs hibernate in winter to survive cold when insects (their food) are scarce."
        },
        
        # ===== True/False (50 questions) =====
        {
            "type": "tf",
            "q": "Habitat provides organisms with food, shelter, and suitable climatic conditions.",
            "answer": "True",
            "explanation": "Habitat is the natural home meeting all needs of an organism."
        },
        {
            "type": "tf",
            "q": "All organisms in a habitat have the same adaptations.",
            "answer": "False",
            "explanation": "Different organisms have different adaptations suited to their specific needs."
        },
        {
            "type": "tf",
            "q": "Adaptation includes changes in body structure and behaviour.",
            "answer": "True",
            "explanation": "Adaptation involves both structural and behavioural changes for survival."
        },
        {
            "type": "tf",
            "q": "Cactus and camels are adapted to live in water.",
            "answer": "False",
            "explanation": "Cactus and camels are adapted to live in deserts, not water."
        },
        {
            "type": "tf",
            "q": "Hydrophytes are plants that live in dry areas.",
            "answer": "False",
            "explanation": "Hydrophytes live in water; xerophytes live in dry areas."
        },
        {
            "type": "tf",
            "q": "Mesophytes require a sufficient amount of water to live on land.",
            "answer": "True",
            "explanation": "Mesophytes grow in moderate moisture conditions."
        },
        {
            "type": "tf",
            "q": "Xerophytes are adapted to cope with dry and hot environments.",
            "answer": "True",
            "explanation": "Xerophytes have adaptations to conserve water and tolerate heat."
        },
        {
            "type": "tf",
            "q": "Water hyacinth is a rooted floating hydrophyte.",
            "answer": "False",
            "explanation": "Water hyacinth is free-floating, not rooted. Lotus is rooted floating."
        },
        {
            "type": "tf",
            "q": "Lotus has roots fixed in soil and leaves that float on water.",
            "answer": "True",
            "explanation": "Lotus is a rooted floating hydrophyte with long petioles."
        },
        {
            "type": "tf",
            "q": "Hydrilla is completely submerged and rooted in soil.",
            "answer": "True",
            "explanation": "Hydrilla is a submerged rooted hydrophyte."
        },
        {
            "type": "tf",
            "q": "Submerged parts of hydrophytes are covered with waxy coating.",
            "answer": "False",
            "explanation": "They are covered with mucilage, not wax. Wax is for xerophytes."
        },
        {
            "type": "tf",
            "q": "Stems of aquatic plants have air spaces for buoyancy.",
            "answer": "True",
            "explanation": "Air spaces (aerenchyma) help plants float."
        },
        {
            "type": "tf",
            "q": "Leaves of submerged plants are broad and flat.",
            "answer": "False",
            "explanation": "They are long, narrow, and ribbon-shaped to reduce water resistance."
        },
        {
            "type": "tf",
            "q": "Floating leaves have stomata on their upper surface.",
            "answer": "True",
            "explanation": "Stomata on upper surface are exposed to air for gas exchange."
        },
        {
            "type": "tf",
            "q": "Aerenchyma provides buoyancy to aquatic plants.",
            "answer": "True",
            "explanation": "Aerenchyma tissue has large air spaces for flotation."
        },
        {
            "type": "tf",
            "q": "In cactus, leaves are reduced to spines to store water.",
            "answer": "False",
            "explanation": "Spines reduce water loss; stem stores water."
        },
        {
            "type": "tf",
            "q": "Cactus stem is green and performs photosynthesis.",
            "answer": "True",
            "explanation": "Green stem takes over leaf function."
        },
        {
            "type": "tf",
            "q": "Xerophytes have numerous stomata on leaf surfaces.",
            "answer": "False",
            "explanation": "They have few, sunken stomata to reduce water loss."
        },
        {
            "type": "tf",
            "q": "Shiny surface of xerophytes reflects light and heat.",
            "answer": "True",
            "explanation": "Shiny coating reduces heat absorption."
        },
        {
            "type": "tf",
            "q": "Mountain trees are cone-shaped to collect more sunlight.",
            "answer": "False",
            "explanation": "Cone shape helps snow slide off, preventing branch damage."
        },
        {
            "type": "tf",
            "q": "Pine trees have needle-like leaves to reduce water loss.",
            "answer": "True",
            "explanation": "Needle-like leaves reduce surface area and water loss."
        },
        {
            "type": "tf",
            "q": "Orchids are parasites that take food from host plants.",
            "answer": "False",
            "explanation": "Orchids are epiphytes, not parasites. They use host only for support."
        },
        {
            "type": "tf",
            "q": "Orchids obtain water and nutrients from air and debris.",
            "answer": "True",
            "explanation": "They absorb moisture and nutrients from air and organic matter on host."
        },
        {
            "type": "tf",
            "q": "Fish have streamlined bodies to reduce water resistance.",
            "answer": "True",
            "explanation": "Streamlined shape helps in efficient swimming."
        },
        {
            "type": "tf",
            "q": "Fish breathe through lungs like humans.",
            "answer": "False",
            "explanation": "Fish breathe through gills, extracting oxygen from water."
        },
        {
            "type": "tf",
            "q": "The tail fin of fish acts as a rudder for changing direction.",
            "answer": "True",
            "explanation": "Tail fin helps steer while swimming."
        },
        {
            "type": "tf",
            "q": "Air bladder helps fish sink to the bottom.",
            "answer": "False",
            "explanation": "Air bladder helps in buoyancy, not sinking."
        },
        {
            "type": "tf",
            "q": "Terrestrial animals live on land.",
            "answer": "True",
            "explanation": "Terrestrial means land-dwelling."
        },
        {
            "type": "tf",
            "q": "All terrestrial animals have webbed feet for swimming.",
            "answer": "False",
            "explanation": "Webbed feet are for aquatic animals; terrestrial have pentadactyl limbs."
        },
        {
            "type": "tf",
            "q": "Bipedal locomotion means walking on two legs.",
            "answer": "True",
            "explanation": "Humans are bipedal."
        },
        {
            "type": "tf",
            "q": "Desert animals are usually active during the day.",
            "answer": "False",
            "explanation": "Many desert animals are nocturnal to avoid daytime heat."
        },
        {
            "type": "tf",
            "q": "Nocturnal animals come out at night.",
            "answer": "True",
            "explanation": "Nocturnal animals are active at night."
        },
        {
            "type": "tf",
            "q": "Camel's hump stores water.",
            "answer": "False",
            "explanation": "Hump stores fat, not water."
        },
        {
            "type": "tf",
            "q": "A camel can go without water for up to 10 days.",
            "answer": "True",
            "explanation": "Camel adaptations allow long periods without water."
        },
        {
            "type": "tf",
            "q": "Camel's large fleshy soles prevent sinking in sand.",
            "answer": "True",
            "explanation": "Broad soles distribute weight on soft sand."
        },
        {
            "type": "tf",
            "q": "Long eyelashes in camel protect from sunlight.",
            "answer": "False",
            "explanation": "They protect from wind-blown sand."
        },
        {
            "type": "tf",
            "q": "Mountain goats have strong hooves for climbing.",
            "answer": "True",
            "explanation": "Hooves provide grip on rocky slopes."
        },
        {
            "type": "tf",
            "q": "Mountain animals have thin fur to stay cool.",
            "answer": "False",
            "explanation": "They have thick fur for insulation against cold."
        },
        {
            "type": "tf",
            "q": "Birds have hollow bones to make them lighter for flight.",
            "answer": "True",
            "explanation": "Hollow, air-filled bones reduce weight."
        },
        {
            "type": "tf",
            "q": "Birds' forelimbs are modified into wings.",
            "answer": "True",
            "explanation": "Wings are modified forelimbs for flying."
        },
        {
            "type": "tf",
            "q": "Birds have heavy, solid bones for strength.",
            "answer": "False",
            "explanation": "Bones are hollow with air cavities for lightness."
        },
        {
            "type": "tf",
            "q": "Birds have air sacs connected to lungs for efficient breathing.",
            "answer": "True",
            "explanation": "Air sacs increase oxygen intake and reduce weight."
        },
        {
            "type": "tf",
            "q": "Hibernation is sleep during summer.",
            "answer": "False",
            "explanation": "Hibernation is winter sleep; summer sleep is aestivation."
        },
        {
            "type": "tf",
            "q": "Frogs hibernate during winter.",
            "answer": "True",
            "explanation": "Frogs hibernate to survive cold when food is scarce."
        },
        {
            "type": "tf",
            "q": "Cactus stems are fleshy to store water.",
            "answer": "True",
            "explanation": "Fleshy stems store water for dry periods."
        },
        {
            "type": "tf",
            "q": "All aquatic plants have well-developed root systems.",
            "answer": "False",
            "explanation": "Some aquatic plants have poorly developed or absent roots."
        },
        {
            "type": "tf",
            "q": "Mechanical tissues are well-developed in hydrophytes.",
            "answer": "False",
            "explanation": "Mechanical tissues are poorly developed as water supports the plant."
        },
        {
            "type": "tf",
            "q": "Xerophytes have deep root systems to absorb water.",
            "answer": "True",
            "explanation": "Deep roots reach underground water sources."
        },
        {
            "type": "tf",
            "q": "Epiphytes like orchids grow on soil.",
            "answer": "False",
            "explanation": "Epiphytes grow on other plants for support."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "Define habitat and adaptation. Explain with examples why adaptation is necessary for survival.",
            "sample": "Habitat is the natural home or environment of an organism where it gets food, shelter, and suitable climatic conditions to survive, breed, and flourish.\n\nExamples of habitats:\n- Desert: cactus, camel\n- Pond: lotus, fish, frog\n- Forest: tiger, elephant\n- Mountain: pine, mountain goat\n\nHabitat has two components:\n1. Biotic (living): plants, animals, microorganisms\n2. Abiotic (non-living): water, soil, temperature, sunlight, air\n\nAdaptation is the ability of an organism to change its body structure and behaviour for better adjustment with its environment over time.\n\nWhy adaptation is necessary:\n\n1. Survival in extreme conditions:\n   - Desert: high temperature, scarce water\n   - Polar: freezing cold\n   - Aquatic: water environment\n   Without adaptations, organisms cannot survive in these conditions.\n\n2. Protection from predators:\n   - Camouflage (chameleon changes colour)\n   - Spines (porcupine, cactus)\n   - Speed (deer runs fast)\n\n3. Obtaining food:\n   - Long neck of giraffe to reach leaves\n   - Sharp teeth of carnivores\n   - Streamlined body of fish to catch prey\n\n4. Reproduction:\n   - Bright colours of flowers attract pollinators\n   - Scent to attract mates\n\n5. Climate regulation:\n   - Thick fur in cold regions\n   - Large ears in desert animals (elephant, jackrabbit) to dissipate heat\n\nExamples of adaptations:\n\nCactus (desert plant):\n- Leaves reduced to spines (reduce water loss)\n- Fleshy stem (stores water)\n- Deep roots (absorb water)\n- Sunken stomata (reduce transpiration)\n\nCamel (desert animal):\n- Hump stores fat (energy source)\n- Can drink large quantity at once\n- Sweats very little\n- Long eyelashes protect from sand\n- Broad soles prevent sinking\n\nFish (aquatic animal):\n- Streamlined body (reduce water resistance)\n- Gills (breathe underwater)\n- Fins (for swimming and balance)\n- Scales with mucus (protection)\n\nThus, adaptation is essential for survival, growth, and reproduction in specific habitats."
        },
        {
            "type": "subjective",
            "q": "Classify plants based on water availability. Explain each category with examples and adaptations.",
            "sample": "Based on water availability in habitat, plants are classified into three categories:\n\n1. Hydrophytes (Aquatic plants):\n   - Plants that live in water\n   - Found in ponds, lakes, rivers\n   \n   Types of hydrophytes:\n   a. Free-floating: Water hyacinth, duckweed\n   b. Rooted floating: Lotus, water lily\n   c. Submerged rooted: Hydrilla, Vallisneria\n   d. Submerged floating: Utricularia\n   \n   Adaptations of hydrophytes:\n   - Submerged parts covered with mucilage (prevents decay)\n   - Stems spongy with air spaces (aerenchyma for buoyancy)\n   - Leaves: ribbon-shaped (submerged) or broad flat (floating)\n   - Floating leaves have stomata on upper surface\n   - Roots poorly developed or absent\n   - Mechanical tissues poorly developed (water supports)\n\n2. Mesophytes:\n   - Plants that grow on land with sufficient moisture\n   - Moderate temperature and humidity\n   - Neither very wet nor very dry conditions\n   \n   Examples:\n   - Rose, sunflower, mango, peepal\n   - Tomato, potato, mustard\n   - Gulmohar, clove, rosewood\n   \n   Adaptations of mesophytes:\n   - Leaves broad but thin\n   - Epidermis with thin cuticle\n   - Stomata numerous on lower surface\n   - Well-developed roots and stems\n   - Well-developed mechanical and conducting tissues\n   - Normal growth in ideal conditions\n\n3. Xerophytes (Desert plants):\n   - Plants adapted to dry, hot conditions\n   - Water scarcity, high temperature\n   \n   Examples:\n   - Cactus, Opuntia\n   - Acacia, babool\n   - Aloe, Agave\n   \n   Adaptations of xerophytes:\n   - Leaves reduced to spines (reduce water loss)\n   - Few, sunken stomata (reduce transpiration)\n   - Thick waxy coating on stems and leaves (reflects heat)\n   - Green stems perform photosynthesis\n   - Fleshy stems store water\n   - Deep root system (reach underground water)\n   - Some have shallow widespread roots (absorb surface moisture)\n\nComparison table:\n\n| Feature | Hydrophytes | Mesophytes | Xerophytes |\n|---------|-------------|------------|------------|\n| Habitat | Water | Moderate moisture | Dry, hot |\n| Leaves | Ribbon/broad | Broad | Spines |\n| Stomata | Upper surface (floating) | Lower surface | Few, sunken |\n| Roots | Poor | Well-developed | Deep/extensive |\n| Stem | Spongy with air spaces | Normal | Fleshy, green |\n| Cuticle | Thin | Thin | Thick waxy |\n| Examples | Lotus, Hydrilla | Rose, mango | Cactus, Acacia |\n\nThus, plants show remarkable adaptations to their water environment."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of hydrophytes (aquatic plants) with examples.",
            "sample": "Hydrophytes are plants that live in water. They show various adaptations to survive in aquatic environment.\n\nTypes of hydrophytes with examples:\n\n1. Free-floating plants:\n   - Float freely on water surface\n   - Not attached to soil\n   - Examples: Water hyacinth, duckweed, Pistia\n\n2. Rooted floating plants:\n   - Roots fixed in soil\n   - Leaves float on surface\n   - Long petioles (leaf stalks)\n   - Examples: Lotus, water lily\n\n3. Submerged rooted plants:\n   - Completely under water\n   - Roots fixed in soil\n   - Examples: Hydrilla, Vallisneria\n\n4. Submerged floating plants:\n   - Completely under water\n   - Not rooted in soil\n   - Examples: Utricularia, Ceratophyllum\n\nAdaptations of hydrophytes:\n\nA. Morphological adaptations (structure):\n\n1. Roots:\n   - Poorly developed or absent\n   - No root hairs\n   - Function mainly for anchorage, not absorption\n   - In floating plants, roots may hang freely\n\n2. Stems:\n   - Soft, spongy, flexible\n   - Large air spaces (aerenchyma) for buoyancy\n   - Hollow in some (lotus)\n   - Long and slender in submerged plants\n\n3. Leaves:\n   - Submerged plants: thin, narrow, ribbon-shaped (Hydrilla)\n     * Allows water to pass easily\n     * Prevents damage from water currents\n   - Floating plants: large, flat, broad (lotus, water lily)\n     * Float on surface\n     * Waxy upper surface (waterproof)\n     * Stomata only on upper surface (exposed to air)\n\n4. Mucilage coating:\n   - Submerged parts covered with mucilage\n   - Protects from decay in water\n\nB. Anatomical adaptations (internal structure):\n\n5. Aerenchyma tissue:\n   - Specialized tissue with large air spaces\n   - Provides buoyancy (helps float)\n   - Facilitates gas exchange\n   - Present in stems, roots, leaves\n\n6. Mechanical tissues:\n   - Poorly developed\n   - Water supports the plant\n   - No need for strong supporting tissues\n\n7. Conducting tissues:\n   - Reduced (xylem and phloem)\n   - Water easily available\n\nC. Physiological adaptations (functions):\n\n8. Gas exchange:\n   - Through entire plant surface\n   - Air spaces store oxygen\n   - Floating leaves exchange gases through stomata\n\n9. Reproduction:\n   - Many reproduce vegetatively (rapid growth)\n   - Flowers raised above water (lotus) for pollination\n\nSpecial features of lotus (example):\n- Roots in mud\n- Long hollow petioles (air channels) bring air to roots\n- Large floating leaves\n- Showy flowers above water\n- Seeds can survive years\n\nThus, hydrophytes are perfectly adapted to life in water."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of xerophytes (desert plants) with examples.",
            "sample": "Xerophytes are plants adapted to survive in dry, hot environments with scarce water. They show remarkable adaptations to conserve water and tolerate heat.\n\nExamples of xerophytes:\n- Cactus (various species)\n- Opuntia (prickly pear)\n- Acacia (babool)\n- Aloe vera\n- Agave\n- Euphorbia\n\nAdaptations of xerophytes:\n\nA. Morphological adaptations (structure):\n\n1. Leaves:\n   - Reduced to spines or scales\n   - Prevents water loss through transpiration\n   - Spines also protect from herbivores\n   - In some, leaves absent altogether\n\n2. Stem:\n   - Becomes green and fleshy\n   - Performs photosynthesis (since leaves are reduced)\n   - Stores water in succulent stems\n   - Thick, waxy coating (cuticle) on stem\n   - Ribbed or fluted (can expand when water available)\n\n3. Roots:\n   - Two types of adaptations:\n     a. Deep root system: taproots reach deep groundwater (Acacia)\n     b. Shallow widespread roots: absorb surface moisture from dew/light rain (cactus)\n   - Extensive root system covers large area\n\n4. Surface features:\n   - Shiny, glazed surface (reflects light and heat)\n   - Thick waxy cuticle (reduces water loss)\n   - Hairy or woolly covering (traps moist air, reduces transpiration)\n\nB. Anatomical adaptations (internal structure):\n\n5. Stomata:\n   - Few in number (reduces transpiration)\n   - Sunken in pits (protected from dry wind)\n   - Open at night (in some) to fix CO₂ (CAM plants)\n   - Close during day to conserve water\n\n6. Tissues:\n   - Thick cuticle on epidermis\n   - Multiple layered epidermis\n   - Palisade cells well-developed for photosynthesis\n   - Water storage tissue in stem (parenchyma)\n   - Reduced intercellular spaces\n\nC. Physiological adaptations (functions):\n\n7. CAM photosynthesis:\n   - Stomata open at night to take in CO₂\n   - CO₂ stored as organic acids\n   - Stomata close during day\n   - Photosynthesis occurs during day using stored CO₂\n   - Minimizes water loss\n\n8. Water conservation:\n   - Very low transpiration rate\n   - Can tolerate losing 50% of water content\n   - Rapid water uptake when available\n   - Store water in stem for dry periods\n\n9. Metabolic adaptations:\n   - Produce mucilage (holds water)\n   - Some have salt glands to excrete excess salt\n   - Can survive long droughts\n\nSpecific examples:\n\nCactus:\n- Leaves modified into spines\n- Green fleshy stem for photosynthesis and water storage\n- Shallow, widespread roots\n- Waxy coating on stem\n- CAM photosynthesis\n\nOpuntia:\n- Flattened stem segments (cladodes) look like leaves\n- Actually stems performing photosynthesis\n- Spines on stems\n- Stores water\n\nAcacia (babool):\n- Deep taproots reach groundwater\n- Small leaves reduce surface area\n- Thick cuticle\n- Some have thorns\n\nAloe vera:\n- Thick fleshy leaves store water\n- Leaf margins have teeth\n- Gel inside stores water\n- Waxy leaf surface\n\nThus, xerophytes have multiple adaptations to survive in harsh desert conditions."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of plants growing in mountains with examples.",
            "sample": "Plants growing in mountains face extreme conditions: low temperature, strong winds, snow, and reduced oxygen. They have special adaptations to survive.\n\nExamples of mountain plants:\n- Pine\n- Fir\n- Deodar\n- Spruce\n- Cedar\n- Juniper\n\nAdaptations of mountain plants:\n\nA. Morphological adaptations (structure):\n\n1. Shape of tree:\n   - Cone-shaped (pyramidal)\n   - Sloping branches\n   - Advantage: Snow slides off easily\n   - Prevents branches from breaking under snow weight\n\n2. Leaves:\n   - Needle-like or scale-like\n   - Small surface area\n   - Reduces water loss\n   - Helps snow slide off\n   - Thick, waxy cuticle\n   - Some have sunken stomata\n\n3. Bark:\n   - Thick bark\n   - Protects from cold\n   - Insulation\n\n4. Branches:\n   - Flexible\n   - Bend under snow without breaking\n   - Sloping downward\n\n5. Roots:\n   - Shallow but widespread\n   - Anchors tree in rocky soil\n   - Absorbs nutrients from thin soil layer\n\nB. Anatomical adaptations (internal structure):\n\n6. Leaves:\n   - Thick cuticle (reduces water loss)\n   - Sunken stomata (protects from cold winds)\n   - Resin canals (produces sticky resin)\n   - Resin prevents freezing\n   - Resin also protects from fungi\n\n7. Wood:\n   - Dense wood\n   - Strong to withstand snow and wind\n   - Resin in wood prevents decay\n\nC. Physiological adaptations (functions):\n\n8. Evergreen nature:\n   - Most conifers are evergreen\n   - Don't shed all leaves in winter\n   - Can photosynthesize whenever conditions allow\n   - Saves energy of producing new leaves each spring\n\n9. Cold tolerance:\n   - Produce antifreeze compounds\n   - Prevent ice crystal formation in cells\n   - Can survive freezing temperatures\n\n10. Reduced metabolism:\n    - Slow growth\n    - Conserves energy\n    - Can survive harsh winters\n\nSpecific examples:\n\nPine tree:\n- Needle-like leaves in bundles\n- Thick bark\n- Cone-shaped\n- Produces resin\n- Evergreen\n\nFir tree:\n- Flat needles\n- Upright cones\n- Pyramid shape\n- Aromatic resin\n\nDeodar:\n- Drooping branches\n- Needle-like leaves\n- Tall, conical shape\n- Found in Himalayas\n\nAdaptations at different altitudes:\n\nLower slopes:\n- Dense forests\n- Tall trees\n\nHigher slopes:\n- Stunted growth (krummholz)\n- Wind-pruned shapes\n- Ground-hugging shrubs\n- Mosses and lichens\n\nAlpine plants (above tree line):\n- Very short growing season\n- Grow close to ground\n- Hairy leaves (trap heat)\n- Dark colours (absorb heat)\n- Cushion growth form\n- Rapid flowering when snow melts\n\nThus, mountain plants are adapted to cold, snow, and wind through shape, leaf structure, and physiological mechanisms."
        },
        {
            "type": "subjective",
            "q": "What are epiphytes? Explain with examples how orchids are adapted as aerial plants.",
            "sample": "Epiphytes are plants that grow on other plants (usually trees) for physical support, but not for nutrition. They are also called aerial plants.\n\nEtymology:\n- 'Epi' means 'on top'\n- 'Phyte' means 'plant'\n\nCharacteristics of epiphytes:\n- Grow on trunks, branches of trees\n- Not parasites (don't take food from host)\n- Obtain water and nutrients from air, rain, and debris\n- Found mostly in tropical rainforests\n- Common in upper canopy for better light\n\nExamples of epiphytes:\n- Orchids\n- Mosses\n- Ferns\n- Bromeliads\n- Lichens\n- Some cacti\n\nOrchids as epiphytes:\n\nOrchids are the most common and well-adapted epiphytes. They show remarkable adaptations:\n\nA. Root adaptations:\n\n1. Two types of roots:\n   - Clinging roots: wrap around host tree for support\n   - Aerial roots: hang freely in air\n\n2. Velamen tissue:\n   - Thick, spongy covering on aerial roots\n   - Multiple layers of dead cells\n   - Absorbs moisture from air like a sponge\n   - Becomes white when dry, green when wet\n   - Protects root from damage\n\n3. Photosynthetic roots:\n   - Some orchid roots contain chlorophyll\n   - Can perform photosynthesis\n   - Helps when leaves are shaded\n\nB. Stem adaptations:\n\n4. Pseudobulbs:\n   - Swollen stem structures\n   - Store water and nutrients\n   - Help survive dry periods\n   - Present in many orchids\n\n5. Creeping stems (rhizomes):\n   - Grow along host branches\n   - Produce new shoots\n\nC. Leaf adaptations:\n\n6. Thick, waxy leaves:\n   - Reduce water loss\n   - Leathery texture\n   - Store water\n\n7. Succulent leaves:\n   - Some orchids have fleshy leaves\n   - Store water\n\n8. Curled leaves:\n   - Some species have leaves that curl\n   - Reduces surface area\n   - Minimizes transpiration\n\n9. CAM photosynthesis:\n   - Many orchids use CAM pathway\n   - Stomata open at night\n   - Reduces water loss\n\nD. Nutritional adaptations:\n\n10. Absorbing nutrients:\n    - From rain water\n    - From dust and debris on host\n    - From decaying organic matter collected around roots\n    - Some have special structures to trap leaf litter\n\n11. Mycorrhizal association:\n    - Orchid roots have fungal association\n    - Fungi help absorb nutrients\n    - Essential for seed germination\n    - Symbiotic relationship\n\nE. Reproductive adaptations:\n\n12. Tiny seeds:\n    - Millions of dust-like seeds\n    - Lightweight, carried by wind\n    - Can reach high branches\n\n13. Flowers:\n    - Bright colours attract pollinators\n    - Complex shapes for specific pollinators\n    - Long-lasting blooms\n\nAdvantages of epiphytic life:\n- Better access to sunlight (in canopy)\n- Less competition for light\n- Escape from ground herbivores\n- Better air circulation\n- Less fungal disease\n\nDisadvantages:\n- Limited water and nutrients\n- Exposure to wind\n- Risk of falling\n- Dependence on rain\n\nThus, orchids are perfectly adapted as epiphytes with specialized roots, water storage, and nutritional strategies."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of fish for living in water.",
            "sample": "Fish are aquatic animals perfectly adapted for life in water. Their adaptations include body shape, fins, gills, and other features.\n\nA. Body shape and external features:\n\n1. Streamlined body:\n   - Tapering at both ends\n   - Reduced water resistance (drag)\n   - Allows fast, efficient swimming\n   - Minimum energy expenditure\n\n2. Body covering:\n   - Covered with scales\n   - Scales overlap like roof tiles\n   - Provide protection\n   - Reduce friction\n   - Mucus coating on scales\n   - Mucus reduces friction\n   - Protects from infection\n\n3. Colouration:\n   - Dark on top, light below (countershading)\n   - Camouflage from predators\n   - Blends with water when viewed from above/below\n\nB. Locomotory adaptations (movement):\n\n4. Fins:\n   - Different types for different functions:\n   \n   a. Tail fin (caudal fin):\n      - Provides propulsion\n      - Acts as rudder for steering\n      - Powerful strokes push fish forward\n   \n   b. Dorsal fin (on back):\n      - Prevents rolling\n      - Provides stability\n   \n   c. Pectoral fins (side, behind gills):\n      - Balancing\n      - Braking\n      - Turning\n      - Slow swimming\n   \n   d. Pelvic fins (lower front):\n      - Stability\n      - Steering\n   \n   e. Anal fin (lower rear):\n      - Stability\n\n5. Body muscles:\n   - Segmented muscles (myotomes)\n   - Wave-like contractions\n   - Produce side-to-side movement\n\nC. Respiratory adaptations (breathing):\n\n6. Gills:\n   - Respiratory organs for underwater breathing\n   - Located on sides of head\n   - Covered by operculum (gill cover)\n   - Rich blood supply\n   - Large surface area\n   - Extract oxygen dissolved in water\n   - Water enters mouth, passes over gills, exits through operculum\n\n7. Counter-current exchange:\n   - Blood flows opposite to water flow\n   - Maximizes oxygen extraction\n   - Up to 80-90% oxygen extracted\n\nD. Sensory adaptations:\n\n8. Lateral line system:\n   - Row of sense organs along sides\n   - Detects water currents and vibrations\n   - Helps detect prey and predators\n   - Avoids obstacles\n\n9. Eyes:\n   - Large, on sides of head\n   - Wide field of vision\n   - No eyelids (always open)\n   - Adapted for underwater vision\n\n10. Olfactory organs (smell):\n    - Detect chemicals in water\n    - Find food, mates\n\n11. Inner ear:\n    - Detects sound vibrations\n    - Balance and orientation\n\nE. Buoyancy adaptations (floating/sinking):\n\n12. Swim bladder (air bladder):\n    - Gas-filled sac in body cavity\n    - Can adjust gas volume\n    - Increases or decreases buoyancy\n    - Fish can maintain depth without swimming\n    - Some fish lack swim bladder (sharks) and must swim constantly\n\n13. Fats and oils:\n    - Some fish store oils\n    - Lighter than water\n    - Aid buoyancy\n\nF. Other adaptations:\n\n14. Osmoregulation:\n    - Freshwater fish: excrete excess water, conserve salts\n    - Saltwater fish: drink water, excrete excess salt\n    - Maintain salt-water balance\n\n15. Reproduction:\n    - Many lay large numbers of eggs\n    - External fertilization in many\n    - Some guard eggs\n    - Some have live birth\n\n16. Feeding adaptations:\n    - Mouth position varies with feeding habit\n    - Teeth types suited to diet\n    - Filter feeders have gill rakers\n\nThus, fish are exquisitely adapted for aquatic life with streamlined body, fins for movement, gills for breathing, and swim bladder for buoyancy."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of camel for living in desert.",
            "sample": "Camel is called the 'ship of the desert' because it is perfectly adapted to survive in harsh desert conditions with extreme heat, sand, and scarce water.\n\nAdaptations of camel:\n\nA. Adaptations for water conservation:\n\n1. Water storage and use:\n   - Can drink up to 100 litres of water at once\n   - Water distributed throughout body tissues\n   - Can go without water for 10 days or more\n   - Loses water very slowly\n\n2. Minimal sweating:\n   - Sweats very little\n   - Body temperature can fluctuate (34°C to 41°C)\n   - Only sweats when temperature exceeds 41°C\n   - Conserves water by not cooling through sweat\n\n3. Concentrated urine:\n   - Kidneys produce highly concentrated urine\n   - Reabsorb most water\n   - Very little water lost in urine\n\n4. Dry faeces:\n   - Faeces contain very little water\n   - Can be used as fuel (dry)\n   - Reabsorbs water from intestines\n\n5. Slow breathing:\n   - Breathing rhythm is slow\n   - Loses little water through breath\n   - Nostrils can close to keep out sand\n\nB. Adaptations for food and energy:\n\n6. Hump:\n   - Stores fat, not water (common misconception)\n   - Fat can be converted to energy when food scarce\n   - Also produces water when fat metabolized\n   - Hump shrinks when camel uses fat\n   - Can survive up to 10 days without food\n\n7. Mouth and lips:\n   - Thick, leathery mouth lining\n   - Can eat thorny desert plants\n   - Split upper lip helps grasp plants\n   - Can close nostrils to keep out sand\n\nC. Adaptations for sand and heat:\n\n8. Feet:\n   - Large, fleshy, padded soles\n   - Spread weight on soft sand\n   - Prevent sinking\n   - Insulate from hot sand\n   - Wide surface area like snowshoes\n\n9. Legs:\n   - Long legs keep body away from hot ground\n   - Knees have thick pads for kneeling on hot sand\n\n10. Eyes:\n    - Long, thick eyelashes\n    - Protect eyes from wind-blown sand\n    - Two rows of eyelashes\n    - Third eyelid (nictitating membrane) can close to clear sand\n\n11. Nostrils:\n    - Can close completely\n    - Prevent sand inhalation during sandstorms\n    - Slit-like nostrils reduce water loss\n\n12. Ears:\n    - Small and hairy\n    - Hair prevents sand entry\n\n13. Coat:\n    - Thick coat reflects sunlight\n    - Light colour (tan/beige) reflects heat\n    - Coat insulates from both heat and cold\n    - Sheds thick winter coat in summer\n\nD. Behavioural adaptations:\n\n14. Resting posture:\n    - Sits facing sun (minimizes exposure)\n    - Keeps body close together\n\n15. Activity pattern:\n    - Feeds in early morning and evening\n    - Rests during hottest part of day\n\nE. Physiological adaptations:\n\n16. Temperature regulation:\n    - Allows body temperature to rise during day\n    - Reduces need for sweating\n    - Cools at night when temperature drops\n\n17. Blood cells:\n    - Oval-shaped RBCs (unlike humans' round)\n    - Can flow even when blood thick (dehydrated)\n    - Can rehydrate quickly without cell damage\n\n18. Kidney function:\n    - Highly efficient kidneys\n    - Reabsorb almost all water\n    - Produce very concentrated urine\n\nCamels can survive:\n- Loss of 25% body water (humans die at 12-15%)\n- Temperature from -20°C to 50°C\n- Days without food and water\n\nThus, camels have multiple adaptations - structural, physiological, and behavioural - that make them perfectly suited for desert life."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of mountain animals with examples.",
            "sample": "Mountain animals live in harsh conditions: low temperature, strong winds, snow, rugged terrain, and low oxygen. They have special adaptations to survive.\n\nExamples of mountain animals:\n- Mountain goat (ibex, markhor)\n- Yak\n- Snow leopard\n- Himalayan thar\n- Pika\n- Marmot\n- Blue sheep (bharal)\n\nAdaptations of mountain animals:\n\nA. Adaptations for cold:\n\n1. Thick fur or hair:\n   - Dense, woolly undercoat\n   - Long, coarse outer hair\n   - Traps air for insulation\n   - Yaks have long shaggy hair\n   - Snow leopards have thick fur\n\n2. Thick layer of fat:\n   - Subcutaneous fat under skin\n   - Insulates against cold\n   - Energy reserve\n\n3. Small ears and noses:\n   - Reduced surface area\n   - Minimizes heat loss\n   - Compare: Arctic animals have tiny ears\n\n4. Compact body shape:\n   - Rounded, stocky bodies\n   - Less surface area relative to volume\n   - Retains heat better\n\n5. Fur on feet:\n   - Provides insulation from snow\n   - Acts like snowshoes\n   - Prevents slipping\n\nB. Adaptations for locomotion on slopes:\n\n6. Strong hooves:\n   - Mountain goats have specialized hooves\n   - Hard outer edge for grip on rocks\n   - Soft, rubbery inner pad for traction on smooth surfaces\n   - Hooves spread when weight applied\n   - Acts like suction cup\n\n7. Cloven hooves:\n   - Split into two toes\n   - Can spread wide\n   - Provides stability\n\n8. Powerful legs:\n   - Strong muscles for climbing\n   - Can jump from rock to rock\n   - Excellent balance\n\n9. Dewclaws:\n   - Extra toes on back of legs\n   - Provide additional grip when descending\n\nC. Adaptations for breathing (low oxygen):\n\n10. Large lungs:\n     - Increased lung capacity\n     - More efficient oxygen extraction\n\n11. More red blood cells:\n     - Higher haemoglobin concentration\n     - Carries more oxygen\n\n12. Deep breathing:\n     - Slow, deep breaths\n     - Efficient gas exchange\n\nD. Adaptations for food:\n\n13. Ability to digest tough plants:\n     - Specialized stomach (ruminants)\n     - Can digest lichens, mosses\n\n14. Food storage:\n     - Some animals store food\n     - Marmots hoard food\n\n15. Migration:\n     - Move to lower slopes in winter\n     - Return to higher slopes in summer\n\nE. Behavioural adaptations:\n\n16. Hibernation:\n     - Some animals hibernate in winter\n     - Marmots, some rodents\n     - Sleep through cold months\n     - Live on stored fat\n\n17. Burrowing:\n     - Dig burrows for shelter\n     - Protect from cold and predators\n     - Pikas live in rock crevices\n\n18. Herding:\n     - Live in groups for warmth\n     - Protection from predators\n\nF. Camouflage:\n\n19. Coat colour:\n     - Snow leopards have spotted fur\n     - Blends with rocky terrain\n     - Mountain hares turn white in winter\n     - Ptarmigan (bird) changes colour seasonally\n\nSpecific examples:\n\nMountain goat (Ibex):\n- Incredible climbers\n- Specialized hooves\n- Can climb near-vertical cliffs\n- Avoids predators by reaching inaccessible places\n\nYak:\n- Long, shaggy hair\n- Large lungs\n- Sure-footed on slopes\n- Used by local people\n\nSnow leopard:\n- Thick, spotted fur\n- Long tail for balance\n- Powerful legs for jumping\n- Camouflaged in rocky terrain\n- Solitary and elusive\n\nMarmot:\n- Hibernates in winter\n- Lives in colonies\n- Whistles to warn of danger\n- Stores fat before hibernation\n\nThus, mountain animals have multiple adaptations for cold, low oxygen, and rugged terrain."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of birds for flight (aerial adaptations).",
            "sample": "Birds are adapted for aerial life with numerous modifications in their body structure, making flight possible and efficient.\n\nA. Body shape and external features:\n\n1. Streamlined body:\n   - Boat-shaped body\n   - Tapering at both ends\n   - Reduces air resistance (drag)\n   - Allows smooth airflow\n\n2. Body covered with feathers:\n   - Feathers are modified scales\n   - Types of feathers:\n     a. Flight feathers (remiges): on wings\n     b. Tail feathers (rectrices): for steering\n     c. Contour feathers: give shape\n     d. Down feathers: insulation\n\n3. Lightweight construction:\n   - Hollow bones\n   - Air sacs\n   - No heavy teeth or jaw muscles\n   - Light beak instead of heavy jaws\n\nB. Skeletal adaptations (bones):\n\n4. Hollow bones (pneumatic bones):\n   - Bones with air cavities\n   - Strong but very light\n   - Filled with air sac extensions\n   - Reduce weight without losing strength\n   - Example: Featherweight skeleton\n\n5. No bone marrow in many bones:\n   - Further reduces weight\n   - Air spaces instead\n\n6. Fusion of bones:\n   - Some bones fused for strength\n   - Provides rigid frame for flight muscles\n   - Furcula (wishbone) acts as spring\n\n7. Keel (carina) on sternum:\n   - Large breastbone with keel\n   - Provides attachment for flight muscles\n   - Well-developed in flying birds\n   - Reduced in flightless birds\n\nC. Muscular adaptations:\n\n8. Powerful flight muscles:\n   - Pectoralis major (downstroke)\n     * Largest muscle\n     * Pulls wings down\n   - Supracoracoideus (upstroke)\n     * Lifts wings up\n   - Breast muscles can be 1/3 of body weight\n\n9. Strong leg muscles:\n   - For take-off and landing\n   - Perching\n\nD. Wing adaptations:\n\n10. Forelimbs modified into wings:\n    - Arm bones (humerus, radius, ulna)\n    - Hand bones reduced and fused\n    - Support flight feathers\n\n11. Wing shape:\n    - Curved upper surface, flat lower\n    - Creates lift (aerofoil)\n    - Air moves faster over top, slower below\n    - Pressure difference creates lift\n\n12. Different wing types:\n    - Long, narrow: soaring (albatross)\n    - Broad, rounded: maneuverability (forest birds)\n    - Pointed, swept-back: speed (swift)\n\nE. Respiratory adaptations:\n\n13. Air sacs:\n    - Balloon-like extensions of lungs\n    - 7-9 air sacs in body\n    - Extend into hollow bones\n    - Make body lighter\n    - Act as bellows\n\n14. Efficient breathing:\n    - Flow-through lungs (not in-and-out)\n    - Air flows in one direction through lungs\n    - Oxygen extracted during both inhalation and exhalation\n    - Highly efficient for flight energy needs\n\nF. Other adaptations:\n\n15. Beak instead of teeth:\n    - Lightweight\n    - Various shapes for different diets\n    - No heavy jaw muscles\n\n16. Reduced digestive system:\n    - Fast digestion\n    - Lightweight\n    - Frequent elimination\n\n17. Absence of urinary bladder:\n    - Reduces weight\n    - Urine excreted with faeces\n\n18. Reproductive adaptations:\n    - Lay eggs (not heavy developing young inside)\n    - One ovary functional (reduces weight)\n\n19. Sensory adaptations:\n    - Excellent vision\n    - Eyes large relative to head\n    - Binocular vision in many\n    - Can see UV light\n\n20. Tail feathers:\n    - Act as rudder for steering\n    - Braking during landing\n    - Balance\n\nEnergy requirements:\n- High metabolic rate\n- Warm-blooded (endothermic)\n- Eat frequently (high energy food)\n- Efficient circulation\n\nFlightless birds (ostrich, emu, penguin):\n- Reduced keel\n- Smaller flight muscles\n- Adapted for running or swimming instead\n\nThus, birds have evolved numerous adaptations - skeletal, muscular, respiratory, and others - making them masters of the air."
        }
    ]
