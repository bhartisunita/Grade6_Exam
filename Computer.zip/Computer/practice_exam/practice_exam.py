import sys
import json
import os
import datetime

from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt

from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet


class PracticeExam(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle("Computer Practice Test")
        self.resize(1200,800)

        self.setStyleSheet("""
        QLabel{font-size:20px;}
        QRadioButton{font-size:20px;}
        QPushButton{font-size:16px;padding:8px;}
        QTextEdit{font-size:20px;}
        """)

        self.questions=[]
        self.index=0
        self.score=0
        self.chapter=None

        self.answered=set()
        self.wrong=[]
        self.student_answers={}

        self.show_chapter_screen()


    # ------------------------------------------------
    # Chapter selection
    # ------------------------------------------------

    def show_chapter_screen(self):

        widget=QWidget()
        layout=QVBoxLayout()

        title=QLabel("Select Chapter")
        title.setStyleSheet("font-size:30px;font-weight:bold")

        layout.addWidget(title)

        for ch in [2,7,8,9,10]:

            btn=QPushButton(f"Chapter {ch}")
            btn.clicked.connect(lambda _,c=ch:self.start_exam(c))

            layout.addWidget(btn)

        layout.addStretch()

        widget.setLayout(layout)
        self.setCentralWidget(widget)


    # ------------------------------------------------
    # Load questions
    # ------------------------------------------------

    def load_questions(self,chapter):

        filename=f"questions/chapter{chapter}.json"

        if not os.path.exists(filename):

            QMessageBox.warning(self,"Missing",
                f"{filename} not found")

            return None

        with open(filename,encoding="utf-8") as f:
            data=json.load(f)

        questions=[]
        questions.extend(data["mcq"])
        questions.extend(data["truefalse"])
        questions.extend(data["subjective"])

        return questions


    # ------------------------------------------------

    def start_exam(self,chapter):

        q=self.load_questions(chapter)

        if not q:
            return

        self.chapter=chapter
        self.questions=q

        self.index=0
        self.score=0
        self.answered=set()
        self.wrong=[]
        self.student_answers={}

        self.build_ui()
        self.load_question()


    # ------------------------------------------------
    # UI
    # ------------------------------------------------

    def build_ui(self):

        main=QVBoxLayout()
        main.setAlignment(Qt.AlignTop)

        header=QHBoxLayout()

        self.section=QLabel("")
        self.counter=QLabel("")

        header.addWidget(self.section)
        header.addStretch()
        header.addWidget(self.counter)

        main.addLayout(header)

        body=QHBoxLayout()

        scroll=QScrollArea()
        scroll.setWidgetResizable(True)

        container=QWidget()
        qpanel=QVBoxLayout(container)
        qpanel.setAlignment(Qt.AlignTop)

        self.question=QLabel("")
        self.question.setWordWrap(True)
        self.question.setStyleSheet("font-size:24px;font-weight:bold")

        qpanel.addWidget(self.question)

        self.status=QLabel("")
        qpanel.addWidget(self.status)

        self.options=[]

        for i in range(4):

            btn=QRadioButton()
            btn.clicked.connect(self.auto_check_answer)

            self.options.append(btn)
            qpanel.addWidget(btn)

        self.subjective=QTextEdit()
        self.subjective.hide()

        qpanel.addWidget(self.subjective)

        self.model_answer=QLabel("")
        self.model_answer.setWordWrap(True)
        self.model_answer.hide()

        qpanel.addWidget(self.model_answer)

        scroll.setWidget(container)

        body.addWidget(scroll,4)

        # Question map

        map_layout=QGridLayout()

        self.qbuttons=[]

        for i in range(len(self.questions)):

            btn=QPushButton(str(i+1))
            btn.setFixedSize(40,40)

            btn.setStyleSheet("background-color:yellow")

            btn.clicked.connect(lambda _,n=i:self.goto_question(n))

            self.qbuttons.append(btn)

            map_layout.addWidget(btn,i//5,i%5)

        body.addLayout(map_layout,1)

        main.addLayout(body)

        # Footer

        footer=QHBoxLayout()

        next_btn=QPushButton("Next")
        submit_btn=QPushButton("Submit Test")
        end_btn=QPushButton("End Test")

        next_btn.clicked.connect(self.next_question)
        submit_btn.clicked.connect(self.submit_test)
        end_btn.clicked.connect(self.end_test)

        footer.addWidget(next_btn)
        footer.addStretch()
        footer.addWidget(submit_btn)
        footer.addWidget(end_btn)

        main.addLayout(footer)

        widget=QWidget()
        widget.setLayout(main)

        self.setCentralWidget(widget)


    # ------------------------------------------------
    # Load question
    # ------------------------------------------------

    def load_question(self):

        q=self.questions[self.index]

        if self.index < 40:
            self.section.setText("Section: MCQ")
        elif self.index < 80:
            self.section.setText("Section: True / False")
        else:
            self.section.setText("Section: Subjective")

        self.counter.setText(f"Question {self.index+1}/100")

        self.question.setText(q["question"])

        self.status.setText("")
        self.model_answer.hide()

        for b in self.options:
            b.hide()
            b.setEnabled(True)
            b.setChecked(False)

        self.subjective.hide()

        if "options" in q:

            for i,opt in enumerate(q["options"]):

                self.options[i].setText(opt)
                self.options[i].show()

        elif "answer" in q:

            self.options[0].setText("True")
            self.options[1].setText("False")

            self.options[0].show()
            self.options[1].show()

        else:

            self.subjective.show()

            if self.index in self.student_answers:
                self.subjective.setText(self.student_answers[self.index])
            else:
                self.subjective.clear()

            if self.index in self.student_answers:
                self.model_answer.setText("Correct Answer: "+q["model_answer"])
                self.model_answer.show()

        self.qbuttons[self.index].setStyleSheet("background-color:blue")


    # ------------------------------------------------
    # Evaluate MCQ/TF
    # ------------------------------------------------

    def auto_check_answer(self):

        if self.index in self.answered:
            return

        q=self.questions[self.index]

        selected=None

        for b in self.options:
            if b.isChecked():
                selected=b.text()

        if selected is None:
            return

        correct=False

        if "options" in q:
            correct=(selected==q["answer"])

        elif "answer" in q:
            correct=((selected=="True")==q["answer"])

        for b in self.options:
            b.setEnabled(False)

        if correct:

            self.score+=1
            self.status.setText("✔ Correct")
            self.status.setStyleSheet("color:green")

            self.qbuttons[self.index].setStyleSheet("background-color:green")

        else:

            self.status.setText("✘ Wrong")
            self.status.setStyleSheet("color:red")

            self.qbuttons[self.index].setStyleSheet("background-color:red")

            self.wrong.append(q)

        self.answered.add(self.index)


    # ------------------------------------------------
    # Next question
    # ------------------------------------------------

    def next_question(self):

        q=self.questions[self.index]

        if "model_answer" in q:

            text=self.subjective.toPlainText().strip()

            if text:

                self.student_answers[self.index]=text

                self.qbuttons[self.index].setStyleSheet("background-color:purple")

                self.model_answer.setText("Correct Answer: "+q["model_answer"])
                self.model_answer.show()

            else:

                QMessageBox.warning(self,"Answer Required",
                                    "Please write your answer before continuing.")
                return

        if self.index < len(self.questions)-1:

            self.index+=1
            self.load_question()


    # ------------------------------------------------
    # Jump question
    # ------------------------------------------------

    def goto_question(self,n):

        self.index=n
        self.load_question()


    # ------------------------------------------------
    # Submit
    # ------------------------------------------------

    def submit_test(self):

        report=self.generate_report()

        QMessageBox.information(
            self,
            "Test Completed",
            f"Score: {self.score}/100\n\nReport saved:\n{report}"
        )

        self.show_chapter_screen()


    # ------------------------------------------------

    def end_test(self):

        reply=QMessageBox.question(
            self,
            "End Test",
            "Are you sure you want to end the test?",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply==QMessageBox.Yes:
            self.submit_test()


    # ------------------------------------------------
    # Report
    # ------------------------------------------------

    def generate_report(self):

        os.makedirs("reports",exist_ok=True)

        filename=f"reports/ch{self.chapter}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

        styles=getSampleStyleSheet()

        story=[]

        story.append(Paragraph(f"Computer Practice Test Chapter {self.chapter}",styles['Title']))
        story.append(Paragraph(f"Score: {self.score}/100",styles['Normal']))

        story.append(Spacer(1,20))
        story.append(Paragraph("Wrong Questions:",styles['Heading2']))

        for q in self.wrong:

            story.append(Paragraph(q["question"],styles['Normal']))

            if "options" in q:
                story.append(Paragraph(f"Correct Answer: {q['answer']}",styles['Normal']))

            elif "correct_statement" in q:
                story.append(Paragraph(q["correct_statement"],styles['Normal']))

            story.append(Spacer(1,10))

        doc=SimpleDocTemplate(filename)
        doc.build(story)

        return filename


app=QApplication(sys.argv)

window=PracticeExam()
window.show()

sys.exit(app.exec_())