import sys
import json
import random
import os
from datetime import datetime
from PyQt6.QtWidgets import *
from PyQt6.QtCore import Qt
from reportlab.pdfgen import canvas

QUESTION_COUNT = 30


class ExcelTrainer(QWidget):

    def __init__(self):

        super().__init__()

        self.setWindowTitle("Excel Learning Trainer")
        self.setGeometry(200,100,900,600)

        self.setStyleSheet("""
        QWidget {background:#F4F6F7;}
        QPushButton{
            background:#2C7BE5;
            color:white;
            padding:10px;
            font-size:18px;
            border-radius:6px;
        }
        QPushButton:hover{background:#1B5FC6;}
        """)

        self.load_questions()

        layout = QVBoxLayout()

        title = QLabel("Excel Learning Trainer – Chapter 2")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size:30px;font-weight:bold")

        layout.addWidget(title)

        self.student_name = QLineEdit()
        self.student_name.setPlaceholderText("Enter Student Name")
        self.student_name.setStyleSheet("font-size:18px")

        layout.addWidget(self.student_name)

        btn_mcq = QPushButton("MCQ Practice")
        btn_mcq.clicked.connect(self.start_mcq)

        btn_tf = QPushButton("True / False Practice")
        btn_tf.clicked.connect(self.start_tf)

        btn_subjective = QPushButton("Subjective Practice")
        btn_subjective.clicked.connect(self.start_subjective)

        for btn in [btn_mcq,btn_tf,btn_subjective]:
            layout.addWidget(btn)

        self.setLayout(layout)

    def load_questions(self):

        with open("questions.json") as f:
            data = json.load(f)

        self.mcq = data["mcq"]
        self.truefalse = data["truefalse"]
        self.subjective = data["subjective"]

    def start_mcq(self):
        self.quiz = QuizWindow("mcq",self.mcq,self.student_name.text())
        self.quiz.show()

    def start_tf(self):
        self.quiz = QuizWindow("truefalse",self.truefalse,self.student_name.text())
        self.quiz.show()

    def start_subjective(self):
        self.quiz = QuizWindow("subjective",self.subjective,self.student_name.text())
        self.quiz.show()


class QuizWindow(QWidget):

    def __init__(self,mode,questions,student):

        super().__init__()

        self.mode = mode
        self.student = student

        self.all_questions = questions

        self.questions = random.sample(questions,min(QUESTION_COUNT,len(questions)))

        self.index = 0
        self.score = 0

        self.wrong_questions = []

        self.setWindowTitle("Practice Mode")
        self.setGeometry(250,120,850,550)

        self.layout = QVBoxLayout()

        self.progress = QProgressBar()
        self.progress.setMaximum(len(self.questions))

        self.layout.addWidget(self.progress)

        self.q_label = QLabel()
        self.q_label.setWordWrap(True)
        self.q_label.setStyleSheet("font-size:22px")

        self.layout.addWidget(self.q_label)

        self.group = QButtonGroup()
        self.option_buttons = []

        for i in range(4):

            btn = QRadioButton()
            btn.setStyleSheet("font-size:18px")

            self.group.addButton(btn)
            self.option_buttons.append(btn)

            self.layout.addWidget(btn)

        self.text_box = QTextEdit()
        self.layout.addWidget(self.text_box)

        self.check_btn = QPushButton("Check Answer")
        self.check_btn.clicked.connect(self.check_answer)

        self.next_btn = QPushButton("Next Question")
        self.next_btn.clicked.connect(self.next_question)

        self.show_answer_btn = QPushButton("Show Answer")
        self.show_answer_btn.clicked.connect(self.show_answer)

        self.layout.addWidget(self.check_btn)
        self.layout.addWidget(self.next_btn)
        self.layout.addWidget(self.show_answer_btn)

        self.result = QLabel("")
        self.layout.addWidget(self.result)

        self.setLayout(self.layout)

        self.load_question()

    def load_question(self):

        self.progress.setValue(self.index + 1)

        q = self.questions[self.index]

        self.q_label.setText(
            f"Question {self.index+1} / {len(self.questions)}\n\n{q['question']}"
        )

        for btn in self.option_buttons:
            btn.hide()

        self.text_box.hide()

        if self.mode == "mcq":

            for i,opt in enumerate(q["options"]):
                self.option_buttons[i].setText(opt)
                self.option_buttons[i].setChecked(False)
                self.option_buttons[i].show()

        elif self.mode == "truefalse":

            self.option_buttons[0].setText("True")
            self.option_buttons[1].setText("False")

            self.option_buttons[0].show()
            self.option_buttons[1].show()

        elif self.mode == "subjective":

            self.text_box.clear()
            self.text_box.show()

        self.result.setText("")

    def check_answer(self):

        q = self.questions[self.index]

        correct = False

        if self.mode == "mcq":

            selected = None

            for btn in self.option_buttons:
                if btn.isChecked():
                    selected = btn.text()

            if selected == q["answer"]:
                correct = True
                self.score += 1
                self.result.setText("✔ Correct")
                self.result.setStyleSheet("color:green")
            else:
                self.result.setText(f"✘ Correct Answer: {q['answer']}")
                self.result.setStyleSheet("color:red")

        elif self.mode == "truefalse":

            selected = self.option_buttons[0].isChecked()

            if selected == q["answer"]:
                correct = True
                self.score += 1
                self.result.setText("✔ Correct")
            else:
                self.result.setText(
                    f"✘ Wrong\nCorrect statement:\n{q['correct_statement']}"
                )

        elif self.mode == "subjective":

            correct = True
            self.result.setText("Answer Saved")

        if not correct:
            self.wrong_questions.append(q)

    def show_answer(self):

        if self.mode == "subjective":

            q = self.questions[self.index]

            QMessageBox.information(
                self,
                "Model Answer",
                q["model_answer"]
            )

    def next_question(self):

        if self.index < len(self.questions)-1:

            self.index += 1
            self.load_question()

        else:

            self.show_result_screen()

    def show_result_screen(self):

        msg = QMessageBox()

        msg.setWindowTitle("Quiz Finished")

        msg.setText(
            f"Score: {self.score}/{len(self.questions)}"
        )

        retry_button = msg.addButton("Retry Wrong Questions",QMessageBox.ButtonRole.ActionRole)

        msg.addButton("Close",QMessageBox.ButtonRole.RejectRole)

        msg.exec()

        if msg.clickedButton() == retry_button:

            if len(self.wrong_questions) == 0:

                QMessageBox.information(self,"Great!","No wrong questions.")

            else:

                self.questions = self.wrong_questions
                self.index = 0
                self.score = 0
                self.wrong_questions = []

                self.load_question()

    def generate_report(self):

        if not os.path.exists("reports"):
            os.mkdir("reports")

        filename = f"reports/report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

        c = canvas.Canvas(filename)

        c.drawString(50,800,f"Student: {self.student}")
        c.drawString(50,780,f"Score: {self.score}/{len(self.questions)}")

        c.save()


app = QApplication(sys.argv)

window = ExcelTrainer()
window.show()

sys.exit(app.exec())