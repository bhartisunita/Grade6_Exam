import sys
import json
import os
import datetime
from PyQt5.QtWidgets import *
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet


class PracticeExam(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Computer Practice Test")
        self.resize(1200,700)

        self.questions=[]
        self.index=0
        self.score=0
        self.chapter=None
        self.answered=set()

        self.show_chapter_selection()

    # -----------------------
    # CHAPTER SELECTION
    # -----------------------

    def show_chapter_selection(self):

        widget=QWidget()
        layout=QVBoxLayout()

        title=QLabel("Select Chapter")
        title.setStyleSheet("font-size:28px")

        layout.addWidget(title)

        chapters=[2,7,8,9,10]

        for ch in chapters:

            btn=QPushButton(f"Chapter {ch}")
            btn.clicked.connect(lambda _,c=ch:self.start_exam(c))
            layout.addWidget(btn)

        widget.setLayout(layout)
        self.setCentralWidget(widget)

    # -----------------------
    # LOAD QUESTIONS
    # -----------------------

    def load_questions(self,chapter):

        filename=f"questions/chapter{chapter}.json"

        if not os.path.exists(filename):
            QMessageBox.warning(self,"Missing",f"Questions for Chapter {chapter} not added yet")
            return None

        with open(filename) as f:
            data=json.load(f)

        questions=[]
        questions+=data["mcq"]
        questions+=data["truefalse"]
        questions+=data["subjective"]

        return questions

    # -----------------------

    def start_exam(self,chapter):

        q=self.load_questions(chapter)

        if not q:
            return

        self.chapter=chapter
        self.questions=q
        self.index=0
        self.score=0
        self.answered=set()

        self.build_ui()

        self.load_question()

    # -----------------------
    # UI
    # -----------------------

    def build_ui(self):

        main=QVBoxLayout()

        # HEADER

        header=QHBoxLayout()

        self.title=QLabel(f"Chapter {self.chapter} Practice Test")
        self.counter=QLabel("Q 1/"+str(len(self.questions)))

        header.addWidget(self.title)
        header.addStretch()
        header.addWidget(self.counter)

        main.addLayout(header)

        # MAIN AREA

        body=QHBoxLayout()

        # QUESTION PANEL

        qpanel=QVBoxLayout()

        self.question=QLabel("")
        self.question.setWordWrap(True)

        qpanel.addWidget(self.question)

        self.options=[]

        for i in range(4):

            btn=QRadioButton()
            self.options.append(btn)
            qpanel.addWidget(btn)

        self.subjective=QTextEdit()
        self.subjective.hide()

        qpanel.addWidget(self.subjective)

        body.addLayout(qpanel,4)

        # QUESTION MAP

        map_layout=QGridLayout()

        self.qbuttons=[]

        cols=5
        rows=(len(self.questions)//cols)+1

        num=0

        for r in range(rows):
            for c in range(cols):

                if num>=len(self.questions):
                    break

                btn=QPushButton(str(num+1))
                btn.setFixedSize(35,35)

                btn.clicked.connect(lambda _,n=num:self.goto_question(n))

                self.qbuttons.append(btn)

                map_layout.addWidget(btn,r,c)

                num+=1

        body.addLayout(map_layout,1)

        main.addLayout(body)

        # FOOTER

        footer=QHBoxLayout()

        check=QPushButton("Check Answer")
        nextb=QPushButton("Next")

        check.clicked.connect(self.check_answer)
        nextb.clicked.connect(self.next_question)

        footer.addWidget(check)
        footer.addStretch()
        footer.addWidget(nextb)

        main.addLayout(footer)

        widget=QWidget()
        widget.setLayout(main)

        self.setCentralWidget(widget)

    # -----------------------
    # LOAD QUESTION
    # -----------------------

    def load_question(self):

        q=self.questions[self.index]

        self.counter.setText(f"Q {self.index+1}/{len(self.questions)}")

        self.question.setText(q["question"])

        for b in self.options:
            b.hide()

        self.subjective.hide()

        if "options" in q:

            for i,opt in enumerate(q["options"]):
                self.options[i].setText(opt)
                self.options[i].setChecked(False)
                self.options[i].show()

        elif "answer" in q:

            self.options[0].setText("True")
            self.options[1].setText("False")

            self.options[0].show()
            self.options[1].show()

        else:

            self.subjective.show()

    # -----------------------

    def check_answer(self):

        if self.index in self.answered:
            return

        q=self.questions[self.index]

        correct=False

        if "options" in q:

            for b in self.options:
                if b.isChecked():
                    if b.text()==q["answer"]:
                        correct=True

        elif "answer" in q:

            for b in self.options[:2]:
                if b.isChecked():
                    if (b.text()=="True")==q["answer"]:
                        correct=True

        else:

            correct=True

        if correct:
            self.score+=1

        self.answered.add(self.index)

        self.qbuttons[self.index].setStyleSheet("background-color:green")

    # -----------------------

    def next_question(self):

        self.index+=1

        if self.index>=len(self.questions):

            report=self.generate_report()

            QMessageBox.information(
                self,
                "Test Completed",
                f"Score: {self.score}/{len(self.questions)}\n\nCheck PDF:\n{report}"
            )

            self.show_chapter_selection()
            return

        self.load_question()

    # -----------------------

    def goto_question(self,n):

        self.index=n
        self.load_question()

    # -----------------------
    # PDF REPORT
    # -----------------------

    def generate_report(self):

        os.makedirs("reports",exist_ok=True)

        filename=f"reports/ch{self.chapter}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

        styles=getSampleStyleSheet()

        story=[]

        story.append(Paragraph(f"Computer Practice Test Chapter {self.chapter}",styles['Title']))
        story.append(Paragraph(f"Score: {self.score}/{len(self.questions)}",styles['Normal']))

        doc=SimpleDocTemplate(filename)

        doc.build(story)

        return filename


app=QApplication(sys.argv)

window=PracticeExam()
window.show()

sys.exit(app.exec_())