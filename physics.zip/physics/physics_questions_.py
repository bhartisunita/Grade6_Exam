"""
English Language — Grade 6 ICSE
Comprehension Practice Questions
Based on: Grade6_Comprehension_Worksheet.docx
3 Passages • 10 Questions Each
"""

QUESTIONS = {

    # ──────────────────────────────────────────────────────────────────
    "Passage 1 — The Wonder of the Ocean": [
        {
            "type": "mcq",
            "q": "What percentage of the Earth's surface does the ocean cover?",
            "options": [
                "More than 50%",
                "More than 70%",
                "Exactly 60%",
                "Less than 70%"
            ],
            "answer": "More than 70%",
            "explanation": "The passage states: 'The ocean covers more than seventy percent of the Earth's surface.'"
        },
        {
            "type": "mcq",
            "q": "Why are coral reefs called the 'rainforests of the sea'?",
            "options": [
                "Because they grow near rainforests",
                "Because they cover a large area of the ocean",
                "Because they cover a small area but support a huge variety of marine life",
                "Because they produce oxygen like rainforests"
            ],
            "answer": "Because they cover a small area but support a huge variety of marine life",
            "explanation": "Coral reefs cover less than 1% of the ocean floor but support nearly 25% of all marine life — just like rainforests which cover a small land area but hold enormous biodiversity."
        },
        {
            "type": "mcq",
            "q": "What causes coral bleaching?",
            "options": [
                "Plastic pollution entering the ocean",
                "Overfishing near coral reefs",
                "Rising ocean temperatures due to climate change",
                "Oil spills in the ocean"
            ],
            "answer": "Rising ocean temperatures due to climate change",
            "explanation": "The passage says 'rising ocean temperatures due to climate change are causing a process called coral bleaching, which destroys these delicate ecosystems.'"
        },
        {
            "type": "mcq",
            "q": "How does the ocean help in regulating the Earth's climate?",
            "options": [
                "By producing rain clouds",
                "By absorbing heat from the sun and distributing it through ocean currents",
                "By storing carbon dioxide in coral reefs",
                "By reflecting sunlight back into space"
            ],
            "answer": "By absorbing heat from the sun and distributing it through ocean currents",
            "explanation": "The passage states the ocean regulates climate 'by absorbing heat from the sun and distributing it around the globe through ocean currents.'"
        },
        {
            "type": "mcq",
            "q": "How much plastic enters the ocean every year?",
            "options": [
                "More than one million tonnes",
                "More than five million tonnes",
                "More than eight million tonnes",
                "More than ten million tonnes"
            ],
            "answer": "More than eight million tonnes",
            "explanation": "The passage states: 'Every year, more than eight million tonnes of plastic enter the ocean.'"
        },
        {
            "type": "tf",
            "q": "Coral reefs cover more than twenty-five percent of the ocean floor.",
            "answer": "False",
            "explanation": "Coral reefs cover LESS than one percent of the ocean floor, but support nearly twenty-five percent of all marine life."
        },
        {
            "type": "tf",
            "q": "Scientists have discovered that some marine organisms can be used to develop medicines for diseases like cancer.",
            "answer": "True",
            "explanation": "The passage says scientists are discovering that 'marine plants and animals contain compounds that can be used to develop new medicines for diseases such as cancer and arthritis.'"
        },
        {
            "type": "mcq",
            "q": "Find the word in Paragraph 2 that means 'very sensitive or fragile'.",
            "options": [
                "Bleaching",
                "Vital",
                "Delicate",
                "Marine"
            ],
            "answer": "Delicate",
            "explanation": "'Delicate' means very sensitive or fragile. In the passage it describes coral reef ecosystems: '…which destroys these delicate ecosystems.'"
        },
        {
            "type": "mcq",
            "q": "Find the word in Paragraph 4 that means 'impossible to undo or reverse'.",
            "options": [
                "Serious",
                "Irreversible",
                "Precious",
                "Primary"
            ],
            "answer": "Irreversible",
            "explanation": "'Irreversible' means impossible to undo. The passage says plastic pollution and other threats are 'causing irreversible damage to marine habitats.'"
        },
        {
            "type": "subjective",
            "q": "Do you think individuals can make a difference in protecting the ocean? Give one reason from the passage to support your answer.",
            "sample": "Yes, individuals can make a difference. The passage says 'it is the responsibility of every individual to protect this precious resource for future generations,' which suggests that individual actions and choices — such as reducing plastic use — do matter and collectively have an impact on the health of the ocean."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    "Passage 2 — Thomas Edison: The Wizard of Menlo Park": [
        {
            "type": "mcq",
            "q": "Where and when was Thomas Edison born?",
            "options": [
                "New York, 1850",
                "Milan, Ohio, 1847",
                "Menlo Park, New Jersey, 1847",
                "Ohio, 1857"
            ],
            "answer": "Milan, Ohio, 1847",
            "explanation": "The passage states Edison was 'Born on February 11, 1847, in Milan, Ohio.'"
        },
        {
            "type": "mcq",
            "q": "Why did Edison's mother decide to homeschool him?",
            "options": [
                "Because there were no schools near their home",
                "Because Edison was physically unwell",
                "Because his teachers considered him a poor student",
                "Because Edison refused to attend school"
            ],
            "answer": "Because his teachers considered him a poor student",
            "explanation": "The passage says 'As a child, he was considered a poor student by his teachers, and his mother decided to homeschool him.'"
        },
        {
            "type": "mcq",
            "q": "What did people use to light their homes BEFORE Edison's light bulb?",
            "options": [
                "Electric torches and lanterns",
                "Candles and gas lamps",
                "Firewood and oil lamps",
                "Solar-powered lights"
            ],
            "answer": "Candles and gas lamps",
            "explanation": "The passage states: 'Before this invention, people relied on candles and gas lamps to light their homes.'"
        },
        {
            "type": "mcq",
            "q": "How many different materials did Edison reportedly test before finding the right filament for the light bulb?",
            "options": [
                "Over one hundred",
                "Over five hundred",
                "Over a thousand",
                "Exactly ninety-nine"
            ],
            "answer": "Over a thousand",
            "explanation": "The passage says 'He reportedly tested over a thousand different materials before finding the right filament for the light bulb.'"
        },
        {
            "type": "mcq",
            "q": "What was the phonograph?",
            "options": [
                "An improved version of the telegraph",
                "A device that could record and play back sound",
                "An early version of the telephone",
                "A device used for transmitting images"
            ],
            "answer": "A device that could record and play back sound",
            "explanation": "The passage describes the phonograph as 'a device that could record and play back sound.'"
        },
        {
            "type": "mcq",
            "q": "How many patents did Edison hold in the United States?",
            "options": [
                "193",
                "1,903",
                "1,093",
                "103"
            ],
            "answer": "1,093",
            "explanation": "The passage states: 'In total, he held 1,093 patents in the United States, a record that stood for many decades.'"
        },
        {
            "type": "tf",
            "q": "Edison's laboratory at Menlo Park was the world's first industrial research laboratory.",
            "answer": "True",
            "explanation": "The passage says 'Edison established the world's first industrial research laboratory in Menlo Park, New Jersey.'"
        },
        {
            "type": "mcq",
            "q": "Find the word in Paragraph 2 that means 'continuing firmly despite difficulty'.",
            "options": [
                "Famously",
                "Persistent",
                "Transformed",
                "Reportedly"
            ],
            "answer": "Persistent",
            "explanation": "'Persistent' means continuing firmly despite difficulty or failure. The passage says Edison 'was not merely lucky — he was famously persistent.'"
        },
        {
            "type": "mcq",
            "q": "Find the word in Paragraph 4 that means 'working together as a team'.",
            "options": [
                "Revolutionary",
                "Organised",
                "Collaborative",
                "Industrial"
            ],
            "answer": "Collaborative",
            "explanation": "'Collaborative' means working jointly with others. The passage describes Edison's lab model as 'organised, collaborative research.'"
        },
        {
            "type": "subjective",
            "q": "Edison said genius is 'one percent inspiration and ninety-nine percent perspiration.' What do you think he meant by this? Do you agree? Give a reason.",
            "sample": "Edison meant that great achievement depends mostly on hard work and sustained effort (99%) rather than natural talent or a lucky idea (1%). I agree because Edison himself is proof — he tested over a thousand materials for the light bulb, showing that persistence matters far more than a single moment of brilliance."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    "Passage 3 — Jaipur: The Pink City of India": [
        {
            "type": "mcq",
            "q": "Who founded Jaipur and in which year?",
            "options": [
                "Maharaja Jai Singh I, in 1700",
                "Maharaja Sawai Jai Singh II, in 1727",
                "The Prince of Wales, in 1876",
                "Maharaja Sawai Jai Singh II, in 1872"
            ],
            "answer": "Maharaja Sawai Jai Singh II, in 1727",
            "explanation": "The passage states: 'Founded in 1727 by Maharaja Sawai Jai Singh II.'"
        },
        {
            "type": "mcq",
            "q": "Jaipur was designed according to which ancient Indian science of architecture?",
            "options": [
                "Feng Shui",
                "Vastu Shastra",
                "Arthashastra",
                "Dharmashastra"
            ],
            "answer": "Vastu Shastra",
            "explanation": "The passage says 'The city was designed according to the principles of Vastu Shastra, an ancient Indian science of architecture.'"
        },
        {
            "type": "mcq",
            "q": "Why was Jaipur painted pink in 1876?",
            "options": [
                "Because the Maharaja loved the colour pink",
                "To celebrate Jaipur becoming the capital of Rajasthan",
                "To welcome the Prince of Wales and Prince Albert",
                "As part of a city beautification programme"
            ],
            "answer": "To welcome the Prince of Wales and Prince Albert",
            "explanation": "The passage states: 'In 1876, the city was painted pink to welcome the Prince of Wales and Prince Albert, as pink is considered the colour of hospitality in Rajasthan.'"
        },
        {
            "type": "mcq",
            "q": "How many small windows (jharokhas) does the Hawa Mahal have?",
            "options": [
                "593",
                "853",
                "953",
                "1,053"
            ],
            "answer": "953",
            "explanation": "The passage describes the Hawa Mahal as 'a five-storey palace with 953 small windows, called jharokhas.'"
        },
        {
            "type": "mcq",
            "q": "What was the purpose of the jharokhas (small windows) in the Hawa Mahal?",
            "options": [
                "To allow cool air into the palace",
                "To allow royal women to observe street life while remaining unseen",
                "To display the royal flag on festival days",
                "To fire arrows during battle"
            ],
            "answer": "To allow royal women to observe street life while remaining unseen",
            "explanation": "The passage says the jharokhas 'allowed royal women to observe street life while remaining unseen,' preserving their privacy."
        },
        {
            "type": "tf",
            "q": "The City Palace in Jaipur is fully occupied by the royal family and has no museum.",
            "answer": "False",
            "explanation": "The passage says the City Palace is 'still partially occupied by the royal family' and 'houses a fascinating museum.'"
        },
        {
            "type": "mcq",
            "q": "In which year was Jaipur designated a UNESCO World Heritage City?",
            "options": [
                "2009",
                "2015",
                "2017",
                "2019"
            ],
            "answer": "2019",
            "explanation": "The passage states: 'Jaipur was designated a UNESCO World Heritage City in 2019.'"
        },
        {
            "type": "mcq",
            "q": "Find the word in Paragraph 1 that means 'organised according to a plan with a regular pattern'.",
            "options": [
                "Distinct",
                "Grid",
                "Principle",
                "Founded"
            ],
            "answer": "Grid",
            "explanation": "'Grid' refers to an organised pattern of streets crossing at right angles. The passage says Jaipur 'was laid out in a grid pattern with wide streets.'"
        },
        {
            "type": "mcq",
            "q": "Find the word in Paragraph 4 that means 'officially named or appointed for a specific purpose'.",
            "options": [
                "Celebrated",
                "Recognised",
                "Designated",
                "Vibrant"
            ],
            "answer": "Designated",
            "explanation": "'Designated' means officially named or appointed. The passage says Jaipur 'was designated a UNESCO World Heritage City in 2019.'"
        },
        {
            "type": "subjective",
            "q": "Would you like to visit Jaipur? Using information from the passage, give two reasons to support your answer.",
            "sample": "Yes, I would love to visit Jaipur. First, the city has magnificent monuments like the Hawa Mahal — a five-storey palace with 953 tiny windows — and the Amber Fort, a massive hilltop fortress, both of which would be thrilling to explore. Second, Jaipur's bustling bazaars like Johari Bazaar offer a wonderful variety of jewellery, block-printed textiles, blue pottery, and spices, making it a vibrant and colourful cultural experience."
        },
    ],
}
