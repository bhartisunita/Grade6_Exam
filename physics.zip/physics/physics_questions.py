"""
Physics — Grade 6 ICSE
Comprehensive Practice Questions
Based on: Physics Textbook Chapters 3-8
6 Chapters • 100 Questions Each (40 MCQ, 40 TF, 20 Subjective)
"""

QUESTIONS = {

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 3: Physical Quantities and Measurement
    # ──────────────────────────────────────────────────────────────────
    "Chapter 3 — Physical Quantities and Measurement": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "What is the branch of science that deals with measurement called?",
            "options": [
                "Physics",
                "Metrology",
                "Meteorology",
                "Biology"
            ],
            "answer": "Metrology",
            "explanation": "The passage states: 'The branch of science that deals with measurement is known as metrology.'"
        },
        {
            "type": "mcq",
            "q": "Which of the following is a fundamental physical quantity?",
            "options": [
                "Area",
                "Volume",
                "Speed",
                "Length"
            ],
            "answer": "Length",
            "explanation": "Length is one of the seven fundamental physical quantities. Area, volume, and speed are derived quantities."
        },
        {
            "type": "mcq",
            "q": "How many fundamental physical quantities are there?",
            "options": [
                "5",
                "7",
                "9",
                "12"
            ],
            "answer": "7",
            "explanation": "There are seven fundamental physical quantities: length, mass, temperature, time, electric current, luminous intensity, and amount of substance."
        },
        {
            "type": "mcq",
            "q": "The measurement of a physical quantity consists of which two parts?",
            "options": [
                "Number and symbol",
                "Magnitude and unit",
                "Value and label",
                "Prefix and suffix"
            ],
            "answer": "Magnitude and unit",
            "explanation": "The measurement of a physical quantity consists of the magnitude (numeral) and the unit."
        },
        {
            "type": "mcq",
            "q": "In ancient Babylon and Egypt, what was a 'cubit'?",
            "options": [
                "The width of a hand",
                "The length from elbow to tip of middle finger",
                "The length from thumb to little finger",
                "The length of a foot"
            ],
            "answer": "The length from elbow to tip of middle finger",
            "explanation": "A cubit was the length of an adult person's forearm, from the elbow to the tip of the middle finger."
        },
        {
            "type": "mcq",
            "q": "What is the SI unit of length?",
            "options": [
                "Centimetre",
                "Kilometre",
                "Metre",
                "Foot"
            ],
            "answer": "Metre",
            "explanation": "The SI unit of length is metre (m)."
        },
        {
            "type": "mcq",
            "q": "How many millimetres are there in one centimetre?",
            "options": [
                "1",
                "10",
                "100",
                "1000"
            ],
            "answer": "10",
            "explanation": "10 mm = 1 cm"
        },
        {
            "type": "mcq",
            "q": "1 inch is equal to how many centimetres?",
            "options": [
                "1.54 cm",
                "2.00 cm",
                "2.54 cm",
                "3.08 cm"
            ],
            "answer": "2.54 cm",
            "explanation": "1 inch = 2.54 cm"
        },
        {
            "type": "mcq",
            "q": "Which system of measurement uses foot, pound, and second as units?",
            "options": [
                "SI system",
                "MKS system",
                "CGS system",
                "FPS system"
            ],
            "answer": "FPS system",
            "explanation": "FPS stands for foot-pound-second system."
        },
        {
            "type": "mcq",
            "q": "What does the prefix 'kilo' mean?",
            "options": [
                "One hundredth part",
                "One thousandth part",
                "One thousand times",
                "Ten times"
            ],
            "answer": "One thousand times",
            "explanation": "Kilo means one thousand times. For example, 1 kilometre = 1000 metres."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a derived physical quantity?",
            "options": [
                "Mass",
                "Time",
                "Temperature",
                "Area"
            ],
            "answer": "Area",
            "explanation": "Area is derived from length × length. Mass, time, and temperature are fundamental quantities."
        },
        {
            "type": "mcq",
            "q": "What is the SI unit of mass?",
            "options": [
                "Gram",
                "Kilogram",
                "Pound",
                "Quintal"
            ],
            "answer": "Kilogram",
            "explanation": "The SI unit of mass is kilogram (kg)."
        },
        {
            "type": "mcq",
            "q": "What is the SI unit of time?",
            "options": [
                "Minute",
                "Hour",
                "Second",
                "Day"
            ],
            "answer": "Second",
            "explanation": "The SI unit of time is second (s)."
        },
        {
            "type": "mcq",
            "q": "What is the SI unit of temperature?",
            "options": [
                "Celsius",
                "Fahrenheit",
                "Kelvin",
                "Joule"
            ],
            "answer": "Kelvin",
            "explanation": "The SI unit of temperature is kelvin (K)."
        },
        {
            "type": "mcq",
            "q": "Which device is used to measure the thickness of a wire indirectly?",
            "options": [
                "Ruler only",
                "Measuring tape",
                "Pencil and ruler by coiling method",
                "Thermometer"
            ],
            "answer": "Pencil and ruler by coiling method",
            "explanation": "The diameter of a wire can be measured by coiling it around a pencil and measuring the total length of turns."
        },
        {
            "type": "mcq",
            "q": "What is the error called that arises due to wrong positioning of the eye while reading a scale?",
            "options": [
                "Human error",
                "Parallax error",
                "Systematic error",
                "Random error"
            ],
            "answer": "Parallax error",
            "explanation": "The error due to wrong positioning of the eye is called parallax error."
        },
        {
            "type": "mcq",
            "q": "What is the principle of working of a beam balance?",
            "options": [
                "When two bodies with equal mass are placed on the two pans, the beam becomes horizontal",
                "It measures weight directly",
                "It works on electromagnetic principle",
                "It uses spring mechanism"
            ],
            "answer": "When two bodies with equal mass are placed on the two pans, the beam becomes horizontal",
            "explanation": "A beam balance works on the principle that when two bodies with equal mass are placed on the two pans, they secure a state of horizontal balance."
        },
        {
            "type": "mcq",
            "q": "Which weighing device has very high accuracy and sensitivity and is used in laboratories?",
            "options": [
                "Beam balance",
                "Grocer's balance",
                "Physical balance",
                "Electronic weighing machine"
            ],
            "answer": "Physical balance",
            "explanation": "A physical balance is a modified and highly sensitive version of the beam balance used in science laboratories."
        },
        {
            "type": "mcq",
            "q": "How many seconds are there in one minute?",
            "options": [
                "30",
                "60",
                "100",
                "120"
            ],
            "answer": "60",
            "explanation": "1 minute = 60 seconds"
        },
        {
            "type": "mcq",
            "q": "What is a mean solar day?",
            "options": [
                "The time taken by the sun to rotate",
                "The time taken by the earth to make one complete rotation about its axis",
                "12 hours of daylight",
                "The time from sunrise to sunset"
            ],
            "answer": "The time taken by the earth to make one complete rotation about its axis",
            "explanation": "Mean solar day is the time taken by the earth to make one complete rotation about its own axis."
        },
        {
            "type": "mcq",
            "q": "In the 24-hour clock system, what does 17:00 hours represent in 12-hour format?",
            "options": [
                "5:00 a.m.",
                "5:00 p.m.",
                "7:00 p.m.",
                "7:00 a.m."
            ],
            "answer": "5:00 p.m.",
            "explanation": "17:00 - 12:00 = 5:00 p.m."
        },
        {
            "type": "mcq",
            "q": "What is the normal temperature of the human body in Celsius?",
            "options": [
                "35°C",
                "37°C",
                "39°C",
                "42°C"
            ],
            "answer": "37°C",
            "explanation": "The normal temperature of human body is 37°C."
        },
        {
            "type": "mcq",
            "q": "What is the normal temperature of the human body in Fahrenheit?",
            "options": [
                "98.6°F",
                "100°F",
                "97°F",
                "99.2°F"
            ],
            "answer": "98.6°F",
            "explanation": "37°C = 98.6°F"
        },
        {
            "type": "mcq",
            "q": "What is the lower fixed point (ice point) in the Celsius scale?",
            "options": [
                "0°C",
                "32°C",
                "100°C",
                "273°C"
            ],
            "answer": "0°C",
            "explanation": "In the Celsius scale, the lower fixed point is taken as 0°C."
        },
        {
            "type": "mcq",
            "q": "What is the upper fixed point (steam point) in the Fahrenheit scale?",
            "options": [
                "100°F",
                "180°F",
                "212°F",
                "373°F"
            ],
            "answer": "212°F",
            "explanation": "In the Fahrenheit scale, the upper fixed point is 212°F."
        },
        {
            "type": "mcq",
            "q": "How many equal parts is the distance between ice point and steam point divided into in the Celsius scale?",
            "options": [
                "100",
                "180",
                "212",
                "273"
            ],
            "answer": "100",
            "explanation": "The distance between 0°C and 100°C is divided into 100 equal parts."
        },
        {
            "type": "mcq",
            "q": "What is the ice point in the Kelvin scale?",
            "options": [
                "0 K",
                "273.15 K",
                "373.15 K",
                "100 K"
            ],
            "answer": "273.15 K",
            "explanation": "According to the Kelvin scale, the ice point is 273.15 K."
        },
        {
            "type": "mcq",
            "q": "What is the purpose of the kink in a clinical thermometer?",
            "options": [
                "To make it look different",
                "To prevent mercury from moving back into the bulb after reading",
                "To measure higher temperatures",
                "To make it stronger"
            ],
            "answer": "To prevent mercury from moving back into the bulb after reading",
            "explanation": "The kink ensures that mercury does not move back into the bulb when the thermometer is taken out for reading."
        },
        {
            "type": "mcq",
            "q": "What is the range of a clinical thermometer?",
            "options": [
                "-20°C to 110°C",
                "0°C to 100°C",
                "35°C to 42°C",
                "32°F to 212°F"
            ],
            "answer": "35°C to 42°C",
            "explanation": "The lower fixed point of a clinical thermometer is 35°C and upper fixed point is 42°C."
        },
        {
            "type": "mcq",
            "q": "What is the range of a laboratory thermometer?",
            "options": [
                "35°C to 42°C",
                "0°C to 50°C",
                "-20°C to 110°C",
                "0°C to 212°C"
            ],
            "answer": "-20°C to 110°C",
            "explanation": "The commonly used laboratory thermometer has the range from -20°C to 110°C."
        },
        {
            "type": "mcq",
            "q": "What is the SI unit of area?",
            "options": [
                "Metre",
                "Square metre",
                "Hectare",
                "Centimetre"
            ],
            "answer": "Square metre",
            "explanation": "The SI unit of area is square metre (m²)."
        },
        {
            "type": "mcq",
            "q": "How many square centimetres are there in one square metre?",
            "options": [
                "100",
                "1000",
                "10,000",
                "100,000"
            ],
            "answer": "10,000",
            "explanation": "1 m² = 10,000 cm²"
        },
        {
            "type": "mcq",
            "q": "What is the formula for the area of a rectangle?",
            "options": [
                "Side × Side",
                "Length × Breadth",
                "½ × Base × Height",
                "π × r²"
            ],
            "answer": "Length × Breadth",
            "explanation": "Area of rectangle = Length × Breadth"
        },
        {
            "type": "mcq",
            "q": "What is the formula for the area of a triangle?",
            "options": [
                "Side × Side",
                "Length × Breadth",
                "½ × Base × Height",
                "π × r²"
            ],
            "answer": "½ × Base × Height",
            "explanation": "Area of triangle = ½ × Base × Height"
        },
        {
            "type": "mcq",
            "q": "What is one hectare equal to in square metres?",
            "options": [
                "100 m²",
                "1,000 m²",
                "10,000 m²",
                "100,000 m²"
            ],
            "answer": "10,000 m²",
            "explanation": "1 hectare = 10,000 m²"
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a fundamental physical quantity?",
            "options": [
                "Length",
                "Mass",
                "Volume",
                "Time"
            ],
            "answer": "Volume",
            "explanation": "Volume is a derived quantity, not a fundamental physical quantity."
        },
        {
            "type": "mcq",
            "q": "What does the prefix 'centi' mean?",
            "options": [
                "One thousandth part",
                "One hundredth part",
                "Ten times",
                "One hundred times"
            ],
            "answer": "One hundredth part",
            "explanation": "Centi means one hundredth part. 1 centimetre = 1/100 metre."
        },
        {
            "type": "mcq",
            "q": "How should the symbol for a unit derived from a person's name be written?",
            "options": [
                "In small letters",
                "In capital letters",
                "With a full stop",
                "In italics"
            ],
            "answer": "In capital letters",
            "explanation": "If the symbol of a unit is derived from the name of a person, it is written in capital letters, e.g., N for newton."
        },
        {
            "type": "mcq",
            "q": "What is an approximation or estimation?",
            "options": [
                "An exact measurement",
                "A reasonable guess about the measure of a physical quantity",
                "A scientific calculation",
                "A standard unit"
            ],
            "answer": "A reasonable guess about the measure of a physical quantity",
            "explanation": "An approximation or estimation is a reasonable guess about the measure of a physical quantity."
        },
        {
            "type": "mcq",
            "q": "How many hours are there in a mean solar day?",
            "options": [
                "12",
                "24",
                "48",
                "60"
            ],
            "answer": "24",
            "explanation": "1 mean solar day = 24 hours"
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "Length and mass are examples of fundamental physical quantities.",
            "answer": "True",
            "explanation": "Length and mass are fundamental physical quantities."
        },
        {
            "type": "tf",
            "q": "In ancient times, a cubit was used to measure the mass of an object.",
            "answer": "False",
            "explanation": "A cubit was used to measure length, not mass. It was the length of an adult person's forearm."
        },
        {
            "type": "tf",
            "q": "There are seven fundamental physical quantities.",
            "answer": "True",
            "explanation": "There are seven fundamental physical quantities."
        },
        {
            "type": "tf",
            "q": "The symbol used for a unit is always written in capital letters.",
            "answer": "False",
            "explanation": "The symbol of a unit is normally written in small letters. Only symbols derived from a person's name are capitalized."
        },
        {
            "type": "tf",
            "q": "A foot consists of 10 inches.",
            "answer": "False",
            "explanation": "Each foot consists of 12 inches."
        },
        {
            "type": "tf",
            "q": "Second is the unit of time in both the CGS and MKS systems.",
            "answer": "True",
            "explanation": "Second is the unit of time in both CGS and MKS systems."
        },
        {
            "type": "tf",
            "q": "The SI unit of temperature is degree centigrade.",
            "answer": "False",
            "explanation": "The SI unit of temperature is kelvin (K)."
        },
        {
            "type": "tf",
            "q": "The symbol of the unit newton is N.",
            "answer": "True",
            "explanation": "Since newton is derived from a person's name, its symbol is capital N."
        },
        {
            "type": "tf",
            "q": "10 mm = 1 cm",
            "answer": "True",
            "explanation": "10 millimetres make 1 centimetre."
        },
        {
            "type": "tf",
            "q": "1 kilometre is equal to 100 metres.",
            "answer": "False",
            "explanation": "1 kilometre is equal to 1000 metres."
        },
        {
            "type": "tf",
            "q": "A measuring tape is flexible and can be used to measure curved objects.",
            "answer": "True",
            "explanation": "Measuring tapes are flexible and can be used to measure curved objects."
        },
        {
            "type": "tf",
            "q": "While using a ruler, the left edge of the object should always be placed exactly at the zero mark.",
            "answer": "False",
            "explanation": "To avoid chipped edges, the left edge should not be placed at the zero mark."
        },
        {
            "type": "tf",
            "q": "The error due to wrong positioning of the eye while reading a scale is called parallax error.",
            "answer": "True",
            "explanation": "This is correctly defined as parallax error."
        },
        {
            "type": "tf",
            "q": "A beam balance works on the principle of comparing masses.",
            "answer": "True",
            "explanation": "A beam balance compares the mass of an object with standard weights."
        },
        {
            "type": "tf",
            "q": "In a beam balance, both arms must be of equal length.",
            "answer": "True",
            "explanation": "For accurate measurement, both arms of a beam balance must be of equal length."
        },
        {
            "type": "tf",
            "q": "Mass and weight mean the same thing in Physics.",
            "answer": "False",
            "explanation": "Mass and weight are different. Mass is the amount of matter, weight is the gravitational force acting on it."
        },
        {
            "type": "tf",
            "q": "A sundial works on the principle that the shadow of a rod changes position and length with the sun's position.",
            "answer": "True",
            "explanation": "This is the correct working principle of a sundial."
        },
        {
            "type": "tf",
            "q": "A sand clock works on the principle that a certain quantity of sand falls from upper to lower chamber in fixed time.",
            "answer": "True",
            "explanation": "This correctly describes the working of a sand clock."
        },
        {
            "type": "tf",
            "q": "In the 12-hour clock system, the time between midnight and noon is indicated by p.m.",
            "answer": "False",
            "explanation": "The time between midnight and noon is indicated by a.m., not p.m."
        },
        {
            "type": "tf",
            "q": "12:00 a.m. in 12-hour format is 00:00 in 24-hour format.",
            "answer": "True",
            "explanation": "12:00 a.m. (midnight) is represented as 00:00 in 24-hour format."
        },
        {
            "type": "tf",
            "q": "03:00 p.m. in 12-hour format is 15:00 in 24-hour format.",
            "answer": "True",
            "explanation": "3:00 p.m. + 12 = 15:00 hours."
        },
        {
            "type": "tf",
            "q": "A clinical thermometer has a kink in its bore to prevent mercury from falling back quickly.",
            "answer": "True",
            "explanation": "The kink prevents mercury from moving back into the bulb after reading."
        },
        {
            "type": "tf",
            "q": "A laboratory thermometer has the range from 35°C to 42°C.",
            "answer": "False",
            "explanation": "A clinical thermometer has the range 35°C to 42°C, not a laboratory thermometer."
        },
        {
            "type": "tf",
            "q": "Anders Celsius was a Swedish astronomer who developed the Celsius temperature scale.",
            "answer": "True",
            "explanation": "Anders Celsius (1701-1744) was a Swedish astronomer who developed the Celsius scale."
        },
        {
            "type": "tf",
            "q": "In the Fahrenheit scale, the distance between ice point and steam point is divided into 100 equal parts.",
            "answer": "False",
            "explanation": "In Fahrenheit scale, it is divided into 180 equal parts (32°F to 212°F)."
        },
        {
            "type": "tf",
            "q": "0°C is equal to 273.15 K.",
            "answer": "True",
            "explanation": "To convert Celsius to Kelvin, add 273.15: 0 + 273.15 = 273.15 K."
        },
        {
            "type": "tf",
            "q": "The Kelvin scale is written with a degree symbol (°K).",
            "answer": "False",
            "explanation": "The Kelvin scale is written without the degree symbol, simply as K."
        },
        {
            "type": "tf",
            "q": "When using a laboratory thermometer, the bulb should touch the bottom of the container for accurate reading.",
            "answer": "False",
            "explanation": "The bulb should be immersed but should not touch the bottom or sides of the container."
        },
        {
            "type": "tf",
            "q": "The SI unit of area is square metre (m²).",
            "answer": "True",
            "explanation": "Area is measured in square metres in the SI system."
        },
        {
            "type": "tf",
            "q": "1 cm² = 100 mm².",
            "answer": "True",
            "explanation": "Since 1 cm = 10 mm, 1 cm² = 10 × 10 = 100 mm²."
        },
        {
            "type": "tf",
            "q": "The area of a square of side 2 m is 4 m².",
            "answer": "True",
            "explanation": "Area = side × side = 2 m × 2 m = 4 m²."
        },
        {
            "type": "tf",
            "q": "Approximations are always accurate in measurements.",
            "answer": "False",
            "explanation": "Approximations are reasonable guesses that save time but are not accurate."
        },
        {
            "type": "tf",
            "q": "Density is a fundamental physical quantity.",
            "answer": "False",
            "explanation": "Density is a derived physical quantity (mass/volume)."
        },
        {
            "type": "tf",
            "q": "A metre rod has a fixed length of one metre divided into 100 divisions of 1 centimetre each.",
            "answer": "True",
            "explanation": "This correctly describes a metre rod."
        },
        {
            "type": "tf",
            "q": "In an electronic weighing machine, standard weights are needed to measure mass.",
            "answer": "False",
            "explanation": "Electronic weighing machines display mass directly without needing standard weights."
        },
        {
            "type": "tf",
            "q": "A decade is equal to 100 years.",
            "answer": "False",
            "explanation": "A decade is 10 years, a century is 100 years."
        },
        {
            "type": "tf",
            "q": "A millennium is 1000 years.",
            "answer": "True",
            "explanation": "A millennium equals 1000 years."
        },
        {
            "type": "tf",
            "q": "The word 'metre' is derived from the Greek word 'metron' meaning to measure.",
            "answer": "True",
            "explanation": "This is correct etymology of the word metre."
        },
        {
            "type": "tf",
            "q": "Plural form of unit symbols is used by adding 's' to the symbol.",
            "answer": "False",
            "explanation": "Symbols of units are never written in plural. So 's' is not added."
        },
        {
            "type": "tf",
            "q": "A full stop is always put at the end of a unit symbol.",
            "answer": "False",
            "explanation": "A full stop is never put at the end of a unit symbol unless it ends a sentence."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "What do you understand by the term 'measurement'?",
            "sample": "Measurement is determining the exact value of an unknown quantity by comparing it with a known fixed quantity of the same kind. For example, measuring the length of a table by comparing it with a known unit like centimetre."
        },
        {
            "type": "subjective",
            "q": "What are derived physical quantities? Give any two examples.",
            "sample": "Derived physical quantities are those that are derived from one or more fundamental physical quantities. Examples: Area (derived from length × length) and Volume (derived from length × breadth × height)."
        },
        {
            "type": "subjective",
            "q": "What is the advantage of the metric system over traditional units?",
            "sample": "Traditional units like cubit, foot, and handspan varied from person to person based on body size, so they were not uniform. The metric system provides standard units that are universally accepted and accurate for scientific measurements. It is also simple with decimal-based conversions."
        },
        {
            "type": "subjective",
            "q": "What are the units of length, mass, and time in the SI system?",
            "sample": "In the SI system: Length is measured in metre (m), Mass is measured in kilogram (kg), Time is measured in second (s)."
        },
        {
            "type": "subjective",
            "q": "How will you measure the length of a curved line using a thread and ruler?",
            "sample": "To measure a curved line: Mark the ends of the curved line as P and Q. Place a thread along the curve from P to Q, marking the points on thread. Then stretch the thread and measure the distance between the two marks using a ruler. This gives the length of the curved line."
        },
        {
            "type": "subjective",
            "q": "How can you measure the thickness of a five-rupee coin using a ruler?",
            "sample": "Stack 10 five-rupee coins one above the other to form a column. Measure the total height of the column using a ruler. Divide this height by 10 (number of coins). The result is the thickness of one coin. Thickness = Height of column ÷ Number of coins."
        },
        {
            "type": "subjective",
            "q": "What is parallax error and how can it be avoided?",
            "sample": "Parallax error is the error that occurs due to wrong positioning of the eye while reading a scale. It can be avoided by positioning the eye vertically above the mark when reading a horizontally placed ruler, or in line with the mark when reading a vertically placed ruler."
        },
        {
            "type": "subjective",
            "q": "Explain the principle of working of a beam balance.",
            "sample": "A beam balance works on the principle that when two bodies with equal mass are placed on the two pans, they secure a state of horizontal balance of the beam. The object to be weighed is placed on one pan, and standard weights are added to the other pan until the beam becomes horizontal and the pointer becomes vertical."
        },
        {
            "type": "subjective",
            "q": "What is a mean solar day?",
            "sample": "A mean solar day is the time taken by the earth to make one complete rotation about its own axis. It is divided into 24 hours, with each hour having 60 minutes and each minute having 60 seconds."
        },
        {
            "type": "subjective",
            "q": "Convert the following 12-hour times to 24-hour times: a. 12:45 a.m. b. 02:15 a.m. c. 04:20 p.m.",
            "sample": "a. 12:45 a.m. = 00:45 hours\nb. 02:15 a.m. = 02:15 hours\nc. 04:20 p.m. = 04:20 + 12:00 = 16:20 hours"
        },
        {
            "type": "subjective",
            "q": "Convert the following 24-hour times to 12-hour times: a. 07:45 b. 15:15 c. 23:15",
            "sample": "a. 07:45 = 7:45 a.m.\nb. 15:15 - 12:00 = 03:15 p.m.\nc. 23:15 - 12:00 = 11:15 p.m."
        },
        {
            "type": "subjective",
            "q": "Describe the Celsius and Fahrenheit scales of temperature.",
            "sample": "Celsius scale: Lower fixed point (ice point) is 0°C, upper fixed point (steam point) is 100°C. The interval is divided into 100 equal parts.\n\nFahrenheit scale: Lower fixed point is 32°F, upper fixed point is 212°F. The interval is divided into 180 equal parts.\n\nBoth scales are used to measure temperature, with Celsius more common in scientific work."
        },
        {
            "type": "subjective",
            "q": "Convert the following temperatures to Kelvin scale: a. 5°C b. -10°C c. 37°C",
            "sample": "a. 5°C = 5 + 273.15 = 278.15 K\nb. -10°C = -10 + 273.15 = 263.15 K\nc. 37°C = 37 + 273.15 = 310.15 K"
        },
        {
            "type": "subjective",
            "q": "Convert the following temperatures to Celsius scale: a. 248.15 K b. 293.15 K c. 310.15 K",
            "sample": "a. 248.15 K = 248.15 - 273.15 = -25°C\nb. 293.15 K = 293.15 - 273.15 = 20°C\nc. 310.15 K = 310.15 - 273.15 = 37°C"
        },
        {
            "type": "subjective",
            "q": "Differentiate between laboratory thermometer and clinical thermometer.",
            "sample": "Laboratory thermometer: Range -20°C to 110°C, no kink, used for scientific purposes, bulb may touch sides but not bottom.\n\nClinical thermometer: Range 35°C to 42°C, has a kink to prevent mercury from falling back, used to measure human body temperature, normal human temperature marked in red (37°C)."
        },
        {
            "type": "subjective",
            "q": "What is the purpose of the kink in a clinical thermometer?",
            "sample": "The kink or slight bend in the bore just above the bulb ensures that mercury does not move back into the bulb when the thermometer is taken out of a person's mouth for reading. After taking the reading, mercury level can be made to drop below 35°C by giving a few jerks to the thermometer."
        },
        {
            "type": "subjective",
            "q": "What is area? How can you measure the area of a rectangular cardboard using graph paper?",
            "sample": "Area is the amount of surface enclosed by a plane figure. To measure area of a rectangular cardboard using graph paper: Place the cardboard on graph paper and trace its outline. Count the number of complete squares within the outline. Multiply the number of squares by the area of one square (usually 1 cm²). For partial squares, estimate and add to the total."
        },
        {
            "type": "subjective",
            "q": "Describe any two guidelines for writing SI units correctly.",
            "sample": "1. Unit names are written in small letters: metre (not Metre), second (not Second).\n2. If a unit is derived from a person's name, its symbol is written in capital letters: newton is N, ampere is A.\n3. Symbols are never written in plural form: 10 metres is written as 10 m (not 10 ms).\n4. No full stop is used at the end of a unit symbol."
        },
        {
            "type": "subjective",
            "q": "Express: a. 2.25 m in cm b. 8000 g in kg",
            "sample": "a. 2.25 m = 2.25 × 100 = 225 cm (since 1 m = 100 cm)\nb. 8000 g = 8000 ÷ 1000 = 8 kg (since 1 kg = 1000 g)"
        },
        {
            "type": "subjective",
            "q": "A piece of wire is wound around a pencil 60 times. If the total width of all the turns is 3 cm, find the diameter of the wire.",
            "sample": "Total width of 60 turns = 3 cm\nDiameter of wire = Total width ÷ Number of turns\n= 3 cm ÷ 60\n= 0.05 cm\n= 0.5 mm (since 1 cm = 10 mm)\nTherefore, the diameter of the wire is 0.5 mm."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 4: Force and Friction
    # ──────────────────────────────────────────────────────────────────
    "Chapter 4 — Force and Friction": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "What is force?",
            "options": [
                "A pull only",
                "A push only",
                "A push or pull acting upon an object as a result of interaction",
                "A measure of mass"
            ],
            "answer": "A push or pull acting upon an object as a result of interaction",
            "explanation": "Force is defined as a push or pull acting upon an object as a result of an interaction."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT an effect of force?",
            "options": [
                "Moving a stationary object",
                "Changing the mass of an object",
                "Changing the direction of a moving object",
                "Changing the shape of an object"
            ],
            "answer": "Changing the mass of an object",
            "explanation": "Force has no effect on the mass of an object. Mass is constant for a particular object."
        },
        {
            "type": "mcq",
            "q": "Which type of force requires physical contact between objects?",
            "options": [
                "Gravitational force",
                "Magnetic force",
                "Electrostatic force",
                "Muscular force"
            ],
            "answer": "Muscular force",
            "explanation": "Muscular force is a contact force that requires physical contact."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a non-contact force?",
            "options": [
                "Frictional force",
                "Muscular force",
                "Magnetic force",
                "Force of pushing"
            ],
            "answer": "Magnetic force",
            "explanation": "Magnetic force is a non-contact force that acts from a distance."
        },
        {
            "type": "mcq",
            "q": "What is the force that opposes the motion of an object called?",
            "options": [
                "Gravitational force",
                "Magnetic force",
                "Frictional force",
                "Electrostatic force"
            ],
            "answer": "Frictional force",
            "explanation": "Frictional force always acts in a direction opposite to the direction of motion, opposing it."
        },
        {
            "type": "mcq",
            "q": "On what factors does friction depend?",
            "options": [
                "Colour of the object",
                "Temperature only",
                "Nature of surfaces and weight of moving object",
                "Size of the object only"
            ],
            "answer": "Nature of surfaces and weight of moving object",
            "explanation": "Friction depends on the roughness of surfaces in contact and the weight of the moving object."
        },
        {
            "type": "mcq",
            "q": "Which surface offers the greatest friction?",
            "options": [
                "Glass",
                "Polished marble",
                "Rough wooden surface",
                "Ice"
            ],
            "answer": "Rough wooden surface",
            "explanation": "Rough surfaces offer greater friction compared to smooth surfaces."
        },
        {
            "type": "mcq",
            "q": "When weight remains the same, friction is independent of:",
            "options": [
                "Nature of surface",
                "Area of surface in contact",
                "Speed of object",
                "Direction of motion"
            ],
            "answer": "Area of surface in contact",
            "explanation": "When weight remains unchanged, friction is independent of the area of the surface in contact."
        },
        {
            "type": "mcq",
            "q": "Which type of friction is the force acting between two objects in contact while at rest?",
            "options": [
                "Sliding friction",
                "Rolling friction",
                "Static friction",
                "Kinetic friction"
            ],
            "answer": "Static friction",
            "explanation": "Static friction acts between two objects in contact while at rest."
        },
        {
            "type": "mcq",
            "q": "Rolling friction is ________ than sliding friction.",
            "options": [
                "Greater",
                "Less",
                "Equal",
                "Sometimes greater, sometimes less"
            ],
            "answer": "Less",
            "explanation": "Rolling friction is less than sliding friction, which is why wheels are used."
        },
        {
            "type": "mcq",
            "q": "What is the gravitational force of the earth acting on the mass of an object called?",
            "options": [
                "Mass",
                "Weight",
                "Density",
                "Volume"
            ],
            "answer": "Weight",
            "explanation": "The gravitational force of the earth acting on the mass of an object is called its weight."
        },
        {
            "type": "mcq",
            "q": "Why does a ball rolling on a rough surface come to rest after some time?",
            "options": [
                "Due to gravitational force",
                "Due to magnetic force",
                "Due to frictional force",
                "Due to electrostatic force"
            ],
            "answer": "Due to frictional force",
            "explanation": "A ball stops due to the force of friction acting between the ball and the surface."
        },
        {
            "type": "mcq",
            "q": "What happens when you bring like poles of two magnets close to each other?",
            "options": [
                "They attract",
                "They repel",
                "No effect",
                "They become demagnetized"
            ],
            "answer": "They repel",
            "explanation": "Like poles of magnets repel each other."
        },
        {
            "type": "mcq",
            "q": "What happens when you bring unlike poles of two magnets close to each other?",
            "options": [
                "They attract",
                "They repel",
                "No effect",
                "They become stronger"
            ],
            "answer": "They attract",
            "explanation": "Unlike poles of magnets attract each other."
        },
        {
            "type": "mcq",
            "q": "Why do tyres of vehicles have grooved designs or treads?",
            "options": [
                "To look attractive",
                "To reduce friction",
                "To increase friction",
                "To reduce weight"
            ],
            "answer": "To increase friction",
            "explanation": "Treads make the surface rough, increasing friction between tyres and road to prevent slipping."
        },
        {
            "type": "mcq",
            "q": "What is the purpose of lubricating machines?",
            "options": [
                "To increase friction",
                "To reduce friction",
                "To make them heavier",
                "To change colour"
            ],
            "answer": "To reduce friction",
            "explanation": "Lubricants like oil and grease fill in the cavities on rough surfaces and make them smooth, reducing friction."
        },
        {
            "type": "mcq",
            "q": "What is streamlining?",
            "options": [
                "Making objects heavier",
                "Giving a special shape to objects to reduce drag",
                "Polishing surfaces",
                "Adding wheels to objects"
            ],
            "answer": "Giving a special shape to objects to reduce drag",
            "explanation": "Streamlining means giving a special shape to objects so they experience minimum drag while travelling through air or water."
        },
        {
            "type": "mcq",
            "q": "Which of the following has a streamlined body?",
            "options": [
                "Fish",
                "Bicycle",
                "Table",
                "Book"
            ],
            "answer": "Fish",
            "explanation": "Fish have naturally streamlined bodies to experience minimum drag while swimming."
        },
        {
            "type": "mcq",
            "q": "What is the force called that is exerted by a charged body on another charged or uncharged body?",
            "options": [
                "Gravitational force",
                "Magnetic force",
                "Electrostatic force",
                "Frictional force"
            ],
            "answer": "Electrostatic force",
            "explanation": "Electrostatic force is exerted by a charged body on another charged or uncharged body."
        },
        {
            "type": "mcq",
            "q": "Why does a plastic ruler attract bits of paper after being rubbed on hair?",
            "options": [
                "Due to gravitational force",
                "Due to magnetic force",
                "Due to electrostatic force",
                "Due to frictional force"
            ],
            "answer": "Due to electrostatic force",
            "explanation": "Rubbing transfers negative charges to the ruler, making it charged. It then attracts opposite charges on paper bits."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a method to reduce friction?",
            "options": [
                "Using lubricants",
                "Using ball bearings",
                "Making surfaces rough",
                "Streamlining"
            ],
            "answer": "Making surfaces rough",
            "explanation": "Making surfaces rough increases friction, not reduces it."
        },
        {
            "type": "mcq",
            "q": "Ball bearings are used to:",
            "options": [
                "Increase friction",
                "Reduce friction",
                "Increase weight",
                "Make machines noisy"
            ],
            "answer": "Reduce friction",
            "explanation": "Ball bearings reduce friction by converting sliding friction into rolling friction."
        },
        {
            "type": "mcq",
            "q": "Why do wrestlers rub special substances on their hands?",
            "options": [
                "To make hands smooth",
                "To increase friction and prevent slipping",
                "To look good",
                "To reduce weight"
            ],
            "answer": "To increase friction and prevent slipping",
            "explanation": "Wrestlers rub special substances to increase friction and prevent their hands from slipping."
        },
        {
            "type": "mcq",
            "q": "What is the disadvantage of friction?",
            "options": [
                "It helps in walking",
                "It produces heat and causes wear and tear",
                "It helps in writing",
                "It allows vehicles to stop"
            ],
            "answer": "It produces heat and causes wear and tear",
            "explanation": "Friction produces heat and causes wear and tear on surfaces, which are disadvantages."
        },
        {
            "type": "mcq",
            "q": "The friction caused due to fluids such as water and air is called:",
            "options": [
                "Sliding friction",
                "Rolling friction",
                "Static friction",
                "Drag"
            ],
            "answer": "Drag",
            "explanation": "The friction caused by fluids is termed as drag."
        },
        {
            "type": "mcq",
            "q": "What will happen if there is no friction between our feet and the ground?",
            "options": [
                "We can walk faster",
                "We may slip or fall",
                "We can jump higher",
                "Nothing will change"
            ],
            "answer": "We may slip or fall",
            "explanation": "In the absence of friction, we may slip or fall while trying to walk."
        },
        {
            "type": "mcq",
            "q": "Which force is responsible for the weight of an object?",
            "options": [
                "Muscular force",
                "Frictional force",
                "Gravitational force",
                "Magnetic force"
            ],
            "answer": "Gravitational force",
            "explanation": "Weight is the gravitational force of the earth acting on the mass of an object."
        },
        {
            "type": "mcq",
            "q": "The mass of an astronaut on the moon is:",
            "options": [
                "One-sixth of his mass on earth",
                "Six times his mass on earth",
                "Same as on earth",
                "Zero"
            ],
            "answer": "Same as on earth",
            "explanation": "Mass remains the same everywhere. Weight changes due to different gravitational forces."
        },
        {
            "type": "mcq",
            "q": "The weight of an astronaut on the moon is:",
            "options": [
                "Same as on earth",
                "One-sixth of his weight on earth",
                "Six times his weight on earth",
                "Zero"
            ],
            "answer": "One-sixth of his weight on earth",
            "explanation": "Moon's gravitational force is one-sixth of earth's, so weight becomes one-sixth."
        },
        {
            "type": "mcq",
            "q": "What happens to the speed of a moving object if force is applied in the direction opposite to its motion?",
            "options": [
                "Speed increases",
                "Speed decreases",
                "Speed remains same",
                "Object stops immediately"
            ],
            "answer": "Speed decreases",
            "explanation": "Force applied opposite to motion slows down the object."
        },
        {
            "type": "mcq",
            "q": "A force can change the direction of a moving object. Which example demonstrates this?",
            "options": [
                "A batsman hitting a ball",
                "A book lying on table",
                "A stationary car",
                "A hanging picture"
            ],
            "answer": "A batsman hitting a ball",
            "explanation": "When a batsman strikes a ball, the force changes the direction of the ball."
        },
        {
            "type": "mcq",
            "q": "What type of force is gravitational force?",
            "options": [
                "Always attractive",
                "Always repulsive",
                "Sometimes attractive, sometimes repulsive",
                "Neither attractive nor repulsive"
            ],
            "answer": "Always attractive",
            "explanation": "Gravitational force is always attractive in nature."
        },
        {
            "type": "mcq",
            "q": "Objects that have opposite charges:",
            "options": [
                "Repel each other",
                "Attract each other",
                "Have no effect",
                "Become neutral"
            ],
            "answer": "Attract each other",
            "explanation": "Opposite charges attract each other, while similar charges repel."
        },
        {
            "type": "mcq",
            "q": "Which of the following is an example of muscular force?",
            "options": [
                "Magnet attracting iron",
                "Earth attracting apple",
                "Player kicking a ball",
                "Ruler attracting paper bits"
            ],
            "answer": "Player kicking a ball",
            "explanation": "Kicking a ball uses muscular force from the player's leg muscles."
        },
        {
            "type": "mcq",
            "q": "Why is it difficult to walk on a wet floor?",
            "options": [
                "Friction increases",
                "Friction decreases",
                "Gravity increases",
                "Weight increases"
            ],
            "answer": "Friction decreases",
            "explanation": "Water reduces friction between feet and floor, making it slippery and difficult to walk."
        },
        {
            "type": "mcq",
            "q": "What is the function of spikes in the soles of sports shoes?",
            "options": [
                "To look stylish",
                "To increase friction and provide grip",
                "To reduce friction",
                "To make shoes lighter"
            ],
            "answer": "To increase friction and provide grip",
            "explanation": "Spikes increase friction so athletes get a firm grip on the ground."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a method to increase friction?",
            "options": [
                "Polishing",
                "Lubricating",
                "Making grooves on surfaces",
                "Using ball bearings"
            ],
            "answer": "Making grooves on surfaces",
            "explanation": "Making grooves (treads) increases roughness and thus increases friction."
        },
        {
            "type": "mcq",
            "q": "What happens when brakes are applied on a bicycle?",
            "options": [
                "Friction between brake shoe and wheel rim increases",
                "Friction decreases",
                "Gravity increases",
                "Weight changes"
            ],
            "answer": "Friction between brake shoe and wheel rim increases",
            "explanation": "Brakes work by increasing friction between brake shoe and wheel rim to stop the vehicle."
        },
        {
            "type": "mcq",
            "q": "Why are aeroplanes given streamlined shapes?",
            "options": [
                "To look beautiful",
                "To reduce drag from air",
                "To carry more passengers",
                "To increase weight"
            ],
            "answer": "To reduce drag from air",
            "explanation": "Streamlined shapes minimize air drag, allowing planes to move efficiently."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a non-contact force?",
            "options": [
                "Gravitational force",
                "Magnetic force",
                "Electrostatic force",
                "Frictional force"
            ],
            "answer": "Frictional force",
            "explanation": "Frictional force requires contact between surfaces, so it is a contact force."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "A force can move a stationary object.",
            "answer": "True",
            "explanation": "Force applied on a stationary object can make it move, like pulling a suitcase."
        },
        {
            "type": "tf",
            "q": "A force can increase the mass of an object.",
            "answer": "False",
            "explanation": "Force has no effect on the mass of an object. Mass is constant."
        },
        {
            "type": "tf",
            "q": "Gravitational force is a non-contact force.",
            "answer": "True",
            "explanation": "Gravitational force acts from a distance without physical contact."
        },
        {
            "type": "tf",
            "q": "Objects having similar charges always attract each other.",
            "answer": "False",
            "explanation": "Objects with similar charges repel each other, opposite charges attract."
        },
        {
            "type": "tf",
            "q": "Friction does not depend on the weight of the moving object.",
            "answer": "False",
            "explanation": "Friction depends on both the nature of surfaces and the weight of the moving object."
        },
        {
            "type": "tf",
            "q": "Friction has no role in our walking or running.",
            "answer": "False",
            "explanation": "Friction helps us walk by opposing the backward movement of our feet."
        },
        {
            "type": "tf",
            "q": "Tyres of vehicles are provided with grooved designs to decrease friction.",
            "answer": "False",
            "explanation": "Grooved designs (treads) increase friction to prevent slipping."
        },
        {
            "type": "tf",
            "q": "Friction wears down the parts of machines.",
            "answer": "True",
            "explanation": "Friction causes wear and tear on machine parts over time."
        },
        {
            "type": "tf",
            "q": "Boats and ships have streamlined shapes.",
            "answer": "True",
            "explanation": "Streamlined shapes reduce water drag, allowing efficient movement."
        },
        {
            "type": "tf",
            "q": "Rolling friction is greater than sliding friction.",
            "answer": "False",
            "explanation": "Rolling friction is less than sliding friction, which is why wheels are used."
        },
        {
            "type": "tf",
            "q": "Magnetic force is a contact force.",
            "answer": "False",
            "explanation": "Magnetic force is a non-contact force that acts from a distance."
        },
        {
            "type": "tf",
            "q": "A force can change the direction of a moving object.",
            "answer": "True",
            "explanation": "Force can change the direction, as seen when a batsman hits a ball."
        },
        {
            "type": "tf",
            "q": "Smooth surfaces such as glass offer more friction than rough surfaces.",
            "answer": "False",
            "explanation": "Smooth surfaces offer less friction, rough surfaces offer more friction."
        },
        {
            "type": "tf",
            "q": "Friction is independent of the area of surface in contact when weight remains the same.",
            "answer": "True",
            "explanation": "For same weight, friction does not depend on contact area."
        },
        {
            "type": "tf",
            "q": "Static friction acts between moving objects.",
            "answer": "False",
            "explanation": "Static friction acts between objects at rest. Kinetic friction acts between moving objects."
        },
        {
            "type": "tf",
            "q": "Ball bearings convert sliding friction into rolling friction.",
            "answer": "True",
            "explanation": "Ball bearings reduce friction by enabling rolling instead of sliding."
        },
        {
            "type": "tf",
            "q": "Weight and mass mean the same thing in Physics.",
            "answer": "False",
            "explanation": "Mass is amount of matter, weight is gravitational force on that mass."
        },
        {
            "type": "tf",
            "q": "An astronaut weighs less on the moon than on earth.",
            "answer": "True",
            "explanation": "Moon's gravity is one-sixth of earth's, so weight is one-sixth."
        },
        {
            "type": "tf",
            "q": "An astronaut's mass is less on the moon than on earth.",
            "answer": "False",
            "explanation": "Mass remains constant everywhere; only weight changes."
        },
        {
            "type": "tf",
            "q": "You can have gravity without weight.",
            "answer": "True",
            "explanation": "Weight is force caused by gravity, but gravity can exist without weight (in free fall)."
        },
        {
            "type": "tf",
            "q": "Friction can never be reduced to zero.",
            "answer": "True",
            "explanation": "Force of friction can be reduced but can never become zero."
        },
        {
            "type": "tf",
            "q": "Electrostatic force is responsible for lightning.",
            "answer": "True",
            "explanation": "Lightning is caused by electrostatic forces in nature."
        },
        {
            "type": "tf",
            "q": "Lubricants increase friction between machine parts.",
            "answer": "False",
            "explanation": "Lubricants reduce friction by making surfaces smooth."
        },
        {
            "type": "tf",
            "q": "Graphite is used as a lubricant in machines that get overheated.",
            "answer": "True",
            "explanation": "Graphite works as a lubricant even at high temperatures."
        },
        {
            "type": "tf",
            "q": "Sand is spread on slippery ground to reduce friction.",
            "answer": "False",
            "explanation": "Sand is spread to increase friction on slippery ground."
        },
        {
            "type": "tf",
            "q": "A force applied on an object always changes its shape.",
            "answer": "False",
            "explanation": "Force may or may not change shape; it depends on the type of force and object."
        },
        {
            "type": "tf",
            "q": "Kneading dough is an example of force changing shape.",
            "answer": "True",
            "explanation": "Applying force on dough changes its shape."
        },
        {
            "type": "tf",
            "q": "Stretching a rubber band changes its size.",
            "answer": "True",
            "explanation": "Force applied by pulling makes the rubber band longer."
        },
        {
            "type": "tf",
            "q": "A magnet attracts all metals.",
            "answer": "False",
            "explanation": "Magnets attract only magnetic substances like iron, nickel, cobalt."
        },
        {
            "type": "tf",
            "q": "A charged balloon sticks to a wall due to magnetic force.",
            "answer": "False",
            "explanation": "It sticks due to electrostatic force, not magnetic force."
        },
        {
            "type": "tf",
            "q": "Friction produces heat that can damage machine parts.",
            "answer": "True",
            "explanation": "Heat from friction can damage moving parts of machines."
        },
        {
            "type": "tf",
            "q": "Talcum powder on a carrom board acts as a lubricant.",
            "answer": "True",
            "explanation": "Fine powder reduces friction between the striker and board."
        },
        {
            "type": "tf",
            "q": "Catching a ball applies force in the opposite direction to stop it.",
            "answer": "True",
            "explanation": "Hands exert force opposite to ball's motion to stop it."
        },
        {
            "type": "tf",
            "q": "A force applied in the direction of motion increases speed.",
            "answer": "True",
            "explanation": "Force in direction of motion accelerates the object."
        },
        {
            "type": "tf",
            "q": "All objects have two types of electrical charges - positive and negative.",
            "answer": "True",
            "explanation": "Objects have both positive and negative charges, usually balanced."
        },
        {
            "type": "tf",
            "q": "A body can stop on its own without any force acting on it.",
            "answer": "False",
            "explanation": "A body stops due to friction, which is a force opposing motion."
        },
        {
            "type": "tf",
            "q": "Friction is always a disadvantage and never useful.",
            "answer": "False",
            "explanation": "Friction is useful in many ways like walking, writing, braking."
        },
        {
            "type": "tf",
            "q": "Polishing a surface increases friction.",
            "answer": "False",
            "explanation": "Polishing makes surfaces smoother, reducing friction."
        },
        {
            "type": "tf",
            "q": "Fish have streamlined bodies to reduce drag in water.",
            "answer": "True",
            "explanation": "Streamlined shape helps fish swim efficiently with less resistance."
        },
        {
            "type": "tf",
            "q": "A force can change the speed but not the direction of a moving object.",
            "answer": "False",
            "explanation": "Force can change both speed and direction of a moving object."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "Define force. Write its SI unit.",
            "sample": "Force is a push or pull acting upon an object as a result of interaction between two objects. The SI unit of force is newton (N)."
        },
        {
            "type": "subjective",
            "q": "Describe any three effects of force. State one example of each.",
            "sample": "1. Force can move a stationary object: Example - Pushing a stationary cart makes it move.\n2. Force can stop a moving object: Example - Catching a ball stops its motion.\n3. Force can change the shape of an object: Example - Kneading dough changes its shape.\n(Also accept: changing speed, changing direction)"
        },
        {
            "type": "subjective",
            "q": "Differentiate between contact and non-contact forces with suitable examples.",
            "sample": "Contact forces require physical contact between objects to act. Examples: Muscular force (pushing a cart), Frictional force.\n\nNon-contact forces act without physical contact from a distance. Examples: Gravitational force (earth attracting objects), Magnetic force (magnet attracting iron), Electrostatic force (charged ruler attracting paper)."
        },
        {
            "type": "subjective",
            "q": "Why do all objects have a tendency to fall towards the earth when thrown up?",
            "sample": "All objects fall towards the earth due to the gravitational force of the earth. The earth exerts a strong attractive force on all objects towards its centre. This force, called gravity, pulls objects downwards even when they are not in contact with the ground, causing them to fall back."
        },
        {
            "type": "subjective",
            "q": "Differentiate between mass and weight of an object.",
            "sample": "Mass: Amount of matter contained in an object. It is constant everywhere. Measured in kilograms (kg).\n\nWeight: Gravitational force of the earth acting on the mass of an object. It varies with gravitational force. Measured in newtons (N).\n\nFor example, an astronaut's mass is same on earth and moon, but weight on moon is one-sixth of that on earth."
        },
        {
            "type": "subjective",
            "q": "How does friction depend upon the nature of the surfaces in contact?",
            "sample": "Friction depends on the roughness of surfaces in contact. Rough surfaces have more irregularities (grooves and ridges) that get caught with each other, offering greater friction. Smooth surfaces have fewer irregularities, offering less friction. When one surface attempts to slide over another, these irregularities interlock and resist motion."
        },
        {
            "type": "subjective",
            "q": "What are the disadvantages of friction? Explain with examples.",
            "sample": "Disadvantages of friction:\n1. Produces heat: Fast-moving machines generate heat that can damage parts. Example: Car engine can get jammed if cooling fails.\n2. Causes wear and tear: Friction wears down surfaces over time. Example: Tyres and shoe soles become thin.\n3. Wastes energy: Vehicles spend extra energy to overcome friction. Example: Cars need more fuel to overcome road friction."
        },
        {
            "type": "subjective",
            "q": "Describe two ways by which friction can be reduced.",
            "sample": "1. Using lubricants: Oils and grease fill in cavities on rough surfaces, making them smooth and reducing friction. Example: Oiling bicycle chain.\n2. Using ball bearings: They convert sliding friction into rolling friction, which is less. Example: Ball bearings in fans and bicycles.\n(Also accept: polishing, streamlining)"
        },
        {
            "type": "subjective",
            "q": "Why does a 'charged' balloon stick to a wall?",
            "sample": "When a balloon is rubbed on hair, it gains extra negative charges and becomes negatively charged. When brought near a wall (which is uncharged), it attracts the opposite (positive) charges on the wall's surface. This electrostatic force of attraction causes the balloon to stick to the wall without any physical contact."
        },
        {
            "type": "subjective",
            "q": "Why is magnetic force considered as an action-at-a-distance force?",
            "sample": "Magnetic force is considered an action-at-a-distance force because it can act without physical contact between objects. A magnet attracts iron objects like pins or nails even when not touching them. As seen in Activity 4, when a magnet is brought near iron pins, they get attracted from a distance, showing that magnetic force works without direct contact."
        },
        {
            "type": "subjective",
            "q": "Define rolling friction and give an example where rolling friction comes into play.",
            "sample": "Rolling friction is the friction that comes into play when an object rolls over a surface. It is less than sliding friction. Example: When a suitcase with wheels is pulled, rolling friction acts between the wheels and the ground. Other examples: Vehicles moving on roads, ball bearings in machines."
        },
        {
            "type": "subjective",
            "q": "How can sliding friction be changed into rolling friction easily?",
            "sample": "Sliding friction can be changed into rolling friction by providing wheels or rollers under the object. For example, placing pencils under a brick and pulling it converts sliding into rolling, requiring less force. This principle is used in vehicles, trolleys, and ball bearings where wheels cut down effort significantly."
        },
        {
            "type": "subjective",
            "q": "What is the basic principle for increasing friction?",
            "sample": "The basic principle for increasing friction is to make the surfaces in contact more rough. Roughness increases the interlocking of irregularities between surfaces, providing greater resistance to motion. Examples: Adding treads to tyres, spreading sand on slippery ground, using spiked shoes for athletes."
        },
        {
            "type": "subjective",
            "q": "Why do wrestlers rub a special substance on their hands before getting into the ring?",
            "sample": "Wrestlers rub a special substance on their hands to increase friction. This prevents their hands from slipping over their opponent's body during the match. Increased friction provides a better grip, allowing them to have better control and apply holds more effectively."
        },
        {
            "type": "subjective",
            "q": "What is 'streamlining'? Why is it important?",
            "sample": "Streamlining means giving a special shape to objects so that they experience minimum drag while travelling through air or water. A streamlined body has a rounded front and gradually narrows along its length. It is important because it reduces fluid friction (drag), allowing objects like aeroplanes, cars, boats, fish, and birds to move efficiently through air or water with less resistance."
        },
        {
            "type": "subjective",
            "q": "Why is it difficult to walk on a wet and smooth floor?",
            "sample": "It is difficult to walk on a wet and smooth floor because water acts as a lubricant, reducing friction between our feet and the floor. Friction is essential for walking as it opposes the backward movement of our feet, allowing us to push forward. With reduced friction, our feet slip, making walking difficult and increasing the chance of falling."
        },
        {
            "type": "subjective",
            "q": "A force always moves a stationary object. Do you agree? Give reason.",
            "sample": "No, I do not agree. A force applied on a stationary object may not always move it if other forces balance it. For example, pushing a heavy wall applies force but the wall doesn't move because the force is not enough to overcome its inertia and other forces. Also, if force is applied but friction or other opposing forces are greater, the object may remain stationary."
        },
        {
            "type": "subjective",
            "q": "Why is rolling friction less than sliding friction?",
            "sample": "Rolling friction is less than sliding friction because when an object rolls, the contact area between the object and the surface changes continuously, and there is no interlocking of irregularities like in sliding. In sliding, the entire surface area drags against the other surface, causing more irregularities to interlock and oppose motion. Wheels convert sliding into rolling, significantly reducing friction."
        },
        {
            "type": "subjective",
            "q": "Friction is a necessary evil. Justify the statement.",
            "sample": "Friction is called a 'necessary evil' because it has both advantages (necessary) and disadvantages (evil).\n\nAdvantages (necessary): It helps us walk, write, hold objects, stop vehicles with brakes, light matchsticks, etc. Without friction, these tasks would be impossible.\n\nDisadvantages (evil): It causes wear and tear of machine parts, produces heat that damages engines, wastes energy in machines, and reduces efficiency.\n\nThus, friction is essential for many activities but also causes problems, making it a necessary evil."
        },
        {
            "type": "subjective",
            "q": "How would the absence of friction change the world around us?",
            "sample": "In the absence of friction:\n1. We would not be able to walk or run as our feet would slip.\n2. Vehicles could not move on roads or stop with brakes.\n3. We could not hold objects in our hands.\n4. Writing on paper would be impossible.\n5. Nails and screws would not stay in walls.\n6. Matchsticks could not be lit.\n7. All knots would untie easily.\n\nHowever, machines would not wear out, and no energy would be wasted overcoming friction. Life would be completely different and very difficult without friction."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 5: Simple Machines
    # ──────────────────────────────────────────────────────────────────
    "Chapter 5 — Simple Machines": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "When is work said to be done in Physics?",
            "options": [
                "When you study",
                "When you think",
                "When a force applied on an object displaces it in the direction of force",
                "When you get tired"
            ],
            "answer": "When a force applied on an object displaces it in the direction of force",
            "explanation": "Work is done when force applied on an object displaces it in the direction of the force."
        },
        {
            "type": "mcq",
            "q": "What is energy?",
            "options": [
                "Force applied on an object",
                "The ability to do work",
                "The displacement of an object",
                "The mass of an object"
            ],
            "answer": "The ability to do work",
            "explanation": "Energy is defined as the ability to do work."
        },
        {
            "type": "mcq",
            "q": "What is a simple machine?",
            "options": [
                "A complex device with many moving parts",
                "A tool that helps us perform work with less effort",
                "An electronic device",
                "A device that produces energy"
            ],
            "answer": "A tool that helps us perform work with less effort",
            "explanation": "Simple machines are tools that help us perform work with less effort."
        },
        {
            "type": "mcq",
            "q": "The force applied on a machine to do work is called:",
            "options": [
                "Load",
                "Effort",
                "Work",
                "Energy"
            ],
            "answer": "Effort",
            "explanation": "The force applied on the machine to do work is called effort."
        },
        {
            "type": "mcq",
            "q": "The force applied by the machine on the object is called:",
            "options": [
                "Load",
                "Effort",
                "Work",
                "Energy"
            ],
            "answer": "Load",
            "explanation": "The force applied by the machine on the object is called load."
        },
        {
            "type": "mcq",
            "q": "What is mechanical advantage?",
            "options": [
                "Effort ÷ Load",
                "Load ÷ Effort",
                "Load × Effort",
                "Effort - Load"
            ],
            "answer": "Load ÷ Effort",
            "explanation": "Mechanical advantage (MA) = Load ÷ Effort"
        },
        {
            "type": "mcq",
            "q": "If MA > 1, then the machine acts as a:",
            "options": [
                "Force reducer",
                "Force multiplier",
                "Speed multiplier",
                "Energy waster"
            ],
            "answer": "Force multiplier",
            "explanation": "If MA > 1, effort < load, so machine multiplies force."
        },
        {
            "type": "mcq",
            "q": "What is efficiency of a machine?",
            "options": [
                "Load ÷ Effort",
                "Output energy ÷ Input energy",
                "Effort ÷ Load",
                "Input energy ÷ Output energy"
            ],
            "answer": "Output energy ÷ Input energy",
            "explanation": "Efficiency = Output energy ÷ Input energy"
        },
        {
            "type": "mcq",
            "q": "How many types of simple machines are there?",
            "options": [
                "4",
                "5",
                "6",
                "7"
            ],
            "answer": "6",
            "explanation": "There are six types of simple machines: lever, inclined plane, wedge, screw, pulley, and wheel-and-axle."
        },
        {
            "type": "mcq",
            "q": "What is a lever?",
            "options": [
                "A sloping surface",
                "A rigid bar that can rotate freely about a point",
                "A wheel with a groove",
                "A sharp-edged tool"
            ],
            "answer": "A rigid bar that can rotate freely about a point",
            "explanation": "A lever is a rigid bar that can rotate freely about a fixed point called fulcrum."
        },
        {
            "type": "mcq",
            "q": "The fixed point about which a lever can rotate is called:",
            "options": [
                "Load",
                "Effort",
                "Fulcrum",
                "Pivot point"
            ],
            "answer": "Fulcrum",
            "explanation": "The fixed point about which the lever rotates is called fulcrum."
        },
        {
            "type": "mcq",
            "q": "In a Class I lever, the fulcrum is located:",
            "options": [
                "Between load and effort",
                "At one end",
                "Between effort and fulcrum",
                "Nowhere"
            ],
            "answer": "Between load and effort",
            "explanation": "In Class I levers, fulcrum lies between load and effort."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a Class I lever?",
            "options": [
                "Nutcracker",
                "Wheelbarrow",
                "See-saw",
                "Tweezers"
            ],
            "answer": "See-saw",
            "explanation": "See-saw is a Class I lever with fulcrum between load and effort."
        },
        {
            "type": "mcq",
            "q": "In a Class II lever, the load is located:",
            "options": [
                "Between fulcrum and effort",
                "At one end",
                "Between effort and fulcrum",
                "At the fulcrum"
            ],
            "answer": "Between effort and fulcrum",
            "explanation": "In Class II levers, load lies between effort and fulcrum."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a Class II lever?",
            "options": [
                "Scissors",
                "Nutcracker",
                "Tweezers",
                "Crowbar"
            ],
            "answer": "Nutcracker",
            "explanation": "Nutcracker is a Class II lever with load between fulcrum and effort."
        },
        {
            "type": "mcq",
            "q": "In a Class III lever, the effort is located:",
            "options": [
                "Between load and fulcrum",
                "At one end",
                "Between fulcrum and load",
                "At the fulcrum"
            ],
            "answer": "Between load and fulcrum",
            "explanation": "In Class III levers, effort lies between load and fulcrum."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a Class III lever?",
            "options": [
                "Bottle opener",
                "Wheelbarrow",
                "Tweezers",
                "Pliers"
            ],
            "answer": "Tweezers",
            "explanation": "Tweezers are Class III levers with effort between load and fulcrum."
        },
        {
            "type": "mcq",
            "q": "What is the mechanical advantage of a Class II lever?",
            "options": [
                "Always less than 1",
                "Always greater than 1",
                "Always equal to 1",
                "Can be any value"
            ],
            "answer": "Always greater than 1",
            "explanation": "In Class II levers, effort arm is always longer than load arm, so MA > 1."
        },
        {
            "type": "mcq",
            "q": "What is the mechanical advantage of a Class III lever?",
            "options": [
                "Always less than 1",
                "Always greater than 1",
                "Always equal to 1",
                "Can be any value"
            ],
            "answer": "Always less than 1",
            "explanation": "In Class III levers, effort arm is shorter than load arm, so MA < 1."
        },
        {
            "type": "mcq",
            "q": "What is an inclined plane?",
            "options": [
                "A rigid sloping surface",
                "A sharp-edged tool",
                "A wheel with groove",
                "A rotating bar"
            ],
            "answer": "A rigid sloping surface",
            "explanation": "An inclined plane is a rigid sloping surface over which heavy loads can be raised."
        },
        {
            "type": "mcq",
            "q": "A wedge is a:",
            "options": [
                "Single inclined plane",
                "Double inclined plane",
                "Wheel and axle",
                "Lever"
            ],
            "answer": "Double inclined plane",
            "explanation": "A wedge is a double inclined plane with two sloping surfaces tapering to form a sharp edge."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a wedge?",
            "options": [
                "Ramp",
                "Staircase",
                "Knife",
                "Pulley"
            ],
            "answer": "Knife",
            "explanation": "A knife is a wedge with a sharp edge used for cutting."
        },
        {
            "type": "mcq",
            "q": "A screw is actually an inclined plane:",
            "options": [
                "Wound around a rod",
                "Made flat",
                "Made sharp",
                "Removed"
            ],
            "answer": "Wound around a rod",
            "explanation": "A screw is an inclined plane wound around a cylindrical rod."
        },
        {
            "type": "mcq",
            "q": "What is the purpose of a pulley?",
            "options": [
                "To cut objects",
                "To lift heavy objects",
                "To hold things together",
                "To measure length"
            ],
            "answer": "To lift heavy objects",
            "explanation": "A pulley is used to lift heavy objects by changing direction of force."
        },
        {
            "type": "mcq",
            "q": "A single fixed pulley changes the:",
            "options": [
                "Magnitude of force",
                "Direction of force",
                "Both magnitude and direction",
                "Neither"
            ],
            "answer": "Direction of force",
            "explanation": "A single fixed pulley changes the direction of applied force from upwards to downwards."
        },
        {
            "type": "mcq",
            "q": "Which type of pulley has a fixed axis of rotation?",
            "options": [
                "Single movable pulley",
                "Single fixed pulley",
                "Both",
                "Neither"
            ],
            "answer": "Single fixed pulley",
            "explanation": "A single fixed pulley has a fixed axis of rotation attached to a rigid support."
        },
        {
            "type": "mcq",
            "q": "A wheel-and-axle arrangement consists of:",
            "options": [
                "A wheel only",
                "An axle only",
                "A wheel attached to an axle",
                "Two wheels"
            ],
            "answer": "A wheel attached to an axle",
            "explanation": "A wheel-and-axle consists of a wheel attached to a rod called axle that rotates together."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a wheel-and-axle?",
            "options": [
                "Knife",
                "Door knob",
                "Ramp",
                "Nutcracker"
            ],
            "answer": "Door knob",
            "explanation": "Door knob is a wheel-and-axle arrangement where turning the knob (wheel) rotates the axle."
        },
        {
            "type": "mcq",
            "q": "The principle of a lever states that:",
            "options": [
                "Load × Load arm = Effort × Effort arm",
                "Load + Load arm = Effort + Effort arm",
                "Load ÷ Load arm = Effort ÷ Effort arm",
                "Load - Load arm = Effort - Effort arm"
            ],
            "answer": "Load × Load arm = Effort × Effort arm",
            "explanation": "According to lever principle, Load × Load arm = Effort × Effort arm."
        },
        {
            "type": "mcq",
            "q": "A crowbar is an example of which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class I",
            "explanation": "Crowbar is a Class I lever with fulcrum between load and effort."
        },
        {
            "type": "mcq",
            "q": "A wheelbarrow is an example of which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class II",
            "explanation": "Wheelbarrow is a Class II lever with load between fulcrum and effort."
        },
        {
            "type": "mcq",
            "q": "A hockey stick is an example of which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class III",
            "explanation": "Hockey stick is a Class III lever with effort between load and fulcrum."
        },
        {
            "type": "mcq",
            "q": "What is the effort required to lift a load of 1000 N using a crowbar of length 2.5 m with fulcrum at 2 m from effort?",
            "options": [
                "500 N",
                "250 N",
                "1000 N",
                "125 N"
            ],
            "answer": "250 N",
            "explanation": "Load arm = 0.5 m, Effort arm = 2 m, E × 2 = 1000 × 0.5, E = 250 N"
        },
        {
            "type": "mcq",
            "q": "Steeper the inclined plane, the effort required to push up the load is:",
            "options": [
                "Greater",
                "Lesser",
                "Same",
                "Zero"
            ],
            "answer": "Greater",
            "explanation": "Steeper inclined plane requires greater effort to push up the load."
        },
        {
            "type": "mcq",
            "q": "The mechanical advantage of an inclined plane is:",
            "options": [
                "Always less than 1",
                "Always greater than 1",
                "Always equal to 1",
                "Sometimes less than 1"
            ],
            "answer": "Always greater than 1",
            "explanation": "MA of inclined plane = length of slope ÷ height, which is always > 1."
        },
        {
            "type": "mcq",
            "q": "A nut-and-bolt arrangement works on the principle of:",
            "options": [
                "Lever",
                "Inclined plane",
                "Screw",
                "Pulley"
            ],
            "answer": "Screw",
            "explanation": "Nut and bolt work on the principle of screw (inclined plane wound around a rod)."
        },
        {
            "type": "mcq",
            "q": "Which simple machine is used in a drilling machine?",
            "options": [
                "Lever",
                "Pulley",
                "Wheel-and-axle",
                "Wedge"
            ],
            "answer": "Wheel-and-axle",
            "explanation": "Drilling machines use wheel-and-axle arrangement."
        },
        {
            "type": "mcq",
            "q": "The mechanical advantage of a machine is 5. If the load is 100 N, the effort required is:",
            "options": [
                "500 N",
                "20 N",
                "50 N",
                "100 N"
            ],
            "answer": "20 N",
            "explanation": "MA = Load ÷ Effort, so Effort = Load ÷ MA = 100 ÷ 5 = 20 N"
        },
        {
            "type": "mcq",
            "q": "A pencil sharpener works on the principle of:",
            "options": [
                "Lever",
                "Wedge",
                "Screw",
                "Pulley"
            ],
            "answer": "Wedge",
            "explanation": "Pencil sharpener uses a wedge-shaped blade to cut wood."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a simple machine?",
            "options": [
                "Lever",
                "Pulley",
                "Sewing machine",
                "Wedge"
            ],
            "answer": "Sewing machine",
            "explanation": "Sewing machine is a complex machine with many moving parts."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "There are four types of simple machines.",
            "answer": "False",
            "explanation": "There are six types of simple machines: lever, inclined plane, wedge, screw, pulley, and wheel-and-axle."
        },
        {
            "type": "tf",
            "q": "The load and the effort act at a single point in a lever.",
            "answer": "False",
            "explanation": "Load and effort act at different points on a lever, with fulcrum at another point."
        },
        {
            "type": "tf",
            "q": "A sewing needle is a wedge-type simple machine.",
            "answer": "True",
            "explanation": "A sewing needle has a pointed edge, making it a wedge."
        },
        {
            "type": "tf",
            "q": "A screw is a special case of an inclined plane.",
            "answer": "True",
            "explanation": "A screw is an inclined plane wound around a cylindrical rod."
        },
        {
            "type": "tf",
            "q": "A single movable pulley has its axis of rotation fixed.",
            "answer": "False",
            "explanation": "A single movable pulley has its axis of rotation not fixed; it moves with the load."
        },
        {
            "type": "tf",
            "q": "A rotating spindle tap is an example of a wheel-and-axle arrangement.",
            "answer": "True",
            "explanation": "The handle of a tap works like a wheel attached to an axle (spindle)."
        },
        {
            "type": "tf",
            "q": "Work is done when you study hard.",
            "answer": "False",
            "explanation": "In Physics, work requires displacement of an object by force. Studying involves no displacement."
        },
        {
            "type": "tf",
            "q": "Energy is the ability to do work.",
            "answer": "True",
            "explanation": "Energy is correctly defined as the ability to do work."
        },
        {
            "type": "tf",
            "q": "Simple machines have many moving parts.",
            "answer": "False",
            "explanation": "Simple machines have few or no moving parts. Complex machines have many moving parts."
        },
        {
            "type": "tf",
            "q": "Machines always multiply the force applied.",
            "answer": "False",
            "explanation": "Some machines change direction of force, some multiply force, some reduce force (Class III levers)."
        },
        {
            "type": "tf",
            "q": "Mechanical advantage is the ratio of load to effort.",
            "answer": "True",
            "explanation": "MA = Load ÷ Effort"
        },
        {
            "type": "tf",
            "q": "Efficiency of a machine is always 100%.",
            "answer": "False",
            "explanation": "Efficiency is always less than 100% due to friction and other losses."
        },
        {
            "type": "tf",
            "q": "In a Class I lever, the fulcrum can be anywhere between load and effort.",
            "answer": "True",
            "explanation": "In Class I levers, fulcrum lies between load and effort, but position can vary."
        },
        {
            "type": "tf",
            "q": "Pliers are an example of Class I lever.",
            "answer": "True",
            "explanation": "Pliers have fulcrum between load and effort, making them Class I levers."
        },
        {
            "type": "tf",
            "q": "In a Class II lever, the effort arm is always shorter than the load arm.",
            "answer": "False",
            "explanation": "In Class II levers, effort arm is always longer than load arm, so MA > 1."
        },
        {
            "type": "tf",
            "q": "Bottle opener is an example of Class II lever.",
            "answer": "True",
            "explanation": "Bottle opener has load (bottle cap) between fulcrum and effort."
        },
        {
            "type": "tf",
            "q": "In a Class III lever, the mechanical advantage is always greater than 1.",
            "answer": "False",
            "explanation": "In Class III levers, MA is always less than 1 because effort arm is shorter."
        },
        {
            "type": "tf",
            "q": "The human forearm is an example of Class III lever.",
            "answer": "True",
            "explanation": "In human forearm, elbow is fulcrum, hand is load, and muscles apply effort in between."
        },
        {
            "type": "tf",
            "q": "An inclined plane always acts as a force multiplier.",
            "answer": "True",
            "explanation": "MA of inclined plane > 1, so it multiplies force."
        },
        {
            "type": "tf",
            "q": "Ramps and staircases are examples of inclined planes.",
            "answer": "True",
            "explanation": "Both are sloping surfaces used to move loads vertically with less effort."
        },
        {
            "type": "tf",
            "q": "A wedge has only one sloping surface.",
            "answer": "False",
            "explanation": "A wedge has two sloping surfaces that taper to form a sharp edge."
        },
        {
            "type": "tf",
            "q": "An axe is an example of a wedge.",
            "answer": "True",
            "explanation": "Axe has a sharp edge formed by two inclined planes."
        },
        {
            "type": "tf",
            "q": "Screws grip wood more firmly than nails.",
            "answer": "True",
            "explanation": "Threads on screws provide better grip than smooth nails."
        },
        {
            "type": "tf",
            "q": "A single fixed pulley multiplies the force applied.",
            "answer": "False",
            "explanation": "A single fixed pulley only changes direction of force, not magnitude (MA = 1)."
        },
        {
            "type": "tf",
            "q": "A single movable pulley has mechanical advantage greater than 1.",
            "answer": "True",
            "explanation": "Single movable pulley has MA = 2, so it multiplies force."
        },
        {
            "type": "tf",
            "q": "Cranes use single movable pulleys to lift heavy loads.",
            "answer": "True",
            "explanation": "Cranes use movable pulleys to gain mechanical advantage."
        },
        {
            "type": "tf",
            "q": "In a wheel-and-axle, when the wheel rotates, the axle does not rotate.",
            "answer": "False",
            "explanation": "When the wheel rotates, the axle also rotates as they are attached."
        },
        {
            "type": "tf",
            "q": "A steering wheel is an example of wheel-and-axle.",
            "answer": "True",
            "explanation": "Steering wheel (wheel) rotates the steering column (axle)."
        },
        {
            "type": "tf",
            "q": "Machines should be kept in dusty environments.",
            "answer": "False",
            "explanation": "Machines should be kept in clean, dust-free environments to prevent damage."
        },
        {
            "type": "tf",
            "q": "Iron machines should be painted to prevent rust.",
            "answer": "True",
            "explanation": "Painting protects iron from rusting due to moisture."
        },
        {
            "type": "tf",
            "q": "Moving parts of machines should be regularly oiled.",
            "answer": "True",
            "explanation": "Oiling reduces friction and wear and tear."
        },
        {
            "type": "tf",
            "q": "A lever of Class I can never have MA = 1.",
            "answer": "False",
            "explanation": "If effort arm = load arm, MA = 1 in Class I lever."
        },
        {
            "type": "tf",
            "q": "James Prescott Joule was an English physicist who studied heat and work.",
            "answer": "True",
            "explanation": "Joule studied the relationship between heat and mechanical work."
        },
        {
            "type": "tf",
            "q": "A spoon can be used as a simple machine to open a lid.",
            "answer": "True",
            "explanation": "A spoon acts as a lever to open lids."
        },
        {
            "type": "tf",
            "q": "In ancient times, screws were made of metal only.",
            "answer": "False",
            "explanation": "Ancient screws were made of wood; metal screws appeared only about 600 years ago."
        },
        {
            "type": "tf",
            "q": "A screw jack used to lift a car works on the principle of screw.",
            "answer": "True",
            "explanation": "Screw jack uses screw principle to lift heavy vehicles."
        },
        {
            "type": "tf",
            "q": "The groove in a pulley prevents the rope from slipping.",
            "answer": "True",
            "explanation": "The groove along the rim holds the rope and prevents slipping."
        },
        {
            "type": "tf",
            "q": "A single fixed pulley is commonly used to draw water from wells.",
            "answer": "True",
            "explanation": "Fixed pulleys are used in wells to change direction of pull."
        },
        {
            "type": "tf",
            "q": "All machines have mechanical advantage greater than 1.",
            "answer": "False",
            "explanation": "Some machines (Class III levers) have MA < 1."
        },
        {
            "type": "tf",
            "q": "Efficiency is about work done, while mechanical advantage is about force applied.",
            "answer": "True",
            "explanation": "This correctly distinguishes between efficiency and mechanical advantage."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "When is work said to be done in Physics?",
            "sample": "In Physics, work is said to be done when a force applied on an object displaces the object in the direction of the force. For example, picking up a book from a table involves force and displacement, so work is done. Reading or studying does not involve displacement, so no work is done in the physics sense."
        },
        {
            "type": "subjective",
            "q": "Define a simple machine. Give examples.",
            "sample": "A simple machine is a tool or object that helps us perform the same amount of work with much less effort than if we did the work manually. Simple machines have few or no moving parts. Examples: lever (see-saw), inclined plane (ramp), wedge (knife), screw (nut and bolt), pulley (flag pole), wheel-and-axle (door knob)."
        },
        {
            "type": "subjective",
            "q": "What do you understand by the term 'mechanical advantage of a machine'?",
            "sample": "Mechanical advantage (MA) is the factor by which a machine multiplies the force applied to it. It is the ratio of the load lifted by the machine to the effort applied on it. MA = Load ÷ Effort. If MA > 1, the machine acts as a force multiplier. If MA < 1, the machine reduces force. If MA = 1, it only changes direction."
        },
        {
            "type": "subjective",
            "q": "What is a lever? On what basis are levers classified?",
            "sample": "A lever is a rigid bar that can rotate freely about a fixed point called the fulcrum. Levers are classified into three classes based on the relative positions of load, effort, and fulcrum:\n\nClass I: Fulcrum between load and effort (e.g., see-saw)\nClass II: Load between fulcrum and effort (e.g., nutcracker)\nClass III: Effort between load and fulcrum (e.g., tweezers)"
        },
        {
            "type": "subjective",
            "q": "State the principle on which a lever works.",
            "sample": "The principle of a lever states that the product of the load and the load arm is always equal to the product of the effort and the effort arm. Mathematically: Load × Load arm = Effort × Effort arm. This means that a smaller effort can balance a larger load if the effort arm is longer than the load arm."
        },
        {
            "type": "subjective",
            "q": "Draw diagrams to show the positions of load, effort and fulcrum in Class II and Class III levers. Explain how their mechanical advantages are different.",
            "sample": "Class II lever: Load is between fulcrum and effort. Effort arm > Load arm, so MA > 1. Example: Nutcracker, wheelbarrow.\n\nClass III lever: Effort is between load and fulcrum. Effort arm < Load arm, so MA < 1. Example: Tweezers, hockey stick.\n\nIn Class II, machine multiplies force; in Class III, machine does not multiply force but gives speed or range of motion."
        },
        {
            "type": "subjective",
            "q": "What is an inclined plane? List the uses of an inclined plane.",
            "sample": "An inclined plane is a rigid sloping surface over which heavy loads can be raised or lowered to a certain height or depth with less effort than lifting directly.\n\nUses of inclined plane:\n1. Loading heavy boxes onto trucks using ramps\n2. Roads built on hills (winding roads)\n3. Staircases\n4. Slides in playgrounds\n5. Wheelchair ramps at building entrances"
        },
        {
            "type": "subjective",
            "q": "What is a screw? Describe its advantage over a nail.",
            "sample": "A screw is a cylindrical rod marked with winding spiral edges called threads. It is actually an inclined plane wound around a rod.\n\nAdvantages over nail:\n1. Less effort is needed to drive a screw into wood than to drive a nail.\n2. Because of its threads, a screw grips the wood more firmly than a nail.\n3. Screws can be removed and reused more easily than nails.\n4. Screws provide stronger holding power."
        },
        {
            "type": "subjective",
            "q": "Describe a pulley. Differentiate between a single fixed pulley and a single movable pulley.",
            "sample": "A pulley is a wheel or circular disc with a groove along its rim that can rotate freely. A rope passes through the groove, with load attached to one end and effort applied at the other.\n\nSingle fixed pulley: Axis of rotation is fixed. It only changes direction of force (from upwards to downwards). MA = 1. Used in wells.\n\nSingle movable pulley: Axis of rotation is not fixed. One end of rope is tied to support, load attached to pulley. It multiplies force (MA = 2). Used in cranes."
        },
        {
            "type": "subjective",
            "q": "Mention any three ways by which we can take care of machines.",
            "sample": "Ways to care for machines:\n1. Keep machines clean and free from dust and moisture. Cover them when not in use.\n2. Protect iron machines from rust by coating them with paint.\n3. Regularly oil the moving parts with good quality machine oil to reduce friction and wear and tear.\n4. Store machines properly when not in use.\n5. Handle machines with care, avoid dropping or rough handling."
        },
        {
            "type": "subjective",
            "q": "Using a suitable example, describe how a machine acts as a force multiplier.",
            "sample": "A machine acts as a force multiplier when its mechanical advantage is greater than 1, meaning it lifts a heavier load with smaller effort.\n\nExample: A bottle opener. It is very difficult to open a sealed metal cap with bare hands. When we use a bottle opener (a Class II lever), the effort applied at the handle is multiplied, and the cap opens easily. Here, the machine multiplies the applied force, so a small effort produces a large force on the cap."
        },
        {
            "type": "subjective",
            "q": "State the wheel-and-axle arrangement in brief.",
            "sample": "A wheel-and-axle arrangement consists of a wheel attached to a rod called axle such that when the wheel is made to rotate, the axle also rotates. When effort is applied on the wheel, the axle rotates with greater force. Examples: steering wheel of a car (wheel) rotates the steering column (axle), door knob, screwdriver, bicycle pedals, and drilling machines."
        },
        {
            "type": "subjective",
            "q": "If the fulcrum of a crowbar, of total length 150 cm, is at a distance of 25 cm from the load, what is the mechanical advantage of the crowbar?",
            "sample": "Given: Total length = 150 cm, Load arm = 25 cm\nEffort arm = Total length - Load arm = 150 - 25 = 125 cm\nMechanical Advantage = Effort arm ÷ Load arm = 125 ÷ 25 = 5\nTherefore, the mechanical advantage of the crowbar is 5."
        },
        {
            "type": "subjective",
            "q": "A crowbar of length 100 cm is used to lift a load of 50 N. The fulcrum is at a distance of 20 cm from the load. Calculate a. the mechanical advantage of the crowbar b. the effort applied at the other end.",
            "sample": "Given: Total length = 100 cm, Load arm = 20 cm, Load = 50 N\nEffort arm = Total length - Load arm = 100 - 20 = 80 cm\n\na. Mechanical Advantage = Effort arm ÷ Load arm = 80 ÷ 20 = 4\n\nb. MA = Load ÷ Effort\n4 = 50 ÷ Effort\nEffort = 50 ÷ 4 = 12.5 N\n\nTherefore, MA = 4 and Effort required = 12.5 N"
        },
        {
            "type": "subjective",
            "q": "The handle of a nutcracker is 18 cm long and a nut is placed 2 cm from its hinge. If a force of 36 kgf is needed to crack the nut, calculate the force which has to be applied at the end of the handle.",
            "sample": "Given: Effort arm = 18 cm, Load arm = 2 cm, Load = 36 kgf\nAccording to lever principle:\nEffort × Effort arm = Load × Load arm\nEffort × 18 = 36 × 2\nEffort × 18 = 72\nEffort = 72 ÷ 18 = 4 kgf\n\nTherefore, force of 4 kgf needs to be applied at the end of the handle."
        },
        {
            "type": "subjective",
            "q": "In a lever of Class I, the effort arm is shorter than the load arm. Does a small applied force help this lever lift a large load?",
            "sample": "No, if the effort arm is shorter than the load arm in a Class I lever, then a small applied force cannot lift a large load. According to lever principle, Effort × Effort arm = Load × Load arm. If effort arm < load arm, then effort must be greater than load to balance. So the lever would act as a force reducer, not a force multiplier. To lift a large load with small effort, the effort arm must be longer than the load arm."
        },
        {
            "type": "subjective",
            "q": "The front end of a boat is shaped like a wedge. How does it help?",
            "sample": "The front end (bow) of a boat is shaped like a wedge to cut through water easily. As a wedge, it splits the water, pushing it aside and reducing resistance (drag). This allows the boat to move forward with less effort. The sharp, pointed shape helps the boat slice through waves rather than pushing against the water, making the boat more efficient and faster."
        },
        {
            "type": "subjective",
            "q": "You have to join two pieces of wooden blocks. What will you prefer - nails or screws? Why?",
            "sample": "I would prefer screws over nails for joining two wooden blocks. Reasons:\n1. Screws grip the wood more firmly due to their threads, providing stronger holding power.\n2. Screws can be easily removed and reused if needed.\n3. Screws cause less damage to the wood and can be driven precisely.\n4. They are less likely to come loose over time compared to nails.\n5. Screws distribute force better along the threads."
        },
        {
            "type": "subjective",
            "q": "An architect has made two designs for a flyover. One with a steep slope and one with a gentle slope. Which one will you choose and why?",
            "sample": "I would choose the design with the gentle slope (longer inclined plane). According to the principle of inclined plane, the mechanical advantage increases as the slope becomes gentler (length increases relative to height). A gentle slope requires less effort for vehicles to climb, saves fuel, and is safer. Steep slopes require more force from vehicles, increase fuel consumption, and can be dangerous, especially for heavy vehicles."
        },
        {
            "type": "subjective",
            "q": "A 12 kgf force is applied on a machine for the movement of a load of 120 kgf. Find the mechanical advantage of the machine.",
            "sample": "Given: Load = 120 kgf, Effort = 12 kgf\nMechanical Advantage = Load ÷ Effort\n= 120 kgf ÷ 12 kgf\n= 10\n\nTherefore, the mechanical advantage of the machine is 10, meaning it multiplies the applied force by 10 times."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 6: Light
    # ──────────────────────────────────────────────────────────────────
    "Chapter 6 — Light": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "What is light?",
            "options": [
                "A form of matter",
                "A form of energy that helps us see objects",
                "A type of sound",
                "A chemical reaction"
            ],
            "answer": "A form of energy that helps us see objects",
            "explanation": "Light is a form of energy that helps us see objects around us."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a luminous object?",
            "options": [
                "Moon",
                "Book",
                "Sun",
                "Table"
            ],
            "answer": "Sun",
            "explanation": "The sun is a luminous object as it gives out its own light."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a non-luminous object?",
            "options": [
                "Sun",
                "Star",
                "Moon",
                "Lighted candle"
            ],
            "answer": "Moon",
            "explanation": "The moon reflects sunlight and does not produce its own light."
        },
        {
            "type": "mcq",
            "q": "Materials that allow light to pass through them completely are called:",
            "options": [
                "Opaque",
                "Translucent",
                "Transparent",
                "Luminous"
            ],
            "answer": "Transparent",
            "explanation": "Transparent materials allow light to pass through completely (e.g., clear glass)."
        },
        {
            "type": "mcq",
            "q": "Materials that allow light to pass through them partially are called:",
            "options": [
                "Opaque",
                "Translucent",
                "Transparent",
                "Luminous"
            ],
            "answer": "Translucent",
            "explanation": "Translucent materials allow light to pass through partially (e.g., frosted glass)."
        },
        {
            "type": "mcq",
            "q": "Materials that do not allow light to pass through them at all are called:",
            "options": [
                "Opaque",
                "Translucent",
                "Transparent",
                "Luminous"
            ],
            "answer": "Opaque",
            "explanation": "Opaque materials do not allow any light to pass through (e.g., wood)."
        },
        {
            "type": "mcq",
            "q": "What is the speed of light in vacuum or air?",
            "options": [
                "3,00,000 m/s",
                "3,00,000 km/s",
                "3,00,000 km/h",
                "3,00,000 m/h"
            ],
            "answer": "3,00,000 km/s",
            "explanation": "The speed of light is about 3,00,000 km/s in vacuum or air."
        },
        {
            "type": "mcq",
            "q": "A very thin path of light is called a:",
            "options": [
                "Beam",
                "Ray",
                "Stream",
                "Wave"
            ],
            "answer": "Ray",
            "explanation": "A very thin path of light is called a ray of light."
        },
        {
            "type": "mcq",
            "q": "A bundle of rays of light is called a:",
            "options": [
                "Ray",
                "Beam",
                "Stream",
                "Wave"
            ],
            "answer": "Beam",
            "explanation": "A bundle of rays of light is called a beam of light."
        },
        {
            "type": "mcq",
            "q": "Rays of light coming from a point source form a:",
            "options": [
                "Parallel beam",
                "Convergent beam",
                "Divergent beam",
                "Straight beam"
            ],
            "answer": "Divergent beam",
            "explanation": "Rays from a point source spread out, forming a divergent beam."
        },
        {
            "type": "mcq",
            "q": "Rays of light meeting at a point form a:",
            "options": [
                "Parallel beam",
                "Convergent beam",
                "Divergent beam",
                "Straight beam"
            ],
            "answer": "Convergent beam",
            "explanation": "Rays that meet at a point form a convergent beam."
        },
        {
            "type": "mcq",
            "q": "The phenomenon that light travels in straight lines is called:",
            "options": [
                "Reflection of light",
                "Refraction of light",
                "Rectilinear propagation of light",
                "Diffusion of light"
            ],
            "answer": "Rectilinear propagation of light",
            "explanation": "Light travels in straight lines, known as rectilinear propagation."
        },
        {
            "type": "mcq",
            "q": "A pinhole camera works on the principle of:",
            "options": [
                "Reflection of light",
                "Refraction of light",
                "Rectilinear propagation of light",
                "Dispersion of light"
            ],
            "answer": "Rectilinear propagation of light",
            "explanation": "Pinhole camera works because light travels in straight lines."
        },
        {
            "type": "mcq",
            "q": "The image formed by a pinhole camera is:",
            "options": [
                "Upright and virtual",
                "Inverted and real",
                "Upright and real",
                "Inverted and virtual"
            ],
            "answer": "Inverted and real",
            "explanation": "The image in a pinhole camera is real (formed on screen) and inverted."
        },
        {
            "type": "mcq",
            "q": "If the distance between the pinhole and screen is increased, the image size:",
            "options": [
                "Increases",
                "Decreases",
                "Remains same",
                "Becomes upright"
            ],
            "answer": "Increases",
            "explanation": "Increasing screen distance increases image size but may blur it."
        },
        {
            "type": "mcq",
            "q": "A shadow is formed when:",
            "options": [
                "Light passes through an object",
                "An opaque object blocks the path of light",
                "Light reflects from an object",
                "Light refracts through an object"
            ],
            "answer": "An opaque object blocks the path of light",
            "explanation": "Shadow forms when an opaque object blocks light, creating a dark area."
        },
        {
            "type": "mcq",
            "q": "Which object does NOT cast a shadow?",
            "options": [
                "Wooden block",
                "Cardboard",
                "Clear glass",
                "Metal sheet"
            ],
            "answer": "Clear glass",
            "explanation": "Transparent objects like clear glass do not cast shadows."
        },
        {
            "type": "mcq",
            "q": "The central dark region of a shadow is called:",
            "options": [
                "Penumbra",
                "Umbra",
                "Core",
                "Dark zone"
            ],
            "answer": "Umbra",
            "explanation": "Umbra is the central dark region of a shadow with no light."
        },
        {
            "type": "mcq",
            "q": "The outer less dark region of a shadow is called:",
            "options": [
                "Penumbra",
                "Umbra",
                "Light zone",
                "Gray area"
            ],
            "answer": "Penumbra",
            "explanation": "Penumbra is the outer region that receives some light."
        },
        {
            "type": "mcq",
            "q": "A point source of light produces a shadow that has:",
            "options": [
                "Only umbra",
                "Only penumbra",
                "Both umbra and penumbra",
                "No shadow"
            ],
            "answer": "Only umbra",
            "explanation": "Point source produces a uniformly dark shadow with only umbra."
        },
        {
            "type": "mcq",
            "q": "An extended source of light produces a shadow that has:",
            "options": [
                "Only umbra",
                "Only penumbra",
                "Both umbra and penumbra",
                "No shadow"
            ],
            "answer": "Both umbra and penumbra",
            "explanation": "Extended source produces shadow with both umbra and penumbra."
        },
        {
            "type": "mcq",
            "q": "What is bioluminescence?",
            "options": [
                "Light from the sun",
                "Light from moon",
                "Light produced by living organisms",
                "Artificial light"
            ],
            "answer": "Light produced by living organisms",
            "explanation": "Bioluminescence is light produced by living organisms like fireflies."
        },
        {
            "type": "mcq",
            "q": "Which of the following shows bioluminescence?",
            "options": [
                "Sun",
                "Moon",
                "Firefly",
                "Electric bulb"
            ],
            "answer": "Firefly",
            "explanation": "Fireflies produce light through chemical reactions in their bodies."
        },
        {
            "type": "mcq",
            "q": "When does a solar eclipse occur?",
            "options": [
                "When earth comes between sun and moon",
                "When moon comes between sun and earth",
                "When sun comes between earth and moon",
                "On every full moon day"
            ],
            "answer": "When moon comes between sun and earth",
            "explanation": "Solar eclipse occurs when moon blocks sunlight from reaching earth."
        },
        {
            "type": "mcq",
            "q": "When does a lunar eclipse occur?",
            "options": [
                "When earth comes between sun and moon",
                "When moon comes between sun and earth",
                "When sun comes between earth and moon",
                "On every new moon day"
            ],
            "answer": "When earth comes between sun and moon",
            "explanation": "Lunar eclipse occurs when earth's shadow falls on the moon."
        },
        {
            "type": "mcq",
            "q": "A solar eclipse occurs on:",
            "options": [
                "Full moon day",
                "New moon day",
                "Any day",
                "First day of month"
            ],
            "answer": "New moon day",
            "explanation": "Solar eclipse occurs on new moon day when moon is between sun and earth."
        },
        {
            "type": "mcq",
            "q": "A lunar eclipse occurs on:",
            "options": [
                "Full moon day",
                "New moon day",
                "Any day",
                "Last day of month"
            ],
            "answer": "Full moon day",
            "explanation": "Lunar eclipse occurs on full moon day when earth is between sun and moon."
        },
        {
            "type": "mcq",
            "q": "During a total solar eclipse, the sun is:",
            "options": [
                "Partially visible",
                "Completely blocked by moon",
                "More bright",
                "Not visible at all"
            ],
            "answer": "Completely blocked by moon",
            "explanation": "In total solar eclipse, moon completely blocks the sun."
        },
        {
            "type": "mcq",
            "q": "The part of earth that falls in the umbra during solar eclipse experiences:",
            "options": [
                "Partial solar eclipse",
                "Total solar eclipse",
                "No eclipse",
                "Annular eclipse"
            ],
            "answer": "Total solar eclipse",
            "explanation": "Umbra region experiences total darkness - total solar eclipse."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a condition for shadow formation?",
            "options": [
                "Source of light",
                "Opaque object",
                "Screen",
                "Transparent object"
            ],
            "answer": "Transparent object",
            "explanation": "Transparent objects do not form shadows; opaque objects are needed."
        },
        {
            "type": "mcq",
            "q": "If you bring an object closer to the light source, the shadow size:",
            "options": [
                "Increases",
                "Decreases",
                "Remains same",
                "Disappears"
            ],
            "answer": "Increases",
            "explanation": "Moving object closer to light source increases shadow size."
        },
        {
            "type": "mcq",
            "q": "If you bring an object closer to the screen, the shadow size:",
            "options": [
                "Increases",
                "Decreases",
                "Remains same",
                "Disappears"
            ],
            "answer": "Decreases",
            "explanation": "Moving object closer to screen decreases shadow size and makes it darker."
        },
        {
            "type": "mcq",
            "q": "A shadow is always:",
            "options": [
                "Coloured like the object",
                "Black or grey",
                "White",
                "Invisible"
            ],
            "answer": "Black or grey",
            "explanation": "Shadows are always dark (black or grey), regardless of object's colour."
        },
        {
            "type": "mcq",
            "q": "The sun appears to rise in the east and set in the west due to:",
            "options": [
                "Rotation of earth",
                "Revolution of earth",
                "Rectilinear propagation of light",
                "Reflection of light"
            ],
            "answer": "Rotation of earth",
            "explanation": "Earth's rotation from west to east causes sun to appear east to west."
        },
        {
            "type": "mcq",
            "q": "Light can travel through:",
            "options": [
                "Solids only",
                "Liquids only",
                "Gases only",
                "Solids, liquids, gases, and vacuum"
            ],
            "answer": "Solids, liquids, gases, and vacuum",
            "explanation": "Light does not need a medium; it can travel through vacuum too."
        },
        {
            "type": "mcq",
            "q": "Frosted glass is an example of:",
            "options": [
                "Transparent material",
                "Translucent material",
                "Opaque material",
                "Luminous material"
            ],
            "answer": "Translucent material",
            "explanation": "Frosted glass allows light to pass through partially, making it translucent."
        },
        {
            "type": "mcq",
            "q": "Wood is an example of:",
            "options": [
                "Transparent material",
                "Translucent material",
                "Opaque material",
                "Luminous material"
            ],
            "answer": "Opaque material",
            "explanation": "Wood does not allow light to pass through, so it is opaque."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a natural luminous object?",
            "options": [
                "Electric bulb",
                "Torch",
                "Sun",
                "Candle"
            ],
            "answer": "Sun",
            "explanation": "Sun is a natural source of light; others are artificial."
        },
        {
            "type": "mcq",
            "q": "The time taken by sunlight to reach Earth is about:",
            "options": [
                "8 seconds",
                "8 minutes",
                "8 hours",
                "8 days"
            ],
            "answer": "8 minutes",
            "explanation": "Light from sun takes a little more than 8 minutes to reach Earth."
        },
        {
            "type": "mcq",
            "q": "An annular solar eclipse occurs when:",
            "options": [
                "Moon completely covers the sun",
                "Tip of umbra falls on earth, sun appears as a ring",
                "Earth is between sun and moon",
                "Moon is in penumbra"
            ],
            "answer": "Tip of umbra falls on earth, sun appears as a ring",
            "explanation": "In annular eclipse, sun appears as a bright ring (corona) around the moon."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "Most objects around us are non-luminous.",
            "answer": "True",
            "explanation": "Most objects like books, tables, etc. do not produce their own light."
        },
        {
            "type": "tf",
            "q": "Bioluminescence is found in almost all organisms.",
            "answer": "False",
            "explanation": "Bioluminescence is found only in some organisms like fireflies and some sea creatures."
        },
        {
            "type": "tf",
            "q": "Light cannot bend around an opaque object in its path.",
            "answer": "True",
            "explanation": "Light travels in straight lines and cannot bend around opaque objects."
        },
        {
            "type": "tf",
            "q": "The pinhole camera works on the principle of rectilinear propagation of light.",
            "answer": "True",
            "explanation": "Pinhole camera works because light travels in straight lines."
        },
        {
            "type": "tf",
            "q": "The region of total darkness in a shadow is called the penumbra.",
            "answer": "False",
            "explanation": "The region of total darkness is called umbra; penumbra is less dark."
        },
        {
            "type": "tf",
            "q": "A solar eclipse occurs only on a full moon day.",
            "answer": "False",
            "explanation": "Solar eclipse occurs on new moon day when moon is between sun and earth."
        },
        {
            "type": "tf",
            "q": "A total lunar eclipse occurs when the moon lies completely in the umbra of earth's shadow.",
            "answer": "True",
            "explanation": "Total lunar eclipse happens when moon is completely in earth's umbra."
        },
        {
            "type": "tf",
            "q": "The moon is a luminous body.",
            "answer": "False",
            "explanation": "The moon is non-luminous; it reflects sunlight."
        },
        {
            "type": "tf",
            "q": "An opaque object does not allow any light to pass through it.",
            "answer": "True",
            "explanation": "Opaque objects block all light from passing through."
        },
        {
            "type": "tf",
            "q": "Light from the sun is a convergent beam.",
            "answer": "False",
            "explanation": "Sunlight reaching earth is nearly parallel, not convergent."
        },
        {
            "type": "tf",
            "q": "Rays of light can bend in any direction.",
            "answer": "False",
            "explanation": "Light travels in straight lines in the same medium."
        },
        {
            "type": "tf",
            "q": "The image formed by a pinhole camera is real and inverted.",
            "answer": "True",
            "explanation": "Pinhole camera forms a real (on screen) and inverted image."
        },
        {
            "type": "tf",
            "q": "A transparent object casts a dark shadow.",
            "answer": "False",
            "explanation": "Transparent objects do not cast shadows."
        },
        {
            "type": "tf",
            "q": "A translucent object casts a weak shadow.",
            "answer": "True",
            "explanation": "Translucent objects allow some light through, casting weak shadows."
        },
        {
            "type": "tf",
            "q": "A shadow always shows the colour of the object.",
            "answer": "False",
            "explanation": "Shadows are always black or grey, regardless of object's colour."
        },
        {
            "type": "tf",
            "q": "The size of a shadow depends on the distance of object from light source and screen.",
            "answer": "True",
            "explanation": "Shadow size changes with object's position relative to light and screen."
        },
        {
            "type": "tf",
            "q": "A shadow can be formed in air without any screen.",
            "answer": "False",
            "explanation": "A shadow can only be formed on a screen like wall or ground."
        },
        {
            "type": "tf",
            "q": "A point source of light produces a shadow with both umbra and penumbra.",
            "answer": "False",
            "explanation": "Point source produces only umbra, no penumbra."
        },
        {
            "type": "tf",
            "q": "An extended source of light produces shadows with blurred edges.",
            "answer": "True",
            "explanation": "Extended source creates penumbra, causing blurred edges."
        },
        {
            "type": "tf",
            "q": "The sun is about 1500 lakh kilometres away from the earth.",
            "answer": "True",
            "explanation": "The sun is approximately 150 million km (1500 lakh km) from earth."
        },
        {
            "type": "tf",
            "q": "Light takes about 8 hours to reach earth from the sun.",
            "answer": "False",
            "explanation": "Light takes about 8 minutes to reach earth from sun."
        },
        {
            "type": "tf",
            "q": "Clear glass is an example of transparent material.",
            "answer": "True",
            "explanation": "Clear glass allows light to pass through completely."
        },
        {
            "type": "tf",
            "q": "Butter paper is an example of opaque material.",
            "answer": "False",
            "explanation": "Butter paper is translucent, allowing partial light through."
        },
        {
            "type": "tf",
            "q": "Cardboard is an example of opaque material.",
            "answer": "True",
            "explanation": "Cardboard blocks all light, making it opaque."
        },
        {
            "type": "tf",
            "q": "Rays from a distant source like the sun form a parallel beam.",
            "answer": "True",
            "explanation": "Sunlight reaching earth is considered a parallel beam due to great distance."
        },
        {
            "type": "tf",
            "q": "A concave lens produces a convergent beam of light.",
            "answer": "False",
            "explanation": "Concave lens produces divergent beam; convex lens produces convergent beam."
        },
        {
            "type": "tf",
            "q": "Day and night occur due to rectilinear propagation of light.",
            "answer": "True",
            "explanation": "Earth's rotation and light's straight-line travel cause day and night."
        },
        {
            "type": "tf",
            "q": "Eclipses occur due to rectilinear propagation of light.",
            "answer": "True",
            "explanation": "Eclipses happen because light travels in straight lines and objects cast shadows."
        },
        {
            "type": "tf",
            "q": "If the distance between pinhole and screen is reduced, image size increases.",
            "answer": "False",
            "explanation": "Reducing screen distance decreases image size but increases brightness."
        },
        {
            "type": "tf",
            "q": "The image in a pinhole camera becomes blurred if the screen is too far.",
            "answer": "True",
            "explanation": "Increasing screen distance beyond optimum blurs the image."
        },
        {
            "type": "tf",
            "q": "A shadow may or may not look like the actual shape of the object.",
            "answer": "True",
            "explanation": "Shadow shape changes with object orientation and light position."
        },
        {
            "type": "tf",
            "q": "When object moves closer to screen, shadow becomes darker with sharp edges.",
            "answer": "True",
            "explanation": "Closer to screen gives darker, sharper shadow."
        },
        {
            "type": "tf",
            "q": "When object moves closer to light source, shadow turns grayish with blurred edges.",
            "answer": "True",
            "explanation": "Closer to light source creates larger, less defined shadow."
        },
        {
            "type": "tf",
            "q": "A total solar eclipse can last for several hours.",
            "answer": "False",
            "explanation": "Total solar eclipse lasts only for a minute or two due to moon's motion."
        },
        {
            "type": "tf",
            "q": "During a partial lunar eclipse, only part of the moon is visible.",
            "answer": "True",
            "explanation": "Part of moon in umbra is invisible; part in penumbra is visible."
        },
        {
            "type": "tf",
            "q": "Solar and lunar eclipses are considered bad omens according to science.",
            "answer": "False",
            "explanation": "Eclipses are purely celestial events with no good or bad significance."
        },
        {
            "type": "tf",
            "q": "The sun is about 400 times farther from earth than the moon.",
            "answer": "True",
            "explanation": "This ratio allows the moon to sometimes completely cover the sun."
        },
        {
            "type": "tf",
            "q": "A pinhole camera produces an upright image.",
            "answer": "False",
            "explanation": "Pinhole camera produces an inverted image."
        },
        {
            "type": "tf",
            "q": "Planets are luminous objects as they shine brightly in the night sky.",
            "answer": "False",
            "explanation": "Planets are non-luminous; they reflect sunlight."
        },
        {
            "type": "tf",
            "q": "The Samrat Yantra in New Delhi is a giant sundial.",
            "answer": "True",
            "explanation": "Samrat Yantra at Jantar Mantar is indeed a giant sundial."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "How do you see non-luminous objects?",
            "sample": "We see non-luminous objects when light from a luminous source (like the sun or a lamp) falls on them, gets reflected from their surface, and then enters our eyes. The reflected light carries the image of the object to our eyes, making it visible. For example, we see the moon because it reflects sunlight, and we see a book because it reflects light from a bulb."
        },
        {
            "type": "subjective",
            "q": "Define rectilinear propagation of light. Describe an experiment to demonstrate it.",
            "sample": "Rectilinear propagation of light means that light travels in straight lines as long as it travels in the same medium.\n\nExperiment: Take three cardboard sheets with holes at the same height. Arrange them in a straight line. Place a candle behind the last cardboard. Look through the first hole - you can see the flame. Now displace the middle cardboard slightly. Look again - you cannot see the flame. This proves light travels in straight lines because when holes are not aligned, light cannot reach your eye."
        },
        {
            "type": "subjective",
            "q": "State the nature of an image formed by a pinhole camera.",
            "sample": "The image formed by a pinhole camera has the following characteristics:\n1. It is real (formed on a screen)\n2. It is inverted (upside down)\n3. It is smaller than the object when screen is close, larger when screen is far\n4. The image is not very bright and can be blurred if screen is too far\n5. Colours of the object are preserved in the image"
        },
        {
            "type": "subjective",
            "q": "How is it possible to increase the size of an image formed by a pinhole camera?",
            "sample": "The size of the image in a pinhole camera can be increased by:\n1. Increasing the distance between the pinhole and the screen (moving the screen further back)\n2. Decreasing the distance between the object and the pinhole (bringing the object closer)\n\nHowever, when the image size increases, it becomes less bright and may become blurred as light spreads over a larger area."
        },
        {
            "type": "subjective",
            "q": "How is a shadow formed? List the conditions for shadow formation.",
            "sample": "A shadow is formed when an opaque object is placed between a source of light and a screen, blocking the path of light and creating a dark area on the screen.\n\nConditions for shadow formation:\n1. There must be a source of light\n2. There must be an opaque object to obstruct the light\n3. There must be a screen (like wall or ground) to receive the shadow\n4. The object should be positioned between the light source and the screen"
        },
        {
            "type": "subjective",
            "q": "List any four characteristics of a shadow.",
            "sample": "Characteristics of a shadow:\n1. A shadow is always dark (black or grey); it does not show the colour of the object.\n2. A shadow may or may not look like the actual shape of the object; shape changes with orientation.\n3. The size of a shadow depends on the distance of object from light source and screen.\n4. A shadow can only be formed on a screen (wall, ground, etc.).\n5. The shadow becomes darker with sharp edges when object is closer to screen.\n6. Transparent objects do not cast shadows; opaque objects cast dark shadows."
        },
        {
            "type": "subjective",
            "q": "What do you understand by a total lunar eclipse?",
            "sample": "A total lunar eclipse occurs when the earth comes directly between the sun and the moon, and the moon lies completely in the umbra (region of total darkness) of the earth's shadow. During this, the moon does not receive any direct sunlight and becomes completely invisible from earth for some time. The moon gradually enters the umbra, becomes totally invisible, and then gradually emerges. Total lunar eclipse occurs only on a full moon day."
        },
        {
            "type": "subjective",
            "q": "Describe the working of a pinhole camera.",
            "sample": "A pinhole camera works on the principle of rectilinear propagation of light. Light rays from an object travel in straight lines. Rays from the top of the object pass through the pinhole and hit the bottom of the screen. Rays from the bottom hit the top of the screen. This crossing of rays creates an inverted image on the screen. The size of the image depends on the distance between pinhole and screen. If screen is closer, image is smaller but brighter; if screen is farther, image is larger but less bright and may blur."
        },
        {
            "type": "subjective",
            "q": "How does the size of a shadow change when the distance between the object and the screen is increased?",
            "sample": "When the distance between the object and the screen is increased (object moved away from screen while keeping light source fixed):\n1. The size of the shadow increases\n2. The shadow becomes less dark (grayish)\n3. The edges become blurred\n4. If the object is moved very far, the shadow may disappear completely\n\nWhen the object is moved closer to the screen, the shadow size decreases, becomes darker, and edges become sharper."
        },
        {
            "type": "subjective",
            "q": "State the characteristics of the shadow formed by an extended source of light when the object is smaller than the source. What will you observe if the screen is moved away from the object?",
            "sample": "When object is smaller than an extended light source:\n1. The shadow has both umbra and penumbra regions\n2. The umbra is very small (smaller than the object)\n3. The penumbra is larger than the umbra\n\nIf the screen is moved away from the object:\n1. The size of both umbra and penumbra increases\n2. The umbra becomes even smaller\n3. If the screen is moved far enough, the umbra may vanish completely, leaving only penumbra\n4. The shadow becomes less distinct with blurred edges"
        },
        {
            "type": "subjective",
            "q": "What is a solar eclipse? How many types of solar eclipses can be formed?",
            "sample": "A solar eclipse occurs when the moon comes between the sun and the earth, casting its shadow on the earth. The part of earth covered by the moon's shadow becomes dark during daytime.\n\nTypes of solar eclipses:\n1. Total solar eclipse: When the moon completely blocks the sun (earth in umbra).\n2. Partial solar eclipse: When the moon partially blocks the sun (earth in penumbra).\n3. Annular solar eclipse: When the moon is farther from earth and appears smaller, not completely covering the sun, leaving a bright ring (corona) visible around the moon."
        },
        {
            "type": "subjective",
            "q": "Differentiate between luminous and non-luminous objects.",
            "sample": "Luminous objects: Objects that give out their own light. Examples: Sun, stars, lighted candle, electric bulb, firefly. They can be natural or artificial sources of light.\n\nNon-luminous objects: Objects that do not emit light of their own. They become visible only when light from luminous objects falls on them and gets reflected to our eyes. Examples: Moon, planets, book, table, chair, trees.\n\nMost objects around us are non-luminous; they reflect light from the sun or artificial sources."
        },
        {
            "type": "subjective",
            "q": "Differentiate between transparent, translucent, and opaque materials with examples.",
            "sample": "Transparent materials: Allow light to pass through completely. Objects can be seen clearly through them. Examples: Clear glass, clear water, air, cellophane paper.\n\nTranslucent materials: Allow light to pass through partially. Objects viewed through them appear hazy or blurred. Examples: Frosted glass, ground glass, butter paper, thin nylon fabric.\n\nOpaque materials: Do not allow light to pass through at all. No objects can be seen through them. Examples: Wood, cardboard, thick plastic, metal sheet, stone."
        },
        {
            "type": "subjective",
            "q": "Differentiate between convergent and divergent beams of light.",
            "sample": "Convergent beam: A beam of light in which rays meet at a point. The rays come together or converge. Example: Rays of light passing through a convex lens converge to a focus point. Also, rays from a concave mirror converge.\n\nDivergent beam: A beam of light in which rays spread out from a point. The rays move away from each other. Example: Rays from a point source like a torch bulb or a candle flame spread out in all directions, forming a divergent beam.\n\nParallel beam: Rays are parallel to each other, as from a distant source like the sun."
        },
        {
            "type": "subjective",
            "q": "Differentiate between point source and extended source of light.",
            "sample": "Point source of light: A source that has negligible extent or size. It can be a very small source or a large source at a great distance. Examples: Light from a pinhole, stars (distant suns). A point source produces a shadow with only umbra (uniformly dark, sharp edges).\n\nExtended source of light: A source that has a definite size or extent. Examples: Sun, torch beam, tube light, candle flame. An extended source produces shadows with both umbra and penumbra, having blurred edges. The shadow characteristics depend on the relative sizes of source and object."
        },
        {
            "type": "subjective",
            "q": "Why are shadows black in colour?",
            "sample": "Shadows are black because they are regions where light is blocked by an opaque object. In these regions, no light reaches from the source, so there is no illumination. The absence of light creates darkness, which we perceive as black or grey. The colour of the object does not affect the shadow's colour because shadow formation is about absence of light, not about the object's properties. Even if the object is coloured, its shadow remains black."
        },
        {
            "type": "subjective",
            "q": "A shadow tells us about the shape of the object. Do you agree? Explain.",
            "sample": "I partially agree. A shadow can give some information about the object's shape, but it is not always accurate because:\n1. The shape of shadow changes with the position of the light source and the orientation of the object.\n2. A shadow is only a two-dimensional outline and may not show all details of a three-dimensional object.\n3. The shadow may be distorted if the light source is not directly in front.\n4. For example, a spherical ball always casts a circular shadow regardless of orientation, but a cube can cast square, rectangular, or even hexagonal shadows depending on how it's held."
        },
        {
            "type": "subjective",
            "q": "Why can't we see the shadows of aeroplanes flying high in the sky?",
            "sample": "We cannot see shadows of high-flying aeroplanes for several reasons:\n1. The shadow is too faint: When the object is far from the ground, the shadow becomes large, diffuse, and less dark (penumbra dominates).\n2. The shadow falls on a large area: The shadow may be spread over such a large area that it's not noticeable.\n3. Light from other sources: Sunlight comes from all directions (scattered), reducing shadow contrast.\n4. The shadow may fall on clouds or be obscured.\n5. The aeroplane is moving fast, so any shadow moves quickly across the ground.\n\nHowever, shadows of low-flying aircraft can sometimes be seen."
        },
        {
            "type": "subjective",
            "q": "With the help of an experiment, show that light travels in a straight line.",
            "sample": "Experiment to show rectilinear propagation of light:\n\nMaterials: Three rectangular cardboards with a hole at the centre of each, a candle, a wooden base.\n\nProcedure:\n1. Fix the cardboards upright on the wooden base in a straight line with holes aligned.\n2. Place a burning candle behind the last cardboard at the same height as holes.\n3. Look through the hole of the first cardboard. You can clearly see the candle flame.\n4. Now displace the middle cardboard slightly so holes are no longer in a straight line.\n5. Look through the first hole again. You cannot see the flame now.\n\nConclusion: This proves that light travels in straight lines because when holes are aligned, light reaches the eye; when not aligned, light is blocked by the cardboard and cannot reach the eye."
        },
        {
            "type": "subjective",
            "q": "Draw a diagram to show a shadow formed by an extended source of light when the object is larger than the source.",
            "sample": "When object is larger than extended source, the shadow has both umbra and penumbra. The umbra is larger than the object and is the central dark region. The penumbra surrounds the umbra and is less dark. If the screen is moved away, both umbra and penumbra increase in size. If the screen is moved very far, the shadow becomes larger but less distinct. The diagram would show the light source, the object (larger than source), and on the screen: a central dark umbra surrounded by a lighter penumbra region."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 8: Magnetism
    # ──────────────────────────────────────────────────────────────────
    "Chapter 8 — Magnetism": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "What is a magnet?",
            "options": [
                "A substance that attracts all metals",
                "A substance that attracts objects made of iron, nickel, cobalt or their alloys",
                "A substance that repels all objects",
                "A substance that produces light"
            ],
            "answer": "A substance that attracts objects made of iron, nickel, cobalt or their alloys",
            "explanation": "A magnet attracts magnetic substances like iron, nickel, and cobalt."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a magnetic substance?",
            "options": [
                "Plastic",
                "Wood",
                "Iron",
                "Paper"
            ],
            "answer": "Iron",
            "explanation": "Iron is attracted by magnets, so it is a magnetic substance."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a non-magnetic substance?",
            "options": [
                "Iron",
                "Nickel",
                "Cobalt",
                "Copper"
            ],
            "answer": "Copper",
            "explanation": "Copper is not attracted by magnets, so it is non-magnetic."
        },
        {
            "type": "mcq",
            "q": "Naturally occurring rocks that have magnetic properties are called:",
            "options": [
                "Artificial magnets",
                "Lodestone or magnetite",
                "Electromagnets",
                "Temporary magnets"
            ],
            "answer": "Lodestone or magnetite",
            "explanation": "Lodestone (magnetite) is a naturally occurring magnetic rock."
        },
        {
            "type": "mcq",
            "q": "The strength of a magnet is strongest at:",
            "options": [
                "Its centre",
                "Its poles",
                "All points equally",
                "Its ends only on one side"
            ],
            "answer": "Its poles",
            "explanation": "The magnetic strength is maximum at the poles (ends) of a magnet."
        },
        {
            "type": "mcq",
            "q": "How many poles does a magnet have?",
            "options": [
                "One",
                "Two",
                "Four",
                "Depends on shape"
            ],
            "answer": "Two",
            "explanation": "Every magnet has two poles: north pole and south pole."
        },
        {
            "type": "mcq",
            "q": "A freely suspended magnet always comes to rest in which direction?",
            "options": [
                "East-west",
                "North-south",
                "North-east",
                "South-west"
            ],
            "answer": "North-south",
            "explanation": "A freely suspended magnet always points in the north-south direction."
        },
        {
            "type": "mcq",
            "q": "The directive property of magnets is used in:",
            "options": [
                "Electric bell",
                "Magnetic compass",
                "Refrigerator",
                "Speaker"
            ],
            "answer": "Magnetic compass",
            "explanation": "Compass uses the directive property to show direction."
        },
        {
            "type": "mcq",
            "q": "When brought close to each other, like poles of two magnets:",
            "options": [
                "Attract",
                "Repel",
                "Have no effect",
                "Become stronger"
            ],
            "answer": "Repel",
            "explanation": "Like poles (N-N or S-S) repel each other."
        },
        {
            "type": "mcq",
            "q": "When brought close to each other, unlike poles of two magnets:",
            "options": [
                "Attract",
                "Repel",
                "Have no effect",
                "Become weaker"
            ],
            "answer": "Attract",
            "explanation": "Unlike poles (N-S) attract each other."
        },
        {
            "type": "mcq",
            "q": "The surest test for magnetism is:",
            "options": [
                "Attraction",
                "Repulsion",
                "Heating",
                "Hammering"
            ],
            "answer": "Repulsion",
            "explanation": "Repulsion is the surest test because only magnets repel each other; attraction can happen with magnetic materials too."
        },
        {
            "type": "mcq",
            "q": "The region around a magnet where its magnetic force can be experienced is called:",
            "options": [
                "Magnetic pole",
                "Magnetic field",
                "Magnetic axis",
                "Magnetic equator"
            ],
            "answer": "Magnetic field",
            "explanation": "The region where magnetic force is felt is the magnetic field."
        },
        {
            "type": "mcq",
            "q": "Magnetic lines of force are:",
            "options": [
                "Straight lines",
                "Curved lines",
                "Broken lines",
                "Dotted lines"
            ],
            "answer": "Curved lines",
            "explanation": "Magnetic field is represented by curved lines of force."
        },
        {
            "type": "mcq",
            "q": "Outside a magnet, magnetic lines of force begin from:",
            "options": [
                "North pole and end at south pole",
                "South pole and end at north pole",
                "Centre and go to poles",
                "Both poles and meet at centre"
            ],
            "answer": "North pole and end at south pole",
            "explanation": "Outside magnet, lines go from N to S; inside, they go from S to N."
        },
        {
            "type": "mcq",
            "q": "Inside a magnet, magnetic lines of force begin from:",
            "options": [
                "North pole and end at south pole",
                "South pole and end at north pole",
                "Centre and go to poles",
                "Both poles and meet at centre"
            ],
            "answer": "South pole and end at north pole",
            "explanation": "Inside the magnet, lines go from south pole to north pole."
        },
        {
            "type": "mcq",
            "q": "No two magnetic lines of force:",
            "options": [
                "Can be parallel",
                "Can intersect",
                "Can be curved",
                "Can be continuous"
            ],
            "answer": "Can intersect",
            "explanation": "Magnetic lines of force never intersect each other."
        },
        {
            "type": "mcq",
            "q": "Densely populated magnetic lines indicate:",
            "options": [
                "Weak magnetic field",
                "Strong magnetic field",
                "No magnetic field",
                "Uniform magnetic field"
            ],
            "answer": "Strong magnetic field",
            "explanation": "Closer lines indicate stronger field."
        },
        {
            "type": "mcq",
            "q": "The earth behaves as a huge magnet with its magnetic south pole near the:",
            "options": [
                "Geographical North Pole",
                "Geographical South Pole",
                "Equator",
                "Centre of earth"
            ],
            "answer": "Geographical North Pole",
            "explanation": "Earth's magnetic south pole is near the geographical north pole."
        },
        {
            "type": "mcq",
            "q": "The difference between geographical and magnetic axes of earth is about:",
            "options": [
                "5°",
                "11°",
                "23°",
                "90°"
            ],
            "answer": "11°",
            "explanation": "The magnetic axis is inclined at about 11° to the geographical axis."
        },
        {
            "type": "mcq",
            "q": "Magnets that retain their magnetic property for a short duration are called:",
            "options": [
                "Permanent magnets",
                "Temporary magnets",
                "Natural magnets",
                "Artificial magnets"
            ],
            "answer": "Temporary magnets",
            "explanation": "Temporary magnets lose magnetism quickly when magnetizing force is removed."
        },
        {
            "type": "mcq",
            "q": "Electromagnets are examples of:",
            "options": [
                "Permanent magnets",
                "Temporary magnets",
                "Natural magnets",
                "Lodestone"
            ],
            "answer": "Temporary magnets",
            "explanation": "Electromagnets work only when current flows; they are temporary."
        },
        {
            "type": "mcq",
            "q": "The core of an electromagnet is generally made of:",
            "options": [
                "Steel",
                "Soft iron",
                "Copper",
                "Aluminium"
            ],
            "answer": "Soft iron",
            "explanation": "Soft iron is used because it loses magnetism quickly when current stops."
        },
        {
            "type": "mcq",
            "q": "In the single-touch method, how many magnets are used?",
            "options": [
                "One",
                "Two",
                "Three",
                "Four"
            ],
            "answer": "One",
            "explanation": "Single-touch method uses one bar magnet."
        },
        {
            "type": "mcq",
            "q": "In the double-touch method, how many magnets are used?",
            "options": [
                "One",
                "Two",
                "Three",
                "Four"
            ],
            "answer": "Two",
            "explanation": "Double-touch method uses two bar magnets with opposite poles together."
        },
        {
            "type": "mcq",
            "q": "Magnetizing a magnetic substance without touching by a magnet is called:",
            "options": [
                "Single-touch method",
                "Double-touch method",
                "Magnetic induction",
                "Electromagnetism"
            ],
            "answer": "Magnetic induction",
            "explanation": "Induction magnetizes without contact, only by bringing magnet near."
        },
        {
            "type": "mcq",
            "q": "Which of the following can demagnetize a magnet?",
            "options": [
                "Heating",
                "Hammering",
                "Dropping from height",
                "All of these"
            ],
            "answer": "All of these",
            "explanation": "Heating, hammering, dropping, and rough handling demagnetize magnets."
        },
        {
            "type": "mcq",
            "q": "A magnetic keeper is made of:",
            "options": [
                "Steel",
                "Soft iron",
                "Copper",
                "Aluminium"
            ],
            "answer": "Soft iron",
            "explanation": "Keepers are made of soft iron to prevent self-demagnetization."
        },
        {
            "type": "mcq",
            "q": "How many magnetic keepers are required for a horseshoe magnet?",
            "options": [
                "One",
                "Two",
                "Three",
                "Four"
            ],
            "answer": "One",
            "explanation": "Only one keeper is needed for a horseshoe magnet."
        },
        {
            "type": "mcq",
            "q": "ALNICO is an alloy used for making:",
            "options": [
                "Temporary magnets",
                "Permanent magnets",
                "Electromagnets",
                "Keepers"
            ],
            "answer": "Permanent magnets",
            "explanation": "ALNICO (aluminium, nickel, cobalt) is used for permanent magnets."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT used in making permanent magnets?",
            "options": [
                "Steel",
                "ALNICO",
                "Cobalt",
                "Soft iron"
            ],
            "answer": "Soft iron",
            "explanation": "Soft iron is used for temporary magnets/electromagnets, not permanent magnets."
        },
        {
            "type": "mcq",
            "q": "In a magnetic compass, the north pole of the needle is marked with:",
            "options": [
                "Blue colour",
                "Red colour",
                "Green colour",
                "Black colour"
            ],
            "answer": "Red colour",
            "explanation": "The north pole of compass needle is typically marked in red."
        },
        {
            "type": "mcq",
            "q": "If a bar magnet is broken into two pieces, each piece will have:",
            "options": [
                "Only north pole",
                "Only south pole",
                "Both north and south poles",
                "No poles"
            ],
            "answer": "Both north and south poles",
            "explanation": "Each piece becomes a complete magnet with both poles."
        },
        {
            "type": "mcq",
            "q": "The strength of an electromagnet can be increased by:",
            "options": [
                "Decreasing current",
                "Increasing number of turns in coil",
                "Using copper core",
                "Removing the core"
            ],
            "answer": "Increasing number of turns in coil",
            "explanation": "More turns or more current increases electromagnetic strength."
        },
        {
            "type": "mcq",
            "q": "Magnets are used in:",
            "options": [
                "Speakers",
                "Electric motors",
                "Hard disks",
                "All of these"
            ],
            "answer": "All of these",
            "explanation": "Magnets have many applications in speakers, motors, hard disks, etc."
        },
        {
            "type": "mcq",
            "q": "Who discovered that electric current can produce a magnetic field?",
            "options": [
                "Anders Celsius",
                "James Prescott Joule",
                "Hans Christian Oersted",
                "Albert Einstein"
            ],
            "answer": "Hans Christian Oersted",
            "explanation": "Oersted discovered electromagnetism."
        },
        {
            "type": "mcq",
            "q": "To store bar magnets, they should be placed with:",
            "options": [
                "Like poles together",
                "Opposite poles together",
                "Any poles together",
                "Separately without touching"
            ],
            "answer": "Opposite poles together",
            "explanation": "Opposite poles together with keepers prevents demagnetization."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a magnetic substance?",
            "options": [
                "Iron",
                "Steel",
                "Nickel",
                "Brass"
            ],
            "answer": "Brass",
            "explanation": "Brass is an alloy of copper and zinc, both non-magnetic."
        },
        {
            "type": "mcq",
            "q": "A magnet attracts iron nails. This is due to:",
            "options": [
                "Gravitational force",
                "Magnetic force",
                "Electrostatic force",
                "Frictional force"
            ],
            "answer": "Magnetic force",
            "explanation": "Magnets exert magnetic force to attract iron."
        },
        {
            "type": "mcq",
            "q": "The magnetic lines of force around a bar magnet can be traced using:",
            "options": [
                "Iron filings",
                "A compass",
                "Both iron filings and compass",
                "None of these"
            ],
            "answer": "Both iron filings and compass",
            "explanation": "Both methods can be used to visualize magnetic field lines."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "In a magnet, the regions of strongest magnetism are near the poles.",
            "answer": "True",
            "explanation": "Magnetic strength is maximum at the poles."
        },
        {
            "type": "tf",
            "q": "If a bar magnet is cut into two pieces, one piece will have only north pole and the other only south pole.",
            "answer": "False",
            "explanation": "Each piece becomes a complete magnet with both north and south poles."
        },
        {
            "type": "tf",
            "q": "A magnetic north pole attracts another north pole.",
            "answer": "False",
            "explanation": "Like poles repel; north pole repels north pole."
        },
        {
            "type": "tf",
            "q": "Magnetic lines of force are straight lines.",
            "answer": "False",
            "explanation": "Magnetic lines of force are curved lines."
        },
        {
            "type": "tf",
            "q": "Electromagnets are temporary magnets.",
            "answer": "True",
            "explanation": "Electromagnets work only when current flows."
        },
        {
            "type": "tf",
            "q": "Magnets are used in the closing mechanism of refrigerator doors.",
            "answer": "True",
            "explanation": "Refrigerator doors use magnetic strips to close tightly."
        },
        {
            "type": "tf",
            "q": "Whenever a magnet is not in use, it should be stored along with other magnets without any precautions.",
            "answer": "False",
            "explanation": "Magnets should be stored with keepers to prevent self-demagnetization."
        },
        {
            "type": "tf",
            "q": "The force exerted by a magnet is called magnetic force.",
            "answer": "True",
            "explanation": "Magnetic force is the force exerted by magnets."
        },
        {
            "type": "tf",
            "q": "A freely suspended magnet always comes to rest in the north-south direction.",
            "answer": "True",
            "explanation": "This is the directive property of magnets."
        },
        {
            "type": "tf",
            "q": "Magnetic poles always exist in pairs.",
            "answer": "True",
            "explanation": "Isolated magnetic poles do not exist."
        },
        {
            "type": "tf",
            "q": "Inside the magnet, magnetic lines of force begin from the south pole and end at the north pole.",
            "answer": "True",
            "explanation": "Inside magnet, lines go from S to N."
        },
        {
            "type": "tf",
            "q": "The north pole of the imaginary magnet of the earth is near the geographical south pole.",
            "answer": "False",
            "explanation": "Earth's magnetic north pole is near geographical south pole."
        },
        {
            "type": "tf",
            "q": "Permanent magnets are generally made of iron, steel, cobalt, nickel or ALNICO.",
            "answer": "True",
            "explanation": "These materials retain magnetism well."
        },
        {
            "type": "tf",
            "q": "Copper is a magnetic substance.",
            "answer": "False",
            "explanation": "Copper is non-magnetic."
        },
        {
            "type": "tf",
            "q": "Plastic, wool, and paper are examples of magnetic substances.",
            "answer": "False",
            "explanation": "These are non-magnetic substances."
        },
        {
            "type": "tf",
            "q": "Lodestone is a natural magnet.",
            "answer": "True",
            "explanation": "Lodestone (magnetite) occurs naturally."
        },
        {
            "type": "tf",
            "q": "Artificial magnets come in different shapes like bar, horseshoe, disc, and ring.",
            "answer": "True",
            "explanation": "Magnets are made in various shapes for different uses."
        },
        {
            "type": "tf",
            "q": "The attractive power of a bar magnet is maximum at its centre.",
            "answer": "False",
            "explanation": "Attraction is maximum at poles, minimum at centre."
        },
        {
            "type": "tf",
            "q": "A magnetic compass consists of a small, flat magnetic needle balanced on a pivot.",
            "answer": "True",
            "explanation": "This is the correct construction of a compass."
        },
        {
            "type": "tf",
            "q": "Magnetic lines of force can intersect each other.",
            "answer": "False",
            "explanation": "Magnetic lines of force never intersect."
        },
        {
            "type": "tf",
            "q": "Densely populated lines of force indicate a weak magnetic field.",
            "answer": "False",
            "explanation": "Dense lines indicate strong field."
        },
        {
            "type": "tf",
            "q": "Widely distributed magnetic lines indicate a weak magnetic field.",
            "answer": "True",
            "explanation": "Spread-out lines mean weaker field."
        },
        {
            "type": "tf",
            "q": "The earth behaves as a huge bar magnet.",
            "answer": "True",
            "explanation": "Earth has its own magnetic field."
        },
        {
            "type": "tf",
            "q": "An iron rod buried in the earth in north-south direction gets magnetized over time.",
            "answer": "True",
            "explanation": "Earth's magnetic field can magnetize iron."
        },
        {
            "type": "tf",
            "q": "Temporary magnets retain their magnetic properties permanently.",
            "answer": "False",
            "explanation": "Temporary magnets lose magnetism quickly."
        },
        {
            "type": "tf",
            "q": "In the single-touch method, the magnet is slid along the needle in one direction only and lifted at the end.",
            "answer": "True",
            "explanation": "This is the correct procedure for single-touch method."
        },
        {
            "type": "tf",
            "q": "In the double-touch method, two magnets with like poles together are used.",
            "answer": "False",
            "explanation": "Opposite poles of two magnets are placed together in double-touch method."
        },
        {
            "type": "tf",
            "q": "Magnetic induction produces temporary magnetism.",
            "answer": "True",
            "explanation": "Induction creates temporary magnets."
        },
        {
            "type": "tf",
            "q": "An iron nail can be magnetized by bringing a magnet near it without touching.",
            "answer": "True",
            "explanation": "This is magnetic induction."
        },
        {
            "type": "tf",
            "q": "An electromagnet's strength depends on the amount of current and number of turns in the coil.",
            "answer": "True",
            "explanation": "More current or more turns increases strength."
        },
        {
            "type": "tf",
            "q": "The core of an electromagnet is made of steel for best results.",
            "answer": "False",
            "explanation": "Soft iron is best as it loses magnetism quickly."
        },
        {
            "type": "tf",
            "q": "Horseshoe magnets are stronger than bar magnets.",
            "answer": "True",
            "explanation": "Horseshoe shape concentrates magnetic field."
        },
        {
            "type": "tf",
            "q": "Magnets are used in computers to store information in hard disks.",
            "answer": "True",
            "explanation": "Hard disks use magnetic materials for data storage."
        },
        {
            "type": "tf",
            "q": "Doctors use small magnets to remove iron splinters from eyes.",
            "answer": "True",
            "explanation": "Magnets are used in medical procedures."
        },
        {
            "type": "tf",
            "q": "Electromagnets are used in electric bells and motors.",
            "answer": "True",
            "explanation": "Electromagnets have many applications."
        },
        {
            "type": "tf",
            "q": "Heating a magnet strengthens it.",
            "answer": "False",
            "explanation": "Heating demagnetizes magnets."
        },
        {
            "type": "tf",
            "q": "Hammering a magnet repeatedly can demagnetize it.",
            "answer": "True",
            "explanation": "Mechanical shock destroys magnetic alignment."
        },
        {
            "type": "tf",
            "q": "Self-demagnetization occurs when magnets are left without keepers.",
            "answer": "True",
            "explanation": "Magnets gradually lose strength if not stored properly."
        },
        {
            "type": "tf",
            "q": "A magnetic keeper is a soft iron bar.",
            "answer": "True",
            "explanation": "Keepers are made of soft iron."
        },
        {
            "type": "tf",
            "q": "Hans Christian Oersted discovered the relationship between electricity and magnetism.",
            "answer": "True",
            "explanation": "Oersted discovered electromagnetism."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "Define a magnet. Give two examples each of magnetic and non-magnetic substances.",
            "sample": "A magnet is a substance that can attract objects made up of iron, nickel, cobalt, or their alloys.\n\nMagnetic substances: Iron, nickel, cobalt, steel\n\nNon-magnetic substances: Plastic, wood, paper, copper, aluminium, glass"
        },
        {
            "type": "subjective",
            "q": "What are natural magnets? Give an example.",
            "sample": "Natural magnets are magnetic rocks found in nature. They occur naturally and have the property of attracting magnetic substances. The most common example is lodestone or magnetite. According to Greek legend, these were first discovered in Magnesia about 4000 years ago. Natural magnets are not very strong and are rarely used today, but they led to the discovery of magnetism."
        },
        {
            "type": "subjective",
            "q": "Name some commonly used shapes of magnets.",
            "sample": "Artificial magnets come in various shapes depending on their use:\n1. Bar magnets - rectangular bars with poles at ends\n2. Horseshoe magnets - U-shaped magnets that are stronger than bar magnets\n3. Disc magnets - circular flat magnets\n4. Ring magnets - circular with a hole in the centre\n5. Cylindrical magnets - rod-shaped\n6. Magnetic needles - used in compasses"
        },
        {
            "type": "subjective",
            "q": "State the directive property of magnets. How can it be demonstrated?",
            "sample": "The directive property of magnets states that a freely suspended magnet always comes to rest pointing in the geographical north-south direction.\n\nDemonstration: Suspend a bar magnet by a thread tied to its centre so it can rotate freely. Allow it to come to rest. Mark the direction it points. Disturb it and let it come to rest again. It will always point in the same direction. Using a compass, we can confirm this direction is north-south. This property is used in magnetic compasses for navigation."
        },
        {
            "type": "subjective",
            "q": "What is the surest test for magnetism? Why?",
            "sample": "Repulsion is the surest test for magnetism. This is because:\n1. Attraction is not a definite test - a magnet attracts magnetic materials, but magnetic materials also get attracted to magnets. So if an object attracts another, it could be either a magnet or a magnetic material.\n2. Repulsion, however, only occurs between two magnets (like poles repel). If an object repels a known magnet, it must itself be a magnet.\n3. Therefore, if a metallic bar repels another magnet, it is definitely a magnet."
        },
        {
            "type": "subjective",
            "q": "What do you understand by the magnetic axis of a bar magnet?",
            "sample": "The magnetic axis of a bar magnet is the imaginary straight line passing through both poles of the magnet (north and south poles). It is the line along which the magnetic field is strongest. In a freely suspended magnet, the magnetic axis aligns itself in the north-south direction. The magnetic axis is different from the geometric axis if the magnet is not perfectly uniform, but in a well-made bar magnet, both axes coincide."
        },
        {
            "type": "subjective",
            "q": "How does the strength of a magnet change along its length?",
            "sample": "The strength of a magnet varies along its length as follows:\n1. Maximum at the poles (ends) - iron filings cling most at the ends\n2. Gradually decreases as we move from ends towards the centre\n3. Minimum (practically zero) at the centre - very few or no iron filings stick at the middle\n4. This shows that magnetic strength is concentrated at the poles, and the centre has negligible magnetic property."
        },
        {
            "type": "subjective",
            "q": "If a bar magnet is placed over iron filings, where will the attraction of the iron filings be maximum and minimum?",
            "sample": "If a bar magnet is placed over iron filings:\n\nMaximum attraction: At the poles (ends) of the magnet. The iron filings will cling most at the north and south poles because magnetic strength is maximum there.\n\nMinimum attraction: At the centre of the magnet. Very few or no iron filings will stick at the centre because magnetic strength is practically zero at the midpoint between the poles.\n\nThis demonstrates that magnetic poles are the regions of strongest magnetism."
        },
        {
            "type": "subjective",
            "q": "Define the following terms regarding a bar magnet: a. Magnetic axis b. North pole c. South pole d. Magnetic field",
            "sample": "a. Magnetic axis: The imaginary straight line passing through both poles (north and south) of a magnet.\n\nb. North pole: The end of a freely suspended magnet that points towards the geographical north. It is the north-seeking pole.\n\nc. South pole: The end of a freely suspended magnet that points towards the geographical south. It is the south-seeking pole.\n\nd. Magnetic field: The region around a magnet within which its magnetic force can be experienced by other magnets or magnetic materials."
        },
        {
            "type": "subjective",
            "q": "Why is it not possible to isolate a single magnetic pole?",
            "sample": "It is not possible to isolate a single magnetic pole because magnetic poles always exist in pairs. If a bar magnet is broken into two pieces, each piece becomes a complete magnet with its own north and south poles. No matter how small the pieces are broken, each fragment will have both poles. This shows that magnetic poles are inseparable. Unlike electric charges (which can exist separately as positive or negative), magnetic monopoles do not exist in nature."
        },
        {
            "type": "subjective",
            "q": "Describe the directive property of a magnet.",
            "sample": "The directive property of magnets states that a freely suspended magnet always comes to rest pointing in the geographical north-south direction.\n\nThis happens because the earth itself behaves like a huge bar magnet. The north pole of the magnet points towards the geographical north because it is attracted to the earth's magnetic south pole (located near the geographical north). This property is used in magnetic compasses for navigation. The end pointing north is called the north-seeking pole or north pole, and the end pointing south is the south-seeking pole or south pole."
        },
        {
            "type": "subjective",
            "q": "How will you test if a given metallic bar is a magnet or not?",
            "sample": "To test if a metallic bar is a magnet:\n\nStep 1: Bring a known magnet near the bar. If the bar is repelled, it is definitely a magnet (repulsion is sure test).\n\nStep 2: If the bar is attracted, it could be a magnetic material or a magnet with opposite pole facing. Bring the other pole of the magnet near the same end of the bar.\n\nStep 3: If the bar is attracted again, it is not a magnet (magnetic material).\n\nStep 4: If the bar is repelled now, it is a magnet (shows like poles repel).\n\nStep 5: Also test if the bar has poles - sprinkle iron filings; if they cling at ends only, it's likely a magnet."
        },
        {
            "type": "subjective",
            "q": "List the properties of magnetic lines of force.",
            "sample": "Properties of magnetic lines of force:\n1. They are continuous curves.\n2. Outside a magnet, they begin from north pole and end at south pole; inside, they go from south to north.\n3. No two lines of force ever intersect.\n4. Densely packed lines indicate strong magnetic field; widely spaced lines indicate weak field.\n5. They show the direction of magnetic field at each point (tangent to the line gives direction).\n6. They are like stretched elastic cords that tend to contract longitudinally and expand laterally."
        },
        {
            "type": "subjective",
            "q": "How is the single-touch method of magnetism different from the double-touch method?",
            "sample": "Single-touch method:\n- Uses one bar magnet\n- Magnet is placed at one end of the needle and stroked to the other end in one direction\n- Magnet is lifted at the end and brought back to starting point\n- Repeated about 30 times\n- The end where stroking starts gets the same pole as the stroking pole\n\nDouble-touch method:\n- Uses two bar magnets\n- Opposite poles of the two magnets are placed together at the centre of the needle\n- Magnets are moved in opposite directions towards the ends\n- Lifted at ends and brought back to centre\n- More effective and produces stronger magnetization"
        },
        {
            "type": "subjective",
            "q": "How can you make an electromagnet? What is the material used for the core of an electromagnet?",
            "sample": "To make an electromagnet:\n1. Take an iron nail (soft iron core)\n2. Wind insulated copper wire around the nail in many turns\n3. Connect the ends of the wire to a battery through a switch\n4. Close the switch - current flows, and the nail becomes a magnet\n5. Bring iron pins near the nail - they get attracted\n6. Open the switch - current stops, nail loses magnetism, pins drop\n\nMaterial for core: Soft iron is used because it gets magnetized quickly when current flows and loses magnetism immediately when current stops. Steel would retain magnetism and become a permanent magnet."
        },
        {
            "type": "subjective",
            "q": "Differentiate between a temporary magnet and a permanent magnet.",
            "sample": "Temporary magnet:\n1. Magnetic properties last only for short duration\n2. Loses magnetism when magnetizing force is removed\n3. Example: Electromagnet, iron nail magnetized by induction\n4. Made of soft iron\n5. Used where magnetism needs to be switched on/off\n\nPermanent magnet:\n1. Retains magnetic properties even after magnetizing force is removed\n2. Magnetism is permanent\n3. Example: Bar magnet, horseshoe magnet\n4. Made of steel, ALNICO, cobalt\n5. Used in compasses, speakers, motors"
        },
        {
            "type": "subjective",
            "q": "How will you store magnets? Why is proper storage important?",
            "sample": "Proper storage of magnets:\n\nFor bar magnets:\n1. Place two bar magnets side by side with opposite poles at the same end\n2. Place soft iron keepers across the ends\n3. This forms a magnetic circuit and prevents self-demagnetization\n\nFor horseshoe magnets:\n1. Place a single soft iron keeper across the poles\n\nImportance of proper storage:\n1. Prevents self-demagnetization over time\n2. Maintains magnetic strength\n3. Prevents mutual attraction/repulsion from weakening magnets\n4. Protects magnets from mechanical damage\n5. Ensures magnets remain useful for longer periods"
        },
        {
            "type": "subjective",
            "q": "Draw a diagram to show the earth as a magnet. Mark the geographical North Pole, geographical South Pole, magnetic north pole and magnetic south pole.",
            "sample": "Earth as a magnet:\n- The earth behaves as a huge bar magnet with its magnetic axis inclined at about 11° to the geographical axis.\n- The magnetic south pole is located near the geographical North Pole.\n- The magnetic north pole is located near the geographical South Pole.\n- This is why the north pole of a compass needle (which is actually a magnetic north pole) points towards geographical north because it is attracted to earth's magnetic south pole.\n- The diagram would show Earth with its geographical axis (vertical) and magnetic axis (tilted about 11°), marking: Geographical North Pole (top), Geographical South Pole (bottom), Magnetic South Pole (near top), Magnetic North Pole (near bottom)."
        },
        {
            "type": "subjective",
            "q": "Magnets must be handled with care. Why?",
            "sample": "Magnets must be handled with care because:\n1. Dropping a magnet can demagnetize it - the mechanical shock disturbs the alignment of magnetic domains.\n2. Hammering or rough handling similarly destroys magnetic properties.\n3. Heating a magnet to high temperatures demagnetizes it by increasing thermal agitation of atoms.\n4. Storing improperly without keepers leads to self-demagnetization.\n5. Strong magnets can get attracted to each other suddenly and break.\n6. Magnets can damage electronic devices like watches, computers, and credit cards.\n7. They can erase data from magnetic storage media like hard disks and magnetic strips."
        },
        {
            "type": "subjective",
            "q": "There is a bar magnet with no marking of its poles. How will you find out its north and south poles?",
            "sample": "To find the poles of an unmarked bar magnet:\n\nMethod 1 (using a compass):\n1. Take a magnetic compass (which has a marked north pole).\n2. Bring one end of the magnet near the compass.\n3. If the compass north pole is repelled, that end of the magnet is north pole (like poles repel).\n4. If attracted, that end is south pole.\n\nMethod 2 (using suspension):\n1. Suspend the magnet freely by a thread tied at its centre.\n2. Allow it to come to rest.\n3. The end pointing towards geographical north is the north pole; the end pointing south is the south pole.\n\nMethod 3 (using known magnet):\nUse a marked magnet and test by repulsion/attraction."
        },
    ],
}