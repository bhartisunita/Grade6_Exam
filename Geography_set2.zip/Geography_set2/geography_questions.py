"""
Geography — Grade 6 ICSE
Comprehensive Practice Questions — Chapters 3, 4, 5
3 Chapters • 100 Questions Each (40 MCQ, 40 True/False, 20 Subjective)
"""

QUESTIONS = {'Chapter 3 — Major Landforms of the Earth': [{'type': 'mcq',
                                               'q': "What percentage of the Earth's surface is covered by land?",
                                               'options': ['29 per cent', '50 per cent', '71 per cent', '39 per cent'],
                                               'answer': '29 per cent',
                                               'explanation': 'Land covers nearly 29 per cent of the surface area of '
                                                              'the earth.'},
                                              {'type': 'mcq',
                                               'q': 'A natural or artificial feature of the solid surface of the earth '
                                                    'is called a:',
                                               'options': ['Topography', 'Landform', 'Terrain', 'Continent'],
                                               'answer': 'Landform',
                                               'explanation': 'A landform is a natural or artificial feature of the '
                                                              'solid surface of the earth.'},
                                              {'type': 'mcq',
                                               'q': 'The arrangement of landforms in a landscape is known as:',
                                               'options': ['Geography', 'Geology', 'Topography', 'Cartography'],
                                               'answer': 'Topography',
                                               'explanation': 'Landforms together make up a terrain, and their '
                                                              'arrangements in the landscape is known as topography.'},
                                              {'type': 'mcq',
                                               'q': 'Which of the following is an internal (endogenous) process?',
                                               'options': ['Erosion',
                                                           'Deposition',
                                                           'Folding and faulting',
                                                           'Wind action'],
                                               'answer': 'Folding and faulting',
                                               'explanation': 'Internal processes (endogenous) lead to upliftment and '
                                                              "sinking of the earth's surface, resulting in folding "
                                                              'and faulting.'},
                                              {'type': 'mcq',
                                               'q': "The wearing away of the earth's surface is called:",
                                               'options': ['Deposition', 'Erosion', 'Subduction', 'Faulting'],
                                               'answer': 'Erosion',
                                               'explanation': "Erosion is the wearing away of the earth's surface."},
                                              {'type': 'mcq',
                                               'q': 'Millions of years ago, there was only one big land mass on Earth '
                                                    'called:',
                                               'options': ['Eurasia', 'Gondwana', 'Pangaea', 'Laurasia'],
                                               'answer': 'Pangaea',
                                               'explanation': 'Millions of years ago, there was only one big land mass '
                                                              'called Pangaea on the surface of the earth.'},
                                              {'type': 'mcq',
                                               'q': 'Which is the largest continent in the world?',
                                               'options': ['Africa', 'North America', 'Asia', 'Europe'],
                                               'answer': 'Asia',
                                               'explanation': 'Asia is the largest continent. It occupies about '
                                                              'one-third of the land area of our planet.'},
                                              {'type': 'mcq',
                                               'q': 'Australia is also known as:',
                                               'options': ['The Frozen Continent',
                                                           'The Land Down Under',
                                                           'The Dark Continent',
                                                           'The Island Continent only'],
                                               'answer': 'The Land Down Under',
                                               'explanation': "Australia is sometimes called 'the Land Down Under' as "
                                                              'it lies to the south of the main land masses.'},
                                              {'type': 'mcq',
                                               'q': "Which continent contains 90 per cent of the world's ice?",
                                               'options': ['Australia', 'Arctic', 'Antarctica', 'North America'],
                                               'answer': 'Antarctica',
                                               'explanation': "Antarctica contains 90 per cent of the world's ice."},
                                              {'type': 'mcq',
                                               'q': 'Mountains are formed when two large plates, known as tectonic '
                                                    'plates:',
                                               'options': ['Move apart',
                                                           "Collide under the earth's surface",
                                                           'Dissolve',
                                                           'Spin'],
                                               'answer': "Collide under the earth's surface",
                                               'explanation': 'Mountains are formed when two large plates, known as '
                                                              "tectonic plates, collide under the earth's surface."},
                                              {'type': 'mcq',
                                               'q': 'The process in which the heavier plate is pushed below the '
                                                    'lighter plate is called:',
                                               'options': ['Erosion', 'Deposition', 'Subduction', 'Compression'],
                                               'answer': 'Subduction',
                                               'explanation': 'Sometimes the collision pushes the heavier plate below '
                                                              'the lighter plate. This process is called subduction.'},
                                              {'type': 'mcq',
                                               'q': "Fold mountains are formed when the layers of the earth's crust "
                                                    'are folded by:',
                                               'options': ['Tension', 'Compression', 'Subduction', 'Erosion'],
                                               'answer': 'Compression',
                                               'explanation': 'Fold mountains are formed when the layers of the '
                                                              "earth's crust are folded by compression."},
                                              {'type': 'mcq',
                                               'q': 'Which of the following is an example of old fold mountains?',
                                               'options': ['Himalayas', 'Andes', 'Appalachians', 'Alps'],
                                               'answer': 'Appalachians',
                                               'explanation': 'Old fold mountains were formed over 250 million years '
                                                              'ago, such as the Urals in Russia, the Appalachians in '
                                                              'North America and the Aravallis in India.'},
                                              {'type': 'mcq',
                                               'q': 'Young fold mountains have which of the following characteristics?',
                                               'options': ['Gentle slopes and low altitude',
                                                           'Rugged and lofty peaks',
                                                           'Flat surfaces',
                                                           'Underground formations'],
                                               'answer': 'Rugged and lofty peaks',
                                               'explanation': 'Young fold mountains are rugged and lofty. They '
                                                              "comprise the world's highest mountain ranges."},
                                              {'type': 'mcq',
                                               'q': 'Block mountains are formed due to:',
                                               'options': ['Compression', 'Erosion', 'Faulting', 'Volcanic eruption'],
                                               'answer': 'Faulting',
                                               'explanation': 'Block mountains are formed due to faulting. Faulting is '
                                                              'the rupturing or fracturing of rock strata due to '
                                                              'strain.'},
                                              {'type': 'mcq',
                                               'q': 'The Vosges in Europe and the Vindhyas in India are examples of:',
                                               'options': ['Fold mountains',
                                                           'Volcanic mountains',
                                                           'Block mountains',
                                                           'Young fold mountains'],
                                               'answer': 'Block mountains',
                                               'explanation': 'The Vosges of Europe and the Vindhyas in India are '
                                                              'examples of block mountains.'},
                                              {'type': 'mcq',
                                               'q': 'In a volcanic mountain, the opening through which lava comes to '
                                                    'the surface is called a:',
                                               'options': ['Crater', 'Vent', 'Magma chamber', 'Trench'],
                                               'answer': 'Vent',
                                               'explanation': 'The opening through which lava and other materials come '
                                                              'to the surface is called a vent.'},
                                              {'type': 'mcq',
                                               'q': "The funnel-shaped depression at the top of a volcano's vent is "
                                                    'called a:',
                                               'options': ['Vent', 'Magma chamber', 'Crater', 'Canyon'],
                                               'answer': 'Crater',
                                               'explanation': 'The funnel-shaped depression at the top of a vent is '
                                                              'called a crater.'},
                                              {'type': 'mcq',
                                               'q': 'Mount Fuji in Japan is an example of which type of mountain?',
                                               'options': ['Fold mountain',
                                                           'Block mountain',
                                                           'Volcanic mountain',
                                                           'Old fold mountain'],
                                               'answer': 'Volcanic mountain',
                                               'explanation': 'Examples of volcanic mountains include Mt Fuji in '
                                                              'Japan, Mt Mayon in the Philippines, Mt Kilimanjaro in '
                                                              'Tanzania.'},
                                              {'type': 'mcq',
                                               'q': "Plateaux are uplifted sections of the earth's crust that are "
                                                    'almost:',
                                               'options': ['Steep and rugged',
                                                           'Flat or level',
                                                           'Submerged',
                                                           'Circular in shape'],
                                               'answer': 'Flat or level',
                                               'explanation': "Plateaux are the uplifted sections of the earth's crust "
                                                              'that are almost flat or level and usually descend '
                                                              'steeply to the surrounding lowlands.'},
                                              {'type': 'mcq',
                                               'q': "A plateau formed by the movement of earth's crustal plates is "
                                                    'called:',
                                               'options': ['Volcanic plateau',
                                                           'Dissected plateau',
                                                           'Tectonic plateau',
                                                           'Piedmont plateau'],
                                               'answer': 'Tectonic plateau',
                                               'explanation': 'A tectonic plateau is formed by the movement of the '
                                                              "earth's crustal plates."},
                                              {'type': 'mcq',
                                               'q': 'Dissected plateaus have an irregular surface marked by:',
                                               'options': ['Smooth plains',
                                                           'Canyons, gorges and steep valleys',
                                                           'Active volcanoes',
                                                           'Deep trenches'],
                                               'answer': 'Canyons, gorges and steep valleys',
                                               'explanation': 'Dissected plateaus have irregular surface marked by '
                                                              'canyons, gorges and steep, narrow valleys formed by '
                                                              'erosion.'},
                                              {'type': 'mcq',
                                               'q': 'The Tibetan Plateau is an example of which type of plateau?',
                                               'options': ['Tectonic plateau',
                                                           'Dissected plateau',
                                                           'Intermontane plateau',
                                                           'Piedmont plateau'],
                                               'answer': 'Intermontane plateau',
                                               'explanation': 'The most common example of an intermontane plateau is '
                                                              'the Tibetan Plateau which is enclosed by the Himalayan '
                                                              'Mountains to its south and the Kunlun Shan to its '
                                                              'north.'},
                                              {'type': 'mcq',
                                               'q': "A depressed section of the earth's crust surrounded by higher "
                                                    'land is called:',
                                               'options': ['Valley', 'Basin', 'Plain', 'Peninsula'],
                                               'answer': 'Basin',
                                               'explanation': "A basin is a depressed section of the earth's crust "
                                                              'surrounded by higher land.'},
                                              {'type': 'mcq',
                                               'q': 'A rift valley is formed when land between:',
                                               'options': ['Two mountains rises',
                                                           'Two faults sinks',
                                                           'Rivers erode',
                                                           'Two volcanoes erupt'],
                                               'answer': 'Two faults sinks',
                                               'explanation': 'A rift valley is a type of valley that is formed when '
                                                              'the land between two faults sinks.'},
                                              {'type': 'mcq',
                                               'q': 'The Narmada Valley in India is an example of a:',
                                               'options': ['River valley',
                                                           'U-shaped valley',
                                                           'Rift valley',
                                                           'Glacial valley'],
                                               'answer': 'Rift valley',
                                               'explanation': 'The Narmada Valley in India and the Nile Valley in '
                                                              'Egypt are examples of rift valleys.'},
                                              {'type': 'mcq',
                                               'q': 'Valleys formed by glaciers are:',
                                               'options': ['V-shaped', 'U-shaped', 'L-shaped', 'Circular'],
                                               'answer': 'U-shaped',
                                               'explanation': 'Valleys formed by glaciers are U-shaped. Many such '
                                                              'glaciers are present in the Alps and the Himalayas.'},
                                              {'type': 'mcq',
                                               'q': 'Plains or lowlands are vast, nearly flat expanses of land which '
                                                    'are usually less than:',
                                               'options': ['100 metres above sea level',
                                                           '200 metres above sea level',
                                                           '500 metres above sea level',
                                                           '50 metres above sea level'],
                                               'answer': '200 metres above sea level',
                                               'explanation': 'Plains or lowlands are vast, nearly flat expanses of '
                                                              'land which are usually less than 200 metres above sea '
                                                              'level.'},
                                              {'type': 'mcq',
                                               'q': 'River plains are also called river plains because they are built '
                                                    'by:',
                                               'options': ['Wind deposits',
                                                           'Alluvium deposited by rivers',
                                                           'Volcanic lava',
                                                           'Glacial deposits'],
                                               'answer': 'Alluvium deposited by rivers',
                                               'explanation': 'Plains are mostly built by alluvium deposited by big '
                                                              'rivers and their tributaries and are, therefore, also '
                                                              'called river plains.'},
                                              {'type': 'mcq',
                                               'q': 'An island is a piece of land which is surrounded on:',
                                               'options': ['One side by water',
                                                           'Two sides by water',
                                                           'Three sides by water',
                                                           'All sides by water'],
                                               'answer': 'All sides by water',
                                               'explanation': 'An island is a piece of land which is surrounded on all '
                                                              'sides by water.'},
                                              {'type': 'mcq',
                                               'q': 'A peninsula is a piece of land that is surrounded by water on:',
                                               'options': ['All four sides',
                                                           'One side only',
                                                           'Three sides',
                                                           'Two sides'],
                                               'answer': 'Three sides',
                                               'explanation': 'A peninsula is a piece of land that is surrounded by '
                                                              'water on three sides and joined to a larger land mass.'},
                                              {'type': 'mcq',
                                               'q': 'An isthmus is an elongated narrow piece of land, with water on '
                                                    'each side, that:',
                                               'options': ['Separates two land masses',
                                                           'Joins two large land masses',
                                                           'Forms a peninsula',
                                                           'Creates an island'],
                                               'answer': 'Joins two large land masses',
                                               'explanation': 'An isthmus is an elongated narrow piece of land, with '
                                                              'water on each side, that joins two large land masses.'},
                                              {'type': 'mcq',
                                               'q': 'India has which two groups of islands?',
                                               'options': ['Andaman and Nicobar Islands, and Sri Lanka',
                                                           'Lakshadweep Islands and Andaman and Nicobar Islands',
                                                           'Maldives and Lakshadweep Islands',
                                                           'Sri Lanka and Maldives'],
                                               'answer': 'Lakshadweep Islands and Andaman and Nicobar Islands',
                                               'explanation': 'India has two groups of islands—the Lakshadweep Islands '
                                                              'in the Arabian Sea and the Andaman and Nicobar Islands '
                                                              'in the Bay of Bengal.'},
                                              {'type': 'mcq',
                                               'q': "Which continent is known as the 'Dark Continent'?",
                                               'options': ['Asia', 'South America', 'Africa', 'Antarctica'],
                                               'answer': 'Africa',
                                               'explanation': 'Africa is the second largest continent. The Atlantic '
                                                              'Ocean in the west separates it from the two Americas.'},
                                              {'type': 'mcq',
                                               'q': 'The Isthmus of Panama joins:',
                                               'options': ['Europe and Asia',
                                                           'North America and South America',
                                                           'Africa and Asia',
                                                           'Asia and Australia'],
                                               'answer': 'North America and South America',
                                               'explanation': 'The Isthmus of Panama joins North America and South '
                                                              'America with the Pacific Ocean on one side and the '
                                                              'Atlantic Ocean on the other.'},
                                              {'type': 'mcq',
                                               'q': 'Structural plains are mainly formed by the uplift of a part of:',
                                               'options': ['Mountain ranges',
                                                           'Seafloor or continental shelf',
                                                           'Volcanic lava',
                                                           'Glaciers'],
                                               'answer': 'Seafloor or continental shelf',
                                               'explanation': 'Structural plains that lie near the coast of a sea or '
                                                              'an ocean are mainly formed by the uplift of a part of '
                                                              'the seafloor or continental shelf.'},
                                              {'type': 'mcq',
                                               'q': 'Which of the following is an example of a young fold mountain?',
                                               'options': ['Aravallis', 'Urals', 'Appalachians', 'Himalayas'],
                                               'answer': 'Himalayas',
                                               'explanation': 'The Rockies of North America, the Andes of South '
                                                              'America, the Alps of Europe and the Himalayas of Asia '
                                                              'are examples of young fold mountains.'},
                                              {'type': 'mcq',
                                               'q': 'The South African Plateau is known for yielding which minerals?',
                                               'options': ['Iron ore and coal',
                                                           'Gold, diamond, copper, manganese and chromium',
                                                           'Bauxite and uranium',
                                                           'Silver and lead'],
                                               'answer': 'Gold, diamond, copper, manganese and chromium',
                                               'explanation': 'The South African Plateau yields gold, diamond, copper, '
                                                              'manganese and chromium.'},
                                              {'type': 'mcq',
                                               'q': 'Mountains provide home for around how many million people '
                                                    'according to UNDP?',
                                               'options': ['120 million', '350 million', '720 million', '1000 million'],
                                               'answer': '720 million',
                                               'explanation': 'According to the United Nations Development Programme '
                                                              '(UNDP), mountains provide home for around 720 million '
                                                              'people.'},
                                              {'type': 'mcq',
                                               'q': 'The Deccan Plateau and the Chota Nagpur Plateau are located in '
                                                    'which country?',
                                               'options': ['China', 'India', 'Brazil', 'Australia'],
                                               'answer': 'India',
                                               'explanation': 'In India, the Deccan Plateau and the Chota Nagpur '
                                                              'Plateau are good examples of plateaux.'},
                                              {'type': 'tf',
                                               'q': 'Land covers nearly 29 per cent of the surface area of the earth.',
                                               'answer': 'True',
                                               'explanation': 'Land covers nearly 29 per cent of the surface area of '
                                                              'the earth.'},
                                              {'type': 'tf',
                                               'q': 'Topography refers to the study of landforms and their arrangement '
                                                    'in a landscape.',
                                               'answer': 'True',
                                               'explanation': 'Landforms together make up a terrain, and their '
                                                              'arrangements in the landscape is known as topography.'},
                                              {'type': 'tf',
                                               'q': 'Erosion is the rebuilding of a lowered surface.',
                                               'answer': 'False',
                                               'explanation': "Erosion is the wearing away of the earth's surface. "
                                                              'Deposition is the rebuilding of a lowered surface.'},
                                              {'type': 'tf',
                                               'q': 'Millions of years ago, there was only one big land mass called '
                                                    'Pangaea.',
                                               'answer': 'True',
                                               'explanation': 'Millions of years ago, there was only one big land mass '
                                                              'called Pangaea on the surface of the earth.'},
                                              {'type': 'tf',
                                               'q': 'Asia occupies about half of the total land area of our planet.',
                                               'answer': 'False',
                                               'explanation': 'Asia occupies about one-third of the land area of our '
                                                              'planet, not half.'},
                                              {'type': 'tf',
                                               'q': 'Antarctica is the most bleak and barren part of the world.',
                                               'answer': 'True',
                                               'explanation': 'Antarctica, a large frozen land mass located in the '
                                                              'extreme south, is the most bleak and barren part of the '
                                                              'world.'},
                                              {'type': 'tf',
                                               'q': 'Australia is the largest continent in the world.',
                                               'answer': 'False',
                                               'explanation': 'Australia is the smallest continent in the world. Asia '
                                                              'is the largest.'},
                                              {'type': 'tf',
                                               'q': 'The movement of tectonic plates causes earthquakes, volcanic '
                                                    'eruptions, and the formation of mountains.',
                                               'answer': 'True',
                                               'explanation': 'The movement of these plates can cause earthquakes, '
                                                              'volcanic eruptions, and the formation of mountains.'},
                                              {'type': 'tf',
                                               'q': 'Old fold mountains have steep slopes and high altitude.',
                                               'answer': 'False',
                                               'explanation': 'Old fold mountains have gentle slopes and low altitude '
                                                              'due to weathering over time.'},
                                              {'type': 'tf',
                                               'q': 'The Himalayas are an example of young fold mountains.',
                                               'answer': 'True',
                                               'explanation': 'The Himalayas of Asia are examples of young fold '
                                                              'mountains, formed comparatively recently about 25 '
                                                              'million years ago.'},
                                              {'type': 'tf',
                                               'q': 'Block mountains are formed due to compression of rock layers.',
                                               'answer': 'False',
                                               'explanation': 'Block mountains are formed due to faulting, which is '
                                                              'the rupturing or fracturing of rock strata due to '
                                                              'strain.'},
                                              {'type': 'tf',
                                               'q': 'Faulting is the rupturing or fracturing of rock strata due to '
                                                    'strain.',
                                               'answer': 'True',
                                               'explanation': 'Faulting is the rupturing or fracturing of rock strata '
                                                              'due to strain.'},
                                              {'type': 'tf',
                                               'q': 'Volcanic mountains are built when molten lava, ash, cinder and '
                                                    'dust from deep inside the earth accumulate in the shape of high '
                                                    'cones.',
                                               'answer': 'True',
                                               'explanation': 'Volcanic mountains are built when molten lava, ash, '
                                                              'cinder and dust from deep inside the earth come out on '
                                                              'the surface and accumulate in the shape of high cones.'},
                                              {'type': 'tf',
                                               'q': 'The Aravallis in India are young fold mountains.',
                                               'answer': 'False',
                                               'explanation': 'The Aravallis in India are old fold mountains, formed '
                                                              'over 250 million years ago.'},
                                              {'type': 'tf',
                                               'q': 'Plateaux are generally used for irrigation and generation of '
                                                    'hydroelectricity.',
                                               'answer': 'True',
                                               'explanation': 'Reservoirs are made and the water from the mountains is '
                                                              'used for irrigation and generation of '
                                                              'hydroelectricity.'},
                                              {'type': 'tf',
                                               'q': 'A tectonic plateau is formed by the spread of successive layers '
                                                    'of lava.',
                                               'answer': 'False',
                                               'explanation': 'A volcanic plateau is formed by the spread of '
                                                              'successive layers of lava. A tectonic plateau is formed '
                                                              "by the movement of the earth's crustal plates."},
                                              {'type': 'tf',
                                               'q': 'Dissected plateaus are mostly common in dry and desert regions.',
                                               'answer': 'True',
                                               'explanation': 'Dissected plateaus are mostly common in dry and desert '
                                                              'regions.'},
                                              {'type': 'tf',
                                               'q': 'The Grand Canyon passes through the Colorado Plateau.',
                                               'answer': 'True',
                                               'explanation': 'The Colorado Plateau, through which the Grand Canyon '
                                                              'passes, is an example of a dissected plateau.'},
                                              {'type': 'tf',
                                               'q': "A basin is an elevated section of the earth's crust surrounded by "
                                                    'lower land.',
                                               'answer': 'False',
                                               'explanation': "A basin is a depressed section of the earth's crust "
                                                              'surrounded by higher land.'},
                                              {'type': 'tf',
                                               'q': 'River valleys are usually V-shaped.',
                                               'answer': 'True',
                                               'explanation': 'River valleys are usually V-shaped. The Rhine Valley in '
                                                              'Europe and the Damodar Valley in India are examples of '
                                                              'river valleys.'},
                                              {'type': 'tf',
                                               'q': 'Plains are usually found more than 500 metres above sea level.',
                                               'answer': 'False',
                                               'explanation': 'Plains are vast, nearly flat expanses of land which are '
                                                              'usually less than 200 metres above sea level.'},
                                              {'type': 'tf',
                                               'q': 'Plains have always been the areas that support large populations.',
                                               'answer': 'True',
                                               'explanation': 'Plains have always been the areas that support large '
                                                              'populations, for example, the Indo-Gangetic Plain, the '
                                                              'Mississippi Plain, and the Yangtze Plain.'},
                                              {'type': 'tf',
                                               'q': 'A peninsula is surrounded by water on all four sides.',
                                               'answer': 'False',
                                               'explanation': 'A peninsula is surrounded by water on three sides and '
                                                              'joined to a larger land mass.'},
                                              {'type': 'tf',
                                               'q': 'An isthmus joins two large land masses.',
                                               'answer': 'True',
                                               'explanation': 'An isthmus is an elongated narrow piece of land, with '
                                                              'water on each side, that joins two large land masses.'},
                                              {'type': 'tf',
                                               'q': 'Structural plains are found near the interior of continents.',
                                               'answer': 'False',
                                               'explanation': 'Structural plains lie near the coast of a sea or an '
                                                              'ocean and border all countries.'},
                                              {'type': 'tf',
                                               'q': 'Mountains affect the climate of an area.',
                                               'answer': 'True',
                                               'explanation': 'Mountains also affect the climate of an area. For '
                                                              'example, the Himalayas cause rainfall in India by '
                                                              'blocking the south-west monsoon winds.'},
                                              {'type': 'tf',
                                               'q': 'The Lakshadweep Islands are in the Bay of Bengal.',
                                               'answer': 'False',
                                               'explanation': 'The Lakshadweep Islands are in the Arabian Sea, while '
                                                              'the Andaman and Nicobar Islands are in the Bay of '
                                                              'Bengal.'},
                                              {'type': 'tf',
                                               'q': 'Sri Lanka is an island just south of India, in the Indian Ocean.',
                                               'answer': 'True',
                                               'explanation': 'Sri Lanka is an island just south of India, in the '
                                                              'Indian Ocean.'},
                                              {'type': 'tf',
                                               'q': 'The process by which mountains are formed from inside the earth '
                                                    'is called endogenous.',
                                               'answer': 'True',
                                               'explanation': 'The movements inside the earth are responsible for the '
                                                              'formation of mountains and volcanoes and this process '
                                                              'is called endogenous (coming from inside).'},
                                              {'type': 'tf',
                                               'q': 'Europe has the most indented coastline among all continents.',
                                               'answer': 'True',
                                               'explanation': 'Europe has the most indented coastline among the '
                                                              'continents, which is why it has numerous ports and some '
                                                              'of the finest harbours in the world.'},
                                              {'type': 'tf',
                                               'q': 'The Sahara Desert is found on the continent of South America.',
                                               'answer': 'False',
                                               'explanation': 'In Africa, lies the largest hot desert of the world, '
                                                              'the Sahara Desert.'},
                                              {'type': 'tf',
                                               'q': 'The plains of the world are the most suitable landform for humans '
                                                    'and animals.',
                                               'answer': 'True',
                                               'explanation': 'Of all the landforms that are on earth, the most '
                                                              'suitable for both humans and animals are the plains.'},
                                              {'type': 'tf',
                                               'q': 'Erosional plains are formed by sediments brought down from the '
                                                    'upper regions of mountains.',
                                               'answer': 'False',
                                               'explanation': 'Depositional plains are formed by sediments brought '
                                                              'down on a large scale by natural agents. Erosional '
                                                              'plains are the result of the erosion of mountains, '
                                                              'hills and plateaux.'},
                                              {'type': 'tf',
                                               'q': 'Mountains are a storehouse of water because many rivers originate '
                                                    'in the glaciers in the mountains.',
                                               'answer': 'True',
                                               'explanation': 'Mountains are a storehouse of water. Many rivers '
                                                              'originate in the glaciers in the mountains.'},
                                              {'type': 'tf',
                                               'q': 'There are six continents in the world.',
                                               'answer': 'False',
                                               'explanation': 'There are seven continents in the world: Asia, Africa, '
                                                              'Europe, North America, South America, Australia and '
                                                              'Antarctica.'},
                                              {'type': 'tf',
                                               'q': 'The Deccan Plateau in India is fertile.',
                                               'answer': 'True',
                                               'explanation': 'The Deccan Plateau covers a large area and is fertile.'},
                                              {'type': 'tf',
                                               'q': 'The Ural Mountains in Russia separate Europe from Asia.',
                                               'answer': 'True',
                                               'explanation': 'The Ural Mountains, the Black Sea and the Caspian Sea '
                                                              'separate the two continents (Europe and Asia).'},
                                              {'type': 'tf',
                                               'q': 'An isthmus is an example of a major landform.',
                                               'answer': 'False',
                                               'explanation': 'An isthmus is classified as a minor landform, along '
                                                              'with islands and peninsulas.'},
                                              {'type': 'tf',
                                               'q': 'Coastal plains of India include both the eastern and western '
                                                    'coastal plains.',
                                               'answer': 'True',
                                               'explanation': 'Plains that are found along the edges of continents '
                                                              'adjacent to seas are called coastal plains, for '
                                                              'example, the eastern and the western coastal plains of '
                                                              'India.'},
                                              {'type': 'tf',
                                               'q': 'Peneplain is a level land surface produced by erosion over a long '
                                                    'period.',
                                               'answer': 'True',
                                               'explanation': 'Peneplain: It is a level land surface produced by '
                                                              'erosion over a long period, undisturbed by crustal '
                                                              'movement.'},
                                              {'type': 'subjective',
                                               'q': 'What is a landform? Explain the two types of processes that '
                                                    'create landforms.',
                                               'sample': 'A landform is a natural or artificial feature of the solid '
                                                         'surface of the earth. Landforms are created by two types of '
                                                         'processes: (1) Internal (endogenous) processes — these lead '
                                                         "to upliftment and sinking of the earth's surface, forming "
                                                         'mountains and valleys through folding and faulting. (2) '
                                                         'External (exogenous) processes — these cause continuous '
                                                         'wearing down and rebuilding of land surfaces through erosion '
                                                         '(wearing away) and deposition (rebuilding).'},
                                              {'type': 'subjective',
                                               'q': 'Differentiate between old fold mountains and young fold mountains '
                                                    'with examples.',
                                               'sample': 'Old fold mountains were formed over 250 million years ago. '
                                                         'They have gentle slopes and low altitude due to weathering '
                                                         'over time. Examples: Urals (Russia), Appalachians (North '
                                                         'America), Aravallis (India). Young fold mountains were '
                                                         'formed comparatively recently, about 25 million years ago. '
                                                         "They are rugged, lofty and comprise the world's highest "
                                                         'mountain ranges. Examples: Himalayas (Asia), Andes (South '
                                                         'America), Alps (Europe), Rockies (North America).'},
                                              {'type': 'subjective',
                                               'q': 'How are block mountains formed? Give two examples.',
                                               'sample': 'Block mountains are formed due to faulting. Faulting is the '
                                                         'rupturing or fracturing of rock strata due to strain. When '
                                                         "such cracks or faults occur in the earth's crust, the land "
                                                         'between the cracks sinks, leaving upstanding blocks on '
                                                         'either side of the fault. These blocks are called block '
                                                         'mountains. Their edges are steep and surfaces are almost '
                                                         'level. Examples: The Vosges in Europe and the Vindhyas in '
                                                         'India.'},
                                              {'type': 'subjective',
                                               'q': 'Explain the formation of volcanic mountains with the help of '
                                                    'relevant terms.',
                                               'sample': 'Volcanic mountains are built when molten lava, ash, cinder '
                                                         'and dust from deep inside the earth come out on the surface '
                                                         "through cracks in the earth's crust and accumulate in the "
                                                         'shape of high cones. The opening through which lava and '
                                                         'other materials come to the surface is called a vent. The '
                                                         'funnel-shaped depression at the top of a vent is called a '
                                                         'crater. Examples: Mt Fuji (Japan), Mt Kilimanjaro '
                                                         '(Tanzania), Mt Vesuvius (Italy).'},
                                              {'type': 'subjective',
                                               'q': 'State any four ways in which mountains are important to human '
                                                    'beings.',
                                               'sample': 'Mountains are important in the following ways: (1) They are '
                                                         'a storehouse of water — many rivers originate in glaciers in '
                                                         'the mountains. (2) River valleys and terraces are most '
                                                         'suitable for farming as the land is very fertile. (3) '
                                                         'Mountains affect the climate of an area — the Himalayas '
                                                         'cause rainfall in India by blocking the south-west monsoon '
                                                         'winds. (4) Mountains are rich in mineral and metal deposits '
                                                         'essential for industries. (5) They provide an ideal holiday '
                                                         'destination for tourists and support sports like skiing and '
                                                         'river rafting.'},
                                              {'type': 'subjective',
                                               'q': 'What are plateaux? Describe any two types of plateaux with '
                                                    'examples.',
                                               'sample': "Plateaux are the uplifted sections of the earth's crust that "
                                                         'are almost flat or level and usually descend steeply to the '
                                                         'surrounding lowlands. They are sometimes referred to as '
                                                         "'plains-in-the-air' or tableland. Two types: (1) Tectonic "
                                                         "Plateau — formed by the movement of earth's crustal plates. "
                                                         'The plateau of South Africa and the Turkish-Iranian Plateau '
                                                         'are examples. (2) Volcanic Plateau — formed by the spread of '
                                                         'successive layers of lava on a particular region. The '
                                                         'Columbia Plateau in USA and the Deccan Plateau are '
                                                         'examples.'},
                                              {'type': 'subjective',
                                               'q': 'What is a rift valley? How is it formed? Give one example each '
                                                    'from India and abroad.',
                                               'sample': 'A rift valley is a type of valley that is formed when the '
                                                         'land between two faults sinks. In other words, the land '
                                                         'between two block mountains is a rift valley. Example from '
                                                         'India: The Narmada Valley. Example from abroad: The Nile '
                                                         'Valley in Egypt.'},
                                              {'type': 'subjective',
                                               'q': 'Explain why plains are considered the most important landform for '
                                                    'human settlement.',
                                               'sample': 'Plains are considered the most important landform for human '
                                                         'settlement for the following reasons: (1) They support large '
                                                         'populations — famous examples include the Indo-Gangetic '
                                                         'Plain and the Mississippi Plain. (2) Crops such as rice, '
                                                         'wheat and sugar cane are grown in plains — they are the '
                                                         'granaries of the world. (3) Large cities and towns are '
                                                         'located mostly in plains. (4) The soft and flat surface '
                                                         'makes it easy for the construction of roads, railways and '
                                                         'airports. (5) The scope for industrialization is much higher '
                                                         'in plains.'},
                                              {'type': 'subjective',
                                               'q': 'Differentiate between a peninsula and an island.',
                                               'sample': 'A peninsula is a piece of land that is surrounded by water '
                                                         'on three sides and joined to a larger land mass. For '
                                                         'example, the peninsular plateau of India and the Malay '
                                                         'Peninsula. An island is a piece of land which is surrounded '
                                                         'on all sides by water. For example, Sri Lanka, Madagascar, '
                                                         "and India's Lakshadweep and Andaman and Nicobar Islands."},
                                              {'type': 'subjective',
                                               'q': 'Describe the continent of Antarctica.',
                                               'sample': 'Antarctica is a large frozen land mass located in the '
                                                         'extreme south of the world. It is the most bleak and barren '
                                                         'part of the world. It is almost circular in shape. '
                                                         "Antarctica contains 90 per cent of the world's ice. It is "
                                                         'even colder than the Arctic region and is surrounded by the '
                                                         'stormiest seas. Several countries of the world have set up '
                                                         'research stations in Antarctica to conduct research in '
                                                         'climatology, earth sciences, human physiology and medicine.'},
                                              {'type': 'subjective',
                                               'q': 'What is the economic value of plateaux? Give examples.',
                                               'sample': 'Plateaux are of great economic value. The South African '
                                                         'Plateau yields gold, diamond, copper, manganese and '
                                                         'chromium, while the plateau in Western Australia is rich in '
                                                         'gold and iron. In India, the Deccan Plateau covers a large '
                                                         'area and is fertile, while the Chota Nagpur Plateau is a '
                                                         'storehouse of mineral wealth. These minerals are essential '
                                                         'for industries and contribute greatly to the economic '
                                                         'development of countries.'},
                                              {'type': 'subjective',
                                               'q': 'What is topography? How do landforms affect the lives of people?',
                                               'sample': 'Topography refers to the arrangement of landforms in a '
                                                         'landscape. Landforms affect the lives of people in many '
                                                         'ways. Flat low-lying areas are suitable for agriculture, '
                                                         'while hill slopes support vineyards and orchards. Mountains '
                                                         'attract tourists and support sports like skiing. Plains '
                                                         'support large populations and industrialization. Volcanic '
                                                         'eruptions and earthquakes can cause severe loss to human '
                                                         'life and property. The availability of water, soil type, and '
                                                         'climate — all related to landforms — determine where and how '
                                                         'people live.'},
                                              {'type': 'subjective',
                                               'q': 'Explain what an isthmus is and give two examples.',
                                               'sample': 'An isthmus is an elongated narrow piece of land, with water '
                                                         'on each side, that joins two large land masses. For example: '
                                                         '(1) The Isthmus of Panama joins North America and South '
                                                         'America, with the Pacific Ocean on one side and the Atlantic '
                                                         'Ocean on the other. (2) The Isthmus of Suez joins Africa to '
                                                         'Asia and separates the Mediterranean Sea and the Red Sea.'},
                                              {'type': 'subjective',
                                               'q': 'How are mountains formed? Explain the role of tectonic plates.',
                                               'sample': 'Mountains are formed when two large plates, known as '
                                                         "tectonic plates, collide under the earth's surface. This "
                                                         'collision leads to the plates being pushed upwards to form '
                                                         'peaks. Sometimes, the collision of these plates pushes the '
                                                         'heavier plate below the lighter plate — this process is '
                                                         'called subduction. The movements inside the earth that are '
                                                         'responsible for the formation of mountains and volcanoes are '
                                                         'called endogenous processes. Tectonic plate theory also '
                                                         'states that the crust is divided into several large plates '
                                                         'that glide over the semi-solid mantle.'},
                                              {'type': 'subjective',
                                               'q': 'Name and describe any three types of valleys.',
                                               'sample': 'Three types of valleys are: (1) River valley — formed by a '
                                                         'river flowing down the mountains. These are usually '
                                                         'V-shaped. Examples: Rhine Valley in Europe, Damodar Valley '
                                                         'in India. (2) Rift valley — formed when the land between two '
                                                         'faults sinks, leaving the land between two block mountains '
                                                         'sunken. Examples: Narmada Valley (India), Nile Valley '
                                                         '(Egypt). (3) Glacial valley — formed by the movement of '
                                                         'glaciers. These are U-shaped. Many are present in the Alps '
                                                         'and the Himalayas.'},
                                              {'type': 'subjective',
                                               'q': "Why is Australia called both 'the Land Down Under' and 'the "
                                                    "island continent'?",
                                               'sample': "Australia is called 'the Land Down Under' because it lies to "
                                                         'the south of the main land masses of the world — below the '
                                                         "equator in the Southern Hemisphere. It is called 'the island "
                                                         "continent' because it is surrounded by water on all sides — "
                                                         'the Indian Ocean in the west, the South Pacific Ocean in the '
                                                         'east, the Southern Ocean in the south, and the Arafura Sea '
                                                         'in the north. Since it is completely surrounded by water, it '
                                                         'is both the smallest continent and technically an island.'},
                                              {'type': 'subjective',
                                               'q': 'Describe the importance of the plains for agriculture.',
                                               'sample': 'Plains are extremely important for agriculture for the '
                                                         'following reasons: (1) Plains are built by alluvium '
                                                         'deposited by big rivers, making the soil extremely fertile. '
                                                         '(2) Crops such as rice, wheat and sugar cane are grown in '
                                                         'the plains — plains are the granaries of the world. (3) The '
                                                         'flat terrain makes it easy to construct irrigation canals '
                                                         'and use farm machinery. (4) Large rivers flowing through '
                                                         'plains provide water for irrigation. (5) Depositional plains '
                                                         'formed by rivers, wind, or glaciers provide rich, flat land '
                                                         'suitable for cultivation.'},
                                              {'type': 'subjective',
                                               'q': 'What is Plate Tectonic theory? Explain briefly.',
                                               'sample': "Plate Tectonic theory states that the earth's outer shell or "
                                                         'the crust is divided into several plates, which are large '
                                                         'blocks of crust. These plates glide over the semi-solid '
                                                         'mantle beneath them. The movement of these plates can cause '
                                                         'earthquakes, volcanic eruptions, and the formation of '
                                                         'mountains. When two plates collide, they can form fold '
                                                         'mountains. When plates move apart, rifts and valleys can be '
                                                         'formed. This theory explains many of the major geological '
                                                         "features of the earth's surface."},
                                              {'type': 'subjective',
                                               'q': 'List any five landforms found in India and give one example of '
                                                    'each.',
                                               'sample': 'Five landforms found in India: (1) Old fold mountains — '
                                                         'Aravallis. (2) Young fold mountains — Himalayas. (3) Block '
                                                         'mountains — Vindhyas. (4) Plateau — Deccan Plateau, Chota '
                                                         'Nagpur Plateau. (5) Plains — Indo-Gangetic Plains. (6) Rift '
                                                         'valley — Narmada Valley. (7) Islands — Lakshadweep Islands '
                                                         '(Arabian Sea), Andaman and Nicobar Islands (Bay of Bengal). '
                                                         '(Any five with correct examples are acceptable.)'},
                                              {'type': 'subjective',
                                               'q': 'What are the three types of plains based on their formation? '
                                                    'Describe each briefly.',
                                               'sample': 'The three types of plains based on formation are: (1) '
                                                         'Structural plains — these lie near the coast and are mainly '
                                                         'formed by the uplift of part of the seafloor or continental '
                                                         'shelf. Example: Coastal plains of south-eastern USA, '
                                                         'northern Russia. (2) Erosional plains — these are the result '
                                                         'of erosion of mountains, hills and plateaux by wind, rivers, '
                                                         'rain and glacier. Example: Plains of northern Canada, '
                                                         'Kashmir in India. (3) Depositional plains — formed by '
                                                         'sediments brought down by natural agents such as moving ice, '
                                                         'water and wind from upper regions of mountains. Example: '
                                                         'Eastern and western coastal plains of India.'}],
 'Chapter 4 — Major Water Bodies': [{'type': 'mcq',
                                     'q': "What percentage of the earth's surface is covered by water?",
                                     'options': ['50 per cent', '61 per cent', '71 per cent', '81 per cent'],
                                     'answer': '71 per cent',
                                     'explanation': "Water covers 71 per cent of the earth's surface in the form of "
                                                    'large and small water bodies.'},
                                    {'type': 'mcq',
                                     'q': 'Which is the largest ocean in the world?',
                                     'options': ['Atlantic Ocean', 'Indian Ocean', 'Pacific Ocean', 'Arctic Ocean'],
                                     'answer': 'Pacific Ocean',
                                     'explanation': 'The Pacific Ocean is the largest ocean and covers over one third '
                                                    'of the globe.'},
                                    {'type': 'mcq',
                                     'q': 'The Pacific Ocean is almost _______ in shape.',
                                     'options': ['Triangular', 'Circular', 'Rectangular', 'S-shaped'],
                                     'answer': 'Circular',
                                     'explanation': 'The Pacific Ocean is almost circular in shape and is bordered on '
                                                    'its edges by new fold mountains.'},
                                    {'type': 'mcq',
                                     'q': "The deepest part of the earth's crust is the Mariana Trench, which lies in "
                                          'the:',
                                     'options': ['Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean', 'Pacific Ocean'],
                                     'answer': 'Pacific Ocean',
                                     'explanation': "The deepest part of the earth's crust—the Mariana Trench—lies in "
                                                    'the Pacific Ocean near the Philippines.'},
                                    {'type': 'mcq',
                                     'q': 'The Atlantic Ocean is shaped like the letter:',
                                     'options': ['O', 'C', 'S', 'Z'],
                                     'answer': 'S',
                                     'explanation': "The Atlantic Ocean is shaped like the letter 'S'."},
                                    {'type': 'mcq',
                                     'q': 'Which ocean is known as the busiest ocean in the world?',
                                     'options': ['Pacific Ocean', 'Indian Ocean', 'Atlantic Ocean', 'Arctic Ocean'],
                                     'answer': 'Atlantic Ocean',
                                     'explanation': 'The Atlantic Ocean is the busiest ocean in the world as many '
                                                    'trade and transportation routes pass across it.'},
                                    {'type': 'mcq',
                                     'q': 'The Indian Ocean is roughly _______ in shape.',
                                     'options': ['Circular', 'Rectangular', 'Triangular', 'S-shaped'],
                                     'answer': 'Triangular',
                                     'explanation': 'The Indian Ocean is roughly triangular in shape and covers one '
                                                    'fifth of the total area under the oceans.'},
                                    {'type': 'mcq',
                                     'q': 'The Arctic Ocean is the northernmost ocean and lies to the north of:',
                                     'options': ['South America, Africa and Australia',
                                                 'North America, Europe and Asia',
                                                 'Africa and Asia',
                                                 'Europe and South America'],
                                     'answer': 'North America, Europe and Asia',
                                     'explanation': 'The Arctic Ocean is the northernmost ocean and lies to the north '
                                                    'of North America, Europe and Asia.'},
                                    {'type': 'mcq',
                                     'q': 'The Southern Ocean (Antarctic Ocean) is formed by the merging of which '
                                          'three oceans?',
                                     'options': ['Pacific, Indian and Arctic',
                                                 'Atlantic, Indian and Arctic',
                                                 'Pacific, Atlantic and Indian',
                                                 'Pacific, Atlantic and Arctic'],
                                     'answer': 'Pacific, Atlantic and Indian',
                                     'explanation': 'The Southern Ocean is formed by the merging of the Pacific, the '
                                                    'Atlantic and the Indian oceans.'},
                                    {'type': 'mcq',
                                     'q': 'The Southern Ocean is the _______ largest ocean in the world.',
                                     'options': ['Second', 'Third', 'Fourth', 'Fifth'],
                                     'answer': 'Fourth',
                                     'explanation': 'The Southern Ocean is the fourth largest ocean in the world.'},
                                    {'type': 'mcq',
                                     'q': 'A sea is a part of an ocean that is smaller and:',
                                     'options': ['Deeper', 'Saltier', 'Shallower', 'Larger'],
                                     'answer': 'Shallower',
                                     'explanation': 'A sea is a part of an ocean that is smaller and shallower. It is '
                                                    'usually located close to the edge of a land mass or continent.'},
                                    {'type': 'mcq',
                                     'q': 'A deep inlet of the sea almost surrounded by land, with a narrow mouth is '
                                          'called a:',
                                     'options': ['Bay', 'Strait', 'Gulf', 'Lake'],
                                     'answer': 'Gulf',
                                     'explanation': 'A gulf is a deep inlet of the sea almost surrounded by land, with '
                                                    'a narrow mouth.'},
                                    {'type': 'mcq',
                                     'q': 'A bay is an open, curving indentation made by the sea or a lake into a:',
                                     'options': ['Island', 'Coastline', 'Mountain', 'Plain'],
                                     'answer': 'Coastline',
                                     'explanation': 'A bay is an open, curving indentation made by the sea or a lake '
                                                    'into a coastline.'},
                                    {'type': 'mcq',
                                     'q': 'A narrow stretch of water that joins two large water bodies is called a:',
                                     'options': ['Bay', 'Gulf', 'Strait', 'Channel'],
                                     'answer': 'Strait',
                                     'explanation': 'A strait is a narrow stretch of water that joins two large water '
                                                    'bodies.'},
                                    {'type': 'mcq',
                                     'q': 'The Strait of Gibraltar connects the Mediterranean Sea to the:',
                                     'options': ['Indian Ocean', 'Pacific Ocean', 'North Atlantic Ocean', 'Red Sea'],
                                     'answer': 'North Atlantic Ocean',
                                     'explanation': 'The Strait of Gibraltar, for example, connects the Mediterranean '
                                                    'Sea to the North Atlantic Ocean.'},
                                    {'type': 'mcq',
                                     'q': 'Lake Baikal is located in:',
                                     'options': ['North America',
                                                 'South-east Siberia',
                                                 'Central Africa',
                                                 'South America'],
                                     'answer': 'South-east Siberia',
                                     'explanation': 'Lake Baikal is located in south-east Siberia, and is the oldest '
                                                    'and the deepest (1,700 m) lake in the world.'},
                                    {'type': 'mcq',
                                     'q': "Lake Baikal contains what percentage of the world's total unfrozen "
                                          'freshwater reserve?',
                                     'options': ['10 per cent', '15 per cent', '20 per cent', '25 per cent'],
                                     'answer': '20 per cent',
                                     'explanation': "Lake Baikal contains 20 per cent of the world's total unfrozen "
                                                    'freshwater reserve.'},
                                    {'type': 'mcq',
                                     'q': 'The five Great Lakes of the USA are Superior, Huron, Michigan, Ontario and:',
                                     'options': ['Chad', 'Titicaca', 'Erie', 'Victoria'],
                                     'answer': 'Erie',
                                     'explanation': 'The five Great Lakes of the USA—Superior, Huron, Michigan, '
                                                    'Ontario and Erie—are a group of five huge freshwater lakes '
                                                    'located between the United States and Canada.'},
                                    {'type': 'mcq',
                                     'q': 'Lake Victoria is the largest lake in:',
                                     'options': ['Asia', 'North America', 'South America', 'Africa'],
                                     'answer': 'Africa',
                                     'explanation': 'Lake Victoria is the largest lake in Africa and is the main '
                                                    'reservoir of the Nile River.'},
                                    {'type': 'mcq',
                                     'q': 'Chilika Lake is a _______ lake located in Odisha, India.',
                                     'options': ['Freshwater', 'Saltwater', 'Glacial', 'Man-made'],
                                     'answer': 'Saltwater',
                                     'explanation': 'Chilika Lake is a saltwater lake in the state of Odisha in the '
                                                    'eastern part of India.'},
                                    {'type': 'mcq',
                                     'q': 'A river is a stream of water which flows from high ground to low ground and '
                                          'finally to a:',
                                     'options': ['Mountain or desert', 'Lake or a sea', 'Plateau or plain', 'Glacier'],
                                     'answer': 'Lake or a sea',
                                     'explanation': 'A river is a stream of water which flows in a channel from high '
                                                    'ground to low ground and finally to a lake or a sea.'},
                                    {'type': 'mcq',
                                     'q': 'The place where a river originates is called its:',
                                     'options': ['Mouth', 'Source', 'Delta', 'Tributary'],
                                     'answer': 'Source',
                                     'explanation': 'The place where a river originates is called its source, which '
                                                    'normally lies in a hill or a mountain.'},
                                    {'type': 'mcq',
                                     'q': 'The Nile River in Africa is approximately how long?',
                                     'options': ['4,000 km', '5,500 km', '6,695 km', '8,000 km'],
                                     'answer': '6,695 km',
                                     'explanation': "The river Nile in Africa, 6,695 km in length, is the world's "
                                                    'longest river.'},
                                    {'type': 'mcq',
                                     'q': 'The Amazon River is the _______ longest river in the world.',
                                     'options': ['Longest', 'Second longest', 'Third longest', 'Fourth longest'],
                                     'answer': 'Second longest',
                                     'explanation': 'The Amazon River, 6,640 km in length, flows through South America '
                                                    'and is the second longest river in the world.'},
                                    {'type': 'mcq',
                                     'q': 'The upper course of a river generally lies in the:',
                                     'options': ['Plains', 'Deserts', 'Mountains', 'Coastal areas'],
                                     'answer': 'Mountains',
                                     'explanation': 'The upper course generally lies in the mountains where the land '
                                                    'is steep. The river flows very swiftly at this stage.'},
                                    {'type': 'mcq',
                                     'q': 'Water pollution is a type of pollution which occurs when:',
                                     'options': ['Air is contaminated',
                                                 'Harmful waste is discharged into water bodies',
                                                 'Soil is degraded',
                                                 'Noise disturbs aquatic life'],
                                     'answer': 'Harmful waste is discharged into water bodies',
                                     'explanation': 'Water pollution is a type of pollution which occurs when harmful '
                                                    'waste is discharged into water bodies.'},
                                    {'type': 'mcq',
                                     'q': 'Which of the following is a cause of water pollution?',
                                     'options': ['Deforestation only',
                                                 'Agricultural activities only',
                                                 'Oil spills',
                                                 'Mountain formation'],
                                     'answer': 'Oil spills',
                                     'explanation': 'Oil spills are one of the major causes of water pollution. When '
                                                    'crude oil gets leaked into the sea, it harms marine life.'},
                                    {'type': 'mcq',
                                     'q': 'The Ganga River has its source in the:',
                                     'options': ['Aravallis', 'Vindhyas', 'Himalayas', 'Western Ghats'],
                                     'answer': 'Himalayas',
                                     'explanation': 'The Ganga River is the most important river of India that has its '
                                                    'source in the Himalayas and flows through India and Bangladesh.'},
                                    {'type': 'mcq',
                                     'q': 'The Indus River was the cradle of the:',
                                     'options': ['Mesopotamian civilization',
                                                 'Egyptian civilization',
                                                 'Chinese civilization',
                                                 'Indus Valley civilization'],
                                     'answer': 'Indus Valley civilization',
                                     'explanation': 'The Indus River is a major south-flowing river in South Asia. It '
                                                    'was also the cradle of the Indus Valley civilization.'},
                                    {'type': 'mcq',
                                     'q': 'The mountain range in the middle of the Atlantic Ocean is called the:',
                                     'options': ['Ring of Fire', 'Mid-Atlantic Ridge', 'Ural Range', 'Mariana Range'],
                                     'answer': 'Mid-Atlantic Ridge',
                                     'explanation': 'In the middle of the Atlantic Ocean is a submerged mountain range '
                                                    'that has some high peaks or ridges that form islands. This '
                                                    'underwater mountain range is called the Mid-Atlantic Ridge.'},
                                    {'type': 'mcq',
                                     'q': 'Large lakes that are cut off from the open ocean are sometimes called:',
                                     'options': ['Coastal lakes', 'Inland seas', 'River lakes', 'Rift lakes'],
                                     'answer': 'Inland seas',
                                     'explanation': 'Large lakes are also called inland seas, for example, the Aral '
                                                    'Sea, the Black Sea and the Caspian Sea in Eurasia.'},
                                    {'type': 'mcq',
                                     'q': 'Surface run-off from farms carries _______ into water bodies, promoting '
                                          'algae growth.',
                                     'options': ['Sand and gravel',
                                                 'Organic and inorganic fertilizers',
                                                 'Salt and minerals',
                                                 'Thermal energy'],
                                     'answer': 'Organic and inorganic fertilizers',
                                     'explanation': 'Surface run-off from farms carries organic and inorganic '
                                                    'fertilizers into water bodies. This promotes the growth of algae, '
                                                    'which reduces the dissolved oxygen level in water.'},
                                    {'type': 'mcq',
                                     'q': 'The Palk Strait connects the Bay of Bengal with the:',
                                     'options': ['Arabian Sea', 'Red Sea', 'Gulf of Mannar', 'Indian Ocean'],
                                     'answer': 'Gulf of Mannar',
                                     'explanation': 'The Palk Strait connects the Bay of Bengal in the north-east with '
                                                    'the Gulf of Mannar in the south-west.'},
                                    {'type': 'mcq',
                                     'q': 'The Arctic Ocean lies within the Arctic Circle and therefore remains frozen '
                                          'for:',
                                     'options': ['The entire year',
                                                 'Most part of the year',
                                                 'Only winter months',
                                                 'Only summer months'],
                                     'answer': 'Most part of the year',
                                     'explanation': 'The Arctic Ocean is located mostly within the Arctic Circle and '
                                                    'therefore remains frozen for most part of the year.'},
                                    {'type': 'mcq',
                                     'q': 'Which of the following diseases is caused by water pollution from untreated '
                                          'waste?',
                                     'options': ['Malaria', 'Typhoid', 'Dengue', 'Tuberculosis'],
                                     'answer': 'Typhoid',
                                     'explanation': 'Untreated liquid waste discharged into rivers exposes people who '
                                                    'use river water to diseases such as typhoid, cholera and amoebic '
                                                    'dysentery.'},
                                    {'type': 'mcq',
                                     'q': 'The Yangtze River in China is the longest river in:',
                                     'options': ['The world', 'Africa', 'South America', 'Asia'],
                                     'answer': 'Asia',
                                     'explanation': 'The Yangtze River in China is the longest river in Asia and the '
                                                    'third-longest in the world.'},
                                    {'type': 'mcq',
                                     'q': 'Oceans moderate the climate of coastal areas through the process of:',
                                     'options': ['Condensation', 'Precipitation', 'Evaporation', 'Infiltration'],
                                     'answer': 'Evaporation',
                                     'explanation': 'Evaporation from ocean and sea surfaces transfers water vapour to '
                                                    'the atmosphere. This water vapour later falls as rain onto the '
                                                    'surface of the earth, moderating the climate of coastal areas.'},
                                    {'type': 'mcq',
                                     'q': 'The Huang He (Yellow River) is the main river of:',
                                     'options': ['Japan', 'India', 'Northern China', 'Russia'],
                                     'answer': 'Northern China',
                                     'explanation': 'Huang He, also known as the Yellow River, is the main river of '
                                                    'northern China, east central and eastern Asia.'},
                                    {'type': 'mcq',
                                     'q': 'How many oceans are there in the world?',
                                     'options': ['Three', 'Four', 'Five', 'Six'],
                                     'answer': 'Five',
                                     'explanation': 'Oceans are large expanses of water. There are five oceans in the '
                                                    'world—the Pacific, the Atlantic, the Indian, the Arctic and the '
                                                    'Southern Ocean.'},
                                    {'type': 'mcq',
                                     'q': 'Gulfs are more _______ than bays and also more enclosed.',
                                     'options': ['Shallow', 'Indented', 'Wide', 'Flat'],
                                     'answer': 'Indented',
                                     'explanation': 'Gulfs are more indented than bays and also more enclosed.'},
                                    {'type': 'tf',
                                     'q': 'The Pacific Ocean covers more than one-third of the globe.',
                                     'answer': 'True',
                                     'explanation': 'The Pacific Ocean is the largest ocean and covers over one third '
                                                    'of the globe.'},
                                    {'type': 'tf',
                                     'q': 'The Atlantic Ocean is the largest ocean in the world.',
                                     'answer': 'False',
                                     'explanation': 'The Pacific Ocean is the largest ocean in the world. The Atlantic '
                                                    'Ocean is the second largest.'},
                                    {'type': 'tf',
                                     'q': "The Mariana Trench is the deepest part of the earth's crust and lies in the "
                                          'Pacific Ocean.',
                                     'answer': 'True',
                                     'explanation': "The deepest part of the earth's crust—the Mariana Trench—lies in "
                                                    'this ocean (Pacific) near the Philippines.'},
                                    {'type': 'tf',
                                     'q': 'The Atlantic Ocean is almost half the size of the Pacific Ocean.',
                                     'answer': 'True',
                                     'explanation': 'The Atlantic Ocean is much smaller in size. It is almost half the '
                                                    'size of the Pacific Ocean.'},
                                    {'type': 'tf',
                                     'q': 'The Indian Ocean is named after India because India is located at the head '
                                          'of this ocean.',
                                     'answer': 'True',
                                     'explanation': 'India is located at the head of this ocean, which is why this '
                                                    'ocean has been named after this country.'},
                                    {'type': 'tf',
                                     'q': 'The Arctic Ocean is the largest and deepest ocean surrounding the North '
                                          'Pole.',
                                     'answer': 'False',
                                     'explanation': 'The Arctic Ocean is the smallest and shallowest ocean surrounding '
                                                    'the North Pole.'},
                                    {'type': 'tf',
                                     'q': 'A gulf has a wider opening than a bay.',
                                     'answer': 'False',
                                     'explanation': 'A bay has a wide indentation while a gulf has a deep indentation. '
                                                    'Gulfs are more indented than bays and also more enclosed.'},
                                    {'type': 'tf',
                                     'q': 'A strait is a narrow stretch of water that joins two large water bodies.',
                                     'answer': 'True',
                                     'explanation': 'A strait is a narrow stretch of water that joins two large water '
                                                    'bodies.'},
                                    {'type': 'tf',
                                     'q': 'Lake Baikal is the oldest and the deepest lake in the world.',
                                     'answer': 'True',
                                     'explanation': 'Lake Baikal is located in south-east Siberia and is the oldest '
                                                    'and the deepest (1,700 m) lake in the world.'},
                                    {'type': 'tf',
                                     'q': 'Lake Titicaca is the largest lake in South America.',
                                     'answer': 'True',
                                     'explanation': 'Lake Titicaca is a large, deep lake in the Andes Mountain '
                                                    'bordering Bolivia and Peru. It is the largest lake in South '
                                                    'America in terms of the volume of water and surface area.'},
                                    {'type': 'tf',
                                     'q': 'Lake Onega is the largest lake in Europe.',
                                     'answer': 'False',
                                     'explanation': 'Lake Onega is the second largest lake in Europe, situated in the '
                                                    'north-western part of the European portion of Russia.'},
                                    {'type': 'tf',
                                     'q': 'Rivers provide means of transport and thus facilitate trade.',
                                     'answer': 'True',
                                     'explanation': 'Rivers provide means of transport to carry humans and goods from '
                                                    'one place to another and thus facilitate trade.'},
                                    {'type': 'tf',
                                     'q': 'The Nile River flows from South America into the Mediterranean Sea.',
                                     'answer': 'False',
                                     'explanation': 'The Nile River, 6,695 km in length, is in Africa. It flows out '
                                                    'into the Mediterranean Sea.'},
                                    {'type': 'tf',
                                     'q': 'The upper course of a river flows swiftly because the land is steep.',
                                     'answer': 'True',
                                     'explanation': 'The upper course generally lies in the mountains where the land '
                                                    'is steep. The river flows very swiftly at this stage.'},
                                    {'type': 'tf',
                                     'q': "A river's mouth is the place where the river originates.",
                                     'answer': 'False',
                                     'explanation': 'The place where the river originates is called its source. The '
                                                    'mouth is the place where the river ends its journey, normally '
                                                    'where it enters the sea.'},
                                    {'type': 'tf',
                                     'q': 'Water pollution affects all forms of water resources on earth.',
                                     'answer': 'True',
                                     'explanation': 'Water pollution affects all forms of water resources on '
                                                    'earth—oceans, seas, rivers and lakes.'},
                                    {'type': 'tf',
                                     'q': 'Oil spills are harmless to marine birds and animals.',
                                     'answer': 'False',
                                     'explanation': 'Oil spills are very harmful for not only fish but also birds and '
                                                    'animals dependent on oceans and seas. The feathers of birds get '
                                                    'covered in oil and they end up getting poisoned while trying to '
                                                    'clean themselves.'},
                                    {'type': 'tf',
                                     'q': 'Chilika Lake in Odisha is a World Heritage Site.',
                                     'answer': 'True',
                                     'explanation': 'Chilika Lake is a World Heritage Site in Odisha.'},
                                    {'type': 'tf',
                                     'q': 'Plastic pollution makes up 80 per cent of all marine pollution.',
                                     'answer': 'True',
                                     'explanation': 'Plastic waste makes up 80 per cent of all marine pollution and '
                                                    'millions of tons of plastic is thrown in our ocean each year.'},
                                    {'type': 'tf',
                                     'q': 'The Ganga River is the most important river of Pakistan.',
                                     'answer': 'False',
                                     'explanation': 'The Ganga River is the most important river of India that has its '
                                                    'source in the Himalayas and flows through India and Bangladesh.'},
                                    {'type': 'tf',
                                     'q': 'Oceans are a source of food supply for many people around the world.',
                                     'answer': 'True',
                                     'explanation': 'Oceans are also a source of food supply for many people around '
                                                    'the world.'},
                                    {'type': 'tf',
                                     'q': 'The five Great Lakes of the USA comprise the largest body of fresh water on '
                                          'earth.',
                                     'answer': 'True',
                                     'explanation': 'The five Great Lakes comprise the largest body of fresh water on '
                                                    'earth.'},
                                    {'type': 'tf',
                                     'q': 'The Indus River flows northward through South Asia.',
                                     'answer': 'False',
                                     'explanation': 'The Indus River is a major south-flowing river in South Asia.'},
                                    {'type': 'tf',
                                     'q': 'Surface run-off from farms can cause growth of algae in water bodies.',
                                     'answer': 'True',
                                     'explanation': 'Surface run-off from farms carries organic and inorganic '
                                                    'fertilizers into water bodies. This promotes the growth of '
                                                    'algae.'},
                                    {'type': 'tf',
                                     'q': 'Lakes are bigger and deeper than ponds.',
                                     'answer': 'True',
                                     'explanation': 'Lakes are small bodies of water which are surrounded by land on '
                                                    'all sides. Lakes are bigger and deeper than ponds.'},
                                    {'type': 'tf',
                                     'q': 'Oceans facilitate international trade by providing oil resources.',
                                     'answer': 'False',
                                     'explanation': 'Oceans facilitate international trade by providing trade routes, '
                                                    'not by providing oil resources directly.'},
                                    {'type': 'tf',
                                     'q': 'The Amazon River is the longest river in the world.',
                                     'answer': 'False',
                                     'explanation': 'The Amazon River, 6,640 km in length, is the second longest river '
                                                    'in the world. The Nile is the longest at 6,695 km.'},
                                    {'type': 'tf',
                                     'q': 'The Ring of Fire refers to mountain ranges around the Pacific Ocean with '
                                          'maximum concentration of active volcanoes.',
                                     'answer': 'True',
                                     'explanation': 'The Pacific Ocean is bordered on its edges by new fold mountains '
                                                    'that have the maximum concentration of active volcanoes. These '
                                                    "mountain ranges have been termed the 'Ring of Fire'."},
                                    {'type': 'tf',
                                     'q': 'The Yangtze River is the longest river in Asia.',
                                     'answer': 'True',
                                     'explanation': 'The Yangtze River in China is the longest river in Asia and the '
                                                    'third-longest in the world.'},
                                    {'type': 'tf',
                                     'q': 'The Arabian Sea and the Bay of Bengal are two important parts of the Indian '
                                          'Ocean.',
                                     'answer': 'True',
                                     'explanation': 'The Arabian Sea and the Bay of Bengal are two important parts of '
                                                    'the Indian Ocean to its north.'},
                                    {'type': 'tf',
                                     'q': 'Lakes formed by dams are called man-made or artificial lakes.',
                                     'answer': 'True',
                                     'explanation': 'There are man-made lakes like reservoirs constructed along with '
                                                    'the dams to store water like the Bhakra Nangal dam.'},
                                    {'type': 'tf',
                                     'q': 'The Rhine River is one of the longest rivers of Asia.',
                                     'answer': 'False',
                                     'explanation': 'The Rhine River is one of the longest and most important rivers '
                                                    'of Europe. It flows through six European countries.'},
                                    {'type': 'tf',
                                     'q': 'Water is very important for sustaining life on earth.',
                                     'answer': 'True',
                                     'explanation': 'Water is very important for sustaining life on earth. All these '
                                                    'water bodies are of great importance for life on earth.'},
                                    {'type': 'tf',
                                     'q': 'The Huang He River is believed to be the cradle of Chinese civilization.',
                                     'answer': 'True',
                                     'explanation': 'The Huang He (Yellow River) is believed to be the cradle of the '
                                                    'Chinese civilization.'},
                                    {'type': 'tf',
                                     'q': "The Murray River is Australia's longest river and rises in the Australian "
                                          'Alps.',
                                     'answer': 'True',
                                     'explanation': "The Murray River is Australia's longest river and rises in the "
                                                    'Australian Alps.'},
                                    {'type': 'tf',
                                     'q': 'The Ob River, also called Obi, is an important river in western Siberia.',
                                     'answer': 'True',
                                     'explanation': 'The Ob River, also Obi, is an important river in western '
                                                    'Siberia.'},
                                    {'type': 'tf',
                                     'q': "The Danube River is Europe's longest river.",
                                     'answer': 'False',
                                     'explanation': "The Danube River is Europe's second-longest river, and also the "
                                                    'longest river in the European Union region. The Rhine is longer '
                                                    'than the Danube.'},
                                    {'type': 'tf',
                                     'q': 'The Saint Lawrence River flows roughly northeastward, connecting the Great '
                                          'Lakes with the Atlantic Ocean.',
                                     'answer': 'True',
                                     'explanation': 'The Saint Lawrence River flows in a roughly north-easterly '
                                                    'direction, connecting the Great Lakes with the Atlantic Ocean.'},
                                    {'type': 'tf',
                                     'q': 'The middle course of a river is in the mountains where the land is steep.',
                                     'answer': 'False',
                                     'explanation': 'The upper course lies in the mountains where the land is steep. '
                                                    'The middle course is when the river descends to the plains from '
                                                    'the mountains.'},
                                    {'type': 'tf',
                                     'q': 'Lakes are an important source of drinking water and are also used for '
                                          'fishing.',
                                     'answer': 'True',
                                     'explanation': 'Lakes are an important source of drinking water and water needed '
                                                    'for agricultural purposes. They are also important for leisure '
                                                    'activities such as fishing.'},
                                    {'type': 'subjective',
                                     'q': "Describe the Pacific Ocean. Why is it called the 'Ring of Fire'?",
                                     'sample': 'The Pacific Ocean is the largest ocean and covers over one-third of '
                                               'the globe. It is almost circular in shape and is bordered on its edges '
                                               'by new fold mountains that have the maximum concentration of active '
                                               "volcanoes. These mountain ranges have been termed the 'Ring of Fire'. "
                                               "The deepest part of the earth's crust — the Mariana Trench — lies in "
                                               'this ocean near the Philippines. Other significant trenches in this '
                                               'ocean are the Philippine (Mindanao) Trench, the Japan Trench and the '
                                               'Kuril Trench.'},
                                    {'type': 'subjective',
                                     'q': 'Differentiate between a gulf and a bay.',
                                     'sample': 'A gulf is a deep inlet of the sea almost surrounded by land, with a '
                                               'narrow mouth. A bay is an open, curving indentation made by the sea or '
                                               'a lake into a coastline. Gulfs are more indented than bays and also '
                                               'more enclosed. In terms of formation, bays are formed by continental '
                                               'drift and erosion of coastline, while gulfs are formed by the movement '
                                               "of the earth's plates. Examples of gulfs: Persian Gulf, Gulf of "
                                               'Mexico. Examples of bays: Bay of Bengal, Hudson Bay, Bay of Biscay.'},
                                    {'type': 'subjective',
                                     'q': 'What are the three stages of a river? Describe each briefly.',
                                     'sample': 'The route or course of a river has three stages: (1) Upper course — '
                                               'the river lies in the mountains where the land is steep. The river '
                                               'flows very swiftly at this stage, forming V-shaped valleys. (2) Middle '
                                               'course — after the river descends to the plains from the mountains. '
                                               'The speed of flow decreases considerably as it flows through areas '
                                               'with a gentler slope. The river deposits sediments and forms meanders. '
                                               '(3) Lower course — the river is near its mouth where the slope is '
                                               'negligible and therefore its flow has nearly halted. The river forms '
                                               'deltas as it meets the sea.'},
                                    {'type': 'subjective',
                                     'q': 'What is water pollution? Name any three causes of water pollution.',
                                     'sample': 'Water pollution is a type of pollution which occurs when harmful waste '
                                               'is discharged into water bodies. It affects all forms of water '
                                               'resources on earth — oceans, seas, rivers and lakes. Three causes of '
                                               'water pollution: (1) Liquid waste from thermal power plants — '
                                               'increases dissolved oxygen content leading to sudden rise in microbe '
                                               'population, reducing oxygen for other organisms. (2) Surface run-off '
                                               'from farms — carries organic and inorganic fertilizers into water '
                                               'bodies promoting algae growth and reducing oxygen levels. (3) '
                                               'Untreated liquid waste — waste from kitchens and toilets discharged '
                                               'into rivers exposes people to diseases like typhoid, cholera and '
                                               'amoebic dysentery.'},
                                    {'type': 'subjective',
                                     'q': 'What are the importance of rivers? Mention any four points.',
                                     'sample': 'Rivers are extremely important for the following reasons: (1) River '
                                               'valleys and plains provide fertile soils and crops grow in plenty in '
                                               'and around the region. (2) River water is used for human and animal '
                                               'consumption. Rivers provide abundant water supply to support large '
                                               'settlements. (3) Rivers provide means of transport to carry humans and '
                                               'goods from one place to another and thus facilitate trade. (4) River '
                                               'water is an important source of energy — it is used to power '
                                               'hydroelectric plants and helps in generation of electricity. (5) '
                                               'Rivers also provide means for recreational activities.'},
                                    {'type': 'subjective',
                                     'q': 'Describe Lake Baikal. Why is it significant?',
                                     'sample': 'Lake Baikal is located in south-east Siberia and is the oldest and the '
                                               'deepest lake in the world (1,700 m deep). It is significant because it '
                                               "contains 20 per cent of the world's total unfrozen freshwater reserve. "
                                               'Lake Baikal is considered a UNESCO World Heritage Site. Its immense '
                                               'depth and age make it home to thousands of species of plants and '
                                               'animals, many of which are found nowhere else on earth. It is a '
                                               'crucial freshwater reservoir for the world.'},
                                    {'type': 'subjective',
                                     'q': 'Describe the importance of oceans to human beings.',
                                     'sample': 'Oceans are extremely important in the following ways: (1) They are '
                                               'great storehouses of oil and mineral resources. (2) They support a '
                                               'large variety of aquatic life, providing food supply for millions of '
                                               'people. (3) They facilitate international trade by providing trade '
                                               'routes. (4) They moderate the climate of coastal areas — evaporation '
                                               'from ocean surfaces transfers water vapour to the atmosphere which '
                                               'falls as rain. (5) They possess enormous energy in the form of tidal '
                                               'waves which can be used to generate electricity. (6) The ocean floor '
                                               'contains valuable mineral deposits.'},
                                    {'type': 'subjective',
                                     'q': 'How do oil spills cause water pollution? What are the effects on marine '
                                          'life?',
                                     'sample': 'An oil spill occurs when crude oil, while being transported from one '
                                               'country to another, gets leaked into the sea. It can happen due to '
                                               'accidents or natural hazards like hurricanes, which cause oil tankers '
                                               'to turn upside down, causing the oil they were carrying to spill. Oil '
                                               'spills are very harmful for marine life — they are harmful not only '
                                               'for fish but also for birds and animals dependent on oceans and seas. '
                                               'For example, the feathers of birds get covered in oil and they end up '
                                               'getting poisoned while trying to clean themselves. Oil creates a layer '
                                               'on the water surface that blocks sunlight and oxygen from reaching '
                                               'underwater organisms.'},
                                    {'type': 'subjective',
                                     'q': 'What is a strait? Give two examples of important straits and describe what '
                                          'they connect.',
                                     'sample': 'A strait is a narrow stretch of water that joins two large water '
                                               'bodies. Examples: (1) Strait of Gibraltar — connects the Mediterranean '
                                               'Sea to the North Atlantic Ocean. It separates Europe from Africa. (2) '
                                               'Palk Strait — connects the Bay of Bengal in the north-east with the '
                                               'Gulf of Mannar in the south-west. It lies between India and Sri '
                                               'Lanka.'},
                                    {'type': 'subjective',
                                     'q': 'Name the five oceans of the world and give one distinguishing feature of '
                                          'each.',
                                     'sample': 'The five oceans and their distinguishing features are: (1) Pacific '
                                               'Ocean — the largest ocean, covers over one-third of the globe, almost '
                                               'circular in shape; contains the Mariana Trench (deepest point on '
                                               "earth). (2) Atlantic Ocean — shaped like letter 'S'; the busiest ocean "
                                               'in the world for trade and transport; contains the Mid-Atlantic Ridge. '
                                               '(3) Indian Ocean — roughly triangular in shape; India is located at '
                                               'its head; has the Arabian Sea and Bay of Bengal as parts. (4) Arctic '
                                               'Ocean — northernmost ocean; lies within Arctic Circle; smallest and '
                                               'shallowest; remains frozen for most of the year. (5) Southern '
                                               '(Antarctic) Ocean — formed by the merging of Pacific, Atlantic and '
                                               'Indian oceans; surrounds Antarctica; fourth largest ocean.'},
                                    {'type': 'subjective',
                                     'q': 'What are the major causes of water pollution and how can it be prevented?',
                                     'sample': 'Major causes of water pollution: (1) Liquid waste from thermal power '
                                               'plants increasing dissolved oxygen causing microbe growth. (2) Surface '
                                               'run-off from farms carrying fertilizers promoting algae growth. (3) '
                                               'Untreated liquid waste from kitchens and toilets discharged into '
                                               'rivers. (4) Oil spills from tankers. Prevention measures: (1) '
                                               'Industries must treat waste before discharging it into water bodies. '
                                               '(2) Farmers should use natural/organic fertilizers and avoid overuse '
                                               'of chemicals. (3) Sewage treatment plants should treat domestic waste '
                                               'before releasing it. (4) Stricter regulations and safety measures for '
                                               'oil transportation. (5) Individual awareness about not throwing '
                                               'plastic and garbage into water bodies.'},
                                    {'type': 'subjective',
                                     'q': 'Describe the Indus Valley civilization and its connection to a river.',
                                     'sample': 'The Indus River is a major south-flowing river in South Asia. It was '
                                               "the cradle of the Indus Valley civilization, one of the world's "
                                               'earliest civilizations. The civilization flourished on the banks of '
                                               'the Indus River around 2500 BCE, with cities like Harappa and '
                                               'Mohenjo-daro. The fertile soil of the river valley allowed agriculture '
                                               'to develop, and the river provided water for drinking and irrigation. '
                                               'Similarly, the Huang He (Yellow River) was the cradle of the Chinese '
                                               'civilization, and the Nile River supported the Egyptian civilization — '
                                               'showing the deep connection between rivers and the growth of early '
                                               'human societies.'},
                                    {'type': 'subjective',
                                     'q': 'Why is the Atlantic Ocean called the busiest ocean?',
                                     'sample': 'The Atlantic Ocean is called the busiest ocean in the world because '
                                               'many trade and transportation routes pass across it. On its east coast '
                                               'lie Europe and Africa while on its western border lie the two '
                                               'Americas. This strategic location between major continents makes it an '
                                               'important route for cargo ships, passenger ships, and commercial '
                                               'vessels carrying goods and people between Europe, the Americas, and '
                                               'Africa. The total length of its coastline is longer than the combined '
                                               'coastlines of the Pacific and the Indian oceans, giving it numerous '
                                               'ports and harbours that facilitate trade.'},
                                    {'type': 'subjective',
                                     'q': 'Describe the importance of the five Great Lakes of North America.',
                                     'sample': 'The five Great Lakes of the USA — Superior, Huron, Michigan, Ontario '
                                               'and Erie — are a group of five huge freshwater lakes located between '
                                               'the United States and Canada. They comprise the largest body of fresh '
                                               'water on earth. Around 34 million people in the United States and '
                                               'Canada and more than 3,500 species of plants and animals inhabit the '
                                               'Great Lakes basin. These lakes serve as popular recreation spots for '
                                               'boating, fishing and other recreational activities. They are also an '
                                               'important channel for the transportation of goods between the two '
                                               'countries and support significant industries in the region.'},
                                    {'type': 'subjective',
                                     'q': 'What is surface run-off and how does it contribute to water pollution?',
                                     'sample': 'Surface run-off is water from rain, melting snow, or other sources '
                                               'that flows over land and is a part of the water cycle. It contributes '
                                               'to water pollution in the following way: Surface run-off from farms '
                                               'carries organic and inorganic fertilizers into water bodies. This '
                                               'promotes the growth of algae, which reduces the dissolved oxygen level '
                                               'in water. Other living organisms in water bodies, including fish, '
                                               'cannot survive in such conditions as they are deprived of oxygen. The '
                                               'run-off may also carry pesticides and other chemicals that are toxic '
                                               'to aquatic life, further degrading water quality.'},
                                    {'type': 'subjective',
                                     'q': 'Give three ways in which we can save water in our daily lives.',
                                     'sample': 'Three ways to save water in our daily lives: (1) At home — turn off '
                                               'taps while brushing teeth, take shorter showers, fix leaking taps '
                                               'promptly, use a bucket instead of a shower for bathing. Collect '
                                               'rainwater for watering plants. (2) At school — report leaking taps and '
                                               'pipes to authorities, use water from drinking fountains carefully '
                                               'without wastage, organize awareness campaigns about water '
                                               'conservation. (3) In the neighbourhood — avoid washing vehicles with '
                                               'running water, use recycled water for gardens, report illegal '
                                               'discharge of waste into water bodies to authorities, participate in '
                                               'river and lake clean-up drives.'},
                                    {'type': 'subjective',
                                     'q': 'What is the Huang He (Yellow River)? Why is it significant?',
                                     'sample': 'The Huang He, also known as the Yellow River, is the main river of '
                                               'northern China, east central and eastern Asia. It is believed to be '
                                               'the cradle of the Chinese civilization, meaning that one of the '
                                               "world's oldest civilizations developed along its fertile banks. The "
                                               "river gets its name 'Yellow River' from the large amounts of "
                                               'yellow-coloured silt it carries. The Yangtze River in China is the '
                                               'longest river in Asia, while the Huang He is another major river of '
                                               "China. Both rivers have been central to China's agricultural "
                                               'development, culture, and history for thousands of years.'},
                                    {'type': 'subjective',
                                     'q': 'What are lakes? How are they formed? Give three examples of important '
                                          'lakes.',
                                     'sample': 'Lakes are small bodies of water which are surrounded by land on all '
                                               'sides. Lakes are bigger and deeper than ponds. They can be natural or '
                                               'man-made. Man-made lakes like reservoirs are constructed along with '
                                               'dams to store water. Natural lakes can be formed by glacial activity, '
                                               'tectonic movements creating depressions, volcanic craters, or river '
                                               'meanders getting cut off. Three important lakes: (1) Lake Baikal '
                                               '(Siberia) — oldest and deepest lake in the world, contains 20% of '
                                               "world's unfrozen freshwater. (2) Lake Victoria (Africa) — largest lake "
                                               'in Africa, main reservoir of the Nile River. (3) Lake Titicaca (South '
                                               'America) — large, deep lake in the Andes, largest lake in South '
                                               'America.'},
                                    {'type': 'subjective',
                                     'q': 'How does the plastic menace affect marine life? What can be done to reduce '
                                          'it?',
                                     'sample': 'Plastic waste makes up 80 per cent of all marine pollution. Millions '
                                               'of tons of plastic are thrown in our oceans each year. Plastic takes '
                                               'thousands of years to degrade, and even then it becomes microplastics. '
                                               'The effects on marine life include: animals mistaking plastic for food '
                                               'and ingesting it, leading to blockages in their digestive systems; '
                                               'entanglement in plastic waste causing injury or drowning; chemical '
                                               'contamination from plastic affecting the food chain. Solutions '
                                               'include: banning single-use plastics, improving waste management '
                                               'systems, recycling plastic, organizing beach and ocean clean-up '
                                               'drives, using biodegradable alternatives, and creating public '
                                               'awareness about the dangers of plastic pollution.'},
                                    {'type': 'subjective',
                                     'q': 'How is Chilika Lake important for biodiversity in India?',
                                     'sample': 'Chilika Lake is a saltwater lake in the state of Odisha in the eastern '
                                               'part of India. It is a World Heritage Site. In winter, it becomes the '
                                               'largest ground for migratory birds in the Indian subcontinent, and is '
                                               'home to a number of threatened species of plants and animals. The lake '
                                               'is spread across the districts of Puri, Khordha and Ganjam. Many '
                                               'islands are present in the lagoon, including Krusnaprasad, Nalaban, '
                                               'Kalijai, Somolo and Birds Islands. The fishery resources of the lake '
                                               'provide livelihood to more than 2 lakh fishermen. The lake also has '
                                               'rich cultural heritage.'}],
 'Chapter 5 — Types of Agriculture': [{'type': 'mcq',
                                       'q': "The word 'agriculture' is derived from two Latin words meaning:",
                                       'options': ['Water and field',
                                                   'Field and to cultivate',
                                                   'Soil and plant',
                                                   'Food and grow'],
                                       'answer': 'Field and to cultivate',
                                       'explanation': "The word 'agriculture' is derived from two Latin words—'ager', "
                                                      "meaning 'field', and 'cultura', meaning 'to cultivate'."},
                                      {'type': 'mcq',
                                       'q': 'Which of the following is NOT an agricultural activity?',
                                       'options': ['Dairy farming',
                                                   'Rearing animals for meat',
                                                   'Pottery making',
                                                   'Rearing fish in ponds'],
                                       'answer': 'Pottery making',
                                       'explanation': 'Agriculture includes growing different types of crops, rearing '
                                                      'animals for dairy and meat, poultry farming and rearing fish in '
                                                      'ponds. Pottery making is not an agricultural activity.'},
                                      {'type': 'mcq',
                                       'q': 'Subsistence farming is practised by farmers who:',
                                       'options': ['Own large pieces of land',
                                                   'Own small pieces of land',
                                                   'Use heavy machinery',
                                                   'Grow crops for export'],
                                       'answer': 'Own small pieces of land',
                                       'explanation': 'Subsistence farming is practised by farmers who own small '
                                                      'pieces of land. Such farmers grow just enough crops to meet '
                                                      'their needs and those of their families.'},
                                      {'type': 'mcq',
                                       'q': 'In subsistence farming, farmers depend on which water source?',
                                       'options': ['Irrigation canals only',
                                                   'Underground water',
                                                   'Monsoon rains',
                                                   'Rivers only'],
                                       'answer': 'Monsoon rains',
                                       'explanation': 'Subsistence farmers depend on the monsoon rains for water for '
                                                      'the crops.'},
                                      {'type': 'mcq',
                                       'q': 'Which of the following is a feature of intensive farming?',
                                       'options': ['Large plot of land',
                                                   'Low yielding seeds',
                                                   'Hybrid or mixed breed seeds',
                                                   'No use of fertilizers'],
                                       'answer': 'Hybrid or mixed breed seeds',
                                       'explanation': 'In intensive farming, the farmer has a small plot of land on '
                                                      'which they use hybrid or mixed breed seeds, which are expensive '
                                                      'but high yielding.'},
                                      {'type': 'mcq',
                                       'q': 'Intensive farming does NOT involve which of the following?',
                                       'options': ['High yielding seeds',
                                                   'Chemical fertilizers',
                                                   'Large plot of land',
                                                   'Pesticides'],
                                       'answer': 'Large plot of land',
                                       'explanation': 'Intensive farming is done on small plots of land. Large plots '
                                                      'are a feature of extensive farming.'},
                                      {'type': 'mcq',
                                       'q': 'Night soil, used in intensive farming, is:',
                                       'options': ['Soil collected at night',
                                                   'Solid waste material passed from the body, used as fertilizer',
                                                   'A type of clay soil',
                                                   'Volcanic ash soil'],
                                       'answer': 'Solid waste material passed from the body, used as fertilizer',
                                       'explanation': 'Night soil is solid waste material, that is passed from the '
                                                      'body, is collected at night and is used as a fertilizer.'},
                                      {'type': 'mcq',
                                       'q': 'Countries like China, Korea and Japan practise which type of farming?',
                                       'options': ['Extensive farming',
                                                   'Intensive farming',
                                                   'Shifting cultivation',
                                                   'Commercial farming'],
                                       'answer': 'Intensive farming',
                                       'explanation': 'Other countries that follow intensive farming are China, Korea '
                                                      'and Japan.'},
                                      {'type': 'mcq',
                                       'q': 'Extensive farming is practised in areas of:',
                                       'options': ['High population and scarce land',
                                                   'Low population and plenty of land',
                                                   'Coastal areas with rivers',
                                                   'Mountainous regions'],
                                       'answer': 'Low population and plenty of land',
                                       'explanation': 'Extensive farming is practised in areas of low population and '
                                                      'where plenty of land is available for cultivation.'},
                                      {'type': 'mcq',
                                       'q': 'The combine harvester is used in which type of farming?',
                                       'options': ['Subsistence farming',
                                                   'Intensive farming',
                                                   'Extensive farming',
                                                   'Shifting cultivation'],
                                       'answer': 'Extensive farming',
                                       'explanation': 'In extensive farming, most of the work is done by using large '
                                                      'machines such as the combine harvester.'},
                                      {'type': 'mcq',
                                       'q': 'The average farm size required for extensive farming is around:',
                                       'options': ['50–100 acres',
                                                   '100–500 acres',
                                                   '1000–2000 acres',
                                                   '5000–10000 acres'],
                                       'answer': '1000–2000 acres',
                                       'explanation': 'The average required size of the farm for extensive farming is '
                                                      'around 1000–2000 acres.'},
                                      {'type': 'mcq',
                                       'q': 'Extensive farming is practised in which Indian states?',
                                       'options': ['Kerala and Tamil Nadu',
                                                   'Punjab and Haryana',
                                                   'Rajasthan and Goa',
                                                   'Assam and West Bengal'],
                                       'answer': 'Punjab and Haryana',
                                       'explanation': 'In India, extensive farming is practised in the states of '
                                                      'Punjab and Haryana, and parts of Uttar Pradesh.'},
                                      {'type': 'mcq',
                                       'q': 'Shifting cultivation is also known as:',
                                       'options': ['Plantation farming',
                                                   'Slash and burn cultivation',
                                                   'Commercial farming',
                                                   'Intensive farming'],
                                       'answer': 'Slash and burn cultivation',
                                       'explanation': "Shifting cultivation is also known as 'slash and burn' or "
                                                      "'shifting cultivation'."},
                                      {'type': 'mcq',
                                       'q': 'In India, shifting cultivation is known as:',
                                       'options': ['Roca', 'Milpa', 'Jhumming', 'Lading'],
                                       'answer': 'Jhumming',
                                       'explanation': "In India, shifting cultivation is known as 'Jhumming', in "
                                                      "Indonesia 'Lading', 'Roca' in the Amazon Basin and 'Milpa' in "
                                                      'Central America.'},
                                      {'type': 'mcq',
                                       'q': 'Shifting cultivation is practised in which Indian state?',
                                       'options': ['Bihar', 'Rajasthan', 'Arunachal Pradesh', 'Madhya Pradesh'],
                                       'answer': 'Arunachal Pradesh',
                                       'explanation': 'In India, this type of cultivation is practiced in the '
                                                      'north-east, particularly in Arunachal Pradesh, Mizoram, '
                                                      'Nagaland, Manipur and in Chhattisgarh and Jharkhand in central '
                                                      'India.'},
                                      {'type': 'mcq',
                                       'q': 'In shifting cultivation, the tool used to cut down trees and bushes is '
                                            'called a:',
                                       'options': ['Sickle', 'Scythe', 'Machete', 'Plough'],
                                       'answer': 'Machete',
                                       'explanation': 'The tool they use to cut down tree and bushes is a long sharp '
                                                      'knife called a machete.'},
                                      {'type': 'mcq',
                                       'q': 'Commercial farming is also known as:',
                                       'options': ['Plantation farming',
                                                   'Agribusiness',
                                                   'Mixed farming',
                                                   'Intensive farming'],
                                       'answer': 'Agribusiness',
                                       'explanation': 'Commercial farming is also known as agribusiness.'},
                                      {'type': 'mcq',
                                       'q': 'Commercial farming uses which of the following?',
                                       'options': ['Only organic fertilizers',
                                                   'HYV seeds, chemical fertilizers and modern irrigation techniques',
                                                   'Only rain-fed water',
                                                   'Traditional seeds only'],
                                       'answer': 'HYV seeds, chemical fertilizers and modern irrigation techniques',
                                       'explanation': 'Commercial farming involves the use of HYV (High Yielding '
                                                      'Variety) of seeds, chemical fertilizers, pesticides, '
                                                      'insecticides, modern irrigation techniques and cold storage.'},
                                      {'type': 'mcq',
                                       'q': 'A plantation is a very large area of agricultural land where:',
                                       'options': ['Food crops are grown for family use',
                                                   'Cash crops are grown on a very large scale',
                                                   'Animals are reared',
                                                   'Subsistence farming is practised'],
                                       'answer': 'Cash crops are grown on a very large scale',
                                       'explanation': 'A plantation is a very large area of agricultural land where '
                                                      'cash crops are grown on a very large scale.'},
                                      {'type': 'mcq',
                                       'q': 'Tea is mainly grown in which type of farming?',
                                       'options': ['Subsistence farming',
                                                   'Extensive farming',
                                                   'Plantation farming',
                                                   'Shifting cultivation'],
                                       'answer': 'Plantation farming',
                                       'explanation': 'Tea, coffee and rubber are some examples of plantation crops. '
                                                      'In India, tea is mainly grown in the north and coffee in the '
                                                      'south.'},
                                      {'type': 'mcq',
                                       'q': 'Plantation farming is popular in which Asian countries?',
                                       'options': ['China and Japan',
                                                   'Sri Lanka and Malaysia',
                                                   'India and Pakistan',
                                                   'Indonesia and Philippines'],
                                       'answer': 'Sri Lanka and Malaysia',
                                       'explanation': 'Plantation farming is popular in Sri Lanka, Malaysia, Brazil, '
                                                      'Indonesia.'},
                                      {'type': 'mcq',
                                       'q': 'Mixed farming involves:',
                                       'options': ['Growing only one type of crop',
                                                   'Rearing animals only',
                                                   'Growing crops and rearing animals on the same area',
                                                   'Using only traditional methods'],
                                       'answer': 'Growing crops and rearing animals on the same area',
                                       'explanation': 'In mixed farming, crops are grown and animals are reared on the '
                                                      'same area.'},
                                      {'type': 'mcq',
                                       'q': 'In colder areas, mixed farming includes rearing of:',
                                       'options': ['Chickens and ducks',
                                                   'Sheep for wool',
                                                   'Pigs and goats',
                                                   'Cows only'],
                                       'answer': 'Sheep for wool',
                                       'explanation': 'In the colder areas, sheep is also reared for the same purpose '
                                                      '(wool/milk and meat).'},
                                      {'type': 'mcq',
                                       'q': 'Mixed farming is NOT popular in which of the following?',
                                       'options': ['USA', 'Europe', 'Australia', 'India'],
                                       'answer': 'India',
                                       'explanation': 'Unlike the USA, Europe, Australia and New Zealand, mixed '
                                                      'farming is still not popular in India.'},
                                      {'type': 'mcq',
                                       'q': 'Multiple cropping is the growing of _______ on the same piece of land in '
                                            'a single year.',
                                       'options': ['One crop',
                                                   'Two or more crops',
                                                   'Only cash crops',
                                                   'Only food crops'],
                                       'answer': 'Two or more crops',
                                       'explanation': 'Multiple cropping is the growing of two or more crops on the '
                                                      'same piece of land in a single year.'},
                                      {'type': 'mcq',
                                       'q': 'The process of growing different crops on the same piece of land in '
                                            'successive years is called:',
                                       'options': ['Double cropping',
                                                   'Multiple cropping',
                                                   'Crop rotation',
                                                   'Mixed cropping'],
                                       'answer': 'Crop rotation',
                                       'explanation': 'Crop rotation is the growing of different crops on the same '
                                                      'piece of land in successive years to protect and enhance soil '
                                                      'fertility.'},
                                      {'type': 'mcq',
                                       'q': 'In India, almost what percentage of the population is engaged in '
                                            'agriculture?',
                                       'options': ['About 20 per cent',
                                                   'About 30 per cent',
                                                   'About 45 per cent',
                                                   'About 70 per cent'],
                                       'answer': 'About 45 per cent',
                                       'explanation': "Almost half of India's population (around 45 per cent) is "
                                                      'engaged in agriculture.'},
                                      {'type': 'mcq',
                                       'q': "The contribution of agriculture to India's total income is about:",
                                       'options': ['One fifth (18 per cent)',
                                                   'One third (33 per cent)',
                                                   'One half (50 per cent)',
                                                   'One tenth (10 per cent)'],
                                       'answer': 'One fifth (18 per cent)',
                                       'explanation': "However, the contribution of agriculture to India's income is "
                                                      'only about one fifth (18 per cent) of the total income.'},
                                      {'type': 'mcq',
                                       'q': 'Subsistence farming uses which type of fertilizer?',
                                       'options': ['Only chemical fertilizers',
                                                   'Organic or natural fertilizers',
                                                   'No fertilizer at all',
                                                   'Only synthetic fertilizers'],
                                       'answer': 'Organic or natural fertilizers',
                                       'explanation': 'Subsistence farmers use organic or natural fertilizers such as '
                                                      'cow dung, animal droppings and dead and dried plants.'},
                                      {'type': 'mcq',
                                       'q': 'The White Revolution in India was related to:',
                                       'options': ['Cotton production',
                                                   'Wheat production',
                                                   'Milk production',
                                                   'Sugar production'],
                                       'answer': 'Milk production',
                                       'explanation': "The programme under Dr Verghese Kurien was called 'Operation "
                                                      "Flood' or 'White Revolution', inspired by the white colour of "
                                                      'milk, aimed at making India one of the largest producers of '
                                                      'milk.'},
                                      {'type': 'mcq',
                                       'q': 'Shifting cultivation disturbs the ecology by:',
                                       'options': ['Improving soil fertility',
                                                   'Displacing wildlife and birds and causing soil erosion',
                                                   'Increasing forest cover',
                                                   'Storing water in soil'],
                                       'answer': 'Displacing wildlife and birds and causing soil erosion',
                                       'explanation': 'This type of cultivation disturbs the ecology of the area, '
                                                      'displaces wildlife and birds from their natural habitats, and '
                                                      'contributes to soil erosion, especially during the monsoon '
                                                      'season.'},
                                      {'type': 'mcq',
                                       'q': 'Which of the following is a disadvantage of intensive farming?',
                                       'options': ['High yield',
                                                   'Use of pesticides kills useful insects and worms',
                                                   'Multiple cropping possible',
                                                   'Small land needed'],
                                       'answer': 'Use of pesticides kills useful insects and worms',
                                       'explanation': 'The heavy use of fertilizers and pesticides leads to the death '
                                                      'of useful insects—it kills insects and worms that help the soil '
                                                      'become rich in nutrients.'},
                                      {'type': 'mcq',
                                       'q': 'In which type of farming is cold storage used?',
                                       'options': ['Subsistence farming',
                                                   'Intensive farming',
                                                   'Commercial farming',
                                                   'Shifting cultivation'],
                                       'answer': 'Commercial farming',
                                       'explanation': 'Commercial farming involves the use of HYV seeds, chemical '
                                                      'fertilizers, pesticides, insecticides, modern irrigation '
                                                      'techniques and cold storage.'},
                                      {'type': 'mcq',
                                       'q': 'Which type of farming provides an opportunity for good ecological and '
                                            'environmental balance?',
                                       'options': ['Intensive farming',
                                                   'Extensive farming',
                                                   'Shifting cultivation',
                                                   'Mixed farming'],
                                       'answer': 'Mixed farming',
                                       'explanation': 'Mixed farming provides an opportunity for a good ecological and '
                                                      'environmental balance securing the habitats of birds, wildlife '
                                                      'and insects.'},
                                      {'type': 'mcq',
                                       'q': 'Temperate grasslands of the world are known for which type of farming?',
                                       'options': ['Intensive farming',
                                                   'Subsistence farming',
                                                   'Extensive farming',
                                                   'Plantation farming'],
                                       'answer': 'Extensive farming',
                                       'explanation': 'The temperate grasslands of the world are known for extensive '
                                                      'farming.'},
                                      {'type': 'mcq',
                                       'q': 'Coffee is grown under which type of farming?',
                                       'options': ['Mixed farming',
                                                   'Subsistence farming',
                                                   'Plantation farming',
                                                   'Extensive farming'],
                                       'answer': 'Plantation farming',
                                       'explanation': 'Tea, coffee and rubber are some examples of plantation crops.'},
                                      {'type': 'mcq',
                                       'q': 'Agriculture traces its roots in India to the:',
                                       'options': ['Mughal Empire',
                                                   'British India',
                                                   'Indus Valley civilization',
                                                   'Mauryan Empire'],
                                       'answer': 'Indus Valley civilization',
                                       'explanation': 'Agriculture in India traces its roots to the Indus Valley '
                                                      'civilization, initially cultivating rice and cotton.'},
                                      {'type': 'mcq',
                                       'q': 'Intensive farming is practiced in places where agricultural land is:',
                                       'options': ['Abundant', 'Infertile', 'Scarce', 'Sandy'],
                                       'answer': 'Scarce',
                                       'explanation': 'Intensive farming is practiced in places where agricultural '
                                                      'land is scarce such as the coastal areas, the Ganga Plain and '
                                                      'the Brahmaputra Valley in Assam in India.'},
                                      {'type': 'mcq',
                                       'q': 'Which of the following best describes the purpose of shifting '
                                            'cultivation?',
                                       'options': ['To grow crops on the same land year after year',
                                                   'To cut and burn forest land to grow crops temporarily before '
                                                   'moving on',
                                                   'To use chemical fertilizers to improve yield',
                                                   'To grow cash crops for export'],
                                       'answer': 'To cut and burn forest land to grow crops temporarily before moving '
                                                 'on',
                                       'explanation': 'In shifting cultivation, a small patch of forests is cut, the '
                                                      'debris is burned and the land is used to grow crops. When the '
                                                      'fertility of the land is reduced, farmers move on to the next '
                                                      'patch of forest land.'},
                                      {'type': 'mcq',
                                       'q': 'India ranks second in the world in which agricultural produce?',
                                       'options': ['Rice, wheat and rubber',
                                                   'Cotton, jute and rice production overall',
                                                   'Only jute',
                                                   'Only rubber'],
                                       'answer': 'Cotton, jute and rice production overall',
                                       'explanation': 'India excels as the largest cotton and jute producer and ranks '
                                                      'second in rice, wheat and sugarcane.'},
                                      {'type': 'tf',
                                       'q': 'Agriculture refers to the cultivation of a field.',
                                       'answer': 'True',
                                       'explanation': "Agriculture is derived from Latin words meaning 'field' and 'to "
                                                      "cultivate'. Hence, agriculture refers to the cultivation of a "
                                                      'field.'},
                                      {'type': 'tf',
                                       'q': 'In subsistence farming, the surplus produce is sold in the market for '
                                            'profit.',
                                       'answer': 'False',
                                       'explanation': 'In subsistence farming, nearly all of the crops raised are used '
                                                      "to maintain the farmer and the farmer's family, leaving little, "
                                                      'if any, surplus for sale or trade.'},
                                      {'type': 'tf',
                                       'q': 'Subsistence farmers use chemical fertilizers to increase yield.',
                                       'answer': 'False',
                                       'explanation': 'Subsistence farmers use organic or natural fertilizers such as '
                                                      'cow dung, animal droppings and dead and dried plants.'},
                                      {'type': 'tf',
                                       'q': 'Intensive farming requires a large plot of land.',
                                       'answer': 'False',
                                       'explanation': 'In intensive farming, the farmer has a small plot of land. '
                                                      'Large plots are a feature of extensive farming.'},
                                      {'type': 'tf',
                                       'q': 'Intensive farming involves the use of skilled labour.',
                                       'answer': 'True',
                                       'explanation': 'Intensive farming involves the use of skilled labour which adds '
                                                      'to the cost of production.'},
                                      {'type': 'tf',
                                       'q': 'Use of pesticides in intensive farming kills useful insects and worms in '
                                            'the soil.',
                                       'answer': 'True',
                                       'explanation': 'The heavy use of fertilizers and pesticides leads to the death '
                                                      'of useful insects — it kills insects and worms that help the '
                                                      'soil become rich in nutrients.'},
                                      {'type': 'tf',
                                       'q': 'Extensive farming is practised in densely populated areas.',
                                       'answer': 'False',
                                       'explanation': 'Extensive farming is practised in areas of low population and '
                                                      'where plenty of land is available for cultivation.'},
                                      {'type': 'tf',
                                       'q': 'Extensive farming is practiced in the USA, Canada and Australia.',
                                       'answer': 'True',
                                       'explanation': 'Extensive farming is practised in countries like the USA, '
                                                      'Canada and Australia.'},
                                      {'type': 'tf',
                                       'q': 'In shifting cultivation, burnt plant ashes make the soil very fertile.',
                                       'answer': 'True',
                                       'explanation': 'After the farmers burn the biomass, they sow the seeds. Due to '
                                                      'the ashes of the burnt plants, the soil becomes very fertile.'},
                                      {'type': 'tf',
                                       'q': 'Shifting cultivation is environmentally friendly and does not damage '
                                            'forests.',
                                       'answer': 'False',
                                       'explanation': 'Shifting cultivation disturbs the ecology of the area, '
                                                      'displaces wildlife and birds from their natural habitats, and '
                                                      'contributes to soil erosion.'},
                                      {'type': 'tf',
                                       'q': 'In India, shifting cultivation is practised mostly in the north-eastern '
                                            'states.',
                                       'answer': 'True',
                                       'explanation': 'In India, this type of cultivation is practised in the '
                                                      'north-east, particularly in Arunachal Pradesh, Mizoram, '
                                                      'Nagaland, Manipur.'},
                                      {'type': 'tf',
                                       'q': 'Commercial farming aims at earning profit by growing crops on a large '
                                            'scale.',
                                       'answer': 'True',
                                       'explanation': 'The purpose of commercial farming is to grow crops on a large '
                                                      'scale, mainly for the purpose of selling the produce at home '
                                                      'and abroad.'},
                                      {'type': 'tf',
                                       'q': 'Plantation farming involves growing many different types of crops on the '
                                            'same plot.',
                                       'answer': 'False',
                                       'explanation': 'Plantation farming involves a single crop cultivated over a '
                                                      'large area of land. It is a type of commercial farming.'},
                                      {'type': 'tf',
                                       'q': "Tea is mainly grown in India's southern states through plantation "
                                            'farming.',
                                       'answer': 'False',
                                       'explanation': 'In India, tea is mainly grown in the north (like Assam and West '
                                                      'Bengal) and coffee in the south.'},
                                      {'type': 'tf',
                                       'q': 'Mixed farming allows farmers to have multiple sources of income.',
                                       'answer': 'True',
                                       'explanation': 'Farmers practice mixed farming in order to have a multiple '
                                                      'source of income. An advantage is that if one source of income '
                                                      'fails, the farmer could still depend on the other source.'},
                                      {'type': 'tf',
                                       'q': 'Mixed farming requires less fertilizers, insecticides and pesticides than '
                                            'other types of farming.',
                                       'answer': 'True',
                                       'explanation': 'Unlike other types of farming, there is less need for inputs '
                                                      'such as fertilizers, insecticides, pesticides and water in '
                                                      'mixed farming.'},
                                      {'type': 'tf',
                                       'q': 'Crop rotation is the practice of growing the same crop on the same land '
                                            'every year.',
                                       'answer': 'False',
                                       'explanation': 'Crop rotation is the growing of different crops on the same '
                                                      'piece of land in successive years to protect and enhance soil '
                                                      'fertility.'},
                                      {'type': 'tf',
                                       'q': 'Double cropping involves growing two crops one after another on the same '
                                            'land in a single year.',
                                       'answer': 'True',
                                       'explanation': 'Double cropping is the growing of two crops one after another '
                                                      'on the same piece of land in a single year.'},
                                      {'type': 'tf',
                                       'q': 'HYV stands for High Yielding Variety of seeds.',
                                       'answer': 'True',
                                       'explanation': 'HYV means High yielding variety of seeds introduced during the '
                                                      'Green Revolution to increase crop production.'},
                                      {'type': 'tf',
                                       'q': 'In India, mixed farming is widely practised across all states.',
                                       'answer': 'False',
                                       'explanation': 'Unlike the USA, Europe, Australia and New Zealand, mixed '
                                                      'farming is still not popular in India. It is seen mainly in the '
                                                      'Himalayan mountains in India.'},
                                      {'type': 'tf',
                                       'q': 'Agriculture has been practised for thousands of years by humankind.',
                                       'answer': 'True',
                                       'explanation': 'Agriculture has been practised for thousands of years by '
                                                      'humankind, and even to this day, it remains an important '
                                                      'occupation for most people around the world.'},
                                      {'type': 'tf',
                                       'q': 'Intensive farming uses irrigation canals apart from monsoon rains.',
                                       'answer': 'True',
                                       'explanation': 'Apart from the monsoon rains, the farmer depends on irrigation '
                                                      'canals for the supply of water for the crops.'},
                                      {'type': 'tf',
                                       'q': 'Jhumming is the term used for shifting cultivation in Indonesia.',
                                       'answer': 'False',
                                       'explanation': 'Jhumming is the term used in India. In Indonesia, it is called '
                                                      "'Lading'."},
                                      {'type': 'tf',
                                       'q': 'Agriculture is still an important occupation for more than 50 per cent of '
                                            'people in Asia and Africa.',
                                       'answer': 'True',
                                       'explanation': 'In most countries in Asia and Africa, more than 50 per cent of '
                                                      'the people are employed in the agricultural sector.'},
                                      {'type': 'tf',
                                       'q': 'Rice is grown in plantation farming.',
                                       'answer': 'False',
                                       'explanation': 'Rice is a food crop, not a plantation crop. Tea, coffee and '
                                                      'rubber are examples of plantation crops.'},
                                      {'type': 'tf',
                                       'q': 'Extensive farming makes large-scale use of machines to compensate for '
                                            'less labour.',
                                       'answer': 'True',
                                       'explanation': 'Less human labour is available in extensive farming because of '
                                                      'a small population. Therefore, most of the work is done by '
                                                      'using large machines such as the combine harvester.'},
                                      {'type': 'tf',
                                       'q': 'Shifting cultivation increases long-term soil fertility.',
                                       'answer': 'False',
                                       'explanation': 'When the farmers realize that the fertility of the land is '
                                                      'reduced, they move on to the next patch of forest land. '
                                                      'Shifting cultivation does not increase long-term soil '
                                                      'fertility.'},
                                      {'type': 'tf',
                                       'q': 'Commercial farming requires a huge investment for cold storage and '
                                            'marketing.',
                                       'answer': 'True',
                                       'explanation': 'A major disadvantage of commercial farming is that a huge '
                                                      'investment is required to market the produce and for keeping '
                                                      'the products in cold storage.'},
                                      {'type': 'tf',
                                       'q': 'Night soil is used in intensive farming as a natural fertilizer.',
                                       'answer': 'True',
                                       'explanation': 'The yield per acre is high since farmers also use night soil '
                                                      'which is a good form of natural fertilizer.'},
                                      {'type': 'tf',
                                       'q': 'Plantation farming is mainly practised in European countries.',
                                       'answer': 'False',
                                       'explanation': 'Plantation farming is popular in Sri Lanka, Malaysia, Brazil, '
                                                      'Indonesia and similar tropical regions, not primarily in '
                                                      'European countries.'},
                                      {'type': 'tf',
                                       'q': 'Animal manure obtained from farm animals helps increase the fertility of '
                                            'the soil in mixed farming.',
                                       'answer': 'True',
                                       'explanation': 'Natural fertilizers and manure are obtained from the farm '
                                                      'animals. This helps increase the fertility of the soil.'},
                                      {'type': 'tf',
                                       'q': 'Subsistence farming is the most productive type of farming in the world.',
                                       'answer': 'False',
                                       'explanation': 'Subsistence farming is not the most productive — it grows just '
                                                      "enough for the farmer's family. Commercial and intensive "
                                                      'farming are more productive.'},
                                      {'type': 'tf',
                                       'q': 'Agribusiness is another name for commercial farming.',
                                       'answer': 'True',
                                       'explanation': 'Commercial farming is also known as agribusiness.'},
                                      {'type': 'tf',
                                       'q': 'Subsistence farming leaves a large surplus of crops for sale.',
                                       'answer': 'False',
                                       'explanation': 'Subsistence farming grows just enough crops to meet the '
                                                      "farmer's needs and those of the family, leaving little, if any, "
                                                      'surplus for sale or trade.'},
                                      {'type': 'tf',
                                       'q': 'Shifting cultivation is practised in the Amazon Basin in Brazil.',
                                       'answer': 'True',
                                       'explanation': 'Shifting cultivation is practised in India, Indonesia, Brazil '
                                                      '(mainly in the Amazon Basin), central America, Malaysia and the '
                                                      'Democratic Republic of Congo.'},
                                      {'type': 'tf',
                                       'q': 'A combine harvester is used in extensive farming to compensate for less '
                                            'human labour.',
                                       'answer': 'True',
                                       'explanation': 'In extensive farming, most of the work is done by using large '
                                                      'machines such as the combine harvester.'},
                                      {'type': 'tf',
                                       'q': 'Mixed farming is widely practised across most of the Indian states.',
                                       'answer': 'False',
                                       'explanation': 'Mixed farming is still not popular in India. It is seen mainly '
                                                      'in the Himalayan mountains in India where people practice '
                                                      'beekeeping, cattle and sheep rearing and mushroom farming.'},
                                      {'type': 'tf',
                                       'q': 'Plantation farming is a single crop cultivated over a large area of land.',
                                       'answer': 'True',
                                       'explanation': 'Plantation farming: a single crop is cultivated over a large '
                                                      'area of land. Cash crops are sold and work is highly '
                                                      'organized.'},
                                      {'type': 'tf',
                                       'q': 'The purpose of commercial farming is to grow crops only for local '
                                            'consumption.',
                                       'answer': 'False',
                                       'explanation': 'The purpose of commercial farming is to grow crops on a large '
                                                      'scale, mainly for the purpose of selling the produce at home '
                                                      'and abroad.'},
                                      {'type': 'tf',
                                       'q': 'In extensive farming, the average farm size is around 1000–2000 acres.',
                                       'answer': 'True',
                                       'explanation': 'The average required size of the farm for extensive farming is '
                                                      'around 1000–2000 acres.'},
                                      {'type': 'subjective',
                                       'q': "Why is shifting cultivation also called 'slash and burn' farming?",
                                       'sample': "Shifting cultivation is called 'slash and burn' farming because of "
                                                 'the method used to prepare the land. Farmers select a small patch of '
                                                 "forest land. They 'slash' (cut down) the trees and bushes using a "
                                                 'long sharp knife called a machete. Then the debris and cut plants '
                                                 "are 'burned'. The ashes from the burnt plants make the soil very "
                                                 'fertile. Seeds are then sown in this cleared and fertilized land. '
                                                 'The farmers grow crops for a few years on this land. When the '
                                                 'fertility of the land decreases, they move on to another patch of '
                                                 'forest land and repeat the process — slash and burn, then move. This '
                                                 'cycle continues. In India it is called Jhumming, in Indonesia '
                                                 'Lading, in the Amazon Basin Roca, and in Central America Milpa.'},
                                      {'type': 'subjective',
                                       'q': "What is the contribution of agriculture to India's GDP and employment?",
                                       'sample': "Agriculture is extremely important to India's economy and "
                                                 "population: (1) Almost half of India's population (around 45 per "
                                                 'cent) is engaged in agriculture. (2) The contribution of agriculture '
                                                 "to India's total income is about one fifth (18 per cent) of the "
                                                 'total income, which is significant given how many people depend on '
                                                 'it. (3) India ranks second in the world in agriculture production, '
                                                 'excelling as the largest cotton and jute producer. (4) India is '
                                                 'second in rice, wheat and sugarcane production. (5) In most '
                                                 'countries in Asia and Africa, more than 50 per cent of the people '
                                                 'are employed in the agricultural sector. (6) Agriculture provides '
                                                 'raw materials for many industries like textiles and food processing. '
                                                 "(7) Despite its large share in employment, agriculture's "
                                                 'contribution to GDP has been decreasing as the services and '
                                                 'industrial sectors have grown.'},
                                      {'type': 'subjective',
                                       'q': 'What are fodder crops? Why are they important?',
                                       'sample': 'Fodder crops are those crops which are mainly grown for the purpose '
                                                 'of feeding and fattening livestock. They are also called animal feed '
                                                 'crops. They are different from food crops (grown for human '
                                                 'consumption) and cash crops (grown for sale). Examples of fodder '
                                                 'crops are maize and oats. Importance: (1) Fodder crops provide '
                                                 'nutritious feed for cattle, sheep, goats, poultry and other farm '
                                                 'animals. (2) They are an essential part of mixed farming — animals '
                                                 'fed on fodder crops provide milk, meat, wool and manure. (3) Manure '
                                                 'from animals fed on fodder helps improve soil fertility. (4) '
                                                 'Countries with large animal populations like Australia, USA and '
                                                 'European nations rely heavily on fodder crop cultivation. (5) In '
                                                 'India, the growing dairy industry also depends on adequate fodder '
                                                 'crop production.'},
                                      {'type': 'subjective',
                                       'q': 'Describe the main features and distribution of extensive farming.',
                                       'sample': 'Extensive farming is practised in areas of low population and where '
                                                 'plenty of land is available for cultivation. The temperate '
                                                 'grasslands of the world are known for extensive farming. Main '
                                                 'features: (1) Less human labour is available because of a small '
                                                 'population. Most of the work is done by using large machines such as '
                                                 'the combine harvester. (2) Crops like wheat, maize, barley and sugar '
                                                 'cane are grown using extensive farming practices. (3) To make this '
                                                 'type of farming profitable, large quantities of land are required. '
                                                 '(4) The average required size of the farm is around 1000–2000 acres. '
                                                 'World distribution: USA, Canada and Australia. In India: Extensive '
                                                 'farming is practised in the states of Punjab and Haryana, and parts '
                                                 'of Uttar Pradesh.'},
                                      {'type': 'subjective',
                                       'q': 'What is subsistence farming? What are its main features?',
                                       'sample': 'Subsistence farming is practised by farmers who own small pieces of '
                                                 'land. Such farmers grow just enough crops to meet their needs and '
                                                 'those of their families. Main features: (1) Small plots of land. (2) '
                                                 'Use organic or natural fertilizers such as cow dung, animal '
                                                 'droppings and dead and dried plants. (3) Depend on monsoon rains for '
                                                 'water. (4) Grow rice or vegetables for family consumption. (5) No '
                                                 'surplus produce for sale or trade. (6) It is a form of farming in '
                                                 'which nearly all crops raised are used to maintain the farmer and '
                                                 "the farmer's family."},
                                      {'type': 'subjective',
                                       'q': 'Describe the important features of intensive farming.',
                                       'sample': 'Important features of intensive farming: (1) The farmer has a small '
                                                 'plot of land on which they use hybrid or mixed breed seeds, which '
                                                 'are expensive but high yielding. (2) The farmer requires plenty of '
                                                 'fertilizers and pesticides, but heavy use of these leads to the '
                                                 'death of useful insects. (3) Use of pesticides kills many birds and '
                                                 'insects such as ladybirds and butterflies. (4) The yield per acre is '
                                                 'high since farmers use night soil as a natural fertilizer. (5) Apart '
                                                 'from monsoon rains, farmers depend on irrigation canals for water. '
                                                 '(6) The farmer carries out double cropping, multiple cropping or '
                                                 'crop rotation. (7) Involves the use of skilled labour, which adds to '
                                                 'cost.'},
                                      {'type': 'subjective',
                                       'q': 'Differentiate between intensive farming and extensive farming.',
                                       'sample': 'Intensive Farming: (1) Practised on small plots of land. (2) Uses '
                                                 'hybrid/mixed breed seeds, fertilizers and pesticides heavily. (3) '
                                                 'Requires a lot of labour. (4) Practised in densely populated areas '
                                                 'where land is scarce. (5) Found in China, Korea, Japan, and coastal '
                                                 'areas of India. Extensive Farming: (1) Practised on large areas of '
                                                 'land (1000–2000 acres). (2) Uses less fertilizer; mainly large '
                                                 'machines like combine harvesters. (3) Requires less human labour. '
                                                 '(4) Practised in sparsely populated areas with plenty of land. (5) '
                                                 'Found in USA, Canada, Australia, and Punjab and Haryana in India.'},
                                      {'type': 'subjective',
                                       'q': 'What is shifting cultivation? Why should it be discouraged?',
                                       'sample': 'Shifting cultivation is an ancient and traditional form of '
                                                 'cultivation practised even today in parts of India, Indonesia, '
                                                 'Brazil, central America, Malaysia and the Democratic Republic of '
                                                 'Congo. In this practice, a small patch of forests is cut, the debris '
                                                 'is burned and the land is used to grow crops like maize, barley, '
                                                 'rice and fruits. When the fertility of the land is reduced, farmers '
                                                 'move to the next patch of forest. It should be discouraged because: '
                                                 '(1) It disturbs the ecology of the area. (2) It displaces wildlife '
                                                 'and birds from their natural habitats. (3) It contributes to soil '
                                                 'erosion during the monsoon season. (4) It destroys forests and '
                                                 'reduces biodiversity. (5) It is not sustainable in the long run.'},
                                      {'type': 'subjective',
                                       'q': 'What is commercial farming? What are the methods employed in commercial '
                                            'farming?',
                                       'sample': 'Commercial farming (also called agribusiness) is the practice of '
                                                 'growing crops on a large scale mainly for the purpose of selling the '
                                                 'produce at home and abroad. The main aim is to earn profit. Methods '
                                                 'employed in commercial farming: (1) High Yielding Variety (HYV) '
                                                 'seeds. (2) Chemical fertilizers, pesticides and insecticides. (3) '
                                                 'Modern irrigation techniques. (4) Cold storage to preserve produce. '
                                                 '(5) Large-scale mechanization with farm machinery. Products include '
                                                 'cheeses, dairy produce, wines, mushrooms, honey, fruits and '
                                                 'vegetables. Commercial farming is practised in European countries, '
                                                 'New Zealand, Scandinavian countries, and states like Maharashtra, '
                                                 'Sikkim, Haryana and Punjab in India.'},
                                      {'type': 'subjective',
                                       'q': 'What are the benefits of mixed farming?',
                                       'sample': 'Benefits of mixed farming: (1) Multiple sources of income — if one '
                                                 'source fails, the farmer depends on another. (2) Mixed farming '
                                                 'includes fodder obtained from residue of crops — useful for feeding '
                                                 'animals. (3) Natural fertilizers and manure from farm animals help '
                                                 'increase soil fertility. (4) It prevents soil erosion and conserves '
                                                 'water. (5) Unlike other types of farming, there is less need for '
                                                 'inputs such as fertilizers, insecticides, pesticides and water. (6) '
                                                 'Mixed farming provides an opportunity for a good ecological and '
                                                 'environmental balance, securing habitats of birds, wildlife and '
                                                 'insects. (7) It is a sustainable form of development.'},
                                      {'type': 'subjective',
                                       'q': 'Explain the three types of cropping practised in intensive farming.',
                                       'sample': 'The three types of cropping practised in intensive farming are: (1) '
                                                 'Double cropping — the growing of two crops one after another on the '
                                                 'same piece of land in a single year. For example, two main crops '
                                                 'such as rice and wheat are grown in a year or one main crop followed '
                                                 'by pulses and oilseeds. (2) Multiple cropping — the growing of two '
                                                 'or more crops on the same piece of land in a single year. This is '
                                                 'possible only with irrigation, use of high yielding variety and '
                                                 'quick ripening seeds, fertilizers, etc. (3) Crop rotation — the '
                                                 'growing of different crops on the same piece of land in successive '
                                                 'years (e.g., wheat in the first year; potatoes, beetroot and carrots '
                                                 'in the second year; barley and rye in the third year) to protect and '
                                                 'enhance soil fertility.'},
                                      {'type': 'subjective',
                                       'q': 'What is plantation farming? Give examples of plantation crops and '
                                            'countries where it is practised.',
                                       'sample': 'A plantation is a very large area of agricultural land where cash '
                                                 'crops are grown on a very large scale. These cash crops are called '
                                                 'plantation crops. The work in plantations is highly organized and '
                                                 'the cash crops are sold. Plantation farming is a type of commercial '
                                                 'farming. Examples of plantation crops: Tea, coffee, rubber. '
                                                 'Countries where plantation farming is practised: Sri Lanka, '
                                                 'Malaysia, Brazil, Indonesia. In India: Tea is mainly grown in the '
                                                 'north (Assam, West Bengal) and coffee in the south (Karnataka, '
                                                 'Kerala, Tamil Nadu). Rubber is grown in Kerala, Tamil Nadu, Tripura, '
                                                 'Assam and Meghalaya.'},
                                      {'type': 'subjective',
                                       'q': 'What is crop rotation and why is it important?',
                                       'sample': 'Crop rotation is the growing of different crops on the same piece of '
                                                 'land in successive years. For example: wheat in the first year; '
                                                 'potatoes, beetroot and carrots in the second year; barley and rye in '
                                                 'the third year; and pulses in the fourth year. Importance: (1) It '
                                                 'protects and enhances soil fertility — different crops use different '
                                                 'nutrients from the soil, so rotating them prevents the soil from '
                                                 'becoming depleted. (2) Some crops, like pulses (legumes), actually '
                                                 'add nitrogen back to the soil, improving its fertility for the next '
                                                 'crop. (3) It helps control pests and diseases that may build up when '
                                                 'the same crop is grown continuously. (4) It enables farmers to earn '
                                                 'income from different sources throughout the year.'},
                                      {'type': 'subjective',
                                       'q': 'Describe the Operation Flood (White Revolution) in India.',
                                       'sample': 'In the 1960s, India was facing a severe shortage of milk and dairy '
                                                 'products and could not meet the rising demands of its population. In '
                                                 '1970, the National Dairy Development Board (NDDB), under the '
                                                 "leadership of Dr Verghese Kurien, launched 'Operation Flood'. Its "
                                                 'aim was to increase milk production to make the country one of the '
                                                 'largest producers of milk in the world. Dr Kurien was a visionary '
                                                 'dairy engineer and the driving force behind the movement. The '
                                                 "programme was also called 'White Revolution', inspired by the white "
                                                 'colour of milk. Due to this initiative, India became one of the '
                                                 'largest producers of milk in the world.'},
                                      {'type': 'subjective',
                                       'q': "Why is India's contribution to agriculture important globally?",
                                       'sample': "India's contribution to agriculture is significant for several "
                                                 'reasons: (1) Agriculture is the chief means of livelihood for about '
                                                 "45 per cent of India's population. (2) India traces its agricultural "
                                                 'roots to the Indus Valley civilization. (3) India is the largest '
                                                 'producer of cotton and jute in the world. (4) India ranks second in '
                                                 'the world in the production of rice, wheat and sugarcane. (5) India '
                                                 'excels in producing a wide variety of crops due to its diverse '
                                                 'climate and geography. (6) India is the second largest producer of '
                                                 'both rice and wheat — the largest staple food crops across the '
                                                 'world, helping to feed its own population and contributing to global '
                                                 'food supply. (7) The Green Revolution in India transformed it from a '
                                                 'food-deficient nation to a food-surplus nation.'},
                                      {'type': 'subjective',
                                       'q': 'How does intensive farming affect the environment negatively?',
                                       'sample': 'Intensive farming affects the environment in the following negative '
                                                 'ways: (1) Heavy use of fertilizers and pesticides leads to the death '
                                                 'of useful insects and worms that help the soil become nutrient-rich. '
                                                 '(2) Birds also become victims of pesticides by consuming poisoned '
                                                 'insects and worms. (3) For these reasons, intensive farming is '
                                                 'harmful to the ecology of the area. (4) Use of pesticides kills many '
                                                 'birds and insects such as ladybirds and butterflies, reducing '
                                                 'biodiversity. (5) Chemical fertilizers and pesticides can leach into '
                                                 'groundwater and nearby rivers, causing water pollution. (6) Overuse '
                                                 'of chemical inputs can make the soil less fertile over time, '
                                                 'reducing its natural capacity to support plant growth.'},
                                      {'type': 'subjective',
                                       'q': 'What is the difference between food crops and cash crops? Give two '
                                            'examples of each.',
                                       'sample': 'Food crops are those crops that are grown primarily to provide food '
                                                 'for people. They include cereals such as rice, wheat, maize, barley, '
                                                 'millets, pulses, and spices. Examples: Rice, Wheat. Cash crops are '
                                                 'grown primarily for cash or for commercial purposes. These crops are '
                                                 'sold in the market for profits. While food crops feed the farmer and '
                                                 'family, cash crops enable the farmer to earn more money. Examples: '
                                                 'Sugar cane, Cotton. Other examples of cash crops include oilseeds '
                                                 'such as mustard, groundnut, soybean; fibre crops like cotton and '
                                                 'jute; and plantation crops like tea, coffee and rubber.'},
                                      {'type': 'subjective',
                                       'q': 'List three advantages and three disadvantages of extensive farming.',
                                       'sample': 'Advantages of extensive farming: (1) Large quantities of crops can '
                                                 'be produced as the farm size is 1000–2000 acres. (2) Less human '
                                                 'labour is required as most work is done by large machines, reducing '
                                                 'labour costs. (3) It is economically profitable when done on a large '
                                                 'scale, especially for export. Disadvantages of extensive farming: '
                                                 '(1) Large areas of land are required, so it cannot be practised in '
                                                 'densely populated areas. (2) Due to monoculture (growing one crop on '
                                                 'large areas), the land becomes depleted of specific nutrients. (3) '
                                                 'Dependent on machinery — any breakdown can cause significant losses. '
                                                 '(4) Not easily applicable in hilly or uneven terrain. (5) High '
                                                 'initial investment is needed for machinery and land.'},
                                      {'type': 'subjective',
                                       'q': 'Why is agriculture important for India and the world?',
                                       'sample': 'Agriculture is important for India and the world for the following '
                                                 'reasons: (1) Agriculture is the primary source of food for the '
                                                 "world's population — food grains are the most important products of "
                                                 'agriculture. (2) In India, about 45 per cent of the population is '
                                                 'engaged in agriculture, making it the main source of livelihood. (3) '
                                                 "Agriculture contributes about 18 per cent to India's GDP. (4) "
                                                 'Agricultural products like cotton, jute, tea, coffee, rubber are '
                                                 'important exports that generate foreign exchange. (5) Agriculture '
                                                 'provides raw materials for many industries (e.g., textile industry '
                                                 'uses cotton and jute). (6) The success of the Green Revolution in '
                                                 'India shows how agriculture can help a country overcome food '
                                                 'shortages and become self-sufficient. (7) Agriculture is essential '
                                                 'for economic development and poverty alleviation.'},
                                      {'type': 'subjective',
                                       'q': 'What is double cropping and how is it different from multiple cropping?',
                                       'sample': 'Double cropping is the growing of two crops one after another on the '
                                                 'same piece of land in a single year. For example, two main crops '
                                                 'such as rice and wheat are grown in a year, or one main crop is '
                                                 'grown followed by pulses and oilseeds. Multiple cropping is the '
                                                 'growing of two or more crops on the same piece of land in a single '
                                                 'year simultaneously. This is possible only with irrigation, use of '
                                                 'high yielding variety seeds, quick ripening seeds and fertilizers. '
                                                 'The key difference is that in double cropping, the two crops are '
                                                 'grown one after the other sequentially, while in multiple cropping, '
                                                 'more than two crops may be grown, possibly at the same time on the '
                                                 'same plot. Both practices enable farmers to earn an income from more '
                                                 'than one source during the year.'}],
                                                  # ──────────────────────────────────────────────────────────────────
    # CHAPTER 6: Major Crops
    # ──────────────────────────────────────────────────────────────────
    "Chapter 6 — Major Crops": [

        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "Which of these is NOT a cereal crop?",
            "options": ["Rice", "Wheat", "Gram", "Maize"],
            "answer": "Gram",
            "explanation": "Gram is a pulse (dal), not a cereal. Rice, wheat and maize are cereals."
        },
        {
            "type": "mcq",
            "q": "Food crops are grown primarily to:",
            "options": ["Earn profit for export", "Provide food for people", "Feed animals only", "Make medicines"],
            "answer": "Provide food for people",
            "explanation": "Food crops are those crops that are grown primarily to provide food for people."
        },
        {
            "type": "mcq",
            "q": "Cash crops are primarily grown for:",
            "options": ["Family consumption", "Animal feed only", "Cash or commercial purposes", "Scientific research"],
            "answer": "Cash or commercial purposes",
            "explanation": "Cash crops are primarily grown for cash or for commercial purposes and are sold in the market for profits."
        },
        {
            "type": "mcq",
            "q": "The three main growing seasons in India are:",
            "options": ["Spring, summer and autumn", "Kharif, rabi and zaid", "Wet, dry and cold", "Monsoon, winter and summer"],
            "answer": "Kharif, rabi and zaid",
            "explanation": "In India, food crops are identified according to the season they are grown in. There are three main growing seasons — kharif, rabi and zaid."
        },
        {
            "type": "mcq",
            "q": "The kharif crop is grown from July and harvested in:",
            "options": ["March", "June", "November", "February"],
            "answer": "November",
            "explanation": "The kharif crop is grown from July when the rains begin and harvested in November when it is dry."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a kharif crop?",
            "options": ["Wheat", "Barley", "Peas", "Cotton"],
            "answer": "Cotton",
            "explanation": "Examples of kharif crops include rice, maize, jute, cotton, pulses, millets, turmeric, groundnuts, sugar cane and soybean."
        },
        {
            "type": "mcq",
            "q": "The rabi crop is a _______ crop grown in October and November.",
            "options": ["Monsoon", "Winter", "Summer", "Spring"],
            "answer": "Winter",
            "explanation": "The rabi crop is a winter crop grown in October and November and harvested around February and March."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a rabi crop?",
            "options": ["Rice", "Cotton", "Jute", "Wheat"],
            "answer": "Wheat",
            "explanation": "Examples of rabi crops include wheat, barley, peas, sesame and mustard."
        },
        {
            "type": "mcq",
            "q": "Zaid crops are grown from:",
            "options": ["July to November", "October to March", "March to June", "June to October"],
            "answer": "March to June",
            "explanation": "Zaid crops are grown from March to June. Examples include bitter gourd, sweet potatoes and fruits like watermelon."
        },
        {
            "type": "mcq",
            "q": "Rice is a staple food for more than _______ of the world's population.",
            "options": ["20 per cent", "30 per cent", "50 per cent", "70 per cent"],
            "answer": "50 per cent",
            "explanation": "Rice is a staple food for more than 50 per cent of the population of the world."
        },
        {
            "type": "mcq",
            "q": "Rice grows best in which type of soil?",
            "options": ["Sandy soil", "Fertile and clayey soil that holds water", "Rocky soil", "Dry desert soil"],
            "answer": "Fertile and clayey soil that holds water",
            "explanation": "Fertile and clayey soil that holds water is best for rice cultivation, such as deep fertile clayey and loamy soil."
        },
        {
            "type": "mcq",
            "q": "Which country is the world's largest rice-producing country?",
            "options": ["India", "Indonesia", "China", "Bangladesh"],
            "answer": "China",
            "explanation": "China is the world's largest rice-producing country, followed by India."
        },
        {
            "type": "mcq",
            "q": "Wheat is the most important food crop of:",
            "options": ["Coastal India", "North India", "South India", "North-East India"],
            "answer": "North India",
            "explanation": "Wheat is the most important food crop of north India and forms part of the basic diet of the people."
        },
        {
            "type": "mcq",
            "q": "In 2021, India was the world's _______ largest wheat-producing country.",
            "options": ["Largest", "Second largest", "Third largest", "Fourth largest"],
            "answer": "Second largest",
            "explanation": "In 2021, India was the world's second largest wheat-producing country, after China."
        },
        {
            "type": "mcq",
            "q": "Which state is the leading wheat-producing state in India?",
            "options": ["Rajasthan", "Madhya Pradesh", "Uttar Pradesh", "Bihar"],
            "answer": "Uttar Pradesh",
            "explanation": "Uttar Pradesh is the leading wheat-producing state in India. Together with Punjab and Haryana it produces about 60 per cent of the total wheat."
        },
        {
            "type": "mcq",
            "q": "Sugar cane stalks grow from 2 m to _______ in height.",
            "options": ["4 m", "6 m", "8 m", "10 m"],
            "answer": "6 m",
            "explanation": "Sugar cane stalks grow from 2 m to 6 m in height."
        },
        {
            "type": "mcq",
            "q": "India is the _______ largest sugar cane producer in the world.",
            "options": ["Largest", "Second-largest", "Third-largest", "Fourth-largest"],
            "answer": "Second-largest",
            "explanation": "India is the second-largest sugar cane producer in the world after Brazil."
        },
        {
            "type": "mcq",
            "q": "The crushed fibre of sugar cane, known as bagasse, is used for:",
            "options": ["Making medicines", "The manufacture of paper and fibre boards", "Animal feed only", "Making sugar directly"],
            "answer": "The manufacture of paper and fibre boards",
            "explanation": "The crushed fibre, known as bagasse, is used for the manufacture of paper and fibre boards."
        },
        {
            "type": "mcq",
            "q": "In 2022, which country was the largest producer of cotton?",
            "options": ["USA", "China", "India", "Pakistan"],
            "answer": "India",
            "explanation": "In 2022, India was the largest producer of cotton, followed by China and USA."
        },
        {
            "type": "mcq",
            "q": "Cotton cultivation in India began around 3000 BCE in the:",
            "options": ["Vedic period", "Mughal Empire", "Indus Valley Civilization", "Mauryan Empire"],
            "answer": "Indus Valley Civilization",
            "explanation": "In India, the cultivation of cotton began about 3000 BCE in the Indus Valley Civilization."
        },
        {
            "type": "mcq",
            "q": "Cotton grows in which type of soil in India?",
            "options": ["Sandy soil", "Alluvial soil", "Lava soil (black and clayey)", "Laterite soil"],
            "answer": "Lava soil (black and clayey)",
            "explanation": "In India, cotton is grown in lava soil that is black and clayey. Black soil was formed millions of years ago from volcanic ash."
        },
        {
            "type": "mcq",
            "q": "Jute is known as the 'golden fibre' because of its:",
            "options": ["High monetary value", "Shiny golden colour", "Ability to be spun into gold thread", "Production in golden season"],
            "answer": "Shiny golden colour",
            "explanation": "Because of its shiny golden colour, jute is also known as the 'golden fibre'."
        },
        {
            "type": "mcq",
            "q": "India is the _______ producer of jute in the world.",
            "options": ["Largest", "Second largest", "Third largest", "Fourth largest"],
            "answer": "Largest",
            "explanation": "India is the largest producer of jute in the world, followed by Bangladesh."
        },
        {
            "type": "mcq",
            "q": "Jute cultivation in India is confined mostly to the eastern states. Which is the largest jute-producing state?",
            "options": ["Bihar", "Assam", "Odisha", "West Bengal"],
            "answer": "West Bengal",
            "explanation": "West Bengal is the largest jute-producing state in India both in area and production."
        },
        {
            "type": "mcq",
            "q": "Tea grows best in:",
            "options": ["Desert regions", "Hilly regions where water does not stagnate", "Flat coastal areas", "Frozen tundra"],
            "answer": "Hilly regions where water does not stagnate",
            "explanation": "Tea bushes grow best in hilly regions where water does not stagnate because of hill slopes."
        },
        {
            "type": "mcq",
            "q": "The finest quality tea in India is grown on the hill slopes of:",
            "options": ["Ooty", "Munnar", "Darjiling", "Wayanad"],
            "answer": "Darjiling",
            "explanation": "The finest quality tea is grown on the hill slopes of Darjiling in West Bengal."
        },
        {
            "type": "mcq",
            "q": "The world's largest producer of coffee is:",
            "options": ["India", "Vietnam", "Indonesia", "Brazil"],
            "answer": "Brazil",
            "explanation": "Brazil is the world's largest producer of coffee followed by Vietnam, Indonesia and Colombia."
        },
        {
            "type": "mcq",
            "q": "In India, which state is the highest coffee-producing state (54 per cent)?",
            "options": ["Kerala", "Karnataka", "Tamil Nadu", "Andhra Pradesh"],
            "answer": "Karnataka",
            "explanation": "In India, Karnataka is the highest coffee producing state (54 per cent), followed by Kerala (19 per cent) and Tamil Nadu (8 per cent)."
        },
        {
            "type": "mcq",
            "q": "The sap of the rubber tree is called:",
            "options": ["Resin", "Gum", "Latex", "Wax"],
            "answer": "Latex",
            "explanation": "The sap of the rubber tree is called the latex. Latex is collected in small cups attached to the tree with the help of wires."
        },
        {
            "type": "mcq",
            "q": "Thailand is the largest rubber producer in the world, followed by:",
            "options": ["India and China only", "Indonesia, Vietnam, India and China", "Brazil and Malaysia", "USA and Europe"],
            "answer": "Indonesia, Vietnam, India and China",
            "explanation": "Internationally, Thailand is the largest rubber producer followed by Indonesia, Vietnam, India and China."
        },
        {
            "type": "mcq",
            "q": "The Green Revolution refers to the spectacular increase in production of food grains in India in the:",
            "options": ["1940s", "1950s", "1960s", "1980s"],
            "answer": "1960s",
            "explanation": "The Green Revolution refers to the spectacular increase in the production of food grains in the 1960s in India."
        },
        {
            "type": "mcq",
            "q": "The new variety of HYV seeds was introduced to Indian farms in 1967 by:",
            "options": ["M. S. Swaminathan", "Dr Norman Borlaug", "Dr Verghese Kurien", "Jawaharlal Nehru"],
            "answer": "Dr Norman Borlaug",
            "explanation": "The new variety of seeds was introduced to Indian farms in 1967 by the Nobel Peace Prize winning agronomist, Dr Norman Borlaug."
        },
        {
            "type": "mcq",
            "q": "HYV stands for:",
            "options": ["High Yield Variety", "Hybrid Yielding Variety", "High Yielding Variety", "Highly Yielded Varieties"],
            "answer": "High Yielding Variety",
            "explanation": "HYV stands for High Yielding Variety of seeds."
        },
        {
            "type": "mcq",
            "q": "The Green Revolution led to a drastic reduction in India's:",
            "options": ["Agricultural exports", "Import of food grains", "Use of irrigation canals", "Farming workforce"],
            "answer": "Import of food grains",
            "explanation": "The Green Revolution led to a drastic reduction in the import of food grains. India became self-sufficient in food grains."
        },
        {
            "type": "mcq",
            "q": "Fodder crops are grown primarily for the purpose of:",
            "options": ["Human consumption", "Export only", "Feeding and fattening livestock", "Making cloth"],
            "answer": "Feeding and fattening livestock",
            "explanation": "Fodder crops are those crops which are mainly grown for the purpose of feeding and fattening livestock. Examples: maize and oats."
        },
        {
            "type": "mcq",
            "q": "Rubber trees require annual rainfall between:",
            "options": ["50–100 cm", "100–150 cm", "200–300 cm", "400–500 cm"],
            "answer": "200–300 cm",
            "explanation": "Rubber trees require heavy rainfall between 200 cm and 300 cm annually."
        },
        {
            "type": "mcq",
            "q": "M. S. Swaminathan earned which title?",
            "options": ["Father of the White Revolution", "Father of the Green Revolution", "Father of the Blue Revolution", "Father of Modern Agriculture"],
            "answer": "Father of the Green Revolution",
            "explanation": "M. S. Swaminathan earned the title 'Father of the Green Revolution'."
        },
        {
            "type": "mcq",
            "q": "It takes how many years before rubber trees can produce the sap?",
            "options": ["Two years", "Four years", "Six years", "Ten years"],
            "answer": "Six years",
            "explanation": "It takes six years before trees can produce the sap. A typical tree can produce about 9 to 10 kilos of rubber each year."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a product obtained from sugar cane besides sugar?",
            "options": ["Latex", "Kerosene", "Molasses and ethanol", "Rubber"],
            "answer": "Molasses and ethanol",
            "explanation": "Apart from juice, sugar cane also provides by-products such as molasses and ethanol for fuel and industrial alcohol."
        },
        {
            "type": "mcq",
            "q": "Tea cultivation is described as 'labour intensive' because:",
            "options": ["It needs heavy machinery", "Tea leaves must be plucked with care by hand", "It requires dams and canals", "It is grown only in factories"],
            "answer": "Tea leaves must be plucked with care by hand",
            "explanation": "The beverage is prepared from tea leaves plucked with care from tea bushes. Therefore, tea cultivation is labour intensive."
        },

        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "Food crops include cereals, pulses and spices.",
            "answer": "True",
            "explanation": "Food crops include cereals such as rice and wheat, pulses such as gram and tur, and spices such as cardamom, pepper, ginger and chillies."
        },
        {
            "type": "tf",
            "q": "Cash crops are grown primarily to feed the farmer's family.",
            "answer": "False",
            "explanation": "Cash crops are grown for cash or commercial purposes and are sold in the market for profits."
        },
        {
            "type": "tf",
            "q": "Kharif crops are grown in the winter season in India.",
            "answer": "False",
            "explanation": "Kharif crops are grown from July (rainy season) and harvested in November. They are not winter crops."
        },
        {
            "type": "tf",
            "q": "Wheat is a rabi crop that grows well in temperate regions.",
            "answer": "True",
            "explanation": "Wheat is a cereal crop which belongs to the grass family. It grows well in temperate regions and is a rabi crop."
        },
        {
            "type": "tf",
            "q": "Rice is the most important food crop of north India.",
            "answer": "False",
            "explanation": "Wheat is the most important food crop of north India. Rice is grown mainly in eastern and coastal regions."
        },
        {
            "type": "tf",
            "q": "China is the world's largest rice-producing country, followed by India.",
            "answer": "True",
            "explanation": "China is the world's largest rice-producing country, followed by India."
        },
        {
            "type": "tf",
            "q": "Sugar cane is a rabi crop that needs a cool climate.",
            "answer": "False",
            "explanation": "Sugar cane is a kharif crop that needs a hot and humid climate with an average temperature between 21°C and 27°C."
        },
        {
            "type": "tf",
            "q": "Uttar Pradesh is the number-one producer of sugar cane in India.",
            "answer": "True",
            "explanation": "Uttar Pradesh is the number one producer of sugar cane in India, followed by Maharashtra, Karnataka, Tamil Nadu and Andhra Pradesh."
        },
        {
            "type": "tf",
            "q": "Bagasse, the crushed sugar cane fibre, is used to make paper and fibre boards.",
            "answer": "True",
            "explanation": "The crushed fibre, known as bagasse, is used for the manufacture of paper and fibre boards."
        },
        {
            "type": "tf",
            "q": "In India, cotton cultivation began about 3000 BCE in the Indus Valley Civilization.",
            "answer": "True",
            "explanation": "In India, the cultivation of cotton began about 3000 BCE in the Indus Valley Civilization."
        },
        {
            "type": "tf",
            "q": "Cotton is a rabi crop in India.",
            "answer": "False",
            "explanation": "In India, cotton is a kharif crop requiring a uniformly high temperature from 21°C to 30°C."
        },
        {
            "type": "tf",
            "q": "Jute is the most affordable natural fibre that can be made into many useful products.",
            "answer": "True",
            "explanation": "Jute is the most affordable natural fibre that can be made into many useful products."
        },
        {
            "type": "tf",
            "q": "Jute is also known as the 'golden fibre' because of its shiny golden colour.",
            "answer": "True",
            "explanation": "Because of its shiny golden colour, jute is also known as the 'golden fibre'."
        },
        {
            "type": "tf",
            "q": "Bangladesh is the largest producer of jute in the world.",
            "answer": "False",
            "explanation": "India is the largest producer of jute in the world, followed by Bangladesh."
        },
        {
            "type": "tf",
            "q": "Tea is the most common beverage in the world.",
            "answer": "True",
            "explanation": "Tea is the most common beverage in the world and is considered to be a very important health drink and stimulant."
        },
        {
            "type": "tf",
            "q": "Tea is a perennial plant that grows well in both tropical and subtropical regions.",
            "answer": "True",
            "explanation": "Tea is a perennial plant that grows well in both tropical and subtropical regions."
        },
        {
            "type": "tf",
            "q": "Tea cultivation requires water to be stagnant in the plantation.",
            "answer": "False",
            "explanation": "Water must not be stagnant and must drain out of the plantation."
        },
        {
            "type": "tf",
            "q": "In India, coffee is grown mainly in Karnataka, Kerala and Tamil Nadu.",
            "answer": "True",
            "explanation": "Karnataka is the highest coffee producing state (54 per cent), followed by Kerala (19 per cent) and Tamil Nadu (8 per cent)."
        },
        {
            "type": "tf",
            "q": "Brazil is the world's largest producer of coffee.",
            "answer": "True",
            "explanation": "Brazil is the world's largest producer of coffee followed by Vietnam, Indonesia and Colombia."
        },
        {
            "type": "tf",
            "q": "Rubber trees take three years before they can produce sap.",
            "answer": "False",
            "explanation": "It takes six years before trees can produce the sap."
        },
        {
            "type": "tf",
            "q": "The rubber tree's sap is called latex.",
            "answer": "True",
            "explanation": "The sap is called the latex. Latex is collected in small cups attached to the tree with the help of wires."
        },
        {
            "type": "tf",
            "q": "The Green Revolution had its origins in Mexico and the Philippines.",
            "answer": "True",
            "explanation": "The Green Revolution had its origins in Mexico and the Philippines, where scientists developed new varieties of wheat, maize and rice in the 1940s."
        },
        {
            "type": "tf",
            "q": "The Green Revolution made India self-sufficient in food grains.",
            "answer": "True",
            "explanation": "India became self-sufficient in food grains due to the Green Revolution. There was now surplus stock which could be exported to other countries."
        },
        {
            "type": "tf",
            "q": "The Green Revolution benefited all farmers equally, including poor farmers.",
            "answer": "False",
            "explanation": "The benefits were confined to rich farmers. Poor farmers could not afford the new and expensive varieties of seeds."
        },
        {
            "type": "tf",
            "q": "One demerit of the Green Revolution was extreme dependence on artificial fertilizers and pesticides.",
            "answer": "True",
            "explanation": "One of the greatest drawbacks was the extreme dependence on artificial fertilizers and pesticides, leading to depletion of soil's natural rejuvenating capacity."
        },
        {
            "type": "tf",
            "q": "M. S. Swaminathan is known as the 'Father of the White Revolution'.",
            "answer": "False",
            "explanation": "M. S. Swaminathan earned the title 'Father of the Green Revolution'. Dr Verghese Kurien is associated with the White Revolution."
        },
        {
            "type": "tf",
            "q": "Tea and coffee are examples of beverages.",
            "answer": "True",
            "explanation": "Tea is the most common beverage in the world. Coffee is a beverage second in popularity to tea."
        },
        {
            "type": "tf",
            "q": "Latex from rubber trees is purified, dried and made into rubber sheets at the factory.",
            "answer": "True",
            "explanation": "The latex is taken to the factory where it is purified, dried and made into rubber sheets."
        },
        {
            "type": "tf",
            "q": "Ratooning is the practice of harvesting a crop by cutting the plant far below the ground.",
            "answer": "False",
            "explanation": "Ratooning involves cutting away the plant just above the ground, leaving the roots intact, to allow the plant to recover and produce a fresh crop."
        },
        {
            "type": "tf",
            "q": "The Green Revolution also created new jobs in India.",
            "answer": "True",
            "explanation": "The Green Revolution created several new jobs. Due to multiple cropping and use of fertilizers, the demand for labour to work in the fields increased."
        },
        {
            "type": "tf",
            "q": "HYV seeds resulted in a decrease in crop production.",
            "answer": "False",
            "explanation": "The introduction of HYV seeds resulted in a spectacular increase in crop production."
        },
        {
            "type": "tf",
            "q": "Jute is biodegradable and environment-friendly.",
            "answer": "True",
            "explanation": "Jute is biodegradable and environmental-friendly. It is used to make ropes, curtains, carpets, sacks and is a very sturdy and safe packaging material."
        },
        {
            "type": "tf",
            "q": "Kerala is the highest coffee-producing state in India.",
            "answer": "False",
            "explanation": "Karnataka is the highest coffee producing state in India (54 per cent). Kerala is second with 19 per cent."
        },
        {
            "type": "tf",
            "q": "Rice requires a temperature between 20°C and 30°C and rainfall of about 150–200 cm.",
            "answer": "True",
            "explanation": "Rice grows in areas where the temperature remains between 20°C to 30°C and requires a good amount of rainfall, about 150–200 cm."
        },
        {
            "type": "tf",
            "q": "Wheat is grown mainly in summer when temperatures are very high.",
            "answer": "False",
            "explanation": "Wheat is grown mainly in the winter months when the temperature is around 10°C and 15°C for sowing."
        },
        {
            "type": "tf",
            "q": "The Green Revolution increased the production of wheat by more than three times in India.",
            "answer": "True",
            "explanation": "The production of wheat increased by more than three times after the Green Revolution."
        },
        {
            "type": "tf",
            "q": "Rice is a good source of carbohydrate which is the body's main source of energy.",
            "answer": "True",
            "explanation": "Rice is a good source of carbohydrate which is the body's main source of energy."
        },
        {
            "type": "tf",
            "q": "Jute has been in use in India since 800 BCE.",
            "answer": "True",
            "explanation": "Jute has been in use in India, the Middle East and Egypt since 800 BCE."
        },
        {
            "type": "tf",
            "q": "The four types of coffee are Arabica, Robusta, Excelsa and Liberica.",
            "answer": "True",
            "explanation": "There are four types of coffee — Arabica, Robusta, Excelsa and Liberica. India produces Arabica and Robusta coffee."
        },
        {
            "type": "tf",
            "q": "In India, rubber is mainly grown in Kerala, Tamil Nadu, Tripura, Assam and Meghalaya.",
            "answer": "True",
            "explanation": "In India, some of the rubber producing states are Kerala, Tamil Nadu, Tripura, Assam and Meghalaya."
        },

        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "Describe the three main crop-growing seasons in India with examples of crops grown in each season.",
            "sample": "The three main crop-growing seasons in India are: (1) Kharif — grown from July when the rains begin and harvested in November. Examples: rice, maize, jute, cotton, pulses, millets, sugar cane and soybean. (2) Rabi — a winter crop grown in October/November and harvested around February/March. Examples: wheat, barley, peas, sesame and mustard. (3) Zaid — grown from March to June. Examples: bitter gourd, sweet potatoes, yams and fruits like watermelon, musk melon, pineapples, grapes and litchis."
        },
        {
            "type": "subjective",
            "q": "Explain the conditions necessary for growing rice in India and name any four rice-growing regions.",
            "sample": "Conditions for growing rice: (1) Temperature — between 20°C to 30°C. (2) Rainfall — a good amount of rainfall, about 150–200 cm. (3) Soil — fertile and clayey soil that holds water; deep fertile clayey and loamy soil; grows well in alluvial soil along river banks. (4) It can be grown in both tropical and temperate regions. Four rice-growing regions in India: (1) The Gangetic Plains stretching from Uttar Pradesh and Bihar to the Sunderbans in West Bengal. (2) The Brahmaputra Plains in Assam. (3) The eastern coastal regions of India — Odisha, Andhra Pradesh, Telangana and Tamil Nadu. (4) Punjab and Haryana in the north."
        },
        {
            "type": "subjective",
            "q": "What is the Green Revolution? What were its main features?",
            "sample": "The Green Revolution refers to the spectacular increase in the production of food grains in the 1960s in India. It had its origins in Mexico and the Philippines. The new variety of seeds was introduced to Indian farms in 1967 by Dr Norman Borlaug. Main features: (1) A marked decrease in shifting agriculture in many parts of India. (2) Genetically improved High Yielding Variety (HYV) of seeds of wheat, rice and maize were the most important components. (3) The Green Revolution led to an expansion of the fertilizer and pesticide manufacturing industries. (4) There was a significant expansion in the network of canals for irrigation because HYV seeds require a lot of water. (5) Farmers had the opportunity for multiple cropping, thereby increasing their income considerably. (6) Rural electrification expanded and so did the network of roads and railways."
        },
        {
            "type": "subjective",
            "q": "Describe the demerits of the Green Revolution.",
            "sample": "Demerits of the Green Revolution: (1) Benefits were confined to rich farmers in Punjab, Haryana, Uttar Pradesh, Andhra Pradesh, Tamil Nadu and parts of West Bengal since only they could afford expensive seeds, fertilizers and machinery. (2) The HYV crops required abundant water supply, making irrigation arrangements time-consuming and expensive. (3) The cost of fertilizers, pesticides and machinery increased beyond the reach of average farmers. (4) Farmers were encouraged to take loans but many incurred large debts without protection if crops failed. (5) New machinery replaced manual labour, leading to unemployment. (6) Extreme dependence on artificial fertilizers and pesticides brought about a depletion of the soil's natural rejuvenating capacity. (7) Farm water polluted with fertilizers and pesticides has caused harm to biodiversity and a proven rise in cancer incidents."
        },
        {
            "type": "subjective",
            "q": "Describe the conditions for growth and areas of production of cotton in India.",
            "sample": "Conditions for growth of cotton: (1) Temperature — cotton is a kharif crop requiring a uniformly high temperature from 21°C to 30°C. During the day, the temperature should be above 26°C for ripening and bursting of cotton bolls. (2) Rainfall — about 50 to 80 cm of well-distributed rainfall. (3) Soil — lava soil that is black and clayey (Black soil), formed from volcanic ash. It has high clay content and retains water well. Areas in India: The leading cotton-growing states are Maharashtra, Gujarat, Telangana, Andhra Pradesh, Madhya Pradesh, Haryana and Rajasthan."
        },
        {
            "type": "subjective",
            "q": "Why is jute called the 'golden fibre'? Describe its conditions for growth and uses.",
            "sample": "Jute is called the 'golden fibre' because of its shiny golden colour. It is a long, soft vegetable fibre that can be spun into strong but coarse threads. It is the most affordable natural fibre, biodegradable and environment-friendly. Conditions for growth: (1) Temperature — kharif crop sown around February/March; needs a hot and humid climate; humidity around 80–90 per cent; average temperature 24°C to 35°C. (2) Rainfall — heavy rainfall, more than 150 cm. (3) Soil — alluvial and clayey soil in flood plains and the Ganga-Brahmaputra Delta. Uses: ropes, curtains, carpets, sacks, packaging material. India is the largest producer; West Bengal is the largest producing state."
        },
        {
            "type": "subjective",
            "q": "Describe the conditions required for tea cultivation and name the major tea-producing regions of India.",
            "sample": "Conditions for tea cultivation: (1) Temperature — grows well in tropical and subtropical regions; temperatures between 21°C and 31°C; above 32°C is not favourable. (2) Rainfall — between 150 cm to 200 cm; water must not be stagnant. (3) Soil — well-drained and rich in humus and organic matter. Tea bushes grow best in hilly regions where water does not stagnate. Major tea-producing regions in India: Assam, West Bengal (finest quality from Darjiling hill slopes), Tamil Nadu and Kerala. Other regions: Sikkim, Tripura, Arunachal Pradesh and the Kangra hills of northern India."
        },
        {
            "type": "subjective",
            "q": "How is rubber obtained? Describe the conditions for its growth and areas of production.",
            "sample": "Rubber is made from the sap (latex) of the rubber tree. Latex is collected in small cups attached to the tree. It takes six years before trees produce sap. The latex is taken to the factory where it is purified, dried and made into rubber sheets. From these sheets, tyres, tubes and other products are manufactured. Conditions for growth: (1) Temperature — tropical countries; 20°C to 35°C. (2) Rainfall — heavy rainfall, 200–300 cm annually; over 75 per cent humidity. (3) Soil — well-drained loamy or laterite soil on hill slopes. World's largest producer: Thailand, followed by Indonesia, Vietnam, India and China. In India: Kerala, Tamil Nadu, Tripura, Assam and Meghalaya."
        },
        {
            "type": "subjective",
            "q": "Compare rice and wheat cultivation — temperature, rainfall, soil and major producing areas in India.",
            "sample": "Rice: Temperature — 20°C to 30°C. Rainfall — about 150–200 cm. Soil — fertile, clayey and loamy soil that holds water. Major areas in India — Gangetic Plains, Brahmaputra Plains (Assam), eastern coastal regions, western coastal plains, Punjab and Haryana. Wheat: Temperature — 10°C to 15°C for sowing; 20°C to 25°C for ripening. Rainfall — about 50 to 100 cm during growing season; about 80 cm annually. Soil — well-drained alluvial soil, loams and clay loams. Major areas in India — Uttar Pradesh (leading producer), Punjab, Haryana, Madhya Pradesh, Rajasthan, Bihar, Gujarat and Maharashtra."
        },
        {
            "type": "subjective",
            "q": "What is the impact of the Green Revolution on the economic development of India?",
            "sample": "Impact of the Green Revolution: (1) Phenomenal increase in food grain production — total increase was more than two times, wheat production increased by more than three times. (2) India became self-sufficient in food grains and drastically reduced imports. (3) Farmers' incomes increased, allowing them to improve agricultural productivity further. (4) Led to growth in industrial sector — increased demand for agricultural machines like tractors, threshers and combine harvesters. (5) Created new jobs due to multiple cropping and use of fertilizers. (6) Expansion of fertilizer and pesticide manufacturing industries. (7) The Green Revolution changed the basic attitude of farmers from traditional methods to modern scientific cultivation."
        },
        {
            "type": "subjective",
            "q": "What are food crops and cash crops? Give three examples of each with one use of each.",
            "sample": "Food crops are grown primarily to provide food for people. They include cereals, pulses and spices. Examples: (1) Rice — provides carbohydrate, staple for over 50% of world's population. (2) Wheat — used for making bread, chapati, etc. (3) Maize — used for cornflour, cooking oil and animal feed. Cash crops are grown primarily for cash or commercial purposes and sold for profit. Examples: (1) Sugar cane — used to produce sugar, jaggery, molasses and ethanol. (2) Cotton — used to make textiles and cloth. (3) Jute — used to make ropes, sacks, curtains, carpets and packaging materials."
        },
        {
            "type": "subjective",
            "q": "Describe the conditions for growing coffee and name major producing regions in India and the world.",
            "sample": "Conditions for growing coffee: (1) Temperature — coffee plants thrive in hot and humid climate; average temperature 15°C to 28°C. (2) Rainfall — must be between 150 cm and 200 cm. Temperature must not exceed 30°C. Strong direct sun is not good, so coffee is grown under large shady trees. (3) Soil — loamy and well-drained; must contain plenty of iron and calcium. In India: Karnataka (54%), Kerala (19%) and Tamil Nadu (8%). India is the fifth largest producer; nearly 70% of India's coffee is exported to European and Asian markets. World's major producers: Brazil (largest), Vietnam, Indonesia, Colombia, Ethiopia and Honduras."
        },
        {
            "type": "subjective",
            "q": "Why was the Green Revolution not equally beneficial for poor farmers?",
            "sample": "The Green Revolution was not equally beneficial for poor farmers because: (1) Benefits were confined mainly to rich farmers who could invest huge amounts in HYV seeds, fertilizers, latest machines, etc. (2) Poor farmers could not afford the new and expensive varieties of seeds. (3) The cost of fertilizers, pesticides and machinery increased beyond the reach of the average farmer. (4) Farmers were encouraged to take loans but many ended up incurring large debts without any protection in case their crops failed. (5) New machinery replaced manual labour, leading to unemployment among farm workers who were mostly poor. (6) The HYV crops required abundant water supply, but arranging irrigation for this became a time-consuming and expensive exercise for small farmers who lacked resources."
        },
        {
            "type": "subjective",
            "q": "Name and describe any two zaid crops and explain their importance.",
            "sample": "Zaid crops are grown from March to June. Two important zaid crops are: (1) Watermelon — a fruit crop grown in the zaid season requiring warm temperatures and sandy loam soil. It is widely consumed in summer months across India and provides hydration and essential nutrients during the hot season. It is also a commercial crop earning good income for farmers during summer. (2) Bitter gourd (karela) — a vegetable grown in the zaid season. It is known for medicinal properties and is used in managing diabetes and other health conditions. Importance: Zaid crops fill the agricultural gap between the rabi and kharif seasons, allowing farmers to earn income throughout the year and ensuring a continuous supply of vegetables and fruits to consumers during the summer months."
        },
        {
            "type": "subjective",
            "q": "What is sugar cane? Describe its products and importance to India's economy.",
            "sample": "Sugar cane is a popular kharif crop grown in the tropical and subtropical parts of the world. It belongs to the grass family. Sugar cane stalks grow from 2 m to 6 m in height. From sugar cane juice, the following products are made: sugar, molasses, jaggery (gur), ethanol and industrial alcohol. The crushed fibre, bagasse, is used for paper and fibre boards. India is the second-largest sugar cane producer in the world after Brazil. According to 2022 reports, India emerged as the world's largest producer and consumer of sugar and the world's second largest exporter of sugar. Uttar Pradesh is the number-one producer in India. The success of the sugar industry in India is attributed to the combined efforts of Central and State Governments, farmers, sugar mills and ethanol distilleries."
        },
        {
            "type": "subjective",
            "q": "Describe the contribution of M. S. Swaminathan to Indian agriculture.",
            "sample": "M. S. Swaminathan, born on 7 August 1925, earned the title 'Father of the Green Revolution'. He created high-yield wheat variants and subsequently championed sustainable progress under the term 'evergreen revolution'. In the 1960s, India faced an imminent famine, prompting Swaminathan, Norman Borlaug and fellow scientists to devise high-yield wheat seeds. His contribution was crucial in transforming India from a food-deficient nation to a food-surplus nation. Time magazine recognized his influence, listing him among the 20th century's most impactful Asians in 1999. In 1967 and 1972, the Indian government honoured him with the Padma Shri and Padma Bhushan awards. His work on sustainable agriculture continues to influence food policy in India and around the world."
        },
        {
            "type": "subjective",
            "q": "Explain the northern and southern sugar cane producing belts of India.",
            "sample": "India has two distinct sugar cane-producing regions — the northern belt and the southern belt. The northern belt comprises Punjab, Haryana, Uttarakhand, Uttar Pradesh and Bihar. Uttar Pradesh is the number-one producer in India. The northern belt grows sugar cane in the fertile Gangetic Plains with alluvial soil and good river water irrigation. The southern belt comprises Maharashtra, Karnataka, Tamil Nadu, Telangana and Andhra Pradesh. The lava soil of the Deccan in Maharashtra is well known for sugar cane cultivation. Maharashtra is the second largest producer in India. The European Union, China, Thailand, Pakistan, Mexico and Indonesia are some of the other important sugar cane-growing regions of the world."
        },
        {
            "type": "subjective",
            "q": "What are fodder crops? Give examples and explain why they are important in mixed farming.",
            "sample": "Fodder crops are those crops which are mainly grown for the purpose of feeding and fattening livestock. They are different from food crops (for human consumption) and cash crops (for sale). Examples of fodder crops: maize and oats. Importance in mixed farming: (1) In mixed farming, farmers grow crops and also rear cows, goats and poultry on the same land. Fodder crops provide nutritious feed for these animals. (2) Animals fed on fodder crops provide milk, meat and wool, giving farmers multiple sources of income. (3) The manure from animals fed on fodder crops is used as natural fertilizer, which improves soil fertility. (4) This creates a sustainable farming cycle that reduces the need for chemical fertilizers. (5) Countries with large animal populations like Australia, USA and European nations depend heavily on fodder crop cultivation."
        },
        {
            "type": "subjective",
            "q": "Describe the importance of cotton to India's textile industry.",
            "sample": "Cotton is the most important of all fibres used in the world. India is often referred to as the 'birthplace of cotton' as cultivation began here around 3000 BCE. In 2022, India was the largest producer of cotton, followed by China and USA. Cotton is important to India's textile industry because: (1) It is the raw material for India's huge textile and garment industry, one of the largest in the world. (2) Cotton seeds are used as animal feed, edible oil and in pharmaceuticals. (3) Egypt cotton, which has the longest fibre length of 7.4 inches, is especially valued. (4) Cotton absorbs water, making it suitable for clothing in India's hot climate. (5) The textile industry is one of India's largest employers and a significant contributor to export earnings. The leading cotton-growing states are Maharashtra, Gujarat, Telangana, Andhra Pradesh and Madhya Pradesh."
        },
        {
            "type": "subjective",
            "q": "Describe the jute industry in India and its global significance.",
            "sample": "The jute industry is one of India's oldest industries. The country has been trading in this versatile fibre for hundreds of years. West Bengal, Bihar and Assam have millions of people engaged in jute cultivation and trade. India ranks first globally in jute production. The jute plant's stem and ribbon (outer skin) are used to produce jute fibre. Jute export: Jute products are in high demand outside India. In 2022, India exported jute products valued at more than ₹37,000 million to other countries. Jute is biodegradable and environmental-friendly. This 'golden fibre' undergoes processes such as spinning, weaving, bleaching, dyeing and finishing. Due to its versatility, natural jute is used to make ropes, curtains, carpets, sacks, etc. Jute is a very sturdy and safe packaging material and is the most affordable natural fibre that can be made into many useful products."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 7: Minerals and Ores
    # ──────────────────────────────────────────────────────────────────
    "Chapter 7 — Minerals and Ores": [

        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "Minerals are natural substances that have:",
            "options": ["Indefinite shapes", "Definite chemical compositions", "Always the same colour", "No economic value"],
            "answer": "Definite chemical compositions",
            "explanation": "Minerals are natural substances that have definite chemical compositions."
        },
        {
            "type": "mcq",
            "q": "There are about _______ known types of minerals.",
            "options": ["500", "1,500", "3,500", "5,000"],
            "answer": "3,500",
            "explanation": "There are about 3,500 known types of minerals."
        },
        {
            "type": "mcq",
            "q": "An ore is a naturally occurring solid material from which a mineral can be:",
            "options": ["Observed", "Profitably extracted", "Created synthetically", "Dissolved in water"],
            "answer": "Profitably extracted",
            "explanation": "An ore is a naturally occurring solid material that contains a large amount of a particular mineral, usually a metal, which can be profitably extracted."
        },
        {
            "type": "mcq",
            "q": "Minerals are obtained by a process called:",
            "options": ["Smelting", "Farming", "Mining", "Refining"],
            "answer": "Mining",
            "explanation": "Minerals are obtained by a process called mining."
        },
        {
            "type": "mcq",
            "q": "Depending on their physical and chemical properties, minerals can be classified as:",
            "options": ["Hard and soft", "Metallic and non-metallic", "Solid and liquid", "Organic and inorganic"],
            "answer": "Metallic and non-metallic",
            "explanation": "Depending on their physical and chemical properties, minerals can be classified as metallic and non-metallic."
        },
        {
            "type": "mcq",
            "q": "Ferrous minerals are those that contain:",
            "options": ["Gold", "Copper", "Iron", "Silver"],
            "answer": "Iron",
            "explanation": "Ferrous minerals are those that contain iron, such as iron ore, manganese and chrome."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a non-ferrous mineral?",
            "options": ["Iron ore", "Manganese", "Chrome", "Copper"],
            "answer": "Copper",
            "explanation": "Non-ferrous minerals are those that do not contain iron, such as gold, silver, copper and lead."
        },
        {
            "type": "mcq",
            "q": "The most important mineral in the world is:",
            "options": ["Gold", "Iron ore", "Copper", "Uranium"],
            "answer": "Iron ore",
            "explanation": "The most important mineral in the world is iron ore."
        },
        {
            "type": "mcq",
            "q": "Which type of iron ore is the most abundant and contains 70 per cent iron?",
            "options": ["Magnetite", "Limonite", "Haematite", "Siderite"],
            "answer": "Haematite",
            "explanation": "Haematite is the most abundant of all ores and contains 70 per cent iron. It is the natural ore and is reddish in colour."
        },
        {
            "type": "mcq",
            "q": "Magnetite is also known as 'black ore' because it is:",
            "options": ["Found in black coal mines", "Deep brown or almost black in colour", "The rarest iron ore", "Radioactive"],
            "answer": "Deep brown or almost black in colour",
            "explanation": "Magnetite is deep brown or almost black in colour and is therefore also known as 'black ore'."
        },
        {
            "type": "mcq",
            "q": "Which type of iron ore is the inferior variety containing only about 48 per cent iron?",
            "options": ["Haematite", "Magnetite", "Limonite", "Siderite"],
            "answer": "Siderite",
            "explanation": "Siderite is an inferior variety of iron ore since it contains only about 48 per cent iron."
        },
        {
            "type": "mcq",
            "q": "In 2021, which country was the largest iron ore-producing country?",
            "options": ["China", "Brazil", "India", "Australia"],
            "answer": "Australia",
            "explanation": "In 2021, Australia was the largest iron ore producing country (912 million tonnes), followed by Brazil (380 million tonnes), China (360 million tonnes) and India (240 million tonnes)."
        },
        {
            "type": "mcq",
            "q": "Uranium is used in nuclear power plants as:",
            "options": ["A coolant", "Fuel", "Building material", "A lubricant"],
            "answer": "Fuel",
            "explanation": "Uranium is used in nuclear power plants as fuel. It is also used by the army in specialized ammunitions."
        },
        {
            "type": "mcq",
            "q": "Bauxite is a clay-like substance from which _______ is extracted.",
            "options": ["Iron", "Copper", "Aluminium", "Gold"],
            "answer": "Aluminium",
            "explanation": "Bauxite is a clay-like substance that contains several minerals, from which alumina, and later aluminium, is extracted."
        },
        {
            "type": "mcq",
            "q": "Bauxite is used in the aircraft industry because it is the:",
            "options": ["Heaviest metal", "Lightest metal", "Strongest metal", "Most magnetic metal"],
            "answer": "Lightest metal",
            "explanation": "Bauxite is the lightest metal, which is why it is used in the aircraft industry."
        },
        {
            "type": "mcq",
            "q": "Which country is the world's largest producer of bauxite?",
            "options": ["China", "India", "USA", "Australia"],
            "answer": "Australia",
            "explanation": "Australia accounts for over 28 per cent of its global bauxite production. The world's largest bauxite mine, Weipa Mine, is in Australia."
        },
        {
            "type": "mcq",
            "q": "The word 'manganese' comes from the Latin word 'magnes' meaning:",
            "options": ["Metal", "Magnet", "Man", "Mineral"],
            "answer": "Magnet",
            "explanation": "The word 'manganese' comes from the Latin word 'magnes' meaning magnet."
        },
        {
            "type": "mcq",
            "q": "Gold gives _______ to a country in economic crisis.",
            "options": ["Military power", "Economic security", "Industrial capacity", "Agricultural wealth"],
            "answer": "Economic security",
            "explanation": "Gold gives economic security to a country in economic crisis."
        },
        {
            "type": "mcq",
            "q": "In 2021, which country was the largest producer of gold in the world?",
            "options": ["South Africa", "USA", "Australia", "China"],
            "answer": "China",
            "explanation": "China was the largest producer of gold in the world in 2021 and accounted for around 9 per cent of total global production."
        },
        {
            "type": "mcq",
            "q": "Silver is the best conductor of:",
            "options": ["Sound and light", "Heat and electricity", "Electricity only", "Heat only"],
            "answer": "Heat and electricity",
            "explanation": "Silver is the best conductor of heat and electricity."
        },
        {
            "type": "mcq",
            "q": "In 2021, the largest producer of silver was:",
            "options": ["China", "India", "Mexico", "Peru"],
            "answer": "Mexico",
            "explanation": "In 2021, Mexico was the largest producer of silver in the world, producing nearly 24 per cent of global production."
        },
        {
            "type": "mcq",
            "q": "Alloys such as brass and bronze are produced using:",
            "options": ["Iron", "Manganese", "Copper", "Silver"],
            "answer": "Copper",
            "explanation": "Copper is an excellent conductor of heat and electricity. Alloys such as brass and bronze are produced using copper."
        },
        {
            "type": "mcq",
            "q": "The world's largest copper mine (Escondida) is located in:",
            "options": ["Peru", "Democratic Republic of Congo", "Northern Chile", "Australia"],
            "answer": "Northern Chile",
            "explanation": "Escondida, located in the Atacama Desert in Northern Chile, is the world's largest copper mine."
        },
        {
            "type": "mcq",
            "q": "Khetri in Rajasthan is the most important _______ producing centre in India.",
            "options": ["Gold", "Silver", "Copper", "Manganese"],
            "answer": "Copper",
            "explanation": "Khetri in Rajasthan is the most important copper-producing centre in India."
        },
        {
            "type": "mcq",
            "q": "Limestone is generally used as a:",
            "options": ["Fuel", "Construction material and for treating wastewater", "Conductor of electricity", "Lightweight metal"],
            "answer": "Construction material and for treating wastewater",
            "explanation": "Limestone is generally used as a construction material. It is also used to treat wastewater."
        },
        {
            "type": "mcq",
            "q": "In India, about _______ of the total limestone produced is used in the cement industry.",
            "options": ["50 per cent", "64 per cent", "94 per cent", "80 per cent"],
            "answer": "94 per cent",
            "explanation": "In India, almost 94 per cent of the total limestone produced is used in the cement industry."
        },
        {
            "type": "mcq",
            "q": "Mica is used in the glass-making and electrical industries. It is also used for:",
            "options": ["Making steel", "Insulation and heat resistance", "Mining fuels", "Making weapons"],
            "answer": "Insulation and heat resistance",
            "explanation": "Mica is used in the glass-making and electrical industries. It is also used for insulation and heat resistance."
        },
        {
            "type": "mcq",
            "q": "Which type of coal has the highest carbon content at 90 per cent?",
            "options": ["Bituminous", "Lignite", "Peat", "Anthracite"],
            "answer": "Anthracite",
            "explanation": "On the basis of carbon content: Anthracite (90%), Bituminous (65%), Lignite (40%) and Peat (very little carbon)."
        },
        {
            "type": "mcq",
            "q": "In 2021, the largest producer of coal in the world was:",
            "options": ["USA", "India", "Indonesia", "China"],
            "answer": "China",
            "explanation": "China is the largest producer of coal in the world. In 2021, China produced over 50 per cent of the coal produced worldwide."
        },
        {
            "type": "mcq",
            "q": "Petroleum is also known as:",
            "options": ["Coal oil only", "Mineral oil, rock oil and crude oil", "Black powder", "Natural petroleum"],
            "answer": "Mineral oil, rock oil and crude oil",
            "explanation": "Petroleum is also known as mineral oil, rock oil and crude oil."
        },
        {
            "type": "mcq",
            "q": "In surface mining, the large pits dug to extract minerals are called:",
            "options": ["Underground mines", "Open cast mines or quarries", "Shafts", "Tunnels"],
            "answer": "Open cast mines or quarries",
            "explanation": "These pits are called open cast mines or quarries. Open cast mining is a common form of coal mining in India."
        },
        {
            "type": "mcq",
            "q": "In underground mining, a shaft is:",
            "options": ["A flat pit on the surface", "A long, narrow passage dug vertically deep into the ground", "A horizontal tunnel only", "An open quarry"],
            "answer": "A long, narrow passage dug vertically deep into the ground",
            "explanation": "In underground mining, a shaft, which is a long, narrow passage, is dug vertically deep into the ground."
        },
        {
            "type": "mcq",
            "q": "Petroleum is formed from plants and animals that sank into the ocean and hardened into:",
            "options": ["Igneous rocks", "Metamorphic rocks", "Sedimentary rocks", "Volcanic rocks"],
            "answer": "Sedimentary rocks",
            "explanation": "Petroleum is the product of plants and animals that sank into the ocean and were buried under many layers of sand and hardened into sedimentary rocks."
        },
        {
            "type": "mcq",
            "q": "Natural gas deposits are generally found with:",
            "options": ["Coal deposits", "Petroleum deposits", "Iron ore deposits", "Bauxite deposits"],
            "answer": "Petroleum deposits",
            "explanation": "Natural gas deposits are generally found with petroleum deposits."
        },
        {
            "type": "mcq",
            "q": "OPEC was founded in 1960 by five major petroleum-producing countries. Which of the following was NOT a founding member?",
            "options": ["Iran", "Iraq", "Kuwait", "Russia"],
            "answer": "Russia",
            "explanation": "OPEC was founded in 1960 by Iran, Iraq, Kuwait, Saudi Arabia and Venezuela. Russia is not a founding member."
        },
        {
            "type": "mcq",
            "q": "The formula for conservation of minerals is:",
            "options": ["Reduce, Reuse and Recycle", "Replace, Reuse and Restore", "Remove, Reduce and Replace", "Reserve, Reuse and Restore"],
            "answer": "Reduce, Reuse and Recycle",
            "explanation": "By practising the formula of 'reuse', 'recycle' and 'reduce', we can save a lot of our metallic and non-metallic minerals."
        },
        {
            "type": "mcq",
            "q": "SAIL produces iron and steel at how many integrated plants?",
            "options": ["Three", "Four", "Five", "Seven"],
            "answer": "Five",
            "explanation": "SAIL produces iron and steel at five integrated plants and three special steel plants, located mainly in the eastern and central regions of India."
        },
        {
            "type": "mcq",
            "q": "Iron ore in India is found mainly in which states?",
            "options": ["Punjab, Haryana and Uttar Pradesh", "Odisha, Madhya Pradesh, Jharkhand, Andhra Pradesh and Tamil Nadu", "Kerala, Karnataka and Goa", "Rajasthan, Gujarat and Maharashtra"],
            "answer": "Odisha, Madhya Pradesh, Jharkhand, Andhra Pradesh and Tamil Nadu",
            "explanation": "Iron ore in India is found in Odisha, Madhya Pradesh, Jharkhand, Andhra Pradesh and Tamil Nadu."
        },
        {
            "type": "mcq",
            "q": "Coal is an exhaustible mineral not expected to last for more than:",
            "options": ["50 years", "100 years", "200 years", "500 years"],
            "answer": "100 years",
            "explanation": "Coal is an exhaustible mineral and is not expected to last for more than 100 years."
        },
        {
            "type": "mcq",
            "q": "Which mineral is used as fuel in nuclear power plants AND in specialized army ammunitions?",
            "options": ["Coal", "Petroleum", "Uranium", "Manganese"],
            "answer": "Uranium",
            "explanation": "Uranium is used in nuclear power plants as fuel. It is also used by the army in specialized ammunitions."
        },

        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "Minerals are natural substances with definite chemical compositions.",
            "answer": "True",
            "explanation": "Minerals are natural substances that have definite chemical compositions."
        },
        {
            "type": "tf",
            "q": "All rocks are composed of minerals.",
            "answer": "True",
            "explanation": "All rocks are composed of minerals."
        },
        {
            "type": "tf",
            "q": "Minerals can be created artificially in laboratories very easily.",
            "answer": "False",
            "explanation": "Minerals are natural substances. They are not created artificially; they occur naturally and take thousands of years to form."
        },
        {
            "type": "tf",
            "q": "Ferrous minerals do not contain iron.",
            "answer": "False",
            "explanation": "Ferrous minerals are those that contain iron, such as iron ore, manganese and chrome."
        },
        {
            "type": "tf",
            "q": "Metallic minerals are found in igneous and metamorphic rocks.",
            "answer": "True",
            "explanation": "Metallic minerals are found in igneous and metamorphic rocks."
        },
        {
            "type": "tf",
            "q": "Non-metallic minerals have a shiny appearance.",
            "answer": "False",
            "explanation": "Metallic minerals have a shiny appearance. Non-metallic minerals have a dull appearance."
        },
        {
            "type": "tf",
            "q": "Haematite is the most abundant iron ore and contains 70 per cent iron.",
            "answer": "True",
            "explanation": "Haematite is the most abundant of all ores and contains 70 per cent iron."
        },
        {
            "type": "tf",
            "q": "Magnetite is the best quality iron ore and contains almost 75 per cent iron.",
            "answer": "True",
            "explanation": "Magnetite is the best quality iron ore. It contains almost 75 per cent iron."
        },
        {
            "type": "tf",
            "q": "Siderite contains the highest percentage of iron among all iron ores.",
            "answer": "False",
            "explanation": "Siderite is an inferior variety with only about 48 per cent iron. Magnetite has the highest iron content at 75 per cent."
        },
        {
            "type": "tf",
            "q": "Australia was the largest iron ore-producing country in 2021.",
            "answer": "True",
            "explanation": "In 2021, Australia was the largest iron ore producing country with 912 million tonnes."
        },
        {
            "type": "tf",
            "q": "Uranium is used in nuclear power plants as fuel.",
            "answer": "True",
            "explanation": "Uranium is used in nuclear power plants as fuel and also by the army in specialized ammunitions."
        },
        {
            "type": "tf",
            "q": "Bauxite is the heaviest metal, which is why it is used in the aircraft industry.",
            "answer": "False",
            "explanation": "Bauxite is the lightest metal, not the heaviest. That is why it is used in the aircraft industry."
        },
        {
            "type": "tf",
            "q": "Gold is the most malleable and ductile of all the elements.",
            "answer": "True",
            "explanation": "Gold is an excellent conductor of heat and electricity. It is the most malleable and ductile of all the elements."
        },
        {
            "type": "tf",
            "q": "Silver is a poor conductor of electricity.",
            "answer": "False",
            "explanation": "Silver is the best conductor of heat and electricity."
        },
        {
            "type": "tf",
            "q": "Copper is used for making electric and telephone wires.",
            "answer": "True",
            "explanation": "Copper is used for making electric and telephone wires. It is also used for making pipes and coins."
        },
        {
            "type": "tf",
            "q": "Chile produces about 50 per cent of the world's copper.",
            "answer": "False",
            "explanation": "Chile produces nearly 25 per cent of the world's copper, not 50 per cent."
        },
        {
            "type": "tf",
            "q": "Limestone is an inorganic mineral that contains calcium.",
            "answer": "True",
            "explanation": "Limestone is inorganic and contains calcium."
        },
        {
            "type": "tf",
            "q": "Mica is used in the glass-making and electrical industries.",
            "answer": "True",
            "explanation": "Mica is used in the glass-making and electrical industries. It is also used for insulation and heat resistance."
        },
        {
            "type": "tf",
            "q": "Anthracite coal has the lowest carbon content among all types of coal.",
            "answer": "False",
            "explanation": "Anthracite has the highest carbon content (90 per cent). Peat has very little carbon and is the lowest quality coal."
        },
        {
            "type": "tf",
            "q": "Petroleum is a major conventional energy resource sometimes called 'black gold'.",
            "answer": "True",
            "explanation": "Petroleum is a major conventional energy resource. Because of its wide use, it is sometimes referred to as 'black gold'."
        },
        {
            "type": "tf",
            "q": "Natural gas is a mixture of hydrocarbons, primarily methane, found along with petroleum.",
            "answer": "True",
            "explanation": "Natural gas is a mixture of hydrocarbons, primarily methane, found along with petroleum."
        },
        {
            "type": "tf",
            "q": "Surface mining preserves trees and natural vegetation.",
            "answer": "False",
            "explanation": "In surface mining, trees and other natural vegetation are destroyed."
        },
        {
            "type": "tf",
            "q": "Underground mining causes sinking of the land and underground water pollution.",
            "answer": "True",
            "explanation": "Underground mining causes sinking of the land, underground water pollution and surface water pollution, among other things."
        },
        {
            "type": "tf",
            "q": "Minerals are renewable resources that can be replenished quickly.",
            "answer": "False",
            "explanation": "Minerals are non-renewable resources. Once used, our mineral resources cannot be replaced. They take thousands of years to form."
        },
        {
            "type": "tf",
            "q": "OPEC was founded in 1960 by five major producers of petroleum.",
            "answer": "True",
            "explanation": "OPEC was founded in 1960 by five major producers of petroleum: Iran, Iraq, Kuwait, Saudi Arabia and Venezuela."
        },
        {
            "type": "tf",
            "q": "Coal is expected to last for more than 500 years.",
            "answer": "False",
            "explanation": "Coal is an exhaustible mineral and is not expected to last for more than 100 years."
        },
        {
            "type": "tf",
            "q": "India is the largest producer of uranium in the world.",
            "answer": "False",
            "explanation": "India produces less than 1 per cent of the total uranium produced in the world. Kazakhstan, Australia, Namibia, Uzbekistan and Canada were the top five in 2021."
        },
        {
            "type": "tf",
            "q": "Metallic minerals are generally found in sedimentary rocks.",
            "answer": "False",
            "explanation": "Metallic minerals are generally found in igneous and metamorphic rocks. Non-metallic minerals are found in sedimentary rocks."
        },
        {
            "type": "tf",
            "q": "Gold and silver are both precious metals used in making jewellery.",
            "answer": "True",
            "explanation": "Gold is mostly used in the manufacturing of jewellery. Silver is also a precious metal used in making jewellery."
        },
        {
            "type": "tf",
            "q": "Petroleum is found in porous sedimentary rocks in the earth.",
            "answer": "True",
            "explanation": "Petroleum is a black, greenish or brown liquid found in porous sedimentary rocks in the earth."
        },
        {
            "type": "tf",
            "q": "Open cast mining is a type of underground mining.",
            "answer": "False",
            "explanation": "Open cast mining (quarrying) is a type of surface mining, not underground mining."
        },
        {
            "type": "tf",
            "q": "The availability of minerals plays a crucial role in the economic development of a country.",
            "answer": "True",
            "explanation": "The availability of minerals plays a crucial role in the economic development of a country."
        },
        {
            "type": "tf",
            "q": "Manganese is never found as a free metal in nature.",
            "answer": "True",
            "explanation": "Manganese is a grey-white metal that breaks easily but is very hard. It is never found as a free metal in nature."
        },
        {
            "type": "tf",
            "q": "Coal is a sedimentary rock formed from the decayed remains of plants and trees.",
            "answer": "True",
            "explanation": "Coal is a sedimentary rock that is formed from the decayed remains of plants and trees. Coal has a high percentage of carbon."
        },
        {
            "type": "tf",
            "q": "The United States was the largest producer of natural gas in 2021.",
            "answer": "True",
            "explanation": "In 2021, the United States was the largest producer of natural gas in the world — it produced approximately 934 billion cubic metres."
        },
        {
            "type": "tf",
            "q": "Limonite is a yellowish coloured iron ore that contains about 60 per cent iron.",
            "answer": "True",
            "explanation": "Limonite is a yellowish coloured iron ore containing about 60 per cent iron. When exposed to air and water it turns yellowish."
        },
        {
            "type": "tf",
            "q": "Minerals are exhaustible resources that cannot be replaced once used.",
            "answer": "True",
            "explanation": "Minerals are non-renewable resources. Once used, our mineral resources cannot be replaced."
        },
        {
            "type": "tf",
            "q": "Compressed Natural Gas (CNG) is an eco-friendly automobile fuel that causes a lot of pollution.",
            "answer": "False",
            "explanation": "Compressed natural gas (CNG) is an eco-friendly automobile fuel that causes little pollution. Public transport in many large Indian cities uses this fuel."
        },
        {
            "type": "tf",
            "q": "Bauxite is used in both the aircraft industry and the electrical industry.",
            "answer": "True",
            "explanation": "Bauxite is the lightest metal, used in the aircraft industry. Also, being a good conductor of electricity, bauxite is very important for the electrical industry."
        },
        {
            "type": "tf",
            "q": "Mica mines in India are located in Hazaribagh in Jharkhand and Munger in Bihar.",
            "answer": "True",
            "explanation": "Mica mines are located in Hazaribagh in Jharkhand and Munger in Bihar."
        },

        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "What are minerals? Describe any five characteristics of minerals.",
            "sample": "Minerals are natural substances that have definite chemical compositions. All rocks are composed of minerals. There are about 3,500 known types of minerals. Five characteristics: (1) They are mostly solid in form. (2) They are naturally occurring substances having similar characteristics. (3) They are of various colours. (4) They are not pure substances. (5) They are exhaustible — they can be used up. Minerals can be recognized from their colour, lustre (shine), hardness and shape. Examples: diamonds, quartz, topaz, gypsum."
        },
        {
            "type": "subjective",
            "q": "Differentiate between metallic and non-metallic minerals with examples.",
            "sample": "Metallic minerals: (1) These minerals contain metals. (2) They have a shiny appearance. (3) Found in igneous and metamorphic rocks. (4) They are ductile and malleable. (5) Good conductors of heat and electricity. (6) High melting point. (7) Found only in solid state at room temperature. Examples: iron ore, gold, copper, uranium, bauxite. Non-metallic minerals: (1) Do not contain metals. (2) Dull appearance. (3) Found in sedimentary rocks. (4) Soft and breakable. (5) Bad conductors of heat and electricity. (6) Very low melting point. (7) Exist in all states at room temperature. Examples: limestone, mica, coal, petroleum, natural gas."
        },
        {
            "type": "subjective",
            "q": "Name and describe the four types of iron ore.",
            "sample": "The four types of iron ore are: (1) Haematite — the most abundant of all ores; contains 70 per cent iron; the natural ore and is reddish in colour. (2) Magnetite — the best quality iron ore; contains almost 75 per cent iron; has properties of a magnet; deep brown or almost black in colour; also known as 'black ore'. (3) Limonite — a yellowish coloured iron ore; contains about 60 per cent iron; closer to the earth's surface so easier and cheaper to mine; turns yellowish when exposed to air and water. (4) Siderite — an inferior variety of iron ore; contains only about 48 per cent iron."
        },
        {
            "type": "subjective",
            "q": "What is uranium? Describe its properties, uses and areas of production.",
            "sample": "Uranium is a hard silvery material. It is highly malleable (can be made into different shapes) and ductile. It can be found in very small traces in the rocks on the earth's surface, waters, ocean waters and some minerals found in the earth's crust. Uses: (1) Used in nuclear power plants as fuel. (2) Used by the army in specialized ammunitions. World distribution: Kazakhstan, Australia, Namibia, Uzbekistan and Canada were the top five uranium-producing countries in 2021. In India: Uranium is found in East Singhbhum in Jharkhand. India produces less than 1 per cent of the total uranium produced in the world."
        },
        {
            "type": "subjective",
            "q": "Why is bauxite an important mineral? Describe its properties, uses and distribution in India.",
            "sample": "Bauxite is an important mineral because aluminium — the metal with the widest industrial applications — is extracted from it. Properties: It is a clay-like substance; pinkish, whitish or reddish in colour depending on iron content; it is the lightest metal. Uses: (1) Used in the aircraft industry because it is the lightest metal. (2) Very important for the electrical industry as it is a good conductor of electricity. World distribution: Australia (largest producer, 28% global production), China. In India: Jharkhand, Chhattisgarh, Maharashtra and Odisha."
        },
        {
            "type": "subjective",
            "q": "Describe the properties and uses of gold and silver. Where are they found in India?",
            "sample": "Gold: Soft, yellow metal with a beautiful glossy shine. Precious metal found in very limited quantity. Excellent conductor of heat and electricity. Most malleable and ductile of all elements. Uses: Manufacturing of jewellery; valued as a medium of foreign trade; gives economic security to a country in economic crisis. In India: Karnataka and Andhra Pradesh. Silver: Soft and lustrous metal. Best conductor of heat and electricity. Strong, ductile and malleable. Can endure extreme temperature ranges and reflects light very well. Uses: Precious metal used in making jewellery; also used in electrical components and coins. In India: Jharkhand, Karnataka and Rajasthan."
        },
        {
            "type": "subjective",
            "q": "What is petroleum? How is it formed and what are its major uses?",
            "sample": "Petroleum is the most important fuel in the world. It is also known as mineral oil, rock oil and crude oil. Formation: Petroleum is the product of plants and animals that sank into the ocean and were buried under many layers of sand and hardened into sedimentary rocks. It is a major conventional energy resource and sometimes referred to as 'black gold'. Major uses: Once petroleum is refined, we obtain petrol, diesel, kerosene, cooking gas, etc. Vehicles such as cars, trucks and trains run on petrol and diesel. Natural gas from petroleum deposits is used as fuel in cars, buses, etc. Petroleum is also used to make synthetic fibres, synthetic rubber, varnish, paints, grease, lubricating oils, detergents, fertilizers, pesticides, cosmetics, plastic products, pharmaceutical products, food colours, dyes, motion picture films and many other things."
        },
        {
            "type": "subjective",
            "q": "Explain the two types of mining. What are the environmental effects of each?",
            "sample": "Two types of mining: (1) Surface mining — the top layer of soil is removed, large pits or holes (open cast mines/quarries) are dug and rocks underneath are extracted using heavy machinery. Done for minerals close to the surface such as coal, limestone and mica. Environmental effects: trees and other natural vegetation are destroyed; soil erosion occurs; habitats of wildlife are disturbed. (2) Underground mining — a shaft (long, narrow passage) is dug vertically deep into the ground; people and machinery are sent down; tunnels are blasted using dynamite; minerals like coal, gold, silver, tin, lead and copper are extracted. Environmental effects: sinking of the land, underground water pollution and surface water pollution; dangerous for workers. Both types harm the environment — surface mining destroys above-ground ecosystems, while underground mining causes subsurface damage."
        },
        {
            "type": "subjective",
            "q": "Why is it important to conserve minerals? Suggest four methods of conservation.",
            "sample": "Importance of conserving minerals: Minerals are non-renewable resources that have taken thousands of years to form. They are being used at a very fast rate and are getting depleted. Once used, they cannot be replaced. Growing population demands are leading to overuse. Coal may not last more than 100 years. Four methods of conservation: (1) Judicious use — avoid wastage of energy resources. (2) Practise the formula of 'reuse', 'recycle' and 'reduce' — recycling scrap metals, for example, reduces the demand for freshly mined ore. (3) Use alternative energy sources — solar energy, wind energy and water (hydroelectricity) to reduce dependence on coal and petroleum. (4) Insulate buildings; turn off lights and fans when not required; use public transport, carpooling or cycling to save fuel."
        },
        {
            "type": "subjective",
            "q": "Describe the importance of minerals in our daily lives with specific examples.",
            "sample": "Minerals play an important role in our daily lives. Things of daily use such as door knobs, latches, window grills and utensils are made of minerals. Specific examples: (1) Iron and its alloy steel — used in making bridges, buildings and a wide range of machines and tools. (2) Copper wires — used in electrical and electronic gadgets. Copper tools and utensils are also widely used. (3) Gold and silver — used in making jewellery. (4) Aluminium extracted from bauxite — used to make aeroplanes, the fastest means of transport. (5) Mica — used in electrical goods. (6) Limestone — used as cement in constructing houses and buildings. (7) Coal, petroleum and natural gas — important energy or power resources used for cooking, heating and electricity generation. A majority of large-scale industries depend on minerals as their raw materials."
        },
        {
            "type": "subjective",
            "q": "What is coal? Name its four types and explain its importance.",
            "sample": "Coal is a sedimentary rock that is formed from the decayed remains of plants and trees. Coal has a high percentage of carbon. It is a non-renewable energy resource and a major conventional energy resource. Four types based on carbon content: (1) Anthracite — 90 per cent carbon, highest quality. (2) Bituminous — 65 per cent carbon, most commonly used in industries. (3) Lignite — 40 per cent carbon, lower quality. (4) Peat — very little carbon, lowest quality. Importance: (1) Used for cooking, heating and producing electricity. (2) Used in steel manufacturing. (3) Major fuel for thermal power plants. India's major coal-producing states: Jharkhand, Odisha, Madhya Pradesh and Chhattisgarh. World's largest producer: China (over 50% in 2021). Coal is exhaustible and not expected to last more than 100 years."
        },
        {
            "type": "subjective",
            "q": "What is an ore? How is it different from a mineral? Give examples.",
            "sample": "A mineral is a natural substance with a definite chemical composition. All rocks are composed of minerals; there are about 3,500 known types. An ore is a naturally occurring solid material that contains a large amount of a particular mineral, usually a metal, which can be profitably extracted. The key difference: all ores are minerals but not all minerals are ores. An ore is a mineral (or combination of minerals) from which a valuable substance — usually a metal — can be extracted economically. Examples: Iron ore (haematite, magnetite, limonite, siderite) — iron is extracted. Bauxite — aluminium is extracted. Copper ores — copper is extracted. Other examples of ores: zinc, lead and manganese ores."
        },
        {
            "type": "subjective",
            "q": "Describe the distribution of iron ore in India and the world.",
            "sample": "World distribution: In 2021, Australia was the largest iron ore-producing country (912 million tonnes), followed by Brazil (380 million tonnes), China (360 million tonnes) and India (240 million tonnes). Other major producers include Russia, Ukraine, Canada, Kazakhstan, Iran and the USA. Distribution in India: Iron ore is found mainly in: (1) Odisha — a major producer. (2) Madhya Pradesh — significant reserves. (3) Jharkhand — rich in iron ore. (4) Andhra Pradesh — important producing area. (5) Tamil Nadu — also produces iron ore. The igneous and metamorphic rocks of central and southern peninsular India are rich in mineral resources including iron ore. SAIL operates five integrated steel plants mainly in the eastern and central regions, located close to iron ore sources."
        },
        {
            "type": "subjective",
            "q": "What is the significance of SAIL (Steel Authority of India Limited)?",
            "sample": "The Steel Authority of India Limited (SAIL) is one of the largest steel companies in India and one of the country's important public sector enterprises. Significance: (1) SAIL produces iron and steel at five integrated plants and three special steel plants, located mainly in the eastern and central regions of India. (2) These plants are situated close to sources of raw materials needed to produce steel — iron ore, coal, limestone and water. (3) SAIL manufactures and sells many steel products for industrial and domestic uses. (4) A wide network of sales offices, warehouses, dealers and a team of engineers ensure quick and adequate supply of steel and steel products across the country. (5) SAIL supports India's infrastructure and industrial development by providing steel for construction, transportation and manufacturing."
        },
        {
            "type": "subjective",
            "q": "What is OPEC? Explain its role in the world economy.",
            "sample": "OPEC stands for the Organization of the Petroleum Exporting Countries. It was founded in 1960 by five major producers of petroleum: Iran, Iraq, Kuwait, Saudi Arabia and Venezuela. As of 2021, 15 nations were members of OPEC. Role in the world economy: (1) OPEC plays a major role in deciding the prices of oil — about 37 per cent of the total global share of crude oil production is contributed by OPEC. (2) By controlling supply, OPEC influences global oil prices — when OPEC reduces production, oil prices tend to rise; when it increases production, prices tend to fall. (3) This gives member nations significant economic and political leverage. (4) Decisions made by OPEC affect industries, transportation and the cost of living in countries all around the world."
        },
        {
            "type": "subjective",
            "q": "Describe copper — its properties, uses and major producing areas in India and the world.",
            "sample": "Copper is a soft metal that has a bright metallic lustre. It is reddish orange in colour. It is malleable and ductile. Copper is an excellent conductor of heat and electricity. Alloys such as brass and bronze are produced using copper. Uses: (1) Used for making electric and telephone wires. (2) Used for making pipes and coins. (3) Used in manufacturing electrical and electronic gadgets. World production: Leading copper-producing countries in 2021 were Chile, Peru and the Democratic Republic of the Congo. Chile produces nearly 25 per cent of the world's copper. Escondida, located in the Atacama Desert in Northern Chile, is the world's largest copper mine. In India: Copper is found in Jharkhand, Chhattisgarh, Madhya Pradesh, Andhra Pradesh and Karnataka. Khetri in Rajasthan is the most important copper-producing centre in India."
        },
        {
            "type": "subjective",
            "q": "What is the Sustainable Development Goal 12 and how does it relate to minerals?",
            "sample": "SDG 12 is about Responsible Consumption and Production. As it relates to minerals: Our reserves of raw mineral resources are limited. Many mineral deposits have been depleted. As ores for minerals like bauxite and iron become harder to find and extract, their prices rise very high, making tools and machinery more expensive to purchase and operate. The common mining methods like surface mining destroy the environment — they harm soil, plants and animal habitats. Some of these methods also pollute water and air as toxic chemicals are released. Therefore, less wasteful mining methods and the recycling of materials have become inevitable. In Japan, car manufacturers recycle many raw materials used in making automobiles. In the USA and India, iron from recycled automobiles and scrap metals reduces mineral consumption. This aligns with SDG 12 — consuming minerals responsibly and minimizing waste."
        },
        {
            "type": "subjective",
            "q": "Describe the non-metallic minerals limestone and mica — their properties, uses and areas of production.",
            "sample": "Limestone: It is inorganic and contains calcium. It is generally used as a construction material. It is also used to treat wastewater. There is increased demand for decorative uses; used to make wall tiles and floor tiles. In India, almost 94 per cent of limestone produced is used in the cement industry (5% in iron and steel, 1% in chemicals, sugar, glass and fertilizers). Three leading limestone-producing countries in 2022: China, USA and India. In India: Rajasthan, Madhya Pradesh, Chhattisgarh, Odisha, Jharkhand, Telangana, Andhra Pradesh, Karnataka and Tamil Nadu. Mica: It is brownish in colour and an excellent conductor of electricity. Used in glass-making and electrical industries. Also used for insulation and heat resistance, and in some electronic and automotive products; used in cosmetic products and paint. World's largest mica producer in 2022: China (about 1,00,000 metric tonnes). India is also a major producer; mica mines are in Hazaribagh (Jharkhand) and Munger (Bihar)."
        },
        {
            "type": "subjective",
            "q": "Explain the contribution of Dorabji Tata to India's iron and steel industry.",
            "sample": "Dorabji Tata was born on 27 August 1859 in Paris and was a prominent Indian industrialist and a key figure in Tata Group's diversification, particularly in iron and steel. He led extensive explorations for optimal iron ore sources, with a focus on Chhattisgarh, known for rich mineral deposits. His efforts led to founding the Tata Iron and Steel Company in 1907 in Jamshedpur, using advanced methods to produce high-quality steel vital for India's industrial growth and infrastructure. This was one of the first large-scale steel plants in Asia and marked a milestone in Indian industrial history. His work laid the foundation for India's iron and steel industry and significantly contributed to the country's economic development."
        },
        {
            "type": "subjective",
            "q": "What is manganese? Describe its properties, uses and areas of production.",
            "sample": "Manganese is a grey-white metal that breaks easily but is very hard. It is never found as a free metal in nature. The word 'manganese' comes from the Latin word 'magnes' meaning magnet. It is found in a number of minerals of different chemical and physical properties. Uses: (1) Used in industries such as glass, chemicals, batteries, insecticides, plastics, potteries, paints and bleaching powder. (2) Mainly used in the production of steel — it is used to produce steel of varying hardness. Areas of production: South Africa was the world's largest producer of manganese — it produced 19.16 million metric tonnes in 2021. Gabon was the second largest producer. India was the 6th largest of the world's manganese producers. In India: Odisha, Madhya Pradesh, Jharkhand and Karnataka."
        },
    ]
                                                 }
