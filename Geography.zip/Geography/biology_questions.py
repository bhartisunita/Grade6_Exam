"""
Biology — Grade 6 ICSE
Chapter 3: The Cell
Comprehensive Practice Questions
50 MCQ • 50 True/False • 40 Subjective
"""

QUESTIONS = {

    "Chapter 3 — The Cell": [
        # ===== MCQ (50 questions) =====
        {
            "type": "mcq",
            "q": "Who discovered cells for the first time?",
            "options": [
                "Anton Van Leeuwenhoek",
                "Robert Hooke",
                "Robert Brown",
                "Matthias Schleiden"
            ],
            "answer": "Robert Hooke",
            "explanation": "Robert Hooke discovered cells in 1665 while observing a thin slice of cork under his compound microscope."
        },
        {
            "type": "mcq",
            "q": "The word 'cell' is derived from which Latin word?",
            "options": [
                "Cellula",
                "Cellular",
                "Cellaris",
                "Cellarius"
            ],
            "answer": "Cellula",
            "explanation": "The word 'cell' comes from the Latin word 'cellula', meaning 'small compartment'."
        },
        {
            "type": "mcq",
            "q": "Who developed the first simple microscope?",
            "options": [
                "Robert Hooke",
                "Anton Van Leeuwenhoek",
                "Robert Brown",
                "Theodor Schwann"
            ],
            "answer": "Anton Van Leeuwenhoek",
            "explanation": "Leeuwenhoek developed the first simple microscope made up of a single lens and observed blood cells and single-celled organisms."
        },
        {
            "type": "mcq",
            "q": "What did Robert Hooke observe under his microscope?",
            "options": [
                "Living cells",
                "Thin slice of cork",
                "Blood cells",
                "Bacteria"
            ],
            "answer": "Thin slice of cork",
            "explanation": "Robert Hooke studied a thin slice of cork and observed small box-like structures which he called 'cells'."
        },
        {
            "type": "mcq",
            "q": "What type of cells did Robert Hooke actually observe?",
            "options": [
                "Living cells",
                "Dead cells",
                "Muscle cells",
                "Nerve cells"
            ],
            "answer": "Dead cells",
            "explanation": "Cork is obtained from the bark of a tree and is made up of cells which were once living, so Hooke observed dead cells."
        },
        {
            "type": "mcq",
            "q": "Who coined the term 'nucleus'?",
            "options": [
                "Robert Hooke",
                "Anton Van Leeuwenhoek",
                "Robert Brown",
                "Ruth Nanda Anshen"
            ],
            "answer": "Robert Brown",
            "explanation": "Robert Brown, a British botanist, coined the term 'nucleus' while studying orchid cells."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a unicellular organism?",
            "options": [
                "Human",
                "Mango tree",
                "Amoeba",
                "Bird"
            ],
            "answer": "Amoeba",
            "explanation": "Amoeba is a unicellular organism made up of a single cell, while humans, mango trees, and birds are multicellular."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a multicellular organism?",
            "options": [
                "Bacteria",
                "Paramecium",
                "Chlamydomonas",
                "Rose"
            ],
            "answer": "Rose",
            "explanation": "Rose is a multicellular plant; bacteria, Paramecium, and Chlamydomonas are unicellular organisms."
        },
        {
            "type": "mcq",
            "q": "Which organism keeps changing its shape?",
            "options": [
                "Paramecium",
                "Amoeba",
                "Chlamydomonas",
                "Euglena"
            ],
            "answer": "Amoeba",
            "explanation": "Amoeba does not have a fixed shape and keeps changing its shape constantly."
        },
        {
            "type": "mcq",
            "q": "What is the shape of Paramecium?",
            "options": [
                "Irregular",
                "Oval",
                "Slipper-shaped or oblong",
                "Thread-like"
            ],
            "answer": "Slipper-shaped or oblong",
            "explanation": "Paramecium is made up of a single slipper-shaped or oblong cell."
        },
        {
            "type": "mcq",
            "q": "Which cells in the human body are elongated and contractile?",
            "options": [
                "Nerve cells",
                "Blood cells",
                "Muscle cells",
                "Skin cells"
            ],
            "answer": "Muscle cells",
            "explanation": "Muscle cells are elongated and can contract and relax, helping in movement."
        },
        {
            "type": "mcq",
            "q": "Which cells in the human body are long and thread-like?",
            "options": [
                "Muscle cells",
                "Nerve cells",
                "Bone cells",
                "Blood cells"
            ],
            "answer": "Nerve cells",
            "explanation": "Nerve cells are long and thread-like to transmit impulses throughout the body."
        },
        {
            "type": "mcq",
            "q": "What is the average size range of most cells?",
            "options": [
                "1 to 3 microns",
                "3 to 30 microns",
                "30 to 100 microns",
                "100 to 500 microns"
            ],
            "answer": "3 to 30 microns",
            "explanation": "The average cell size ranges from 3 to 30 micrometres (microns)."
        },
        {
            "type": "mcq",
            "q": "What is one micron equal to?",
            "options": [
                "One-thousandth of a millimetre",
                "One-hundredth of a millimetre",
                "One-tenth of a millimetre",
                "One-millionth of a millimetre"
            ],
            "answer": "One-thousandth of a millimetre",
            "explanation": "One micron (micrometre) is equal to one-thousandth of a millimetre."
        },
        {
            "type": "mcq",
            "q": "What are the smallest cells in the human body?",
            "options": [
                "Nerve cells",
                "Muscle cells",
                "Red blood cells",
                "Skin cells"
            ],
            "answer": "Red blood cells",
            "explanation": "Red blood cells are the smallest cells in the human body."
        },
        {
            "type": "mcq",
            "q": "What is the size range of bacterial cells?",
            "options": [
                "0.2 to 0.5 micron",
                "2 to 5 microns",
                "10 to 20 microns",
                "20 to 50 microns"
            ],
            "answer": "0.2 to 0.5 micron",
            "explanation": "The smallest cells are those of bacteria, ranging from 0.2 to 0.5 micron in diameter."
        },
        {
            "type": "mcq",
            "q": "How long is an ostrich egg?",
            "options": [
                "About 6 cm",
                "About 15 cm",
                "About 23 cm",
                "About 30 cm"
            ],
            "answer": "About 23 cm",
            "explanation": "An ostrich egg measures about 23 cm in length, while a hen's egg measures about 6 cm."
        },
        {
            "type": "mcq",
            "q": "How long can a nerve cell of an elephant be?",
            "options": [
                "1 metre",
                "2 metres",
                "3 metres",
                "5 metres"
            ],
            "answer": "3 metres",
            "explanation": "A nerve cell of an elephant can be as long as 3 metres."
        },
        {
            "type": "mcq",
            "q": "What is the jelly-like substance inside a cell called?",
            "options": [
                "Nucleus",
                "Cytoplasm",
                "Protoplasm",
                "Cell membrane"
            ],
            "answer": "Protoplasm",
            "explanation": "The cell is filled with a jelly-like substance called protoplasm."
        },
        {
            "type": "mcq",
            "q": "What are the two parts of protoplasm?",
            "options": [
                "Nucleus and cytoplasm",
                "Cell wall and cell membrane",
                "Mitochondria and ribosomes",
                "Vacuole and chloroplast"
            ],
            "answer": "Nucleus and cytoplasm",
            "explanation": "Protoplasm has two parts - a darker denser part called nucleus and a semi-solid jelly-like part called cytoplasm."
        },
        {
            "type": "mcq",
            "q": "Which part of the cell is called the control centre?",
            "options": [
                "Cytoplasm",
                "Nucleus",
                "Mitochondria",
                "Cell membrane"
            ],
            "answer": "Nucleus",
            "explanation": "The nucleus controls all vital activities of a cell and is called the control centre."
        },
        {
            "type": "mcq",
            "q": "What is the outer covering of a cell called?",
            "options": [
                "Cell wall",
                "Cell membrane or plasma membrane",
                "Nuclear membrane",
                "Tonoplast"
            ],
            "answer": "Cell membrane or plasma membrane",
            "explanation": "Each cell is bound by a thin delicate skin-like membrane called the cell membrane or plasma membrane."
        },
        {
            "type": "mcq",
            "q": "Why is the cell membrane called selectively permeable?",
            "options": [
                "It allows all substances to pass through",
                "It allows only selective substances to pass through",
                "It allows no substances to pass through",
                "It allows only water to pass through"
            ],
            "answer": "It allows only selective substances to pass through",
            "explanation": "The cell membrane allows only selective substances to pass through it, hence it is called a selectively permeable membrane."
        },
        {
            "type": "mcq",
            "q": "Which of the following is found only in plant cells?",
            "options": [
                "Cell membrane",
                "Nucleus",
                "Cell wall",
                "Cytoplasm"
            ],
            "answer": "Cell wall",
            "explanation": "Cell wall is an additional protective wall found only in plant cells around the cell membrane."
        },
        {
            "type": "mcq",
            "q": "What is the cell wall made up of?",
            "options": [
                "Protein",
                "Cellulose",
                "Fat",
                "Starch"
            ],
            "answer": "Cellulose",
            "explanation": "The cell wall is made up of a complex carbohydrate called cellulose."
        },
        {
            "type": "mcq",
            "q": "The cell wall is:",
            "options": [
                "Selectively permeable",
                "Impermeable",
                "Permeable",
                "Semi-permeable"
            ],
            "answer": "Permeable",
            "explanation": "The cell wall is permeable, meaning it allows free passage of substances through it."
        },
        {
            "type": "mcq",
            "q": "The cell membrane is:",
            "options": [
                "Permeable",
                "Impermeable",
                "Selectively permeable",
                "Non-living"
            ],
            "answer": "Selectively permeable",
            "explanation": "The cell membrane is selectively permeable, allowing only selective substances to pass through."
        },
        {
            "type": "mcq",
            "q": "Which organelle is known as the powerhouse of the cell?",
            "options": [
                "Nucleus",
                "Mitochondria",
                "Chloroplast",
                "Ribosome"
            ],
            "answer": "Mitochondria",
            "explanation": "Mitochondria are called the powerhouses of the cell because they release energy in the form of ATP during respiration."
        },
        {
            "type": "mcq",
            "q": "What are the finger-like structures inside mitochondria called?",
            "options": [
                "Granum",
                "Cristae",
                "Cisternae",
                "Stroma"
            ],
            "answer": "Cristae",
            "explanation": "The inner membrane of mitochondria is folded to form finger-like structures called cristae."
        },
        {
            "type": "mcq",
            "q": "Which organelle is known as the protein factory of the cell?",
            "options": [
                "Golgi bodies",
                "Ribosomes",
                "Lysosomes",
                "Endoplasmic reticulum"
            ],
            "answer": "Ribosomes",
            "explanation": "Ribosomes synthesize proteins in the cell, so they are called protein factories."
        },
        {
            "type": "mcq",
            "q": "Where are ribosomes found in a cell?",
            "options": [
                "Only in nucleus",
                "Only in cytoplasm",
                "In cytoplasm or attached to endoplasmic reticulum",
                "Only on cell membrane"
            ],
            "answer": "In cytoplasm or attached to endoplasmic reticulum",
            "explanation": "Ribosomes are present either in a free state in the cytoplasm or attached to the endoplasmic reticulum."
        },
        {
            "type": "mcq",
            "q": "Which organelle is called the 'suicide bag' of the cell?",
            "options": [
                "Mitochondria",
                "Lysosome",
                "Ribosome",
                "Golgi body"
            ],
            "answer": "Lysosome",
            "explanation": "Lysosomes contain enzymes that can digest other cell organelles under certain conditions, so they are called suicide bags."
        },
        {
            "type": "mcq",
            "q": "What is the function of lysosomes?",
            "options": [
                "Protein synthesis",
                "Digestion of food within the cell",
                "Energy production",
                "Photosynthesis"
            ],
            "answer": "Digestion of food within the cell",
            "explanation": "Lysosomes contain enzymes that help in the digestion of food within the cell."
        },
        {
            "type": "mcq",
            "q": "Which organelle is found only in animal cells and helps in cell division?",
            "options": [
                "Centrosome",
                "Plastids",
                "Vacuole",
                "Cell wall"
            ],
            "answer": "Centrosome",
            "explanation": "Centrosome is a small organelle found only in animal cells that helps in cell division."
        },
        {
            "type": "mcq",
            "q": "What does the centrosome contain?",
            "options": [
                "One centriole",
                "Two tiny granules called centrioles",
                "Many centrioles",
                "No centrioles"
            ],
            "answer": "Two tiny granules called centrioles",
            "explanation": "The centrosome has two tiny granules called centrioles."
        },
        {
            "type": "mcq",
            "q": "Which plastid contains chlorophyll?",
            "options": [
                "Chromoplast",
                "Leucoplast",
                "Chloroplast",
                "Amyloplast"
            ],
            "answer": "Chloroplast",
            "explanation": "Chloroplasts contain the green pigment called chlorophyll."
        },
        {
            "type": "mcq",
            "q": "What is the function of chloroplasts?",
            "options": [
                "Store food",
                "Perform photosynthesis",
                "Give colour to flowers",
                "Store starch"
            ],
            "answer": "Perform photosynthesis",
            "explanation": "Chloroplasts trap solar energy to perform photosynthesis, so they are called the kitchen of the cell."
        },
        {
            "type": "mcq",
            "q": "Which plastids give colour to fruits and flowers?",
            "options": [
                "Chloroplasts",
                "Chromoplasts",
                "Leucoplasts",
                "Amyloplasts"
            ],
            "answer": "Chromoplasts",
            "explanation": "Chromoplasts are plastids with coloured pigments other than green, found in fruits and petals of flowers."
        },
        {
            "type": "mcq",
            "q": "Which plastids store food in plants?",
            "options": [
                "Chloroplasts",
                "Chromoplasts",
                "Leucoplasts",
                "All of these"
            ],
            "answer": "Leucoplasts",
            "explanation": "Leucoplasts are colourless plastids that store food in the form of starch, proteins, and fats."
        },
        {
            "type": "mcq",
            "q": "What is the membrane surrounding a vacuole called?",
            "options": [
                "Cell membrane",
                "Nuclear membrane",
                "Tonoplast",
                "Plasma membrane"
            ],
            "answer": "Tonoplast",
            "explanation": "A vacuole is bound by a single membrane called tonoplast."
        },
        {
            "type": "mcq",
            "q": "What is the fluid inside a vacuole called?",
            "options": [
                "Cytoplasm",
                "Nucleoplasm",
                "Cell sap",
                "Protoplasm"
            ],
            "answer": "Cell sap",
            "explanation": "The membrane of a vacuole encloses a fluid called cell sap, containing sugars, proteins, amino acids, and minerals."
        },
        {
            "type": "mcq",
            "q": "Which of the following is present in plant cells but absent in animal cells?",
            "options": [
                "Mitochondria",
                "Ribosomes",
                "Plastids",
                "Golgi bodies"
            ],
            "answer": "Plastids",
            "explanation": "Plastids are present only in plant cells, not in animal cells."
        },
        {
            "type": "mcq",
            "q": "Which of the following is present in animal cells but absent in plant cells?",
            "options": [
                "Cell wall",
                "Plastids",
                "Centrosome",
                "Large vacuole"
            ],
            "answer": "Centrosome",
            "explanation": "Centrosome is present in animal cells but absent in plant cells."
        },
        {
            "type": "mcq",
            "q": "The red blood cells in our body do not have:",
            "options": [
                "Cytoplasm",
                "Cell membrane",
                "Nucleus",
                "Haemoglobin"
            ],
            "answer": "Nucleus",
            "explanation": "Mature red blood cells in humans do not have a nucleus, which provides more space for haemoglobin."
        },
        {
            "type": "mcq",
            "q": "How many chromosomes do human beings have?",
            "options": [
                "23",
                "46",
                "24",
                "48"
            ],
            "answer": "46",
            "explanation": "Human beings have 46 chromosomes in each cell."
        },
        {
            "type": "mcq",
            "q": "How many chromosomes does an onion have?",
            "options": [
                "8",
                "16",
                "24",
                "32"
            ],
            "answer": "16",
            "explanation": "Onion cells have 16 chromosomes."
        },
        {
            "type": "mcq",
            "q": "What is the thread-like structure in the nucleus called?",
            "options": [
                "Chromosomes",
                "Chromatin network",
                "Nucleolus",
                "Nucleoplasm"
            ],
            "answer": "Chromatin network",
            "explanation": "The nucleoplasm contains a network of thread-like structures called the chromatin network."
        },
        {
            "type": "mcq",
            "q": "What do chromosomes carry?",
            "options": [
                "Proteins",
                "Fats",
                "Genes",
                "Vitamins"
            ],
            "answer": "Genes",
            "explanation": "Chromosomes carry genes, which are responsible for hereditary characters."
        },
        {
            "type": "mcq",
            "q": "The process by which new cells are formed is called:",
            "options": [
                "Cell growth",
                "Cell division",
                "Cell digestion",
                "Cell respiration"
            ],
            "answer": "Cell division",
            "explanation": "The process by which new cells are formed is known as cell division."
        },
        {
            "type": "mcq",
            "q": "The new cells formed through cell division are called:",
            "options": [
                "Parent cells",
                "Daughter cells",
                "Sister cells",
                "Brother cells"
            ],
            "answer": "Daughter cells",
            "explanation": "The new cells formed through cell division are known as daughter cells."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a cell organelle?",
            "options": [
                "Mitochondria",
                "Ribosome",
                "Cell inclusions",
                "Golgi body"
            ],
            "answer": "Cell inclusions",
            "explanation": "Cell inclusions are non-living substances in the cell, not organelles. Organelles are living structures."
        },
        
        # ===== True/False (50 questions) =====
        {
            "type": "tf",
            "q": "Cells were discovered after the invention of the microscope.",
            "answer": "True",
            "explanation": "Cells are too small to be seen with the naked eye and were discovered only after microscopes were invented."
        },
        {
            "type": "tf",
            "q": "Anton Van Leeuwenhoek was the first to call the structures he observed as 'cells'.",
            "answer": "False",
            "explanation": "Leeuwenhoek observed living organisms but did not call them cells. Robert Hooke coined the term 'cells'."
        },
        {
            "type": "tf",
            "q": "Robert Hooke used a compound microscope with two lenses.",
            "answer": "True",
            "explanation": "Robert Hooke devised a compound microscope using two lenses to study thin slices of cork."
        },
        {
            "type": "tf",
            "q": "All organisms start their life as a single cell.",
            "answer": "True",
            "explanation": "Every living organism begins life as a single cell, which then divides and grows."
        },
        {
            "type": "tf",
            "q": "Bacteria are made up of many cells.",
            "answer": "False",
            "explanation": "Bacteria are unicellular organisms made up of a single cell."
        },
        {
            "type": "tf",
            "q": "Human beings are made up of billions of cells.",
            "answer": "True",
            "explanation": "Humans are multicellular organisms composed of billions of cells."
        },
        {
            "type": "tf",
            "q": "All cells in a human body have the same shape.",
            "answer": "False",
            "explanation": "Human body has different types of cells with different shapes - blood cells, skin cells, nerve cells, muscle cells, etc."
        },
        {
            "type": "tf",
            "q": "Amoeba has a constant shape throughout its life.",
            "answer": "False",
            "explanation": "Amoeba keeps changing its shape constantly and does not have a fixed shape."
        },
        {
            "type": "tf",
            "q": "White blood cells have a fixed shape.",
            "answer": "False",
            "explanation": "White blood cells are irregular in shape and can change their shape like Amoeba."
        },
        {
            "type": "tf",
            "q": "Chlamydomonas has an oval-shaped body.",
            "answer": "True",
            "explanation": "Chlamydomonas is a unicellular organism with an oval-shaped body."
        },
        {
            "type": "tf",
            "q": "Nerve cells are long and thread-like.",
            "answer": "True",
            "explanation": "Nerve cells are elongated and thread-like to transmit impulses throughout the body."
        },
        {
            "type": "tf",
            "q": "Muscle cells are long and thread-like like nerve cells.",
            "answer": "False",
            "explanation": "Muscle cells are elongated and contractile, but not thread-like like nerve cells."
        },
        {
            "type": "tf",
            "q": "A hen's egg is larger than an ostrich's egg.",
            "answer": "False",
            "explanation": "An ostrich's egg (about 23 cm) is much larger than a hen's egg (about 6 cm)."
        },
        {
            "type": "tf",
            "q": "The size of cells is measured in centimetres.",
            "answer": "False",
            "explanation": "Most cells are microscopic and their size is measured in micrometres or microns, not centimetres."
        },
        {
            "type": "tf",
            "q": "One micron is one-thousandth of a millimetre.",
            "answer": "True",
            "explanation": "1 micron (micrometre) = 1/1000 millimetre."
        },
        {
            "type": "tf",
            "q": "Bacterial cells are among the largest cells.",
            "answer": "False",
            "explanation": "Bacterial cells are among the smallest cells, ranging from 0.2 to 0.5 micron in diameter."
        },
        {
            "type": "tf",
            "q": "Red blood cells are the smallest cells in the human body.",
            "answer": "True",
            "explanation": "Red blood cells are the smallest cells in the human body."
        },
        {
            "type": "tf",
            "q": "Paramecium is a multicellular organism.",
            "answer": "False",
            "explanation": "Paramecium is a unicellular organism made up of a single cell."
        },
        {
            "type": "tf",
            "q": "Cells in the outer layer of animal skin are flat to cover a large area.",
            "answer": "True",
            "explanation": "Flat cells in the skin help to cover and protect larger surface areas."
        },
        {
            "type": "tf",
            "q": "The study of cells is called cell biology.",
            "answer": "True",
            "explanation": "Cell biology is the branch of biology that studies cells."
        },
        {
            "type": "tf",
            "q": "All cells have the same basic structure regardless of their shape and size.",
            "answer": "True",
            "explanation": "Even though cells vary in shape and size, their basic structure is almost similar."
        },
        {
            "type": "tf",
            "q": "The cell membrane is non-living.",
            "answer": "False",
            "explanation": "The cell membrane is living and elastic in nature."
        },
        {
            "type": "tf",
            "q": "The cell wall is a living structure.",
            "answer": "False",
            "explanation": "The cell wall is non-living and made up of cellulose."
        },
        {
            "type": "tf",
            "q": "The cell wall is found in both plant and animal cells.",
            "answer": "False",
            "explanation": "The cell wall is found only in plant cells and bacterial cells, not in animal cells."
        },
        {
            "type": "tf",
            "q": "The cell membrane is elastic and enables the cell to stretch.",
            "answer": "True",
            "explanation": "The cell membrane is elastic in nature and allows the cell to stretch to some extent."
        },
        {
            "type": "tf",
            "q": "The nucleus is surrounded by a single membrane.",
            "answer": "False",
            "explanation": "The nucleus is surrounded by a double membrane called the nuclear membrane."
        },
        {
            "type": "tf",
            "q": "The nucleolus is present inside the nucleus.",
            "answer": "True",
            "explanation": "The nucleus contains one or more spherical bodies called nucleolus (plural: nucleoli)."
        },
        {
            "type": "tf",
            "q": "Chromatin network is found in the cytoplasm.",
            "answer": "False",
            "explanation": "The chromatin network is found in the nucleoplasm inside the nucleus."
        },
        {
            "type": "tf",
            "q": "When a cell divides, the chromatin network forms chromosomes.",
            "answer": "True",
            "explanation": "During cell division, the chromatin network condenses to form thread-like chromosomes."
        },
        {
            "type": "tf",
            "q": "Genes are responsible for hereditary characters.",
            "answer": "True",
            "explanation": "Genes carry hereditary information from parents to offspring."
        },
        {
            "type": "tf",
            "q": "Every species has a fixed number of chromosomes.",
            "answer": "True",
            "explanation": "Each species has a characteristic and fixed number of chromosomes."
        },
        {
            "type": "tf",
            "q": "Rice has 16 chromosomes.",
            "answer": "False",
            "explanation": "Rice has 24 chromosomes, not 16. Onion has 16 chromosomes."
        },
        {
            "type": "tf",
            "q": "Dogs have 60 chromosomes.",
            "answer": "True",
            "explanation": "Dogs have 60 chromosomes in their cells."
        },
        {
            "type": "tf",
            "q": "Mitochondria are rod-shaped or spherical organelles.",
            "answer": "True",
            "explanation": "Mitochondria are small, rod-shaped or spherical organelles found in large numbers."
        },
        {
            "type": "tf",
            "q": "ATP is the energy currency of the cell.",
            "answer": "True",
            "explanation": "ATP (Adenosine Triphosphate) is the energy molecule produced in mitochondria."
        },
        {
            "type": "tf",
            "q": "Endoplasmic reticulum provides internal support to the cell.",
            "answer": "True",
            "explanation": "ER is a network of tubes that gives internal support and provides a pathway for transport."
        },
        {
            "type": "tf",
            "q": "Ribosomes are bound by a membrane.",
            "answer": "False",
            "explanation": "Ribosomes are not bound by any membrane."
        },
        {
            "type": "tf",
            "q": "Golgi bodies are called dictyosomes in plant cells.",
            "answer": "True",
            "explanation": "In plant cells, Golgi bodies are smaller, unconnected, and called dictyosomes."
        },
        {
            "type": "tf",
            "q": "Lysosomes protect the cell against foreign bodies.",
            "answer": "True",
            "explanation": "Lysosomes contain enzymes that digest foreign materials and protect the cell."
        },
        {
            "type": "tf",
            "q": "Centrosome is found in both plant and animal cells.",
            "answer": "False",
            "explanation": "Centrosome is found only in animal cells, not in plant cells."
        },
        {
            "type": "tf",
            "q": "Plastids are found only in plant cells.",
            "answer": "True",
            "explanation": "Plastids are special organelles found only in plant cells."
        },
        {
            "type": "tf",
            "q": "Chloroplasts have two regions - grana and stroma.",
            "answer": "True",
            "explanation": "A chloroplast shows two regions - grana (stack of discs) and stroma (fluid matrix)."
        },
        {
            "type": "tf",
            "q": "Chromoplasts impart green colour to leaves.",
            "answer": "False",
            "explanation": "Chloroplasts impart green colour. Chromoplasts give red, orange, or yellow colour to fruits and flowers."
        },
        {
            "type": "tf",
            "q": "Leucoplasts store food in plants.",
            "answer": "True",
            "explanation": "Leucoplasts are colourless plastids that store starch, proteins, and fats."
        },
        {
            "type": "tf",
            "q": "Vacuoles in plant cells are very small or absent.",
            "answer": "False",
            "explanation": "Plant cells have large vacuoles, sometimes just one large vacuole, while animal cells have small or no vacuoles."
        },
        {
            "type": "tf",
            "q": "Cell inclusions are living substances in the cell.",
            "answer": "False",
            "explanation": "Cell inclusions are non-living substances, such as starch, oil globules, gums, and resins."
        },
        {
            "type": "tf",
            "q": "Lysosomes are present in plant cells.",
            "answer": "False",
            "explanation": "Lysosomes are present in animal cells but absent in plant cells."
        },
        {
            "type": "tf",
            "q": "Cell division is needed for growth and to replace dead cells.",
            "answer": "True",
            "explanation": "New cells are formed through cell division for growth and to replace old and worn-out cells."
        },
        {
            "type": "tf",
            "q": "Human cheek cells have a cell wall.",
            "answer": "False",
            "explanation": "Human cheek cells are animal cells and do not have a cell wall."
        },
        {
            "type": "tf",
            "q": "Onion peel cells are plant cells with a cell wall.",
            "answer": "True",
            "explanation": "Onion peel cells are plant cells and have a cell wall, which gives them a rectangular shape."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "Describe the discovery of the cell. Who discovered cells and how?",
            "sample": "The discovery of the cell:\n\nCells were discovered after the invention of the microscope.\n\nAnton Van Leeuwenhoek (1632-1723):\n- Dutch scientist who developed the first simple microscope with a single lens\n- Observed blood cells in the capillaries of a frog's webbed foot\n- Observed tiny single-celled organisms in a drop of water\n- First to recognize these as living units, but did not call them cells\n\nRobert Hooke (1635-1703):\n- English scientist who devised a compound microscope using two lenses\n- Studied a thin slice of cork under his microscope in 1665\n- Observed small box-like structures and called them 'cells'\n- The word 'cell' comes from Latin 'cellula' meaning 'small compartment'\n- Actually observed dead cells since cork comes from tree bark\n\nThus, Robert Hooke is credited with discovering and naming cells for the first time in 1665."
        },
        {
            "type": "subjective",
            "q": "Why is the cell called the structural and functional unit of life? Explain.",
            "sample": "The cell is called the structural and functional unit of life because:\n\nStructural unit:\n- All living organisms are made up of cells\n- Cells are the building blocks of life\n- Many cells together form tissues, tissues form organs, and organs form organ systems\n- Even the largest organism starts life as a single cell\n\nFunctional unit:\n- A cell is capable of independent existence\n- It can perform all essential functions for survival\n- Any function performed by an organism is due to the activity of its cells\n- Examples:\n  * Root cells absorb water and minerals from soil\n  * Leaf cells with chlorophyll prepare food by photosynthesis\n  * Muscle cells contract and relax for movement\n  * Nerve cells transmit impulses\n- Cells can live, grow, reproduce, and respond to stimuli\n\nTherefore, the cell is both the structural building block and the functional unit capable of performing life processes."
        },
        {
            "type": "subjective",
            "q": "Explain the diversity in cells with respect to shape, size, and number.",
            "sample": "Cells show great diversity in shape, size, and number across different organisms:\n\nA. Shape of cells:\n1. Irregular: Amoeba and white blood cells (change shape constantly)\n2. Oval: Chlamydomonas\n3. Oblong/slipper-shaped: Paramecium\n4. Elongated: Muscle cells (contractile for movement)\n5. Thread-like: Nerve cells (long for transmitting impulses)\n6. Flat: Skin cells (cover large area)\n7. Round/Rectangular/Oval: Plant cells depending on function\n8. Long and thin: Cells that carry water and food in plants\n\nB. Size of cells:\n- Most cells are microscopic (3-30 microns)\n- Smallest: Bacterial cells (0.2-0.5 micron)\n- Smallest in humans: Red blood cells\n- Large cells: Hen's egg (6 cm), Ostrich egg (23 cm)\n- Longest: Nerve cell of elephant (up to 3 metres)\n\nC. Number of cells:\n1. Unicellular organisms (single cell):\n   - Bacteria, Amoeba, Paramecium, Chlamydomonas\n2. Multicellular organisms (many cells):\n   - Plants: lotus, rose, mango, wheat, rice\n   - Animals: insects, fishes, birds, human beings\n   - Humans have billions of cells"
        },
        {
            "type": "subjective",
            "q": "What is protoplasm? Explain its components with their functions.",
            "sample": "Protoplasm is the jelly-like substance that fills a cell. It is the living material of the cell where all life processes occur.\n\nProtoplasm has two main parts:\n\n1. Nucleus:\n- Darker, denser part of protoplasm\n- Usually spherical or oval in shape\n- Surrounded by double membrane called nuclear membrane\n- Contains nucleoplasm (colourless dense fluid)\n- Has one or more nucleoli\n- Contains chromatin network (thread-like structures)\n\nFunctions of nucleus:\n- Control centre of the cell - controls all vital activities\n- Carrier of heredity from parents to offspring\n- Plays important role in cell division\n\n2. Cytoplasm:\n- Semi-solid, colourless, jelly-like part\n- Enclosed within cell membrane, surrounding nucleus\n- Contains various cell organelles\n- Most cellular activities occur here\n\nFunctions of cytoplasm:\n- Helps in distribution of molecules and nutrients within cell\n- Helps in exchange of materials between different cell organelles\n\nTogether, the nucleus and cytoplasm (protoplasm) perform all life functions of the cell."
        },
        {
            "type": "subjective",
            "q": "Differentiate between cell wall and cell membrane with a suitable table.",
            "sample": "Differences between cell wall and cell membrane:\n\n| Characteristic | Cell Wall | Cell Membrane |\n|----------------|-----------|---------------|\n| Location | Outermost, thick protective layer in plant cells | Outer covering of protoplasm in all cells |\n| Occurrence | Found only in bacterial and plant cells | Found in plant and animal cells |\n| Living/Non-living | Non-living | Living |\n| Permeability | Permeable - allows free passage of all substances | Selectively permeable - allows only selective substances |\n| Composition | Made of cellulose (complex carbohydrate) | Made of proteins and lipids |\n| Elasticity | Not elastic, rigid | Elastic, enables cell to stretch |\n| Function | Provides strength, rigidity, and definite shape to plant cells | Gives shape, controls movement of materials, provides protection |\n| Visibility | Visible under light microscope | Visible only under electron microscope |\n\nSimilarities:\n- Both provide shape and support to the cell\n- Both protect the internal components of the cell"
        },
        {
            "type": "subjective",
            "q": "Describe the structure and functions of the nucleus.",
            "sample": "Structure of nucleus:\n- Usually spherical or oval in shape\n- Located in the centre of the cell (in animal cells) or pushed to side (in plant cells with large vacuole)\n- Surrounded by a double membrane called nuclear membrane\n- Nuclear membrane has pores for exchange of materials\n- Contains colourless, dense fluid called nucleoplasm\n- Has one or more spherical bodies called nucleolus/nucleoli\n- Contains thread-like chromatin network made of DNA and proteins\n\nWhen a cell divides, the chromatin network condenses to form chromosomes. Chromosomes carry genes responsible for hereditary characters.\n\nFunctions of nucleus:\n1. Control centre: Controls all vital activities of the cell\n2. Heredity: Carries genetic material (genes) from parents to offspring\n3. Cell division: Plays important role in cell division process\n4. Protein synthesis: Directs synthesis of proteins through RNA\n5. Growth and development: Regulates growth and development of the cell\n6. Metabolism: Controls various metabolic activities of the cell\n\nBecause of these functions, the nucleus is called the 'brain' or 'control centre' of the cell."
        },
        {
            "type": "subjective",
            "q": "What are mitochondria? Why are they called the powerhouses of the cell?",
            "sample": "Mitochondria (singular: mitochondrion) are small, rod-shaped or spherical organelles found in large numbers in the cytoplasm of all eukaryotic cells.\n\nStructure of mitochondria:\n- Bound by two membranes - outer and inner membrane\n- Outer membrane is smooth and continuous\n- Inner membrane is folded to form finger-like structures called cristae\n- Cristae increase surface area for chemical reactions\n- The space inside contains fluid called matrix\n- Have their own DNA and ribosomes (semi-autonomous)\n\nFunctions of mitochondria:\n1. Site of cellular respiration\n2. During respiration, food (glucose) is oxidized in the presence of oxygen\n3. Energy is released in the form of ATP (Adenosine Triphosphate)\n4. ATP is the energy currency of the cell, used for all cellular activities\n5. Provide energy for movement, growth, reproduction, and other life processes\n\nWhy called powerhouses:\n- Just as a powerhouse generates electricity for a city, mitochondria generate energy (ATP) for the cell\n- All energy-requiring processes in the cell depend on mitochondria\n- Cells with high energy needs (muscle cells, nerve cells) have more mitochondria\n\nTherefore, mitochondria are rightly called the 'powerhouses of the cell'."
        },
        {
            "type": "subjective",
            "q": "Explain the structure and functions of plastids. Name the three types.",
            "sample": "Plastids are special organelles found only in plant cells. They are bound by a double membrane and manufacture or store pigments.\n\nStructure of plastids:\n- Bound by double membrane\n- Contain internal membrane system\n- May contain pigments or storage materials\n- Have their own DNA and ribosomes\n\nThree types of plastids:\n\n1. Chloroplasts:\n- Contain green pigment called chlorophyll\n- Impart green colour to leaves and other plant parts\n- Have two regions - grana (stack of disc-like structures) and stroma (fluid matrix)\n- Function: Trap solar energy to perform photosynthesis\n- Called the 'kitchen of the cell'\n\n2. Chromoplasts:\n- Contain coloured pigments other than green\n- Found in fruits and petals of flowers\n- Impart red, orange, or yellow colour\n- Function: Attract pollinators and seed dispersers\n\n3. Leucoplasts:\n- Colourless plastids without any pigment\n- Found in roots and underground stems (potato, ginger)\n- Function: Store food in the form of starch, proteins, and fats\n- Also called amyloplasts when storing starch\n\nThus, plastids are essential for photosynthesis, colouration, and food storage in plants."
        },
        {
            "type": "subjective",
            "q": "What are lysosomes? Why are they called suicide bags of the cell?",
            "sample": "Lysosomes are tiny sac-like organelles bound by a single membrane, found in the cytoplasm of animal cells.\n\nStructure:\n- Spherical vesicles\n- Bound by a single membrane\n- Contain powerful digestive enzymes\n- More numerous in animal cells\n\nFunctions of lysosomes:\n1. Digestion: Contain enzymes that digest food particles within the cell\n2. Protection: Destroy foreign bodies like bacteria and viruses\n3. Waste removal: Break down worn-out cell organelles\n4. Cell cleaning: Remove debris and unwanted materials\n\nWhy called 'suicide bags':\n- Under certain conditions (like cell damage, starvation, or ageing), lysosomes may burst\n- When they burst, they release their digestive enzymes into the cytoplasm\n- These enzymes digest the cell's own organelles and eventually the entire cell\n- The cell thus 'commits suicide' by digesting itself\n- This process is called autolysis (self-digestion)\n\nImportance of this property:\n- Helps in removing old and worn-out cells\n- Useful in metamorphosis (tadpole to frog, caterpillar to butterfly)\n- Helps in defense against pathogens\n\nTherefore, lysosomes are called 'suicide bags' due to their self-destruct mechanism."
        },
        {
            "type": "subjective",
            "q": "Differentiate between plant cell and animal cell with a table and well-labelled diagrams.",
            "sample": "Differences between plant cell and animal cell:\n\n| Characteristic | Plant Cell | Animal Cell |\n|----------------|------------|-------------|\n| Cell wall | Present around cell membrane (made of cellulose) | Absent |\n| Plastids | Present (chloroplasts, chromoplasts, leucoplasts) | Absent |\n| Centrosome | Absent | Present (with centrioles) |\n| Vacuole | Large central vacuole (occupies most space) | Small vacuoles or absent |\n| Lysosomes | Absent | Present |\n| Nucleus | Pushed to periphery due to large vacuole | Usually central |\n| Shape | Fixed, rectangular due to cell wall | Irregular, can change shape |\n| Cytoplasm | Less dense, vacuole occupies space | Denser, more organelles |\n| Mitochondria | Present | Present |\n| ER, Golgi bodies | Present | Present |\n| Ribosomes | Present | Present |\n| Cell membrane | Present (inside cell wall) | Present (outermost) |\n| Food storage | Starch | Glycogen |\n\nSimilarities:\n- Both have cell membrane, nucleus, cytoplasm\n- Both have mitochondria, ER, Golgi bodies, ribosomes\n- Both are basic units of life\n- Both carry out similar life processes\n\n[Note: Students should draw and label diagrams of both cell types showing all parts]"
        },
        {
            "type": "subjective",
            "q": "What is cell division? Why is it important for living organisms?",
            "sample": "Cell division is the process by which a parent cell divides to form two or more new daughter cells.\n\nProcess:\n- When a cell is formed, it is small\n- After digesting food, it grows in size\n- After reaching a certain critical size, the cell divides\n- Each new cell (daughter cell) grows and may divide again\n- This continues throughout the life of an organism\n\nTypes of cell division:\n- Mitosis: For growth and repair (produces identical cells)\n- Meiosis: For reproduction (produces gametes with half chromosomes)\n\nImportance of cell division:\n\n1. Growth:\n   - Organisms grow by increasing the number of cells\n   - A baby grows into an adult through countless cell divisions\n\n2. Repair and replacement:\n   - Old and worn-out cells are continuously replaced by new ones\n   - Wounds heal through cell division\n   - Skin cells are constantly replaced\n   - Blood cells have limited lifespan and need replacement\n\n3. Reproduction:\n   - In unicellular organisms, cell division is a mode of reproduction\n   - In multicellular organisms, special cell divisions produce gametes\n\n4. Development:\n   - A single fertilized egg develops into a complex organism through repeated cell divisions\n\nThus, cell division is essential for life, growth, and continuity of species."
        },
        {
            "type": "subjective",
            "q": "Describe an activity to observe human cheek cells under a microscope.",
            "sample": "Aim: To observe human cheek cells under a microscope\n\nMaterials required:\n- Clean toothpick\n- Glass slide\n- Coverslip\n- Microscope\n- Water\n- Iodine solution (stain)\n\nProcedure:\n\nStep 1: Preparation\n- Rinse your mouth thoroughly with water\n- Gently scrape the inner lining of your cheek with a clean toothpick\n- Do not scrape too hard to avoid injury\n\nStep 2: Making the slide\n- Put a drop of water on a clean glass slide\n- Transfer the scraping onto the drop of water\n- Spread it evenly\n- Add a drop of iodine solution (stains the cells for better visibility)\n- Carefully place a coverslip over the preparation to avoid air bubbles\n\nStep 3: Observation\n- Place the slide on the microscope stage\n- Focus under low power, then high power\n- Observe the cells\n\nObservations:\n- You will see many flat, irregularly shaped cells\n- Each cell has a distinct boundary (cell membrane)\n- A dark stained spot (nucleus) is visible in each cell\n- Cytoplasm appears lighter around the nucleus\n- Cells are arranged in groups or singly\n\nConclusion:\n- Human cheek cells are animal cells with cell membrane, nucleus, and cytoplasm\n- They do not have a cell wall\n- Iodine stains the nucleus darker for better visibility"
        },
        {
            "type": "subjective",
            "q": "Describe an activity to observe onion peel cells under a microscope.",
            "sample": "Aim: To observe onion peel cells under a microscope\n\nMaterials required:\n- Onion bulb\n- Knife\n- Forceps\n- Glass slide\n- Coverslip\n- Microscope\n- Water\n- Iodine solution\n\nProcedure:\n\nStep 1: Preparing the onion peel\n- Take an onion bulb and cut it into four pieces lengthwise\n- Remove a fleshy, scaly leaf\n- Break it by bending gently\n- Using forceps, carefully peel off a thin, transparent layer from the inner side\n- This thin membrane is the onion peel\n\nStep 2: Making the slide\n- Put a drop of water on a clean glass slide\n- Place the onion peel in the water drop\n- Spread it flat without folds\n- Add a drop of iodine solution (stains the cells)\n- Gently place a coverslip over the preparation\n\nStep 3: Observation\n- Place the slide under the microscope\n- Focus first under low power, then high power\n- Observe the structure\n\nObservations:\n- You will see many rectangular compartments (cells)\n- Each cell has a distinct cell wall (outer boundary)\n- Dark stained dots (nuclei) are visible in most cells\n- Clear space in cells may be vacuoles\n- Cells are arranged in a regular pattern\n\nConclusion:\n- Onion peel cells are plant cells with cell wall, nucleus, and cytoplasm\n- The rectangular shape is due to the rigid cell wall\n- Iodine stains the nucleus, making it visible\n- These are similar to what Robert Hooke observed in cork"
        },
        {
            "type": "subjective",
            "q": "What are chromosomes? Explain their importance in heredity.",
            "sample": "Chromosomes are thread-like structures formed from the chromatin network when a cell is about to divide.\n\nFormation:\n- In a non-dividing cell, genetic material exists as chromatin network\n- During cell division, chromatin network condenses and thickens\n- These condensed structures are called chromosomes\n\nStructure:\n- Made of DNA (Deoxyribonucleic Acid) and proteins\n- Each chromosome has two identical halves called chromatids\n- Joined at a point called centromere\n- Carry genes (units of heredity) along their length\n\nNumber of chromosomes:\n- Fixed for each species\n- Human beings: 46 chromosomes\n- Onion: 16 chromosomes\n- Rice: 24 chromosomes\n- Dogs: 60 chromosomes\n- All cells of an organism have the same number\n\nImportance in heredity:\n\n1. Carry genes:\n   - Chromosomes contain genes that determine traits\n   - Eye colour, hair colour, height, etc. are controlled by genes\n\n2. Transmission of traits:\n   - During reproduction, chromosomes pass from parents to offspring\n   - Children inherit traits from both parents\n\n3. Species continuity:\n   - Fixed chromosome number ensures species characteristics are maintained\n\n4. Variation:\n   - Mixing of parental chromosomes creates variation in offspring\n\n5. Cell division:\n   - Chromosomes ensure accurate distribution of genetic material to daughter cells\n\nThus, chromosomes are the physical basis of heredity."
        },
        {
            "type": "subjective",
            "q": "Explain the functions of the cell membrane.",
            "sample": "The cell membrane (also called plasma membrane) is the thin, delicate, skin-like covering that surrounds the cytoplasm of all cells.\n\nStructure:\n- Made of proteins and lipids\n- Elastic and flexible\n- Selectively permeable (allows only certain substances to pass)\n\nFunctions of cell membrane:\n\n1. Provides shape:\n   - Gives a definite shape to the cell\n   - In animal cells (without cell wall), it maintains shape\n   - Elastic nature allows cells to stretch and change shape\n\n2. Controls movement of materials:\n   - Regulates entry and exit of substances\n   - Allows nutrients to enter\n   - Allows waste products to leave\n   - Prevents harmful substances from entering\n   - Maintains internal environment (homeostasis)\n\n3. Protection:\n   - Protects internal components from injury\n   - Acts as a barrier against pathogens\n   - Prevents loss of important cellular contents\n\n4. Selective permeability:\n   - Allows only useful substances to pass through\n   - Small molecules like oxygen and water pass freely\n   - Large molecules are restricted\n   - This property is essential for cell survival\n\n5. Cell recognition:\n   - Contains markers that help cells recognize each other\n   - Important in tissue formation and immune response\n\n6. Cell communication:\n   - Receives signals from other cells\n   - Helps in coordinating activities\n\nThus, the cell membrane is essential for cell survival and function."
        },
        {
            "type": "subjective",
            "q": "Write a short note on the discovery of the nucleus by Robert Brown.",
            "sample": "Robert Brown (1773-1858) was a British botanist who made significant contributions to cell biology.\n\nBackground:\n- Brown loved to collect plants and studied them extensively\n- He did research on pollination and fertilization in plants\n- He was particularly interested in orchid cells\n\nDiscovery of nucleus:\n- While studying orchid cells under a microscope\n- He observed pollen grains moving in and out of certain structures in the cells\n- These structures appeared as small, spherical 'ovals' within the cell\n- He noticed that these structures were present in all orchid cells he examined\n- He named these structures 'nucleus' (from Latin for 'kernel' or 'nut')\n\nImportance of his discovery:\n- He recognized that the nucleus played a key role in fertilization and embryo development\n- He correctly identified that the nucleus was involved in reproduction\n- This was the first identification of an organelle within the cell\n- It laid the foundation for understanding cell structure and function\n\nOther contributions:\n- He also studied and named the random motion of particles in fluids\n- This phenomenon is now called 'Brownian motion' in his honour\n- He described the nucleus in many different plant cells\n\nLegacy:\n- Robert Brown's work established the nucleus as a fundamental part of the cell\n- Later scientists discovered its role in heredity and cell division\n- Today we know the nucleus as the control centre of the cell"
        },
        {
            "type": "subjective",
            "q": "What are cell organelles? Name them and write one function of each.",
            "sample": "Cell organelles are specialized structures within the cytoplasm that perform specific functions for the cell. They are like tiny organs of the cell.\n\nList of cell organelles and their functions:\n\n1. Mitochondria:\n   - Powerhouse of the cell\n   - Produce energy in the form of ATP through respiration\n\n2. Endoplasmic Reticulum (ER):\n   - Provides internal support\n   - Pathway for transport of materials within the cell\n   - Rough ER (with ribosomes) helps in protein synthesis\n   - Smooth ER helps in lipid synthesis\n\n3. Ribosomes:\n   - Protein factories of the cell\n   - Synthesize proteins\n\n4. Golgi bodies:\n   - Secrete substances\n   - Help in synthesis of cell wall in plants\n   - Package and transport materials\n\n5. Lysosomes:\n   - Digest food within the cell\n   - Protect against foreign bodies\n   - Suicide bags - digest old organelles\n\n6. Centrosome (animal cells only):\n   - Helps in cell division\n   - Contains centrioles that form spindle fibres\n\n7. Plastids (plant cells only):\n   - Chloroplasts: Perform photosynthesis\n   - Chromoplasts: Give colour to fruits and flowers\n   - Leucoplasts: Store food\n\n8. Vacuoles:\n   - Store food and water\n   - Maintain turgor pressure\n   - Store waste products\n\nThese organelles work together to keep the cell alive and functioning properly."
        },
        {
            "type": "subjective",
            "q": "Explain the structure and function of vacuoles. How do they differ in plant and animal cells?",
            "sample": "Vacuoles are fluid-filled, sac-like structures in the cytoplasm bound by a single membrane.\n\nStructure:\n- Bound by a single membrane called tonoplast\n- Contains fluid called cell sap\n- Cell sap contains water, sugars, proteins, amino acids, minerals, and waste products\n- May also contain pigments in some plant cells\n\nFunctions of vacuoles:\n1. Storage:\n   - Store food materials and water\n   - Store minerals and nutrients\n   - Store waste products temporarily\n\n2. Turgidity and shape:\n   - Help the cell remain turgid (firm)\n   - Maintain cell shape by exerting pressure on cell wall\n   - In plant cells, large vacuole provides structural support\n\n3. Waste disposal:\n   - Store harmful waste products away from cytoplasm\n   - Isolate toxic substances\n\n4. Digestion (in some cells):\n   - Contain digestive enzymes in some protozoa\n   - Help in food digestion\n\nDifferences in plant and animal cells:\n\nPlant cell vacuoles:\n- Large, single central vacuole\n- Occupies most of the cell volume (up to 90%)\n- Pushes nucleus to the periphery\n- Permanent structure\n- Maintains turgor pressure for support\n\nAnimal cell vacuoles:\n- Small, numerous vacuoles (if present)\n- Occupy very little space\n- Temporary structures\n- May be absent in many cells\n- In Amoeba, food vacuole and contractile vacuole are present\n- Contractile vacuole helps in osmoregulation"
        },
        {
            "type": "subjective",
            "q": "Write a note on unicellular and multicellular organisms with examples.",
            "sample": "Organisms are classified into two types based on the number of cells they are made of: unicellular and multicellular organisms.\n\nUnicellular organisms:\n- Made up of a single cell\n- One cell performs all life functions\n- Cell is independent and can survive alone\n- Visible only under microscope\n\nExamples of unicellular organisms:\n1. Bacteria: Smallest cells, various shapes\n2. Amoeba: Irregular shape, changes constantly\n3. Paramecium: Slipper-shaped, moves with cilia\n4. Chlamydomonas: Oval-shaped, has chlorophyll\n5. Euglena: Has features of both plant and animal\n6. Yeast: Fungus used in baking\n\nCharacteristics:\n- Single cell carries out all activities\n- No tissues or organs\n- Reproduction by cell division\n- Can live in various habitats\n\nMulticellular organisms:\n- Made up of many cells\n- Cells are specialized for different functions\n- Cells work together and depend on each other\n- May be microscopic or macroscopic\n\nExamples of multicellular organisms:\n1. Plants: Lotus, rose, mango, wheat, rice, peepal\n2. Animals: Insects, fishes, birds, human beings\n3. Fungi: Mushrooms\n\nCharacteristics:\n- Cells form tissues, tissues form organs\n- Cells are specialized (muscle cells, nerve cells, etc.)\n- Cells cannot survive independently\n- Complex body organization\n- Larger size possible\n\nAll organisms start life as a single cell, but in multicellular organisms, that single cell divides repeatedly to form many cells that become specialized."
        },
        {
            "type": "subjective",
            "q": "What are cell inclusions? Give examples.",
            "sample": "Cell inclusions are non-living substances present in the cell, either freely in the cytoplasm or inside vacuoles. Unlike cell organelles, they are not living and do not perform metabolic functions.\n\nCharacteristics of cell inclusions:\n- Non-living in nature\n- No metabolic activity\n- May be temporary or permanent\n- Products of cellular metabolism\n- Can be organic or inorganic\n\nTypes of cell inclusions:\n\n1. Reserve food materials:\n   - Starch grains: In plant cells (potato, rice, wheat)\n   - Oil globules: In plant seeds and animal fat cells\n   - Glycogen: In animal cells and fungi\n   - Proteins: In aleurone grains of seeds\n\n2. Secretory products:\n   - Gums: Secreted by plants for protection\n   - Resins: Produced by plants (pine resin)\n   - Latex: In rubber plants, papaya\n   - Mucilage: In aquatic plants\n\n3. Excretory products:\n   - Tannins: In plant cells (tea, bark)\n   - Alkaloids: In plants (caffeine, nicotine)\n   - Urea: In animal cells (waste product)\n   - Uric acid: In birds and reptiles\n\n4. Pigments:\n   - Anthocyanins: In flower petals (water-soluble)\n   - Carotenoids: In chromoplasts\n\n5. Minerals:\n   - Calcium oxalate crystals: In plant cells\n   - Calcium carbonate: In some algae\n\nFunctions:\n- Storage of nutrients for future use\n- Protection from herbivores\n- Attracting pollinators (pigments)\n- Waste storage\n- Structural support"
        },
        {
            "type": "subjective",
            "q": "Explain why red blood cells in humans do not have a nucleus. What is the advantage?",
            "sample": "Red blood cells (erythrocytes) in humans are unique because mature RBCs do not have a nucleus. This is an adaptation for their specific function.\n\nDevelopment of RBCs:\n- RBCs are produced in the bone marrow\n- Initially, they have a nucleus when formed\n- As they mature, they lose their nucleus before entering the bloodstream\n- They become biconcave, disc-shaped cells without nucleus\n\nReasons for losing nucleus:\n\n1. More space for haemoglobin:\n   - Haemoglobin is the oxygen-carrying protein\n   - Without nucleus, more haemoglobin can be packed\n   - Each RBC can carry more oxygen\n\n2. Biconcave shape:\n   - Losing nucleus allows cells to become biconcave\n   - This shape increases surface area\n   - More surface area for oxygen absorption and release\n\n3. Flexibility:\n   - Without nucleus, RBCs become flexible\n   - Can squeeze through narrow capillaries\n   - Can change shape to pass through tiny blood vessels\n\nAdvantages:\n\n1. Maximum oxygen transport:\n   - More haemoglobin = more oxygen carried\n   - Efficient oxygen delivery to all body cells\n\n2. Efficient gas exchange:\n   - Large surface area for diffusion\n   - Quick absorption of oxygen in lungs\n   - Quick release of oxygen to tissues\n\n3. Easy passage:\n   - Flexibility allows travel through smallest capillaries\n   - Can reach every part of the body\n\nDisadvantage:\n- Cannot repair themselves\n- No protein synthesis\n- Limited lifespan (about 120 days)\n- Must be constantly replaced by bone marrow"
        },
        {
            "type": "subjective",
            "q": "Describe the structure of a typical plant cell as seen under an electron microscope.",
            "sample": "A typical plant cell has a well-defined structure with various organelles visible under an electron microscope:\n\nOuter coverings:\n1. Cell wall:\n   - Outermost, rigid layer\n   - Made of cellulose\n   - Provides shape and support\n   - Permeable to all substances\n\n2. Cell membrane:\n   - Just inside the cell wall\n   - Thin, elastic, selectively permeable\n   - Controls entry and exit of materials\n\nCytoplasm:\n- Semi-solid, jelly-like matrix\n- Contains all organelles\n- Site of many metabolic activities\n\nNucleus:\n- Large, usually pushed to side by vacuole\n- Surrounded by double nuclear membrane with pores\n- Contains nucleolus (1-2) and chromatin network\n- Controls all cell activities\n\nMitochondria:\n- Rod-shaped or spherical\n- Double membrane with inner folds (cristae)\n- Powerhouse of the cell\n- Numerous in active cells\n\nPlastids:\n- Chloroplasts: Green, with grana and stroma\n- Chromoplasts: Coloured, in fruits and flowers\n- Leucoplasts: Colourless, store starch\n\nEndoplasmic Reticulum:\n- Network of tubes throughout cytoplasm\n- Rough ER (with ribosomes) and Smooth ER\n- Transport and support\n\nGolgi bodies:\n- Stack of flattened discs\n- Called dictyosomes in plants\n- Secretion and cell wall synthesis\n\nVacuole:\n- Large central vacuole\n- Bound by tonoplast\n- Filled with cell sap\n- Maintains turgor pressure\n\nRibosomes:\n- Small granules, free or on ER\n- Protein synthesis\n\nAll these structures work together to keep the plant cell alive and functioning."
        },
        {
            "type": "subjective",
            "q": "What would happen if there were no lysosomes in a cell?",
            "sample": "Lysosomes are essential organelles that act as the digestive and waste disposal system of the cell. If there were no lysosomes, several serious consequences would occur:\n\n1. Accumulation of waste materials:\n   - Worn-out organelles would not be broken down\n   - Dead organelles would accumulate in the cytoplasm\n   - Cell would become filled with debris\n   - Space for new organelles would be limited\n\n2. No digestion of food:\n   - Food particles engulfed by the cell would not be digested\n   - Nutrients would not be released from food\n   - Cell would starve despite having food inside\n\n3. No defense against pathogens:\n   - Bacteria and viruses entering the cell would not be destroyed\n   - Infections would spread easily\n   - Cell would be vulnerable to diseases\n\n4. No self-destruct mechanism:\n   - Old and damaged cells would not be removed\n   - This could lead to accumulation of abnormal cells\n   - May increase risk of cancer\n\n5. Impaired cellular cleanup:\n   - No removal of toxic substances\n   - Harmful materials would remain in cytoplasm\n   - Could damage other organelles\n\n6. No role in development:\n   - In organisms like tadpoles, lysosomes help in metamorphosis\n   - Tail of tadpole would not be absorbed during frog development\n\n7. Accumulation of undigested materials:\n   - Could form harmful deposits\n   - May interfere with normal cell functions\n\n8. No recycling of materials:\n   - Components of old organelles would not be reused\n   - Cell would waste resources\n\nIn summary, without lysosomes, a cell would become a garbage dump, unable to digest food, fight infections, or recycle materials, leading to cell death."
        },
        {
            "type": "subjective",
            "q": "What is the significance of the nucleus being called the 'control centre' of the cell?",
            "sample": "The nucleus is called the control centre of the cell because it directs and regulates all cellular activities. Its significance can be explained as follows:\n\n1. Contains genetic material:\n   - Nucleus contains DNA in the form of chromatin/chromosomes\n   - DNA has genes that carry instructions for all cell functions\n   - Like a computer's hard drive storing all programs\n\n2. Controls protein synthesis:\n   - Nucleus sends messages (mRNA) to ribosomes\n   - Instructs which proteins to make\n   - Proteins determine cell structure and function\n\n3. Regulates metabolism:\n   - Controls production of enzymes\n   - Enzymes control all chemical reactions\n   - Without nucleus, metabolism would stop\n\n4. Directs cell division:\n   - Initiates and controls cell division process\n   - Ensures equal distribution of chromosomes\n   - Without nucleus, cell cannot divide\n\n5. Determines cell specialization:\n   - Different genes are activated in different cells\n   - Makes muscle cells different from nerve cells\n   - Controls cell differentiation\n\n6. Maintains cell identity:\n   - Genetic material determines species and individual characteristics\n   - Human cells remain human, not become animal cells\n\n7. Controls growth and development:\n   - Regulates when and how cells grow\n   - Coordinates development of organism\n\n8. Responds to signals:\n   - Receives signals from environment\n   - Adjusts cell activities accordingly\n\nEvidence of nucleus as control centre:\n- Cells without nucleus (like RBCs) cannot divide or repair\n- They have limited lifespan and functions\n- They cannot synthesize new proteins\n- They depend on other cells for maintenance\n\nThus, the nucleus truly acts as the brain or control centre of the cell, without which the cell cannot function properly."
        },
        {
            "type": "subjective",
            "q": "Explain the relationship between cells, tissues, organs, and organ systems.",
            "sample": "Living organisms are organized in a hierarchical manner, from the simplest to the most complex level. This relationship can be explained as follows:\n\n1. Cells:\n   - Basic structural and functional unit of life\n   - Smallest living unit capable of independent existence\n   - Examples: Muscle cell, nerve cell, blood cell\n   - Each cell type has specific structure for its function\n\n2. Tissues:\n   - Group of similar cells performing the same function\n   - Cells in a tissue work together\n   - Examples in animals:\n     * Muscular tissue: Made of muscle cells for movement\n     * Nervous tissue: Made of nerve cells for impulse transmission\n     * Blood tissue: Made of blood cells for transport\n   - Examples in plants:\n     * Conducting tissue: For transport of water and food\n     * Protective tissue: For covering and protection\n\n3. Organs:\n   - Different tissues organized together\n   - Perform specific functions\n   - Examples in humans:\n     * Heart: Made of muscle, nerve, blood tissues - pumps blood\n     * Stomach: Made of epithelial, muscle, gland tissues - digests food\n     * Brain: Made of nerve tissue - controls body\n   - Examples in plants:\n     * Leaf: Made of photosynthetic, protective, conducting tissues\n     * Root: Made of absorptive, protective, conducting tissues\n\n4. Organ systems:\n   - Group of organs working together\n   - Perform major body functions\n   - Examples in humans:\n     * Digestive system: Mouth, stomach, intestines, liver, pancreas\n     * Circulatory system: Heart, blood vessels, blood\n     * Nervous system: Brain, spinal cord, nerves\n   - Examples in plants:\n     * Shoot system: Stems, leaves, flowers\n     * Root system: Roots and their branches\n\n5. Organism:\n   - All organ systems working together\n   - Complete living being\n   - Examples: Human, tree, bird, fish\n\nThus, cells → tissues → organs → organ systems → organism, showing increasing complexity and organization."
        },
        {
            "type": "subjective",
            "q": "Write a note on the life span of different cells in the human body.",
            "sample": "Different cells in the human body have varying life spans based on their type, function, and location. Some live for days, others for years.\n\n1. Digestive tract cells:\n   - Cells lining the stomach and intestines\n   - Life span: 2-5 days\n   - Reason: Constant exposure to digestive acids and enzymes\n   - Rapidly replaced to maintain protection\n\n2. Skin cells:\n   - Epidermal cells (outer layer)\n   - Life span: About 2-4 weeks\n   - Constantly shed and replaced\n   - Complete skin renewal about every 28 days\n\n3. Red blood cells (RBCs):\n   - Life span: About 120 days (4 months)\n   - No nucleus, cannot repair themselves\n   - Continuously produced in bone marrow\n   - About 2 million replaced every second\n\n4. White blood cells (WBCs):\n   - Life span: 12 hours to 12 days\n   - Some lymphocytes can live for years\n   - Short-lived due to active role in fighting infections\n\n5. Platelets:\n   - Life span: 5-9 days\n   - Continuously replaced\n\n6. Bone cells:\n   - Osteocytes (mature bone cells)\n   - Life span: Up to 25 years\n   - Some bone cells last a lifetime\n\n7. Muscle cells:\n   - Cardiac muscle cells: Lifetime\n   - Skeletal muscle cells: Long-lived, can repair\n   - Limited regeneration capacity\n\n8. Nerve cells (neurons):\n   - Life span: Lifetime (last a lifetime)\n   - Formed before birth, not replaced\n   - Can't divide after maturity\n   - Damage is usually permanent\n\n9. Liver cells:\n   - Life span: 300-500 days\n   - Can regenerate and divide\n   - Remarkable repair capacity\n\n10. Eye lens cells:\n    - Life span: Lifetime\n    - Formed in childhood, last entire life\n\n11. Fat cells:\n    - Life span: About 8-10 years\n    - Slowly replaced\n\nThis diversity in life spans ensures that the body maintains itself efficiently, with rapidly replaced cells protecting vital organs and long-lived cells providing stability."
        },
        {
            "type": "subjective",
            "q": "Why do cells have different shapes? Explain with examples.",
            "sample": "Cells have different shapes because their structure is adapted to their specific functions. The shape of a cell directly relates to what it does in the body.\n\n1. Flat cells (Squamous epithelial cells):\n   - Thin, plate-like shape\n   - Function: Covering and lining surfaces\n   - Example: Skin cells, lining of blood vessels\n   - Advantage: Large area covered, easy diffusion\n\n2. Cuboidal cells:\n   - Cube-like shape\n   - Function: Secretion and absorption\n   - Example: Kidney tubule cells, gland cells\n   - Advantage: Efficient for secretion\n\n3. Columnar cells:\n   - Tall, pillar-like shape\n   - Function: Absorption and secretion\n   - Example: Intestinal lining cells\n   - Advantage: More surface area for absorption\n\n4. Spindle-shaped cells (Muscle cells):\n   - Elongated with tapered ends\n   - Function: Contraction and movement\n   - Example: Smooth muscle cells\n   - Advantage: Can contract and relax\n\n5. Long, thread-like cells (Nerve cells):\n   - Extremely elongated with branches\n   - Function: Transmit impulses\n   - Example: Neurons\n   - Advantage: Can carry signals over long distances\n\n6. Biconcave disc-shaped cells (RBCs):\n   - Disc-shaped with depressed centre\n   - Function: Oxygen transport\n   - Example: Red blood cells\n   - Advantage: Large surface area for gas exchange\n\n7. Irregular cells:\n   - Constantly changing shape\n   - Function: Engulf foreign particles\n   - Example: Amoeba, white blood cells\n   - Advantage: Can surround and engulf prey/germs\n\n8. Spherical cells:\n   - Round shape\n   - Function: Various\n   - Example: Egg cells, some WBCs\n   - Advantage: Efficient for storage\n\n9. Branched cells:\n   - Have extensions\n   - Function: Connection and communication\n   - Example: Cardiac muscle cells, some neurons\n   - Advantage: Form networks\n\nThus, form follows function in cell biology - each cell's shape is perfectly suited to its job."
        },
        {
            "type": "subjective",
            "q": "What are the functions of cytoplasm in a cell?",
            "sample": "Cytoplasm is the semi-solid, colourless, jelly-like substance that fills the cell between the cell membrane and the nucleus. It is a major part of protoplasm and performs several crucial functions:\n\n1. Medium for cellular activities:\n   - Provides a medium where all chemical reactions occur\n   - Metabolic reactions (glycolysis, protein synthesis) happen here\n   - Enzymes are distributed throughout the cytoplasm\n\n2. Distribution of molecules:\n   - Helps in distribution of nutrients within the cell\n   - Allows movement of molecules from one part to another\n   - Facilitates transport of materials\n\n3. Exchange of materials:\n   - Helps in exchange of materials between different organelles\n   - Connects all organelles physically and functionally\n   - Allows communication between cell parts\n\n4. Support and structure:\n   - Provides shape to the cell (especially in animal cells)\n   - Contains cytoskeleton (microtubules, microfilaments)\n   - Gives mechanical support\n\n5. Storage:\n   - Stores nutrients, ions, and waste products temporarily\n   - Contains cell inclusions (starch, oil, etc.)\n   - Holds dissolved substances\n\n6. Site of organelle function:\n   - All organelles float in cytoplasm\n   - Organelles interact through cytoplasm\n   - Movements of organelles occur here\n\n7. Locomotion (in some cells):\n   - In Amoeba, cytoplasmic streaming helps in movement\n   - Pseudopodia formation depends on cytoplasm\n   - Cyclosis (cytoplasmic streaming) circulates materials\n\n8. Buffer zone:\n   - Protects organelles from physical shock\n   - Maintains internal environment\n   - Cushions the nucleus and organelles\n\n9. Cell division:\n   - Cytoplasm divides during cytokinesis\n   - Distributes organelles to daughter cells\n\nWithout cytoplasm, a cell would be just an empty membrane with a nucleus, unable to perform most life functions."
        },
        {
            "type": "subjective",
            "q": "Write a note on the function of endoplasmic reticulum and Golgi bodies.",
            "sample": "Endoplasmic Reticulum (ER) and Golgi bodies work together as the cell's manufacturing, packaging, and transport system.\n\nEndoplasmic Reticulum (ER):\n\nStructure:\n- Network of tube-like structures throughout cytoplasm\n- Connected to nuclear membrane\n- Two types: Rough ER (with ribosomes) and Smooth ER (without ribosomes)\n\nFunctions of ER:\n\n1. Internal support:\n   - Provides structural framework to the cell\n   - Acts as cytoskeleton\n\n2. Transport:\n   - Pathway for transport of materials within the cell\n   - Connects nucleus to cell membrane\n   - Transports proteins and lipids\n\n3. Protein synthesis (Rough ER):\n   - Ribosomes on RER synthesize proteins\n   - Proteins are modified and folded here\n   - Transports proteins to Golgi bodies\n\n4. Lipid synthesis (Smooth ER):\n   - Synthesizes lipids and steroids\n   - Detoxifies drugs and poisons (in liver cells)\n   - Stores calcium ions (in muscle cells)\n\nGolgi bodies (Golgi apparatus):\n\nStructure:\n- Stack of parallel flattened discs (cisternae)\n- In plant cells, called dictyosomes\n- Located near nucleus\n\nFunctions of Golgi bodies:\n\n1. Secretion:\n   - Secretes various substances (enzymes, hormones)\n   - Packages materials for secretion\n   - Forms secretory vesicles\n\n2. Modification:\n   - Modifies proteins received from ER\n   - Adds sugar molecules (glycosylation)\n   - Prepares molecules for specific functions\n\n3. Packaging:\n   - Packages materials into vesicles\n   - Forms lysosomes\n   - Concentrates secretory products\n\n4. Transport:\n   - Sends materials to different cell parts\n   - Directs vesicles to cell membrane for export\n   - Helps in intracellular transport\n\n5. Cell wall formation (in plants):\n   - Helps in synthesis of cell wall materials\n   - Contributes to formation of new cell wall during division\n\nTogether, ER and Golgi bodies form the endomembrane system, ensuring proper processing and delivery of cellular products."
        },
        {
            "type": "subjective",
            "q": "Explain the importance of cell division in living organisms.",
            "sample": "Cell division is the process by which a parent cell divides to form two or more daughter cells. It is essential for all living organisms.\n\nTypes of cell division:\n- Mitosis: For growth and repair (produces identical cells)\n- Meiosis: For reproduction (produces gametes with half chromosomes)\n\nImportance of cell division:\n\n1. Growth of organisms:\n   - Organisms grow by increasing cell number\n   - A single fertilized egg develops into a multicellular organism\n   - A baby grows into an adult through cell division\n   - Plants grow taller due to cell division at tips\n\n2. Repair and regeneration:\n   - Wounds heal through cell division\n   - Broken bones repair by producing new cells\n   - Skin replaces damaged cells\n   - Liver can regenerate lost tissue\n\n3. Replacement of old cells:\n   - Old and worn-out cells are continuously replaced\n   - Red blood cells (120-day lifespan) need constant replacement\n   - Skin cells are shed and replaced\n   - Intestinal lining cells are replaced every few days\n\n4. Reproduction:\n   - In unicellular organisms (bacteria, Amoeba), cell division = reproduction\n   - In multicellular organisms, special divisions produce gametes\n   - Ensures continuation of species\n\n5. Development:\n   - Embryo develops through countless cell divisions\n   - Cells become specialized (differentiation)\n   - Organs and tissues form\n\n6. Maintenance:\n   - Maintains proper cell size (cells divide when too large)\n   - Maintains nucleus-to-cytoplasm ratio\n   - Prevents cells from becoming inefficient\n\n7. Genetic continuity:\n   - Mitosis ensures identical genetic material in all body cells\n   - Preserves species characteristics\n\n8. Variation (through meiosis):\n   - Meiosis creates genetic variation in offspring\n   - Helps evolution and adaptation\n\nWithout cell division, life would not exist - organisms could not grow, repair damage, or reproduce."
        },
        {
            "type": "subjective",
            "q": "Describe the structure and functions of ribosomes.",
            "sample": "Ribosomes are small, round, non-membranous organelles found in all living cells. They are the sites of protein synthesis.\n\nStructure of ribosomes:\n\n1. Size and shape:\n   - Very small (about 20-30 nm in diameter)\n   - Round or slightly oval in shape\n   - Not visible under light microscope\n   - Visible only under electron microscope\n\n2. Composition:\n   - Made of two subunits - large and small\n   - Composed of ribosomal RNA (rRNA) and proteins\n   - No membrane around them\n\n3. Location in cell:\n   - Free ribosomes: Float freely in cytoplasm\n   - Bound ribosomes: Attached to endoplasmic reticulum (Rough ER)\n   - Also found in mitochondria and chloroplasts\n\n4. Number:\n   - Present in large numbers\n   - Active protein-making cells have more ribosomes\n   - E.g., pancreatic cells (make digestive enzymes) have many\n\nFunctions of ribosomes:\n\n1. Protein synthesis (main function):\n   - Called 'protein factories' of the cell\n   - Assemble amino acids into proteins\n   - Read genetic code from mRNA\n   - Link amino acids with peptide bonds\n\n2. Types of proteins made:\n   - Structural proteins (for cell structure)\n   - Enzymes (for biochemical reactions)\n   - Hormones (chemical messengers)\n   - Antibodies (for immunity)\n   - Transport proteins (like haemoglobin)\n\n3. Free ribosomes:\n   - Make proteins for use inside the cell\n   - Cytoplasmic proteins\n   - Enzymes for metabolism\n\n4. Bound ribosomes (on RER):\n   - Make proteins for export\n   - Proteins for membranes\n   - Proteins for lysosomes\n   - Secretory proteins\n\n5. Quality control:\n   - Ensure correct protein folding\n   - Help in protein modification\n\nImportance:\n- All life processes depend on proteins\n- Without ribosomes, no proteins = no life\n- Antibiotics like tetracycline work by blocking bacterial ribosomes\n\nThus, ribosomes are essential for all cellular functions."
        },
        {
            "type": "subjective",
            "q": "How do plant cells store food? Explain the role of leucoplasts.",
            "sample": "Plant cells store food in various forms using specialized organelles called plastids. Leucoplasts are the colourless plastids responsible for food storage.\n\nTypes of leucoplasts based on stored food:\n\n1. Amyloplasts (starch storage):\n   - Store starch (complex carbohydrate)\n   - Found in potato tubers, rice, wheat grains\n   - Starch appears as grains under microscope\n   - Provide energy for germination\n\n2. Proteinoplasts (protein storage):\n   - Store proteins\n   - Found in seeds (beans, peas, nuts)\n   - Store reserve proteins for embryo\n   - Help in early growth of seedling\n\n3. Elaioplasts (oil/fat storage):\n   - Store oils and fats\n   - Found in oilseeds (mustard, groundnut, sunflower)\n   - Store lipids as energy reserve\n   - Used in making vegetable oils\n\nStructure of leucoplasts:\n- Colourless (no pigments)\n- Bound by double membrane\n- Contain internal membrane system\n- Size varies with amount of stored food\n\nLocation of leucoplasts:\n- Roots (carrot, radish, beetroot)\n- Underground stems (potato, ginger, turmeric)\n- Seeds (cereals, pulses, nuts)\n- Fruits (banana, apple)\n\nRole of leucoplasts in food storage:\n\n1. Energy reserve:\n   - Store carbohydrates as starch\n   - Break down starch when energy needed\n   - Provide energy during night (no photosynthesis)\n\n2. Seed germination:\n   - Seeds contain stored food in leucoplasts\n   - Embryo uses this food until leaves form\n   - Critical for seedling survival\n\n3. Perennation:\n   - Underground parts store food for next season\n   - Plants survive winter/drought\n   - Regrow when conditions improve\n\n4. Propagation:\n   - Storage organs (tubers, rhizomes) help in vegetative propagation\n   - New plants grow from stored food\n\n5. Protection:\n   - Stored food helps plants survive stress\n   - Provides energy for flowering and fruiting\n\nThus, leucoplasts are essential for plant survival, growth, and reproduction."
        },
        {
            "type": "subjective",
            "q": "Write a note on the discovery of cells by Robert Hooke and Anton Van Leeuwenhoek.",
            "sample": "The discovery of cells was made possible by the invention of microscopes, with two scientists playing crucial roles.\n\nAnton Van Leeuwenhoek (1632-1723):\n\nHis contribution:\n- Dutch scientist who developed the first simple microscope\n- Microscope had a single powerful lens\n- Could magnify objects up to 270 times\n\nHis observations:\n- Observed blood cells in capillaries of frog's webbed foot\n- Saw tiny single-celled organisms in a drop of pond water\n- Observed bacteria from scrapings of his teeth\n- First to see living cells and microorganisms\n- Called them 'animalcules' (little animals)\n\nSignificance:\n- First to recognize these as living units of living beings\n- Opened the door to microbiology\n- Did not call them 'cells' but his work was foundational\n\nRobert Hooke (1635-1703):\n\nHis contribution:\n- English scientist who built a compound microscope\n- Used two lenses - objective and eyepiece\n- Better magnification than simple microscopes\n\nHis observations (1665):\n- Studied a thin slice of cork (from tree bark)\n- Saw small, box-like, empty compartments\n- These reminded him of small rooms (cells) in a monastery\n- Named them 'cells' from Latin 'cellula' (small room)\n\nPublished work:\n- Described his findings in book 'Micrographia'\n- Included detailed drawings of his observations\n- First scientific description of cells\n\nSignificance:\n- Coined the term 'cell' that we still use today\n- First to identify and name cells\n- Laid foundation for cell biology\n\nComparison:\n- Hooke observed dead cells (cork)\n- Leeuwenhoek observed living cells (bacteria, protozoa)\n- Hooke named them, Leeuwenhoek saw them alive\n- Both contributed to the discovery of cells\n\nThus, while Leeuwenhoek first saw living cells, Hooke discovered and named the cell, making 1665 a landmark year in biology."
        },
        {
            "type": "subjective",
            "q": "Explain why plant cells have a cell wall while animal cells do not.",
            "sample": "Plant cells have a cell wall while animal cells do not because of their different lifestyles, needs, and functions.\n\nWhy plant cells need a cell wall:\n\n1. Support and rigidity:\n   - Plants are fixed in one place (don't move)\n   - Need rigid structure to stand upright\n   - Cell wall provides mechanical strength\n   - Like a building's framework\n\n2. Protection from environment:\n   - Plants face wind, rain, and weather\n   - Cell wall protects against physical damage\n   - Prevents dehydration in dry conditions\n   - Barrier against pathogens\n\n3. Turgor pressure:\n   - Plant cells have large central vacuole\n   - Water enters, creates pressure against cell wall\n   - This turgor pressure keeps plant firm\n   - Without cell wall, cell would burst\n\n4. No skeleton:\n   - Animals have internal skeletons (bones)\n   - Plants have no bones or skeleton\n   - Cell wall acts as external skeleton\n   - Provides shape without bones\n\n5. Transport:\n   - Cell wall is permeable (allows all substances)\n   - Helps in movement of water and minerals\n   - Facilitates transport between cells\n\n6. Cell-cell connections:\n   - Plasmodesmata (channels) pass through cell walls\n   - Allows communication between plant cells\n   - Helps coordinate plant functions\n\nWhy animal cells don't need a cell wall:\n\n1. Movement:\n   - Animals move from place to place\n   - Cell wall would be rigid and prevent movement\n   - Flexible membrane allows shape changes\n\n2. Flexibility:\n   - Animals need flexible bodies\n   - Muscle contraction requires shape change\n   - White blood cells need to change shape\n\n3. Internal skeleton:\n   - Animals have endoskeleton (bones)\n   - Provides support without cell wall\n   - Allows both support and movement\n\n4. Different feeding:\n   - Animals engulf food (phagocytosis)\n   - Cell wall would prevent this\n   - Membrane allows engulfing\n\n5. Cell communication:\n   - Animal cells communicate through membrane\n   - No need for permanent channels\n\nThus, the presence or absence of cell wall reflects the different lifestyles and needs of plants and animals."
        },
        {
            "type": "subjective",
            "q": "What is the function of chloroplasts? Why are they called the 'kitchen of the cell'?",
            "sample": "Chloroplasts are green plastids found in plant cells that contain the pigment chlorophyll. They are the sites of photosynthesis.\n\nStructure of chloroplasts:\n- Bound by double membrane\n- Contain stacks of disc-like structures called grana (singular: granum)\n- Each granum has many thylakoids (contain chlorophyll)\n- Surrounded by fluid matrix called stroma\n- Have their own DNA and ribosomes\n\nFunctions of chloroplasts:\n\n1. Photosynthesis (main function):\n   - Trap solar energy with chlorophyll\n   - Convert light energy into chemical energy\n   - Produce food (glucose) from CO₂ and water\n   - Release oxygen as byproduct\n   - Formula: 6CO₂ + 6H₂O + sunlight → C₆H₁₂O₆ + 6O₂\n\n2. Food production:\n   - Produce carbohydrates (glucose)\n   - Glucose converted to starch for storage\n   - Provide food for the entire plant\n   - Basis of food chains on Earth\n\n3. Oxygen production:\n   - Release oxygen into atmosphere\n   - Maintain oxygen balance in air\n   - Essential for animal life\n\n4. Energy conversion:\n   - Convert light energy to chemical energy (ATP)\n   - Store energy in food molecules\n   - Provide energy for plant activities\n\nWhy called 'kitchen of the cell':\n\n1. Food production:\n   - Just as a kitchen prepares food for a family\n   - Chloroplasts prepare food for the entire plant\n   - All plant cells depend on chloroplasts for food\n\n2. Self-sufficiency:\n   - Plants are autotrophs (self-feeders)\n   - Chloroplasts make plants self-sufficient\n   - Can produce their own organic food\n\n3. Energy conversion:\n   - Convert raw materials (CO₂, water) into food\n   - Like cooking raw ingredients into a meal\n\n4. Distribution:\n   - Food made in chloroplasts is distributed to all cells\n   - Non-green parts depend on leaves for food\n\n5. Life support:\n   - Without chloroplasts, plants would starve\n   - All life on Earth depends on this process\n\nThus, chloroplasts truly deserve the title 'kitchen of the cell'."
        },
        {
            "type": "subjective",
            "q": "Differentiate between the three types of plastids with examples.",
            "sample": "Plastids are organelles found only in plant cells. They are of three main types based on their colour and function.\n\n1. Chloroplasts (Green plastids):\n\nCharacteristics:\n- Contain green pigment called chlorophyll\n- Green in colour\n- Have two regions - grana and stroma\n- Found in leaves and green parts of plants\n\nFunctions:\n- Perform photosynthesis\n- Trap solar energy\n- Produce food (glucose)\n- Release oxygen\n\nExamples:\n- Leaf cells of all green plants\n- Young stems\n- Green fruits (before ripening)\n- Some algae (Chlamydomonas, Spirogyra)\n\n2. Chromoplasts (Coloured plastids):\n\nCharacteristics:\n- Contain pigments other than chlorophyll\n- May be red, orange, yellow, or other colours\n- No photosynthesis\n- Found in mature fruits and flower petals\n\nFunctions:\n- Impart colour to fruits and flowers\n- Attract pollinators (insects, birds)\n- Attract seed dispersers\n- Help in seed dispersal\n\nExamples:\n- Tomato (red due to lycopene)\n- Carrot (orange due to carotene)\n- Marigold petals (yellow)\n- Capsicum (red, yellow, orange varieties)\n- Ripe mango (yellow)\n\n3. Leucoplasts (Colourless plastids):\n\nCharacteristics:\n- No pigments, colourless\n- Found in non-green parts\n- Underground parts, seeds, roots\n- Store food materials\n\nTypes of leucoplasts:\n- Amyloplasts: Store starch (potato, rice, wheat)\n- Proteinoplasts: Store proteins (beans, peas)\n- Elaioplasts: Store oils/fats (groundnut, mustard)\n\nFunctions:\n- Store reserve food\n- Provide energy during germination\n- Help in perennation\n\nExamples:\n- Potato tuber (starch storage)\n- Rice and wheat grains (starch)\n- Groundnut seeds (oil storage)\n- Bean seeds (protein storage)\n- Ginger rhizome (starch)\n\nComparison table:\n\n| Feature | Chloroplasts | Chromoplasts | Leucoplasts |\n|---------|--------------|--------------|-------------|\n| Colour | Green | Red, orange, yellow | Colourless |\n| Pigment | Chlorophyll | Carotenoids, xanthophylls | None |\n| Location | Leaves, green parts | Fruits, flowers | Roots, stems, seeds |\n| Function | Photosynthesis | Attraction | Food storage |"
        },
        {
            "type": "subjective",
            "q": "Why is the cell called the basic unit of life? Explain.",
            "sample": "The cell is called the basic unit of life because it is the smallest structure that can perform all life functions independently. Several reasons support this:\n\n1. Structural unit:\n   - All living organisms are made of cells\n   - From bacteria to blue whales, all have cellular structure\n   - No living thing exists without cells\n   - Viruses (non-living) have no cellular structure\n\n2. Functional unit:\n   - A single cell can perform all life processes\n   - Nutrition: Takes in and digests food\n   - Respiration: Exchanges gases\n   - Growth: Increases in size and divides\n   - Reproduction: Creates new cells\n   - Excretion: Removes waste\n   - Response: Responds to stimuli\n\n3. Independent existence:\n   - Unicellular organisms (Amoeba, Paramecium) live independently\n   - One cell = complete organism\n   - Can survive, grow, and reproduce alone\n\n4. Building blocks:\n   - Multicellular organisms are built from cells\n   - Billions of cells form tissues and organs\n   - Like bricks form a building\n\n5. Origin of life:\n   - All organisms start as a single cell\n   - Human life begins as one fertilized egg\n   - This single cell contains all information for development\n\n6. Similarity in basic structure:\n   - All cells have similar basic components\n   - Cell membrane, cytoplasm, nucleus\n   - Same fundamental processes\n\n7. Continuity of life:\n   - Cells come from pre-existing cells\n   - Life continues through cell division\n   - Genetic information passed from cell to cell\n\n8. Disease basis:\n   - Diseases affect cells first\n   - Understanding cells helps treat diseases\n   - Cancer is uncontrolled cell division\n\n9. Energy production:\n   - Cells produce energy (ATP) for life\n   - Without cellular respiration, no life\n\n10. Repair and regeneration:\n    - Wound healing occurs at cellular level\n    - New cells replace dead ones\n\nThus, the cell is the fundamental unit where life begins, continues, and expresses itself. It is to biology what the atom is to chemistry."
        }
    ],

#Biology — Grade 6 ICSE
#Chapter 4: Digestive System
#omprehensive Practice Questions
#50 MCQ • 50 True/False • 40 Subjective

    "Chapter 4 — Digestive System": [
        # ===== MCQ (50 questions) =====
        {
            "type": "mcq",
            "q": "What is the process of taking in food through the mouth called?",
            "options": [
                "Digestion",
                "Ingestion",
                "Absorption",
                "Egestion"
            ],
            "answer": "Ingestion",
            "explanation": "Ingestion is the first stage of nutrition in which food is taken in through the mouth."
        },
        {
            "type": "mcq",
            "q": "The conversion of complex food into simple absorbable form is called:",
            "options": [
                "Ingestion",
                "Digestion",
                "Assimilation",
                "Egestion"
            ],
            "answer": "Digestion",
            "explanation": "Digestion is the process of converting complex food into simple, absorbable form by the action of enzymes."
        },
        {
            "type": "mcq",
            "q": "The process by which digested food is absorbed into the blood stream is called:",
            "options": [
                "Digestion",
                "Assimilation",
                "Absorption",
                "Egestion"
            ],
            "answer": "Absorption",
            "explanation": "Absorption is the stage where digested food passes into the blood stream through the walls of the small intestine."
        },
        {
            "type": "mcq",
            "q": "The process by which absorbed food is utilized by the body for energy and growth is called:",
            "options": [
                "Absorption",
                "Assimilation",
                "Digestion",
                "Egestion"
            ],
            "answer": "Assimilation",
            "explanation": "Assimilation is the process where absorbed food materials are used by the body to provide energy and for growth and repair."
        },
        {
            "type": "mcq",
            "q": "The elimination of undigested food from the body is called:",
            "options": [
                "Digestion",
                "Absorption",
                "Assimilation",
                "Egestion"
            ],
            "answer": "Egestion",
            "explanation": "Egestion is the last stage of nutrition where undigested insoluble food is eliminated as faeces."
        },
        {
            "type": "mcq",
            "q": "The digestive system in humans consists of:",
            "options": [
                "Alimentary canal only",
                "Digestive glands only",
                "Alimentary canal and associated digestive glands",
                "Stomach and intestine only"
            ],
            "answer": "Alimentary canal and associated digestive glands",
            "explanation": "The human digestive system has two parts - the alimentary canal and its associated digestive glands (salivary glands, liver, pancreas)."
        },
        {
            "type": "mcq",
            "q": "The alimentary canal runs from:",
            "options": [
                "Mouth to stomach",
                "Mouth to small intestine",
                "Mouth to anus",
                "Stomach to anus"
            ],
            "answer": "Mouth to anus",
            "explanation": "The alimentary canal is a long tube-like muscular structure that runs from the mouth to the anus."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a part of the alimentary canal?",
            "options": [
                "Oesophagus",
                "Stomach",
                "Liver",
                "Large intestine"
            ],
            "answer": "Liver",
            "explanation": "Liver is a digestive gland associated with the alimentary canal, not a part of the canal itself."
        },
        {
            "type": "mcq",
            "q": "The digestive glands associated with the alimentary canal are:",
            "options": [
                "Salivary glands, liver, and pancreas",
                "Salivary glands and stomach only",
                "Liver and pancreas only",
                "Stomach and intestine only"
            ],
            "answer": "Salivary glands, liver, and pancreas",
            "explanation": "The three main digestive glands are salivary glands (in mouth), liver (largest gland), and pancreas."
        },
        {
            "type": "mcq",
            "q": "The mouth cavity is also called:",
            "options": [
                "Buccal cavity",
                "Nasal cavity",
                "Oral cavity",
                "Pharynx"
            ],
            "answer": "Buccal cavity",
            "explanation": "The mouth opens into a small chamber called mouth cavity or buccal cavity."
        },
        {
            "type": "mcq",
            "q": "How many sets of teeth do humans have in their lifetime?",
            "options": [
                "One",
                "Two",
                "Three",
                "Four"
            ],
            "answer": "Two",
            "explanation": "Humans have two sets of teeth - milk teeth (temporary) and permanent teeth."
        },
        {
            "type": "mcq",
            "q": "Milk teeth are also called:",
            "options": [
                "Permanent teeth",
                "Temporary or deciduous teeth",
                "Wisdom teeth",
                "Adult teeth"
            ],
            "answer": "Temporary or deciduous teeth",
            "explanation": "Milk teeth are temporary and fall off between 6 and 12 years of age, so they are called temporary or deciduous teeth."
        },
        {
            "type": "mcq",
            "q": "How many milk teeth do children have?",
            "options": [
                "20",
                "28",
                "32",
                "16"
            ],
            "answer": "20",
            "explanation": "Children have 20 milk teeth - 8 incisors, 4 canines, and 8 premolars."
        },
        {
            "type": "mcq",
            "q": "How many permanent teeth do adult humans have?",
            "options": [
                "28",
                "30",
                "32",
                "34"
            ],
            "answer": "32",
            "explanation": "Adult humans normally have 32 permanent teeth - 8 incisors, 4 canines, 8 premolars, and 12 molars."
        },
        {
            "type": "mcq",
            "q": "Which teeth are used for biting and cutting food?",
            "options": [
                "Canines",
                "Incisors",
                "Premolars",
                "Molars"
            ],
            "answer": "Incisors",
            "explanation": "Incisors are the front teeth with sharp edges used for biting and cutting food."
        },
        {
            "type": "mcq",
            "q": "Which teeth are used for tearing food?",
            "options": [
                "Incisors",
                "Canines",
                "Premolars",
                "Molars"
            ],
            "answer": "Canines",
            "explanation": "Canines are pointed teeth used for tearing food, especially meat."
        },
        {
            "type": "mcq",
            "q": "Which teeth are used for crushing and grinding food?",
            "options": [
                "Incisors and canines",
                "Canines and premolars",
                "Premolars and molars",
                "Incisors only"
            ],
            "answer": "Premolars and molars",
            "explanation": "Premolars and molars have broad, flat surfaces for crushing and grinding food."
        },
        {
            "type": "mcq",
            "q": "How many incisors are there in each jaw of an adult human?",
            "options": [
                "2",
                "4",
                "6",
                "8"
            ],
            "answer": "4",
            "explanation": "Each jaw has 4 incisors, so total 8 incisors in an adult human."
        },
        {
            "type": "mcq",
            "q": "How many canines are there in each jaw of an adult human?",
            "options": [
                "1",
                "2",
                "3",
                "4"
            ],
            "answer": "2",
            "explanation": "Each jaw has 2 canines, so total 4 canines in an adult human."
        },
        {
            "type": "mcq",
            "q": "How many premolars are there in each jaw of an adult human?",
            "options": [
                "2",
                "4",
                "6",
                "8"
            ],
            "answer": "4",
            "explanation": "Each jaw has 4 premolars, so total 8 premolars in an adult human."
        },
        {
            "type": "mcq",
            "q": "How many molars are there in each jaw of an adult human?",
            "options": [
                "4",
                "6",
                "8",
                "12"
            ],
            "answer": "6",
            "explanation": "Each jaw has 6 molars, so total 12 molars in an adult human."
        },
        {
            "type": "mcq",
            "q": "The last molar in each jaw is also called:",
            "options": [
                "Premolar",
                "Wisdom tooth",
                "Canine",
                "Incisor"
            ],
            "answer": "Wisdom tooth",
            "explanation": "The last molar appears late (17-20 years) and is called wisdom tooth."
        },
        {
            "type": "mcq",
            "q": "The hardest substance in the human body is:",
            "options": [
                "Bone",
                "Enamel",
                "Dentine",
                "Cartilage"
            ],
            "answer": "Enamel",
            "explanation": "Enamel covering the crown of teeth is the hardest substance in the human body."
        },
        {
            "type": "mcq",
            "q": "The part of tooth visible above the gum is called:",
            "options": [
                "Root",
                "Crown",
                "Neck",
                "Pulp"
            ],
            "answer": "Crown",
            "explanation": "The crown is the upper visible part of the tooth above the gum."
        },
        {
            "type": "mcq",
            "q": "The part of tooth embedded in the jawbone is called:",
            "options": [
                "Crown",
                "Neck",
                "Root",
                "Enamel"
            ],
            "answer": "Root",
            "explanation": "The root is the lower part embedded in a cup-like socket of the jawbone."
        },
        {
            "type": "mcq",
            "q": "The pulp cavity in a tooth contains:",
            "options": [
                "Enamel",
                "Dentine",
                "Nerves and blood vessels",
                "Air"
            ],
            "answer": "Nerves and blood vessels",
            "explanation": "The pulp cavity beneath the dentine contains nerves and blood vessels."
        },
        {
            "type": "mcq",
            "q": "Tooth decay is also called:",
            "options": [
                "Dental plaque",
                "Dental caries",
                "Tartar",
                "Gingivitis"
            ],
            "answer": "Dental caries",
            "explanation": "Tooth decay caused by acid produced by bacteria is called dental caries."
        },
        {
            "type": "mcq",
            "q": "The mixture of saliva, food, and bacteria that forms on teeth is called:",
            "options": [
                "Tartar",
                "Plaque",
                "Cavity",
                "Enamel"
            ],
            "answer": "Plaque",
            "explanation": "Dental plaque is a sticky film of saliva, food particles, and bacteria that forms on teeth."
        },
        {
            "type": "mcq",
            "q": "Hardened plaque is called:",
            "options": [
                "Cavity",
                "Tartar",
                "Enamel",
                "Dentine"
            ],
            "answer": "Tartar",
            "explanation": "When plaque hardens, it becomes tartar or calculus."
        },
        {
            "type": "mcq",
            "q": "The tongue helps in:",
            "options": [
                "Tasting food only",
                "Moving food in the mouth",
                "Chewing food",
                "Both tasting and moving food"
            ],
            "answer": "Both tasting and moving food",
            "explanation": "The tongue has taste buds for tasting and helps move food for chewing and swallowing."
        },
        {
            "type": "mcq",
            "q": "The common passage for food and air is called:",
            "options": [
                "Oesophagus",
                "Trachea",
                "Pharynx",
                "Larynx"
            ],
            "answer": "Pharynx",
            "explanation": "The pharynx is the common passage for food and air from mouth and nose to throat."
        },
        {
            "type": "mcq",
            "q": "The food pipe is also called:",
            "options": [
                "Trachea",
                "Oesophagus",
                "Pharynx",
                "Windpipe"
            ],
            "answer": "Oesophagus",
            "explanation": "The oesophagus, or food pipe, is a tube about 25 cm long extending from pharynx to stomach."
        },
        {
            "type": "mcq",
            "q": "The wave-like muscular contractions that push food through the oesophagus are called:",
            "options": [
                "Digestion",
                "Peristalsis",
                "Absorption",
                "Segmentation"
            ],
            "answer": "Peristalsis",
            "explanation": "Peristalsis is the wave-like contraction and relaxation of muscles that pushes food forward."
        },
        {
            "type": "mcq",
            "q": "The stomach is shaped like the letter:",
            "options": [
                "I",
                "U",
                "J",
                "C"
            ],
            "answer": "J",
            "explanation": "The stomach is a J-shaped muscular bag-like organ on the left side of the abdomen."
        },
        {
            "type": "mcq",
            "q": "The inner wall of the stomach has millions of:",
            "options": [
                "Villi",
                "Gastric glands",
                "Enzymes",
                "Pores"
            ],
            "answer": "Gastric glands",
            "explanation": "Gastric glands in the stomach wall secrete gastric juice containing HCl and enzymes."
        },
        {
            "type": "mcq",
            "q": "Gastric juice contains:",
            "options": [
                "Pepsin only",
                "Hydrochloric acid only",
                "Hydrochloric acid and enzymes",
                "Bile"
            ],
            "answer": "Hydrochloric acid and enzymes",
            "explanation": "Gastric juice is rich in hydrochloric acid and enzymes like pepsin and rennin."
        },
        {
            "type": "mcq",
            "q": "The small intestine is divided into:",
            "options": [
                "Duodenum, jejunum, and ileum",
                "Caecum, colon, and rectum",
                "Duodenum and ileum only",
                "Jejunum and colon"
            ],
            "answer": "Duodenum, jejunum, and ileum",
            "explanation": "The small intestine has three parts - duodenum (anterior), jejunum (middle), and ileum (posterior)."
        },
        {
            "type": "mcq",
            "q": "The finger-like projections in the small intestine are called:",
            "options": [
                "Cilia",
                "Villi",
                "Cristae",
                "Grana"
            ],
            "answer": "Villi",
            "explanation": "Villi are finger-like projections that increase surface area for absorption of digested food."
        },
        {
            "type": "mcq",
            "q": "The function of villi is:",
            "options": [
                "Digestion of food",
                "Absorption of digested food",
                "Secretion of enzymes",
                "Storage of food"
            ],
            "answer": "Absorption of digested food",
            "explanation": "Villi absorb digested food through their thin walls into the blood capillaries."
        },
        {
            "type": "mcq",
            "q": "The large intestine has which parts?",
            "options": [
                "Duodenum, jejunum, ileum",
                "Caecum, colon, rectum",
                "Stomach and intestine",
                "Oesophagus and stomach"
            ],
            "answer": "Caecum, colon, rectum",
            "explanation": "The large intestine has three parts: caecum, colon, and rectum (which opens to anus)."
        },
        {
            "type": "mcq",
            "q": "The main function of the large intestine is:",
            "options": [
                "Digestion of food",
                "Absorption of water",
                "Secretion of enzymes",
                "Production of bile"
            ],
            "answer": "Absorption of water",
            "explanation": "The large intestine reabsorbs excess water from undigested food."
        },
        {
            "type": "mcq",
            "q": "How many pairs of salivary glands are there?",
            "options": [
                "One",
                "Two",
                "Three",
                "Four"
            ],
            "answer": "Three",
            "explanation": "There are three pairs of salivary glands that open into the mouth cavity."
        },
        {
            "type": "mcq",
            "q": "Saliva contains an enzyme called:",
            "options": [
                "Pepsin",
                "Trypsin",
                "Salivary amylase or ptyalin",
                "Lipase"
            ],
            "answer": "Salivary amylase or ptyalin",
            "explanation": "Saliva contains salivary amylase (ptyalin) which acts on starch and breaks it into maltose."
        },
        {
            "type": "mcq",
            "q": "The largest gland in the human body is:",
            "options": [
                "Pancreas",
                "Liver",
                "Salivary gland",
                "Stomach"
            ],
            "answer": "Liver",
            "explanation": "The liver is the largest gland inside our body, located in the upper right side of abdominal cavity."
        },
        {
            "type": "mcq",
            "q": "Bile is produced by the:",
            "options": [
                "Pancreas",
                "Liver",
                "Gall bladder",
                "Stomach"
            ],
            "answer": "Liver",
            "explanation": "Bile is made in the liver and stored in the gall bladder."
        },
        {
            "type": "mcq",
            "q": "Bile is stored in the:",
            "options": [
                "Liver",
                "Pancreas",
                "Gall bladder",
                "Stomach"
            ],
            "answer": "Gall bladder",
            "explanation": "The gall bladder stores and concentrates bile produced by the liver."
        },
        {
            "type": "mcq",
            "q": "The function of bile is:",
            "options": [
                "Digestion of proteins",
                "Digestion of carbohydrates",
                "Emulsification of fats",
                "Digestion of all foods"
            ],
            "answer": "Emulsification of fats",
            "explanation": "Bile breaks down large fat globules into tiny droplets for enzyme action - this is emulsification."
        },
        {
            "type": "mcq",
            "q": "Pancreatic juice contains which enzymes?",
            "options": [
                "Amylase only",
                "Trypsin and lipase",
                "Amylase, trypsin, and lipase",
                "Pepsin and rennin"
            ],
            "answer": "Amylase, trypsin, and lipase",
            "explanation": "Pancreatic juice contains starch-digesting amylase, protein-digesting trypsin, and fat-digesting lipase."
        },
        {
            "type": "mcq",
            "q": "The enzyme that digests proteins in the stomach is:",
            "options": [
                "Trypsin",
                "Pepsin",
                "Lipase",
                "Amylase"
            ],
            "answer": "Pepsin",
            "explanation": "Pepsin in gastric juice changes proteins into proteases and peptones."
        },
        {
            "type": "mcq",
            "q": "Rennin acts on:",
            "options": [
                "Starch",
                "Proteins",
                "Milk protein (casein)",
                "Fats"
            ],
            "answer": "Milk protein (casein)",
            "explanation": "Rennin changes milk protein casein into paracasein (insoluble curd)."
        },
        {
            "type": "mcq",
            "q": "Trypsin acts on proteins and changes them into:",
            "options": [
                "Amino acids",
                "Polypeptides",
                "Glucose",
                "Fatty acids"
            ],
            "answer": "Polypeptides",
            "explanation": "Trypsin changes proteins, proteoses, and peptones into polypeptides."
        },
        {
            "type": "mcq",
            "q": "Lipase acts on fats to change them into:",
            "options": [
                "Glucose and fructose",
                "Amino acids",
                "Fatty acids and glycerol",
                "Maltose"
            ],
            "answer": "Fatty acids and glycerol",
            "explanation": "Lipase breaks down fats into fatty acids and glycerol."
        },
        
        # ===== True/False (50 questions) =====
        {
            "type": "tf",
            "q": "Nutrition is the process by which living organisms obtain and use food.",
            "answer": "True",
            "explanation": "This is the correct definition of nutrition."
        },
        {
            "type": "tf",
            "q": "Animals including humans depend only on plants for their food.",
            "answer": "False",
            "explanation": "Animals depend on plants AND other animals for food (some are carnivores/omnivores)."
        },
        {
            "type": "tf",
            "q": "Food can be utilized by the body in the same form as it is consumed.",
            "answer": "False",
            "explanation": "Food must be broken down into simpler forms before it can be absorbed and utilized."
        },
        {
            "type": "tf",
            "q": "Digestion is the first stage of nutrition.",
            "answer": "False",
            "explanation": "Ingestion (taking in food) is the first stage, followed by digestion."
        },
        {
            "type": "tf",
            "q": "The five stages of nutrition are ingestion, digestion, absorption, assimilation, and egestion.",
            "answer": "True",
            "explanation": "These are the five stages in correct sequence."
        },
        {
            "type": "tf",
            "q": "The alimentary canal is a long tube-like muscular structure.",
            "answer": "True",
            "explanation": "The alimentary canal is a long, tubular, muscular structure from mouth to anus."
        },
        {
            "type": "tf",
            "q": "The main function of the mouth is to start protein digestion.",
            "answer": "False",
            "explanation": "The mouth receives food and starts carbohydrate digestion (starch) with salivary amylase."
        },
        {
            "type": "tf",
            "q": "Milk teeth are also called permanent teeth.",
            "answer": "False",
            "explanation": "Milk teeth are temporary or deciduous teeth that fall off and are replaced by permanent teeth."
        },
        {
            "type": "tf",
            "q": "Children have 20 milk teeth.",
            "answer": "True",
            "explanation": "Children have 20 temporary teeth - 8 incisors, 4 canines, and 8 premolars."
        },
        {
            "type": "tf",
            "q": "Adults have 28 permanent teeth.",
            "answer": "False",
            "explanation": "Adults have 32 permanent teeth - 8 incisors, 4 canines, 8 premolars, and 12 molars."
        },
        {
            "type": "tf",
            "q": "Incisors are used for tearing food.",
            "answer": "False",
            "explanation": "Incisors are for biting/cutting; canines are for tearing."
        },
        {
            "type": "tf",
            "q": "Canines are pointed teeth used for tearing food.",
            "answer": "True",
            "explanation": "Canines have sharp points for tearing, especially meat."
        },
        {
            "type": "tf",
            "q": "Premolars and molars have flat surfaces for crushing and grinding food.",
            "answer": "True",
            "explanation": "These teeth have broad, flat surfaces for grinding food."
        },
        {
            "type": "tf",
            "q": "The last molar is called wisdom tooth and appears in all people.",
            "answer": "False",
            "explanation": "Wisdom teeth may not appear in some people; this is normal."
        },
        {
            "type": "tf",
            "q": "Enamel is the hardest substance in the human body.",
            "answer": "True",
            "explanation": "Tooth enamel is harder than bone."
        },
        {
            "type": "tf",
            "q": "The crown of a tooth is embedded in the jawbone.",
            "answer": "False",
            "explanation": "The root is embedded in the jawbone; the crown is visible above the gum."
        },
        {
            "type": "tf",
            "q": "The pulp cavity contains nerves and blood vessels.",
            "answer": "True",
            "explanation": "The pulp cavity has nerves and blood vessels that keep the tooth alive."
        },
        {
            "type": "tf",
            "q": "Tooth decay is caused by viruses.",
            "answer": "False",
            "explanation": "Tooth decay is caused by bacteria acting on food particles, producing acid."
        },
        {
            "type": "tf",
            "q": "Dental plaque is a mixture of saliva, food, and bacteria.",
            "answer": "True",
            "explanation": "Plaque forms on teeth within half an hour of eating."
        },
        {
            "type": "tf",
            "q": "Hardened plaque is called tartar.",
            "answer": "True",
            "explanation": "When plaque hardens, it becomes tartar or calculus."
        },
        {
            "type": "tf",
            "q": "The tongue has taste buds that help in distinguishing tastes.",
            "answer": "True",
            "explanation": "Different regions of the tongue detect different tastes - sweet, sour, salty, bitter."
        },
        {
            "type": "tf",
            "q": "The pharynx is the passage only for food.",
            "answer": "False",
            "explanation": "The pharynx is a common passage for both food and air."
        },
        {
            "type": "tf",
            "q": "Food moves through the oesophagus by gravity.",
            "answer": "False",
            "explanation": "Food moves by peristalsis (muscular contractions), not gravity."
        },
        {
            "type": "tf",
            "q": "Peristalsis is the wave-like motion of muscles that pushes food forward.",
            "answer": "True",
            "explanation": "Muscles contract and relax in waves to propel food."
        },
        {
            "type": "tf",
            "q": "The stomach is an I-shaped organ on the right side of the abdomen.",
            "answer": "False",
            "explanation": "The stomach is J-shaped and on the left side of the abdomen."
        },
        {
            "type": "tf",
            "q": "Gastric glands secrete gastric juice containing HCl and enzymes.",
            "answer": "True",
            "explanation": "Gastric juice has hydrochloric acid and enzymes like pepsin and rennin."
        },
        {
            "type": "tf",
            "q": "Hydrochloric acid in the stomach kills bacteria and provides acidic medium.",
            "answer": "True",
            "explanation": "HCl kills bacteria and creates an acidic environment for pepsin to work."
        },
        {
            "type": "tf",
            "q": "Pepsin digests carbohydrates.",
            "answer": "False",
            "explanation": "Pepsin digests proteins, not carbohydrates."
        },
        {
            "type": "tf",
            "q": "Rennin changes milk protein casein into insoluble curd.",
            "answer": "True",
            "explanation": "Rennin acts on casein to form paracasein (curd)."
        },
        {
            "type": "tf",
            "q": "The food coming out of the stomach is called chyme.",
            "answer": "True",
            "explanation": "Chyme is the thick paste formed when food mixes with gastric juice."
        },
        {
            "type": "tf",
            "q": "The small intestine is shorter than the large intestine.",
            "answer": "False",
            "explanation": "The small intestine is longer (about 6-7 m) but narrower; large intestine is shorter but wider."
        },
        {
            "type": "tf",
            "q": "Villi increase the surface area for absorption in the small intestine.",
            "answer": "True",
            "explanation": "Millions of villi provide huge surface area for absorption."
        },
        {
            "type": "tf",
            "q": "The large intestine absorbs water from undigested food.",
            "answer": "True",
            "explanation": "Water reabsorption occurs in the large intestine."
        },
        {
            "type": "tf",
            "q": "The rectum stores undigested food before egestion.",
            "answer": "True",
            "explanation": "Faeces are stored in the rectum until eliminated through the anus."
        },
        {
            "type": "tf",
            "q": "An average adult generates about 1.7 litres of saliva every day.",
            "answer": "True",
            "explanation": "Saliva production is continuous and helps in digestion and protection."
        },
        {
            "type": "tf",
            "q": "Saliva contains an enzyme that digests proteins.",
            "answer": "False",
            "explanation": "Saliva contains salivary amylase that digests starch (carbohydrates)."
        },
        {
            "type": "tf",
            "q": "The liver performs over 500 different body functions.",
            "answer": "True",
            "explanation": "The liver is involved in metabolism, storage, detoxification, and many other functions."
        },
        {
            "type": "tf",
            "q": "The liver can regenerate itself completely even if 75% is removed.",
            "answer": "True",
            "explanation": "The liver has remarkable regenerative capacity."
        },
        {
            "type": "tf",
            "q": "Bile contains enzymes that digest fats.",
            "answer": "False",
            "explanation": "Bile does not contain enzymes; it emulsifies fats for enzyme action."
        },
        {
            "type": "tf",
            "q": "Emulsification is the breaking down of large fat droplets into tiny droplets.",
            "answer": "True",
            "explanation": "This increases surface area for lipase action."
        },
        {
            "type": "tf",
            "q": "The pancreas secretes pancreatic juice into the stomach.",
            "answer": "False",
            "explanation": "Pancreatic juice is secreted into the small intestine (duodenum)."
        },
        {
            "type": "tf",
            "q": "Trypsin in pancreatic juice digests proteins.",
            "answer": "True",
            "explanation": "Trypsin breaks down proteins into polypeptides."
        },
        {
            "type": "tf",
            "q": "Lipase digests carbohydrates.",
            "answer": "False",
            "explanation": "Lipase digests fats; amylase digests carbohydrates."
        },
        {
            "type": "tf",
            "q": "Maltase changes maltose into glucose.",
            "answer": "True",
            "explanation": "Maltase is an enzyme in the small intestine that acts on maltose."
        },
        {
            "type": "tf",
            "q": "Sucrase changes sucrose into glucose and fructose.",
            "answer": "True",
            "explanation": "Sucrose (table sugar) is broken down into glucose and fructose."
        },
        {
            "type": "tf",
            "q": "Lactase changes lactose into glucose and galactose.",
            "answer": "True",
            "explanation": "Lactose (milk sugar) is broken down by lactase."
        },
        {
            "type": "tf",
            "q": "Glucose is converted into glycogen and stored in the pancreas.",
            "answer": "False",
            "explanation": "Glucose is converted to glycogen and stored in the liver and muscles."
        },
        {
            "type": "tf",
            "q": "Excess amino acids are converted into urea and excreted.",
            "answer": "True",
            "explanation": "The liver converts excess amino acids to urea, which kidneys excrete."
        },
        {
            "type": "tf",
            "q": "Vomiting occurs when the stomach is overfilled and contents are thrown out.",
            "answer": "True",
            "explanation": "Vomiting is a protective reflex to expel harmful substances."
        },
        {
            "type": "tf",
            "q": "Food would not reach the stomach if a person eats while standing upside down.",
            "answer": "False",
            "explanation": "Peristalsis moves food regardless of gravity; it would still reach the stomach."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "Explain the five stages of nutrition in humans with a brief description of each.",
            "sample": "The five stages of nutrition in humans are:\n\n1. Ingestion:\n   - Taking in food through the mouth\n   - Food is ingested and chewed\n   - First stage of nutrition\n\n2. Digestion:\n   - Conversion of complex food into simple, absorbable form\n   - Occurs by action of enzymes\n   - Mechanical (chewing, churning) and chemical (enzymes) digestion\n   - Begins in mouth, continues in stomach, completed in small intestine\n\n3. Absorption:\n   - Digested food passes into blood stream\n   - Occurs mainly in small intestine through villi\n   - Nutrients enter blood capillaries\n\n4. Assimilation:\n   - Absorbed food is utilized by the body\n   - Provides energy for activities\n   - Used for growth and repair of tissues\n   - Excess stored for future use (glycogen in liver, fat in adipose tissue)\n\n5. Egestion:\n   - Elimination of undigested insoluble food\n   - Undigested food forms faeces in large intestine\n   - Faeces stored in rectum and passed out through anus\n   - Last stage of nutrition"
        },
        {
            "type": "subjective",
            "q": "Describe the structure and functions of different types of teeth in humans.",
            "sample": "Humans have four types of teeth with different structures and functions:\n\n1. Incisors:\n   Structure:\n   - Front teeth, 8 in number (4 in each jaw)\n   - Sharp, chisel-shaped edges\n   - Single root\n   \n   Function:\n   - Biting and cutting food\n   - Used for biting into fruits, vegetables, bread\n\n2. Canines:\n   Structure:\n   - Pointed, sharp teeth, 4 in number (2 in each jaw)\n   - Longest teeth, single root\n   - Cone-shaped\n   \n   Function:\n   - Tearing and piercing food\n   - Especially important for tearing meat\n\n3. Premolars:\n   Structure:\n   - 8 in number (4 in each jaw)\n   - Have broad, flat surfaces with ridges\n   - Two roots (upper jaw), one root (lower jaw)\n   \n   Function:\n   - Crushing and grinding food\n   - Help in chewing\n\n4. Molars:\n   Structure:\n   - 12 in number (6 in each jaw)\n   - Largest teeth, broad flat surfaces\n   - Multiple roots (2-3)\n   - Last molars called wisdom teeth\n   \n   Function:\n   - Grinding and chewing food\n   - Reduce food to small particles for swallowing\n\nTooth structure (common to all):\n- Crown: Visible part above gum, covered with enamel (hardest substance)\n- Neck: Surrounded by gum\n- Root: Embedded in jawbone\n- Dentine: Beneath enamel, forms bulk of tooth\n- Pulp cavity: Contains nerves and blood vessels"
        },
        {
            "type": "subjective",
            "q": "What is tooth decay? Explain its causes and prevention.",
            "sample": "Tooth decay (dental caries) is the gradual destruction of tooth structure caused by acid produced by bacteria.\n\nCauses of tooth decay:\n\n1. Food particles trapped between teeth:\n   - Especially sugary and starchy foods\n   - Food debris remains in mouth after eating\n\n2. Bacterial action:\n   - Bacteria in mouth act on food particles\n   - They produce acid as a byproduct\n\n3. Acid formation:\n   - Acid slowly dissolves enamel\n   - Creates cavities (holes) in teeth\n   - If untreated, reaches dentine and pulp\n\n4. Plaque formation:\n   - Mixture of saliva, food, and bacteria forms sticky film (plaque)\n   - Plaque hardens into tartar if not removed\n   - Bacteria in plaque cause infection and inflammation\n\nSymptoms:\n- Toothache\n- Sensitivity to hot/cold/sweet\n- Visible holes in teeth\n- Bad breath\n- Pain while chewing\n\nPrevention:\n\n1. Regular brushing:\n   - Brush twice daily (morning and before bed)\n   - Use fluoride toothpaste\n   - Brush correctly for 2-3 minutes\n\n2. Flossing:\n   - Clean between teeth daily\n   - Remove trapped food particles\n\n3. Healthy diet:\n   - Avoid excess sugary foods and drinks\n   - Limit sticky sweets (toffees, chocolates)\n   - Eat crunchy vegetables (clean teeth naturally)\n\n4. Dental checkups:\n   - Visit dentist every 6 months\n   - Get cavities filled early\n   - Professional cleaning removes tartar\n\n5. Rinse mouth:\n   - Rinse after every meal\n   - Use mouthwash if recommended"
        },
        {
            "type": "subjective",
            "q": "Describe the structure of a tooth with a labeled diagram.",
            "sample": "Structure of a tooth (premolar as example):\n\nExternal parts:\n1. Crown:\n   - Upper visible part of tooth\n   - Projects above the gum\n   - Covered with enamel\n\n2. Neck:\n   - Narrow portion between crown and root\n   - Surrounded by gum tissue\n\n3. Root:\n   - Lower part embedded in jawbone\n   - Fits into socket (alveolus)\n   - Number varies by tooth type\n\nInternal structure:\n\n4. Enamel:\n   - Hardest substance in human body\n   - Covers the crown\n   - Protects tooth from wear and acid\n   - Made of calcium phosphate\n\n5. Dentine:\n   - Beneath the enamel\n   - Forms the bulk of the tooth\n   - Softer than enamel but harder than bone\n   - Yellowish in colour\n   - Contains microscopic tubules\n\n6. Pulp cavity:\n   - Innermost part of tooth\n   - Contains blood vessels\n   - Contains nerves\n   - Keeps tooth alive and sensitive\n   - Extends into root as root canal\n\n7. Cementum:\n   - Covers the root\n   - Helps attach tooth to jawbone\n\n8. Periodontal ligament:\n   - Fibers that hold tooth in socket\n   - Acts as shock absorber\n\nBlood supply and nerves:\n- Enter through root tip\n- Supply nutrients to tooth\n- Provide sensation (pain, temperature)\n\n[Note: Students should draw and label a diagram showing all these parts]"
        },
        {
            "type": "subjective",
            "q": "Explain the functions of the tongue in digestion.",
            "sample": "The tongue is a thick muscular organ in the mouth cavity that performs several important functions in digestion:\n\n1. Tasting food:\n   - Covered with taste buds (about 10,000)\n   - Different regions detect different tastes:\n     * Tip: Sweet\n     * Sides front: Salty\n     * Sides middle: Sour\n     * Back: Bitter\n   - Helps identify food quality (spoiled vs fresh)\n\n2. Mixing food with saliva:\n   - Moves food around the mouth\n   - Helps mix food thoroughly with saliva\n   - Saliva contains enzymes that start digestion\n   - Moistens food for swallowing\n\n3. Forming bolus:\n   - Rolls food into small, soft ball (bolus)\n   - Prepares food for swallowing\n   - Makes food slippery with mucus from saliva\n\n4. Swallowing:\n   - Pushes bolus towards pharynx\n   - Initiates swallowing reflex\n   - Prevents food from entering windpipe\n\n5. Speech (indirectly related to digestion):\n   - Helps form words to ask for food\n   - Not a digestive function but important\n\n6. Cleaning teeth:\n   - Moves food from between teeth\n   - Helps keep mouth clean\n\n7. Sensation:\n   - Detects temperature (hot/cold)\n   - Detects texture (hard/soft)\n   - Detects harmful substances\n\n8. Suckling in infants:\n   - Essential for breastfeeding\n   - Helps obtain milk\n\nThus, the tongue is essential for both mechanical digestion (mixing, forming bolus) and sensory evaluation of food."
        },
        {
            "type": "subjective",
            "q": "What is peristalsis? Explain its role in digestion with a diagram.",
            "sample": "Peristalsis is the wave-like contraction and relaxation of muscles in the walls of the alimentary canal that pushes food forward.\n\nMechanism of peristalsis:\n\n1. Circular muscles contract behind the food bolus:\n   - This narrows the tube\n   - Prevents food from moving backward\n\n2. Longitudinal muscles ahead of bolus contract:\n   - This shortens the tube ahead\n   - Pulls the wall forward\n\n3. Circular muscles ahead relax:\n   - Widens the tube\n   - Creates space for food to move into\n\n4. Wave of contraction moves forward:\n   - Progresses along the canal\n   - Pushes food continuously\n\nRole in different parts:\n\n1. In oesophagus:\n   - Moves bolus from pharynx to stomach\n   - Takes about 5-8 seconds\n   - Works against gravity\n\n2. In stomach:\n   - Churns and mixes food with gastric juice\n   - Helps in mechanical digestion\n   - Gradually pushes chyme to small intestine\n\n3. In small intestine:\n   - Mixes food with digestive juices\n   - Moves food along for absorption\n   - Segmental movements also occur\n\n4. In large intestine:\n   - Slower peristalsis\n   - Moves undigested material to rectum\n   - Helps in water absorption\n\nImportance:\n- Ensures continuous movement of food\n- Works even if you're upside down\n- Automatic (involuntary) process\n- Essential for digestion and egestion\n\n[Note: Students should draw a diagram showing waves of contraction and relaxation]"
        },
        {
            "type": "subjective",
            "q": "Describe the structure and functions of the stomach.",
            "sample": "The stomach is a J-shaped muscular organ located on the left side of the abdomen, below the diaphragm.\n\nStructure of stomach:\n\n1. External features:\n   - J-shaped, bag-like structure\n   - About 25-30 cm long\n   - Can stretch to hold 1-1.5 litres of food\n   - Upper end connects to oesophagus (cardiac end)\n   - Lower end opens into small intestine (pyloric end)\n\n2. Layers of stomach wall (from outside to inside):\n   - Outer serous layer (protective)\n   - Muscular layer (3 layers of muscles)\n   - Submucosa (contains blood vessels)\n   - Inner mucous layer (contains gastric glands)\n\n3. Gastric glands:\n   - Millions of microscopic glands\n   - Secrete gastric juice\n   - Contain different cell types:\n     * Chief cells: Produce pepsinogen\n     * Parietal cells: Produce HCl\n     * Mucus cells: Produce mucus\n\nFunctions of stomach:\n\n1. Storage of food:\n   - Acts as a reservoir\n   - Releases food gradually to small intestine\n   - Allows time for digestion\n\n2. Mechanical digestion:\n   - Muscles churn and mix food\n   - Breaks food into smaller pieces\n   - Forms semi-fluid chyme\n\n3. Chemical digestion:\n   - Gastric juice contains:\n     * Hydrochloric acid: Kills bacteria, provides acidic medium\n     * Pepsin: Digests proteins → proteoses + peptones\n     * Rennin: Curdles milk (casein → paracasein)\n\n4. Protection:\n   - Acid kills many harmful bacteria\n   - Mucus protects stomach lining\n\n5. Absorption:\n   - Limited absorption (water, alcohol, some drugs)\n   - Most absorption occurs in small intestine\n\n6. Regulation:\n   - Controls rate of food passage\n   - Signals hunger and fullness"
        },
        {
            "type": "subjective",
            "q": "Explain the structure and function of villi in the small intestine.",
            "sample": "Villi (singular: villus) are finger-like projections lining the inner wall of the small intestine that greatly increase surface area for absorption.\n\nStructure of villi:\n\n1. Shape and size:\n   - Finger-like projections, about 0.5-1.5 mm long\n   - Millions present (about 20-40 per square mm)\n   - Give velvety appearance to inner intestinal wall\n   - Increase surface area by about 30 times\n\n2. Covering:\n   - Single layer of epithelial cells\n   - Cells have microvilli (brush border)\n   - Further increases surface area\n\n3. Internal structure:\n   - Blood capillaries (network of tiny blood vessels)\n   - Lymph vessel called lacteal (central)\n   - Thin walls for easy diffusion\n\n4. Associated structures:\n   - Intestinal glands (crypts) between villi\n   - Secrete intestinal juice (contains enzymes)\n\nFunctions of villi:\n\n1. Absorption of digested food:\n   - Glucose and amino acids: Enter blood capillaries\n   - Fatty acids and glycerol: Enter lacteal (as tiny droplets)\n   - Vitamins and minerals: Pass into blood\n\n2. Transport:\n   - Blood carries nutrients to liver via hepatic portal vein\n   - Lymph carries fats to lymphatic system\n\n3. Secretion:\n   - Cells secrete digestive enzymes\n   - Complete digestion of food\n\n4. Protection:\n   - Mucous coating protects intestinal wall\n   - Prevents self-digestion\n\nAdaptations for absorption:\n\n1. Large surface area:\n   - Long intestine (6-7 m)\n   - Millions of villi\n   - Microvilli on villi cells\n\n2. Thin walls:\n   - One cell thick\n   - Easy diffusion of nutrients\n\n3. Rich blood supply:\n   - Dense capillary network\n   - Quick transport of absorbed nutrients\n\n4. Constant movement:\n   - Villi move and sway\n   - Increases contact with food"
        },
        {
            "type": "subjective",
            "q": "Differentiate between small intestine and large intestine.",
            "sample": "Differences between small intestine and large intestine:\n\n| Characteristic | Small Intestine | Large Intestine |\n|----------------|-----------------|-----------------|\n| Length | About 6-7 metres long | About 1.5 metres long |\n| Diameter | Narrower (about 2.5-3 cm) | Wider (about 5-6 cm) |\n| Parts | Duodenum, jejunum, ileum | Caecum, colon, rectum |\n| Inner surface | Has villi and microvilli | Smooth, no villi |\n| Wall structure | Thinner walls | Thicker, muscular walls |\n| Movement | Peristalsis and segmentation | Slower peristalsis |\n| Main function | Digestion and absorption of nutrients | Absorption of water and salts |\n| Secretions | Intestinal juice, receives bile and pancreatic juice | No digestive enzymes secreted |\n| Contents | Chyme (semi-fluid digested food) | Undigested residue, water, bacteria |\n| Bacterial action | Limited bacteria | Many bacteria (gut flora) |\n| Vitamin production | No vitamin synthesis | Bacteria produce vitamin K and B vitamins |\n| Time food stays | 3-5 hours | 12-24 hours |\n| End product | Absorbed nutrients to blood | Faeces to rectum |\n| Associated structures | Villi, lacteals | Appendix (at caecum) |\n| Sphincters | Pyloric sphincter (entry) | Ileocaecal valve, anal sphincters |\n\nSimilarities:\n- Both are parts of alimentary canal\n- Both have muscular walls\n- Both involved in movement of food\n- Both lined with mucous membrane\n\nPath of food:\nStomach → Small intestine (duodenum → jejunum → ileum) → Large intestine (caecum → colon → rectum) → anus"
        },
        {
            "type": "subjective",
            "q": "Describe the role of the liver in digestion.",
            "sample": "The liver is the largest gland in the human body and plays multiple crucial roles in digestion and metabolism.\n\nLocation and structure:\n- Located in upper right side of abdominal cavity\n- Protected by rib cage\n- Divided into right and left lobes\n- Dark reddish-brown organ\n- Receives blood from digestive tract via hepatic portal vein\n\nDigestive functions of liver:\n\n1. Production of bile:\n   - Liver cells (hepatocytes) produce bile continuously\n   - About 600-1000 ml per day\n   - Bile is greenish-yellow fluid\n   - Stored and concentrated in gall bladder\n\n2. Emulsification of fats:\n   - Bile salts break down large fat globules into tiny droplets\n   - Increases surface area for lipase action\n   - No enzymes in bile, but essential for fat digestion\n\n3. Alkaline medium:\n   - Bile is alkaline (contains sodium bicarbonate)\n   - Neutralizes acidic chyme from stomach\n   - Provides optimal pH for intestinal and pancreatic enzymes\n\nMetabolic functions related to digestion:\n\n4. Carbohydrate metabolism:\n   - Converts glucose to glycogen (glycogenesis)\n   - Stores glycogen\n   - Converts glycogen back to glucose when needed (glycogenolysis)\n   - Maintains blood sugar level\n\n5. Protein metabolism:\n   - Deamination of excess amino acids\n   - Converts ammonia to urea (less toxic)\n   - Synthesizes plasma proteins\n\n6. Fat metabolism:\n   - Synthesizes cholesterol\n   - Produces lipoproteins\n   - Stores some fats\n\n7. Vitamin storage:\n   - Stores vitamins A, D, E, K, B12\n   - Stores iron and copper\n\n8. Detoxification:\n   - Removes toxins and drugs from blood\n   - Processes alcohol\n   - Breaks down hormones\n\n9. Production of blood clotting factors:\n   - Produces fibrinogen, prothrombin\n   - Requires vitamin K\n\nThus, the liver is essential not only for digestion but for overall metabolism and health."
        },
        {
            "type": "subjective",
            "q": "Explain the function of the pancreas in digestion.",
            "sample": "The pancreas is a digestive gland located behind the stomach that produces pancreatic juice containing multiple digestive enzymes.\n\nLocation and structure:\n- Leaf-shaped, yellowish gland\n- About 15-20 cm long\n- Lies behind the stomach\n- Connected to duodenum by pancreatic duct\n- Has both exocrine (digestive) and endocrine (hormonal) parts\n\nComposition of pancreatic juice:\n- Water and salts\n- Sodium bicarbonate (alkaline)\n- Digestive enzymes:\n  * Pancreatic amylase (for starch)\n  * Trypsin (for proteins)\n  * Lipase (for fats)\n  * Other enzymes (peptidases, nucleases)\n\nFunctions of pancreatic enzymes:\n\n1. Pancreatic amylase:\n   - Continues starch digestion\n   - Breaks down starch into maltose\n   - Similar to salivary amylase but works in alkaline medium\n\n2. Trypsin:\n   - Secreted as inactive trypsinogen\n   - Activated in duodenum\n   - Digests proteins into polypeptides\n   - Also digests proteoses and peptones\n\n3. Lipase:\n   - Most important fat-digesting enzyme\n   - Works on emulsified fats\n   - Breaks fats into fatty acids and glycerol\n   - Requires bile for effectiveness\n\n4. Other enzymes:\n   - Peptidases: Break polypeptides into amino acids\n   - Nucleases: Digest nucleic acids\n\nRole of sodium bicarbonate:\n- Makes pancreatic juice alkaline (pH about 8)\n- Neutralizes acidic chyme from stomach\n- Provides optimal pH for pancreatic enzymes\n- Protects intestinal lining from acid\n\nRegulation of pancreatic secretion:\n- Stimulated by hormone secretin (from duodenum)\n- Stimulated by hormone cholecystokinin\n- Presence of food in duodenum triggers release\n\nImportance:\n- Completes digestion of all major food types\n- Without pancreas, severe malnutrition occurs\n- Pancreatic enzymes used in some digestive medicines\n\nEndocrine function:\n- Islets of Langerhans produce insulin and glucagon\n- Regulate blood sugar level\n- Not directly digestive but important for metabolism"
        },
        {
            "type": "subjective",
            "q": "What is emulsification of fats? Why is it important?",
            "sample": "Emulsification of fats is the process of breaking down large fat globules into tiny droplets to increase surface area for enzyme action.\n\nDefinition:\nEmulsification is the breakdown of large fat droplets into many smaller droplets, forming a milky emulsion. This is not chemical digestion (no bonds broken) but physical preparation for digestion.\n\nRole of bile in emulsification:\n\n1. Bile contains bile salts:\n   - Act as emulsifying agents\n   - Reduce surface tension of fat droplets\n   - Prevent tiny droplets from coalescing\n\n2. Mechanical action:\n   - Churning in intestine helps\n   - Peristalsis breaks fat into smaller pieces\n\n3. Result:\n   - Large fat globule → thousands of tiny droplets\n   - Each droplet has large surface area\n   - Forms stable emulsion (like milk)\n\nWhy emulsification is important:\n\n1. Increases surface area:\n   - Lipase (fat-digesting enzyme) is water-soluble\n   - Fats are insoluble in water\n   - Emulsification creates oil-water interface\n   - More surface area = faster digestion\n\n2. Enzyme accessibility:\n   - Lipase can only act on surface of fat droplets\n   - Tiny droplets have much more surface area\n   - Same volume, more surface = efficient digestion\n\n3. Prevents coalescence:\n   - Bile salts keep droplets separated\n   - Prevents them from joining again\n\n4. Allows complete digestion:\n   - Without emulsification, fats would digest very slowly\n   - May lead to fat malabsorption\n\nAnalogy:\n- Whole potato takes long to cook\n- Chopped potatoes cook faster (more surface area)\n- Mashed potatoes cook even faster\n- Emulsification is like chopping fats into tiny pieces\n\nExamples of emulsification in daily life:\n- Milk is natural emulsion of fat in water\n- Mayonnaise is emulsion of oil in vinegar\n- Soap emulsifies grease for washing\n\nConsequences of poor emulsification:\n- Fat indigestion\n- Fatty stools (steatorrhea)\n- Deficiency of fat-soluble vitamins (A, D, E, K)"
        },
        {
            "type": "subjective",
            "q": "List the enzymes found in different parts of the digestive system and their functions.",
            "sample": "Enzymes are biological catalysts that speed up digestive reactions. Here are the main digestive enzymes:\n\n1. MOUTH (Salivary glands):\n\nEnzyme: Salivary amylase (Ptyalin)\n- Substrate: Starch (carbohydrate)\n- Product: Maltose\n- Optimal pH: Neutral (around 7)\n\n2. STOMACH (Gastric glands):\n\nEnzyme: Pepsin\n- Substrate: Proteins\n- Product: Proteoses and peptones\n- Optimal pH: Acidic (1.5-2.5)\n- Activated from pepsinogen by HCl\n\nEnzyme: Rennin (in infants)\n- Substrate: Casein (milk protein)\n- Product: Paracasein (insoluble curd)\n- Optimal pH: Acidic\n\n3. PANCREAS (Pancreatic juice):\n\nEnzyme: Pancreatic amylase\n- Substrate: Starch\n- Product: Maltose\n- Optimal pH: Alkaline (8)\n\nEnzyme: Trypsin\n- Substrate: Proteins, proteoses, peptones\n- Product: Polypeptides\n- Optimal pH: Alkaline\n- Secreted as trypsinogen, activated by enterokinase\n\nEnzyme: Lipase\n- Substrate: Emulsified fats\n- Product: Fatty acids + glycerol\n- Optimal pH: Alkaline\n\n4. SMALL INTESTINE (Intestinal juice):\n\nEnzyme: Erepsin (peptidases)\n- Substrate: Polypeptides, peptides\n- Product: Amino acids\n\nEnzyme: Maltase\n- Substrate: Maltose\n- Product: Glucose\n\nEnzyme: Sucrase\n- Substrate: Sucrose\n- Product: Glucose + Fructose\n\nEnzyme: Lactase\n- Substrate: Lactose\n- Product: Glucose + Galactose\n\nEnzyme: Lipase (intestinal)\n- Substrate: Fats\n- Product: Fatty acids + glycerol\n\nSummary table:\n\n| Location | Enzyme | Substrate | Product |\n|----------|--------|-----------|---------|\n| Mouth | Salivary amylase | Starch | Maltose |\n| Stomach | Pepsin | Proteins | Proteoses + peptones |\n| Stomach | Rennin | Casein | Paracasein |\n| Pancreas | Pancreatic amylase | Starch | Maltose |\n| Pancreas | Trypsin | Proteins | Polypeptides |\n| Pancreas | Lipase | Fats | Fatty acids + glycerol |\n| Intestine | Erepsin | Polypeptides | Amino acids |\n| Intestine | Maltase | Maltose | Glucose |\n| Intestine | Sucrase | Sucrose | Glucose + fructose |\n| Intestine | Lactase | Lactose | Glucose + galactose |"
        },
        {
            "type": "subjective",
            "q": "Explain the complete digestion of carbohydrates from mouth to absorption.",
            "sample": "Digestion of carbohydrates involves breakdown of complex carbohydrates (starch) into simple sugars (glucose) that can be absorbed.\n\nSources of carbohydrates:\n- Starch: Rice, wheat, potatoes, bread\n- Sucrose: Table sugar, sweets\n- Lactose: Milk and milk products\n- Cellulose: Not digestible by humans (fiber)\n\nSteps of carbohydrate digestion:\n\n1. In the mouth:\n   - Food is chewed (mechanical digestion)\n   - Saliva contains salivary amylase (ptyalin)\n   - Salivary amylase acts on cooked starch\n   - Starch → Maltose (partial digestion)\n   - Food stays in mouth briefly (only about 30% starch digested)\n\n2. In the stomach:\n   - No carbohydrate-digesting enzymes (acid inactivates salivary amylase)\n   - Acid stops further starch digestion temporarily\n   - Mechanical churning continues\n\n3. In the small intestine (duodenum):\n   - Pancreatic amylase from pancreas\n   - Continues starch digestion\n   - Remaining starch → Maltose\n\n4. In the small intestine (ileum):\n   - Intestinal juice contains specific enzymes:\n     * Maltase: Maltose → Glucose + Glucose\n     * Sucrase: Sucrose → Glucose + Fructose\n     * Lactase: Lactose → Glucose + Galactose\n   - All complex carbohydrates now broken into monosaccharides\n\n5. Absorption:\n   - Glucose, fructose, galactose are monosaccharides\n   - Absorbed through villi into blood capillaries\n   - Transported to liver via hepatic portal vein\n\n6. Fate of absorbed sugars:\n   - Glucose used for immediate energy\n   - Excess glucose converted to glycogen in liver and muscles (storage)\n   - Further excess converted to fat (adipose tissue)\n   - Blood sugar level regulated by insulin and glucagon\n\nSummary equation:\nStarch → Maltose → Glucose\nSucrose → Glucose + Fructose\nLactose → Glucose + Galactose\n\nKey points:\n- Carbohydrate digestion begins in mouth\n- Completed in small intestine\n- Final product is glucose (main energy source)\n- All enzymes are specific to their substrates"
        },
        {
            "type": "subjective",
            "q": "Explain the complete digestion of proteins from mouth to absorption.",
            "sample": "Protein digestion involves breaking down proteins into amino acids that can be absorbed and used by the body.\n\nSources of proteins:\n- Animal sources: Meat, fish, eggs, milk, cheese\n- Plant sources: Pulses, beans, nuts, soyabean\n\nSteps of protein digestion:\n\n1. In the mouth:\n   - No protein-digesting enzymes in saliva\n   - Only mechanical digestion (chewing) breaks food into smaller pieces\n   - Increases surface area for later enzyme action\n\n2. In the stomach:\n   - Gastric juice contains:\n     * Hydrochloric acid: Kills bacteria, denatures proteins (unfolds them)\n     * Pepsinogen → Pepsin (activated by HCl)\n   - Pepsin acts on proteins\n   - Proteins → Proteoses + Peptones (smaller protein fragments)\n   - Also contains rennin (in infants) for milk protein digestion\n   - Food becomes acidic chyme\n\n3. In the small intestine (duodenum):\n   - Pancreatic juice contains trypsin\n   - Trypsin secreted as inactive trypsinogen\n   - Activated by enterokinase (intestinal enzyme)\n   - Trypsin acts on:\n     * Remaining whole proteins\n     * Proteoses and peptones\n   - All → Polypeptides (smaller chains of amino acids)\n\n4. In the small intestine (ileum):\n   - Intestinal juice contains erepsin (peptidases)\n   - Several different peptidases\n   - Erepsin acts on polypeptides\n   - Polypeptides → Amino acids (final product)\n   - Also acts on any remaining dipeptides\n\n5. Absorption:\n   - Amino acids are small enough to be absorbed\n   - Absorbed through villi into blood capillaries\n   - Transported to liver via hepatic portal vein\n\n6. Fate of amino acids:\n   - Used to build body proteins (muscles, enzymes, hormones)\n   - Used for growth and repair of tissues\n   - Excess amino acids deaminated in liver\n   - Converted to urea (excreted) and carbon skeleton (used for energy/fat)\n\nSummary equation:\nProteins → Proteoses/Peptones → Polypeptides → Amino acids\n\nKey points:\n- Protein digestion begins in stomach (not mouth)\n- Completed in small intestine\n- Final product is amino acids\n- Different enzymes work sequentially\n- Pepsin works in acid, trypsin in alkaline"
        },
        {
            "type": "subjective",
            "q": "Explain the complete digestion of fats from ingestion to absorption.",
            "sample": "Fat digestion involves breaking down fats (lipids) into fatty acids and glycerol that can be absorbed.\n\nSources of fats:\n- Animal fats: Butter, ghee, meat fat\n- Plant oils: Vegetable oils, nuts, seeds\n\nSteps of fat digestion:\n\n1. In the mouth:\n   - No fat-digesting enzymes in saliva\n   - Lingual lipase (minor role, mainly in infants)\n   - Mechanical chewing breaks fat-containing foods\n\n2. In the stomach:\n   - Limited fat digestion\n   - Gastric lipase (minor role, especially in infants)\n   - Most fats remain undigested\n   - Acidic stomach not ideal for fat digestion\n\n3. In the small intestine (duodenum):\n   - Major site of fat digestion\n   - Two processes occur: emulsification and chemical digestion\n\n   A. Emulsification (by bile from liver):\n      - Bile released into duodenum\n      - Bile salts break large fat globules into tiny droplets\n      - Increases surface area enormously\n      - No chemical change, just physical breakdown\n      - Prevents droplets from rejoining\n\n   B. Chemical digestion (by pancreatic lipase):\n      - Pancreatic lipase acts on emulsified fats\n      - Works at oil-water interface\n      - Fats → Fatty acids + Glycerol\n      - Requires alkaline pH (provided by bile and pancreatic juice)\n\n4. Absorption of fats (unique process):\n   - Fatty acids and glycerol are absorbed differently from other nutrients\n   - They enter the lacteals (lymph vessels) in villi, not blood capillaries\n   - Inside intestinal cells, they reform into tiny fat droplets\n   - These enter lymph as chylomicrons\n   - Lymph eventually drains into blood near heart\n\n5. Fate of fatty acids and glycerol:\n   - Used for energy (especially during fasting)\n   - Stored in adipose tissue for later use\n   - Used to build cell membranes\n   - Essential for absorption of fat-soluble vitamins (A, D, E, K)\n\nSummary:\nLarge fat globules → (emulsification by bile) → Tiny fat droplets → (lipase action) → Fatty acids + Glycerol → (absorption via lacteals) → Lymph → Blood\n\nKey points:\n- Bile is essential but contains no enzymes\n- Emulsification is physical, not chemical digestion\n- Fats take longest to digest\n- Fats are absorbed into lymph, not directly into blood\n- Fat-soluble vitamins depend on fat digestion for absorption"
        },
        {
            "type": "subjective",
            "q": "What happens to the food in the stomach? Describe the process of digestion in the stomach.",
            "sample": "The stomach is where significant protein digestion begins and food is converted into a semi-fluid paste called chyme.\n\nEntry of food:\n- Food enters stomach from oesophagus through cardiac sphincter\n- Stomach gradually fills and expands\n- Food stays in stomach for 2-4 hours depending on meal type\n\nMechanical digestion in stomach:\n\n1. Churning and mixing:\n   - Three layers of muscles contract rhythmically\n   - Food is churned, crushed, and mixed\n   - Breaks food into smaller pieces\n   - Mixes food thoroughly with gastric juice\n\n2. Formation of chyme:\n   - Food becomes semi-fluid paste\n   - Called chyme\n   - Gradually released to small intestine\n\nChemical digestion in stomach:\n\n3. Secretion of gastric juice:\n   - Gastric glands secrete about 2-3 litres daily\n   - Contains:\n     a. Hydrochloric acid (HCl):\n        - Kills bacteria in food\n        - Stops carbohydrate digestion (inactivates salivary amylase)\n        - Provides acidic pH (1.5-2.5) for pepsin\n        - Denatures proteins (unfolds them)\n     \n     b. Pepsinogen:\n        - Inactive form\n        - Activated by HCl to pepsin\n        - Pepsin digests proteins → proteoses + peptones\n     \n     c. Rennin (in infants):\n        - Digests milk protein (casein)\n        - Forms curd for slower digestion\n     \n     d. Mucus:\n        - Protects stomach lining from acid and enzymes\n        - Lubricates food\n\n4. Limited absorption:\n   - Water, alcohol, some drugs absorbed\n   - Most nutrients not absorbed here\n\nExit from stomach:\n- Pyloric sphincter opens periodically\n- Small amounts of chyme released into duodenum\n- Regulated to prevent overload of small intestine\n\nFactors affecting stomach emptying:\n- Fatty foods slow emptying\n- Liquid leaves faster than solids\n- Large meals take longer\n\nSummary of changes in stomach:\n- Food: Solid → Semi-fluid chyme\n- Proteins: Partially digested to proteoses/peptones\n- Carbohydrates: Digestion temporarily stopped\n- Fats: Mostly unchanged\n- Bacteria: Killed by acid"
        },
        {
            "type": "subjective",
            "q": "Describe the process of digestion in the small intestine.",
            "sample": "The small intestine is the major site of digestion where all foods are completely broken down and absorbed.\n\nStructure for digestion:\n- Long (6-7 m), coiled tube\n- Three parts: duodenum, jejunum, ileum\n- Inner surface has villi and microvilli\n- Receives secretions from liver and pancreas\n\nEntry of chyme:\n- Chyme enters duodenum from stomach through pyloric sphincter\n- Acidic chyme stimulates release of hormones\n- Hormones trigger release of bile and pancreatic juice\n\nSecretions in small intestine:\n\n1. Bile (from liver):\n   - Stored in gall bladder\n   - Emulsifies fats (no enzymes)\n   - Alkaline (neutralizes acid)\n\n2. Pancreatic juice (from pancreas):\n   - Contains enzymes:\n     * Pancreatic amylase: Starch → Maltose\n     * Trypsin: Proteins → Polypeptides\n     * Lipase: Fats → Fatty acids + Glycerol\n   - Contains sodium bicarbonate (alkaline)\n\n3. Intestinal juice (from intestinal glands):\n   - Contains enzymes:\n     * Erepsin: Polypeptides → Amino acids\n     * Maltase: Maltose → Glucose\n     * Sucrase: Sucrose → Glucose + Fructose\n     * Lactase: Lactose → Glucose + Galactose\n     * Intestinal lipase: Fats → Fatty acids + Glycerol\n\nDigestion of different foods:\n\nCarbohydrates:\n- Pancreatic amylase completes starch digestion\n- Maltase, sucrase, lactase act on disaccharides\n- Final product: Glucose, fructose, galactose\n\nProteins:\n- Trypsin acts on proteins and peptones\n- Erepsin acts on polypeptides\n- Final product: Amino acids\n\nFats:\n- Bile emulsifies fats first\n- Lipase acts on emulsified fats\n- Final product: Fatty acids and glycerol\n\nAbsorption:\n- Villi absorb digested food\n- Glucose and amino acids → blood capillaries\n- Fatty acids and glycerol → lacteals (lymph)\n- Water and minerals absorbed\n\nMovement:\n- Peristalsis moves food along\n- Segmentation mixes for better absorption\n- Takes 3-5 hours to pass through\n\nCompletion:\n- All digestible food now broken down\n- Remaining material passes to large intestine\n\nSummary:\nThe small intestine completes digestion of all food types using enzymes from pancreas and its own walls, with bile from liver helping fat digestion, and absorbs nutrients through villi."
        },
        {
            "type": "subjective",
            "q": "What is the role of the large intestine in digestion?",
            "sample": "The large intestine (colon) is the final part of the alimentary canal where water is reabsorbed and faeces are formed.\n\nStructure:\n- About 1.5 metres long\n- Wider than small intestine\n- Parts: Caecum, colon (ascending, transverse, descending, sigmoid), rectum\n- Appendix attached to caecum (vestigial in humans)\n- Opens to outside through anus\n\nFunctions of large intestine:\n\n1. Absorption of water:\n   - Reabsorbs about 90% of water from undigested food\n   - About 1-1.5 litres of water absorbed daily\n   - Prevents dehydration\n   - Concentrates waste material\n\n2. Absorption of minerals:\n   - Absorbs sodium, potassium, and chloride ions\n   - Helps maintain electrolyte balance\n\n3. Formation of faeces:\n   - Undigested food becomes semi-solid\n   - Contains:\n     * Cellulose and fiber\n     * Dead bacteria\n     * Sloughed-off cells\n     * Bile pigments (give colour)\n     * Water\n\n4. Bacterial action:\n   - Home to many beneficial bacteria (gut flora)\n   - Bacteria ferment undigested carbohydrates\n   - Produce gases (flatulence)\n   - Synthesize vitamins:\n     * Vitamin K (for blood clotting)\n     * Some B vitamins (biotin, B12)\n   - These vitamins are absorbed and used by body\n\n5. Storage:\n   - Stores faeces temporarily\n   - Rectum stores until elimination\n   - Signals when full (urge to defecate)\n\n6. Egestion:\n   - Elimination of faeces through anus\n   - Controlled by anal sphincters\n   - Voluntary and involuntary control\n\n7. Lubrication:\n   - Mucus secreted to lubricate passage\n   - Helps faeces move easily\n\nDifferences from small intestine:\n- No villi (so no nutrient absorption except water/minerals)\n- No digestive enzymes secreted\n- Slower movement (12-24 hours)\n- More bacteria present\n\nProblems related to large intestine:\n- Constipation (too much water absorbed)\n- Diarrhoea (too little water absorbed)\n- Irritable bowel syndrome\n- Colitis (inflammation)\n\nSummary:\nThe large intestine does not digest food but is essential for water balance, vitamin production, and waste elimination."
        },
        {
            "type": "subjective",
            "q": "Explain the process of absorption of digested food in the small intestine.",
            "sample": "Absorption is the process by which digested food passes from the small intestine into the blood and lymph.\n\nSite of absorption:\n- Mainly in small intestine (jejunum and ileum)\n- Villi are the absorbing structures\n- Each villus has blood capillaries and lacteal\n\nMechanisms of absorption:\n\n1. Passive diffusion:\n   - Molecules move from high to low concentration\n   - No energy required\n   - For: Water, some minerals, fatty acids\n\n2. Active transport:\n   - Requires energy (ATP)\n   - Moves against concentration gradient\n   - For: Glucose, amino acids, some ions\n\n3. Facilitated diffusion:\n   - Uses carrier proteins\n   - No energy required\n   - For: Fructose\n\nAbsorption of different nutrients:\n\nA. Carbohydrates (as monosaccharides):\n   - Glucose, galactose: Active transport\n   - Fructose: Facilitated diffusion\n   - Enter blood capillaries of villi\n   - Transported to liver via hepatic portal vein\n\nB. Proteins (as amino acids):\n   - Active transport\n   - Enter blood capillaries\n   - To liver via hepatic portal vein\n\nC. Fats (as fatty acids and glycerol):\n   - Diffuse into intestinal cells\n   - Reformed into tiny fat droplets\n   - Enter lacteals (lymph vessels)\n   - Transported via lymphatic system\n   - Eventually enter blood near heart\n\nD. Water:\n   - Passive diffusion and osmosis\n   - 8-9 litres absorbed daily (from food and secretions)\n   - Most in small intestine, some in large\n\nE. Minerals and vitamins:\n   - Various mechanisms\n   - Fat-soluble vitamins (A, D, E, K) with fats\n   - Water-soluble vitamins (B, C) into blood\n\nF. Bile salts:\n   - Reabsorbed in ileum\n   - Returned to liver via blood\n   - Recycled (enterohepatic circulation)\n\nAdaptations for absorption:\n\n1. Large surface area:\n   - Long intestine (6-7 m)\n   - Villi (millions)\n   - Microvilli on villi cells\n   - Total area ~200-300 m²\n\n2. Thin walls:\n   - One cell thick\n   - Short diffusion distance\n\n3. Rich blood supply:\n   - Dense capillary network\n   - Quick removal of absorbed nutrients\n\n4. Constant movement:\n   - Villi move and sway\n   - Increases contact with nutrients\n\n5. Transport systems:\n   - Blood for most nutrients\n   - Lymph for fats\n\nSummary:\nAbsorption converts digested food from the intestine lumen into the body's internal environment, making nutrients available for all cells."
        },
        {
            "type": "subjective",
            "q": "What is assimilation? Explain what happens to glucose, amino acids, and fats after absorption.",
            "sample": "Assimilation is the process by which absorbed nutrients are utilized by the body cells for energy, growth, and repair, or stored for future use.\n\nAfter absorption, nutrients travel via blood to the liver first (hepatic portal system), then to all body cells.\n\nFate of glucose (carbohydrates):\n\n1. Immediate energy:\n   - Glucose is primary energy source for cells\n   - Broken down in respiration to produce ATP\n   - Brain cells depend almost entirely on glucose\n\n2. Storage as glycogen:\n   - Excess glucose converted to glycogen\n   - Stored in liver and muscles\n   - Glycogen can be quickly converted back to glucose\n   - Limited storage capacity\n\n3. Conversion to fat:\n   - When glycogen stores are full\n   - Excess glucose converted to fat\n   - Stored in adipose tissue\n   - Unlimited storage capacity\n\nFate of amino acids (proteins):\n\n1. Protein synthesis:\n   - Build new proteins for:\n     * Muscle tissue (growth and repair)\n     * Enzymes (catalyze reactions)\n     * Hormones (chemical messengers)\n     * Antibodies (immunity)\n     * Haemoglobin (oxygen transport)\n   - Continuous process (proteins constantly broken down and rebuilt)\n\n2. Energy (when needed):\n   - Can be used for energy if carbohydrates scarce\n   - Amino group removed (deamination)\n   - Carbon skeleton enters energy pathways\n\n3. Deamination of excess:\n   - Excess amino acids cannot be stored\n   - Liver removes amino group (deamination)\n   - Produces urea (excreted in urine)\n   - Carbon part used for energy or fat\n\nFate of fatty acids and glycerol (fats):\n\n1. Energy production:\n   - Fats are concentrated energy stores\n   - Provide more energy per gram than carbs\n   - Used during fasting, exercise\n\n2. Storage in adipose tissue:\n   - Under skin and around organs\n   - Insulation and protection\n   - Reserve energy supply\n\n3. Cell membrane structure:\n   - Phospholipids in all cell membranes\n   - Cholesterol for membrane fluidity\n\n4. Formation of essential compounds:\n   - Steroid hormones\n   - Vitamin D\n   - Bile salts\n\n5. Insulation:\n   - Subcutaneous fat keeps body warm\n   - Around nerves (myelin) for insulation\n\nOther nutrients:\n- Vitamins: Used as coenzymes, antioxidants\n- Minerals: For bones, teeth, enzyme function\n- Water: All cellular processes\n\nRegulation of assimilation:\n- Hormones control nutrient use and storage\n  * Insulin: Promotes glucose uptake and storage\n  * Glucagon: Releases glucose from stores\n  * Growth hormone: Promotes protein synthesis\n\nThus, assimilation ensures nutrients are used where needed and stored for future requirements."
        },
        {
            "type": "subjective",
            "q": "What are good food habits? List them and explain their importance.",
            "sample": "Good food habits are practices related to eating that promote proper digestion, good health, and prevention of digestive disorders.\n\nList of good food habits:\n\n1. Eat a balanced diet:\n   - Include all food groups: carbohydrates, proteins, fats, vitamins, minerals\n   - Proportionate amounts according to age and activity\n   - Variety ensures all nutrients\n\n2. Eat at regular hours:\n   - Fixed meal times help digestive system prepare\n   - Avoid long gaps between meals\n   - 3 main meals + 2 small snacks ideal\n   - Prevents overeating\n\n3. Eat clean and hygienic food:\n   - Wash vegetables and fruits before eating\n   - Cook food properly (especially meat, eggs)\n   - Avoid stale or spoiled food\n   - Prevent food poisoning\n\n4. Chew food properly:\n   - Digestion begins in mouth\n   - Chewing breaks food into small pieces\n   - Mixes with saliva (contains enzymes)\n   - Well-chewed food digests easily\n   - Aim for 20-30 chews per bite\n\n5. Drink adequate water:\n   - 6-8 glasses daily\n   - Water helps in digestion and absorption\n   - Prevents constipation\n   - But not too much during meals (dilutes digestive juices)\n\n6. Avoid junk food:\n   - Limit fried, oily, spicy foods\n   - Reduce sugary drinks and snacks\n   - These are low in nutrients, high in calories\n   - Can cause indigestion, obesity\n\n7. Do not overeat:\n   - Eat until satisfied, not stuffed\n   - Overeating stresses digestive system\n   - Causes discomfort, gas, heartburn\n   - Small portions at frequent intervals better\n\n8. Wash hands before eating:\n   - Prevents entry of germs\n   - Reduces risk of infections\n   - Basic hygiene practice\n\n9. Rinse mouth after eating:\n   - Removes food particles from teeth\n   - Prevents tooth decay\n   - Freshens breath\n\n10. Eat slowly and calmly:\n    - Rushed eating causes poor digestion\n    - Stress affects digestive processes\n    - Enjoy food, eat mindfully\n\n11. Avoid lying down immediately after meals:\n    - Wait at least 30 minutes\n    - Prevents acid reflux\n    - Allows digestion to begin\n\n12. Include fiber in diet:\n    - Fruits, vegetables, whole grains\n    - Prevents constipation\n    - Keeps digestive system healthy\n\nImportance of good food habits:\n- Proper digestion and absorption\n- Prevention of digestive disorders (indigestion, acidity, constipation)\n- Maintenance of healthy weight\n- Strong immunity\n- Good dental health\n- Overall physical and mental well-being\n- Long-term health (prevents lifestyle diseases)"
        },
        {
            "type": "subjective",
            "q": "What is indigestion? What are its causes, symptoms, and prevention?",
            "sample": "Indigestion (dyspepsia) is a condition of discomfort or pain in the upper abdomen, often related to eating.\n\nDefinition:\nIndigestion is not a disease but a symptom of various digestive problems. It refers to difficulty in digesting food properly.\n\nCommon symptoms of indigestion:\n\n1. Abdominal pain or discomfort:\n   - Burning sensation in upper abdomen\n   - Pain may come and go\n\n2. Heartburn:\n   - Burning feeling behind breastbone\n   - Caused by acid reflux\n\n3. Bloating:\n   - Feeling of fullness and swelling\n   - Gas in stomach and intestines\n\n4. Excessive gas:\n   - Burping frequently\n   - Flatulence\n\n5. Nausea:\n   - Feeling like vomiting\n   - May or may not lead to vomiting\n\n6. Early satiety:\n   - Feeling full soon after starting meal\n   - Cannot finish normal portion\n\n7. Acidic taste in mouth:\n   - Regurgitation of food/acid\n\nCauses of indigestion:\n\n1. Dietary causes:\n   - Eating very spicy or oily food\n   - Overeating\n   - Eating too quickly\n   - Drinking too much water between meals\n   - Consuming alcohol or carbonated drinks with meals\n   - Excessive caffeine\n\n2. Lifestyle factors:\n   - Stress and anxiety\n   - Smoking\n   - Lying down soon after meals\n   - Irregular meal times\n\n3. Medical conditions:\n   - Gastritis (inflammation of stomach lining)\n   - GERD (gastroesophageal reflux disease)\n   - Ulcers\n   - Gallbladder problems\n   - Pancreatitis\n\n4. Medications:\n   - Certain painkillers (aspirin, ibuprofen)\n   - Some antibiotics\n\nPrevention of indigestion:\n\n1. Healthy eating habits:\n   - Eat smaller, more frequent meals\n   - Chew food thoroughly\n   - Eat slowly, don't rush\n   - Avoid overeating\n   - Limit spicy and fatty foods\n\n2. Proper meal timing:\n   - Don't skip meals\n   - Eat at regular times\n   - Avoid late-night eating\n   - Wait 2-3 hours before lying down\n\n3. Hydration wisely:\n   - Drink water between meals, not during\n   - Limit fluids with meals\n   - Avoid carbonated drinks\n\n4. Stress management:\n   - Relax before eating\n   - Don't eat when stressed\n   - Practice deep breathing\n\n5. Avoid triggers:\n   - Identify foods that cause indigestion\n   - Limit alcohol and caffeine\n   - Quit smoking\n\n6. Healthy weight:\n   - Maintain appropriate weight\n   - Excess weight increases pressure on stomach\n\nWhen to see a doctor:\n- Persistent symptoms\n- Unexplained weight loss\n- Difficulty swallowing\n- Blood in vomit or stool\n- Severe pain"
        },
        {
            "type": "subjective",
            "q": "Describe the journey of a piece of bread through the digestive system until it is absorbed.",
            "sample": "Follow the journey of a piece of bread (containing carbohydrates, some proteins, and minimal fats) through the digestive system:\n\n1. Mouth (Buccal cavity):\n   - Bread is chewed by teeth (incisors bite, molars grind)\n   - Tongue mixes it with saliva\n   - Saliva contains salivary amylase (ptyalin)\n   - Starch in bread → Maltose (partial digestion)\n   - Bread becomes soft bolus\n   - Swallowed into pharynx\n\n2. Pharynx:\n   - Common passage for food and air\n   - Epiglottis closes windpipe\n   - Bolus pushed into oesophagus\n\n3. Oesophagus:\n   - No digestion occurs here\n   - Peristalsis pushes bolus downward\n   - Takes about 5-8 seconds\n   - Cardiac sphincter opens into stomach\n\n4. Stomach:\n   - Food停留 for 2-4 hours\n   - Mixed with gastric juice by churning\n   - HCl stops carbohydrate digestion (inactivates salivary amylase)\n   - Proteins in bread (gluten) partially digested by pepsin → proteoses/peptones\n   - Bread becomes acidic chyme\n   - Gradually released to small intestine\n\n5. Small intestine (Duodenum):\n   - Chyme enters duodenum\n   - Pancreatic juice added:\n     * Pancreatic amylase digests remaining starch → Maltose\n     * Trypsin digests proteins → Polypeptides\n   - Bile from liver (emulsifies any fats, but bread has minimal fat)\n   - Intestinal juice added\n\n6. Small intestine (Jejunum and Ileum):\n   - Intestinal enzymes act:\n     * Maltase: Maltose → Glucose\n     * Erepsin: Polypeptides → Amino acids\n   - Digestion now complete\n   - Nutrients ready for absorption\n\n7. Absorption through villi:\n   - Glucose and amino acids pass into blood capillaries\n   - Transported to liver via hepatic portal vein\n   - Any fats (from butter on bread) enter lacteals\n\n8. Liver:\n   - Processes absorbed nutrients\n   - Regulates blood sugar\n   - Stores excess glucose as glycogen\n   - Amino acids used for protein synthesis\n\n9. To body cells:\n   - Glucose used for energy\n   - Amino acids for growth and repair\n   - Excess stored as fat\n\n10. Remaining undigested parts:\n    - Some fiber (cellulose) not digested\n    - Passes to large intestine\n    - Water absorbed\n    - Forms faeces\n    - Stored in rectum\n    - Eliminated through anus\n\nTotal time: About 24-48 hours from mouth to elimination"
        },
        {
            "type": "subjective",
            "q": "Why is it necessary to chew food properly? Explain.",
            "sample": "Proper chewing (mastication) is essential for good digestion and overall health. Here's why:\n\n1. Increases surface area:\n   - Large food pieces have small surface area\n   - Chewing breaks food into smaller particles\n   - Smaller pieces have much larger surface area\n   - Digestive enzymes can act more effectively\n   - Example: Whole potato vs mashed potato - mashed digests faster\n\n2. Mixes with saliva:\n   - Saliva contains salivary amylase (starch digestion)\n   - Proper mixing ensures enzyme contact with food\n   - Saliva also contains mucus for lubrication\n   - Lubricated food slides easily through oesophagus\n\n3. Begins carbohydrate digestion:\n   - Starch digestion starts in mouth\n   - More chewing = more time for enzyme action\n   - Partially digested food easier for stomach\n\n4. Reduces work of stomach:\n   - Stomach has no teeth\n   - Cannot break large pieces effectively\n   - Well-chewed food requires less churning\n   - Prevents stomach overwork\n\n5. Prevents digestive problems:\n   - Poorly chewed food can cause:\n     * Indigestion\n     * Gas and bloating\n     * Stomach pain\n     * Acid reflux\n   - Large particles ferment in intestines\n\n6. Better nutrient absorption:\n   - Smaller particles release nutrients more easily\n   - Nutrients more available for absorption\n   - Prevents malnutrition even with adequate food\n\n7. Signals satiety (fullness):\n   - Chewing takes time (15-20 minutes per meal)\n   - Brain receives fullness signals during this time\n   - Prevents overeating\n   - Helps maintain healthy weight\n\n8. Protects teeth and gums:\n   - Chewing stimulates saliva flow\n   - Saliva neutralizes acids\n   - Washes away food particles\n   - Strengthens jaw muscles\n\n9. Aids taste enjoyment:\n   - Food releases flavours when chewed\n   - Taste buds detect flavours better\n   - Enhances eating experience\n\n10. Prevents choking:\n    - Large pieces can block airway\n    - Properly chewed food safer to swallow\n\nHow to chew properly:\n- Chew each bite 20-30 times\n- Eat slowly, don't rush\n- Put down utensils between bites\n- Focus on food, not TV/phone\n- Take smaller bites\n\nConsequences of poor chewing:\n- Indigestion\n- Malabsorption\n- Weight gain (from overeating)\n- Choking risk\n- Dental problems\n\nThus, the saying \"drink your solids and chew your liquids\" emphasizes thorough chewing of solid foods."
        },
        {
            "type": "subjective",
            "q": "Describe the role of hydrochloric acid in the stomach.",
            "sample": "Hydrochloric acid (HCl) is a strong acid secreted by parietal cells of gastric glands in the stomach. It plays multiple crucial roles in digestion and protection.\n\nSecretion of HCl:\n- Produced by parietal (oxyntic) cells in stomach lining\n- Concentration: About 0.5% (pH 1.5-2.5)\n- Secretion stimulated by:\n  * Thought/sight/smell of food (vagus nerve)\n  * Presence of food in stomach\n  * Hormone gastrin\n- About 2-3 litres of gastric juice secreted daily\n\nFunctions of HCl:\n\n1. Activates pepsinogen:\n   - Pepsinogen (inactive) secreted by chief cells\n   - HCl converts pepsinogen to active pepsin\n   - Pepsin then digests proteins\n   - Also provides acidic pH for pepsin action\n\n2. Kills bacteria:\n   - Most bacteria cannot survive in strong acid\n   - Sterilizes food\n   - Prevents infections\n   - First line of defense against pathogens\n\n3. Stops carbohydrate digestion:\n   - Salivary amylase works best at neutral pH\n   - Acid inactivates salivary amylase\n   - Stops starch digestion in stomach\n   - Prevents continued carbohydrate digestion in wrong environment\n\n4. Denatures proteins:\n   - HCl unfolds (denatures) protein molecules\n   - Makes proteins accessible to enzymes\n   - Like unravelling a tangled ball of yarn\n   - Exposes peptide bonds for pepsin action\n\n5. Provides optimal pH for pepsin:\n   - Pepsin works best at pH 1.5-2.5\n   - Acidic environment essential\n   - Pepsin inactive at neutral/alkaline pH\n\n6. Stimulates secretion of hormones:\n   - Acid in duodenum stimulates secretin release\n   - Secretin promotes pancreatic bicarbonate secretion\n   - Helps neutralize acid in small intestine\n\n7. Aids calcium and iron absorption:\n   - Acidic pH helps dissolve minerals\n   - Makes calcium and iron more absorbable\n   - Important for bone health and blood formation\n\n8. Prevents gastrin overproduction:\n   - Acid inhibits further gastrin release\n   - Negative feedback control\n   - Prevents excessive acid production\n\nProtection of stomach from its own acid:\n\n1. Mucus layer:\n   - Thick, alkaline mucus coats stomach lining\n   - Physical barrier against acid\n   - Contains bicarbonate to neutralize acid\n\n2. Rapid cell renewal:\n   - Stomach lining cells replaced every 3-5 days\n   - Fast repair of any damage\n\n3. Tight junctions:\n   - Cells tightly connected\n   - Prevents acid penetration\n\nProblems with HCl imbalance:\n\nToo much acid:\n- Gastritis (inflammation)\n- Ulcers\n- Acid reflux\n\nToo little acid (hypochlorhydria):\n- Increased infection risk\n- Poor protein digestion\n- Mineral deficiencies\n\nThus, HCl is essential for digestion, protection, and mineral absorption, but must be carefully regulated."
        },
        {
            "type": "subjective",
            "q": "What would happen if bile is not secreted? Explain.",
            "sample": "If bile is not secreted (due to liver disease, blocked bile duct, or gall bladder removal without adaptation), serious digestive problems would occur, especially with fat digestion.\n\nCauses of bile deficiency:\n- Liver disease (hepatitis, cirrhosis)\n- Blocked bile duct (gallstones)\n- Surgical removal of gall bladder (temporary effect)\n- Congenital absence of bile ducts\n\nEffects of bile deficiency:\n\n1. Impaired fat digestion:\n   - Large fat globules remain large\n   - Lipase cannot access fats effectively\n   - Only surface of fat globules digested\n   - Most fats pass through undigested\n   - Result: Only 10-20% of fats digested instead of 95%\n\n2. Fatty stools (steatorrhea):\n   - Undigested fats appear in faeces\n   - Stools become pale, bulky, greasy\n   - Float in toilet water\n   - Foul-smelling\n   - Difficult to flush\n\n3. Fat-soluble vitamin deficiencies:\n   - Vitamins A, D, E, K need fats for absorption\n   - Without fat digestion, these vitamins not absorbed\n   - Vitamin A deficiency: Night blindness, dry skin\n   - Vitamin D deficiency: Rickets (soft bones)\n   - Vitamin E deficiency: Nerve problems\n   - Vitamin K deficiency: Bleeding disorders\n\n4. Malnutrition:\n   - Fats are concentrated energy sources\n   - Loss of fat calories leads to weight loss\n   - Essential fatty acids deficiency\n   - Poor growth in children\n\n5. Loss of alkaline secretion:\n   - Bile is alkaline (helps neutralize stomach acid)\n   - Without bile, acidic chyme enters duodenum\n   - May damage intestinal lining\n   - Pancreatic enzymes less effective in acid\n\n6. Constipation:\n   - Bile salts stimulate peristalsis\n   - Without bile, intestinal motility reduced\n   - Waste moves slowly\n\n7. Changes in gut bacteria:\n   - Bile has antibacterial properties\n   - Without bile, bacterial overgrowth may occur\n   - Can cause diarrhoea or infection\n\n8. Jaundice:\n   - Bile pigments (bilirubin) not eliminated\n   - Accumulate in blood\n   - Skin and eyes become yellow\n   - Urine becomes dark\n   - Itching (pruritus)\n\n9. Indigestion symptoms:\n   - Bloating after meals (especially fatty meals)\n   - Abdominal discomfort\n   - Nausea\n   - Gas\n\n10. Colour changes:\n    - Stools become pale or clay-coloured (no bile pigments)\n    - Urine becomes dark (bilirubin excreted via kidneys)\n\nTreatment:\n- Dietary fat restriction\n- Medium-chain triglycerides (absorbed without bile)\n- Fat-soluble vitamin supplements\n- Enzyme supplements (lipase)\n- Treat underlying cause\n\nAdaptation:\n- After gall bladder removal, body gradually adapts\n- Bile drips continuously instead of in concentrated bursts\n- Small frequent meals help\n\nThus, bile is essential for normal fat digestion and absorption of fat-soluble vitamins."
        },
        {
            "type": "subjective",
            "q": "Write a note on dental care and prevention of tooth decay.",
            "sample": "Dental care is essential for maintaining healthy teeth, preventing decay, and ensuring proper digestion throughout life.\n\nCauses of tooth decay:\n- Food particles trapped between teeth\n- Bacteria acting on sugars producing acid\n- Plaque formation (sticky film of bacteria and food)\n- Acid dissolving enamel → cavities\n- Poor oral hygiene\n- Excessive sugary foods and drinks\n\nDaily dental care routine:\n\n1. Brushing teeth:\n   - Brush twice daily (morning and before bed)\n   - Use fluoride toothpaste\n   - Brush for at least 2-3 minutes\n   - Correct technique:\n     * Hold brush at 45° angle to gums\n     * Gentle circular motions\n     * Brush all surfaces: outer, inner, chewing\n     * Brush tongue to remove bacteria\n   - Replace brush every 3-4 months\n\n2. Flossing:\n   - Floss once daily\n   - Removes food between teeth\n   - Where brush cannot reach\n   - Prevents gum disease\n\n3. Mouthwash:\n   - Use antiseptic mouthwash\n   - Kills bacteria\n   - Freshens breath\n   - Not a substitute for brushing/flossing\n\n4. Rinse after meals:\n   - Swish water in mouth after eating\n   - Removes loose food particles\n   - Dilutes acids\n\nDietary habits for healthy teeth:\n\n5. Limit sugary foods:\n   - Reduce sweets, candies, chocolates\n   - Avoid sticky sweets that cling to teeth\n   - Limit sugary drinks (soda, juice)\n   - If eating sweets, have with meals not between\n\n6. Eat tooth-friendly foods:\n   - Crunchy vegetables (carrot, apple) clean teeth\n   - Cheese and milk (calcium for strong teeth)\n   - Water (washes away food)\n   - Fiber-rich foods stimulate saliva\n\n7. Avoid frequent snacking:\n   - Each snack = acid attack on teeth\n   - Constant eating = constant acid\n   - Better to eat at meal times\n\nProfessional dental care:\n\n8. Regular dental checkups:\n   - Visit dentist every 6 months\n   - Professional cleaning removes tartar\n   - Early detection of cavities\n   - X-rays if needed\n\n9. Fluoride treatments:\n   - Fluoride strengthens enamel\n   - In toothpaste, water, or professional application\n   - Makes teeth more resistant to acid\n\n10. Dental sealants:\n    - Protective coating on chewing surfaces\n    - Prevents food trapping in grooves\n    - Especially for children\n\nAdditional tips:\n\n11. Don't use teeth as tools:\n    - Never open bottles with teeth\n    - Don't bite nails or pens\n    - Prevents cracking and wear\n\n12. Protect teeth during sports:\n    - Use mouthguard for contact sports\n    - Prevents injury\n\n13. Avoid tobacco:\n    - Stains teeth\n    - Causes gum disease\n    - Increases oral cancer risk\n\n14. Address teeth grinding:\n    - If you grind teeth at night, see dentist\n    - May need mouth guard\n\nSigns of problems:\n- Toothache\n- Bleeding gums\n- Persistent bad breath\n- Loose teeth\n- Mouth sores\n- See dentist promptly\n\nGood dental care = healthy teeth for lifetime = proper chewing = good digestion"
        },
        {
            "type": "subjective",
            "q": "Explain the role of enzymes in digestion.",
            "sample": "Enzymes are biological catalysts that speed up chemical reactions in digestion without being consumed themselves. They are essential for breaking down large food molecules into absorbable units.\n\nCharacteristics of digestive enzymes:\n- Protein in nature\n- Specific in action (each enzyme acts on one substrate)\n- Work best at optimal pH and temperature\n- Not used up in reaction\n- Named after substrate with '-ase' ending (e.g., lipase for lipids)\n\nTypes of digestive enzymes by function:\n\n1. Carbohydrases (digest carbohydrates):\n   - Salivary amylase: Starch → Maltose\n   - Pancreatic amylase: Starch → Maltose\n   - Maltase: Maltose → Glucose\n   - Sucrase: Sucrose → Glucose + Fructose\n   - Lactase: Lactose → Glucose + Galactose\n\n2. Proteases (digest proteins):\n   - Pepsin (stomach): Proteins → Proteoses + Peptones\n   - Trypsin (pancreas): Proteins → Polypeptides\n   - Erepsin/Peptidases (intestine): Polypeptides → Amino acids\n   - Rennin: Casein (milk protein) → Paracasein\n\n3. Lipases (digest fats):\n   - Pancreatic lipase: Fats → Fatty acids + Glycerol\n   - Intestinal lipase: Fats → Fatty acids + Glycerol\n   - Lingual/gastric lipase (minor role)\n\n4. Nucleases (digest nucleic acids):\n   - From pancreas: DNA/RNA → Nucleotides\n\nHow enzymes work:\n\n1. Lock and key model:\n   - Enzyme has active site (lock)\n   - Substrate (key) fits into active site\n   - Specific shape determines which substrate\n\n2. Enzyme-substrate complex formed\n\n3. Reaction occurs:\n   - Bonds broken\n   - Products formed\n\n4. Enzyme released unchanged:\n   - Can work again on new substrate\n\nFactors affecting enzyme action:\n\n1. Temperature:\n   - Human enzymes work best at 37°C (body temperature)\n   - Too high: denature (lose shape)\n   - Too low: work slowly\n\n2. pH:\n   - Each enzyme has optimal pH:\n     * Pepsin: pH 1.5-2.5 (acidic)\n     * Salivary amylase: pH 6.5-7.5 (neutral)\n     * Trypsin: pH 7.5-8.5 (alkaline)\n   - Wrong pH = enzyme inactive\n\n3. Concentration:\n   - More enzyme = faster reaction (up to point)\n   - More substrate = faster reaction (until saturated)\n\n4. Inhibitors:\n   - Some substances block enzyme action\n   - Poisons may inhibit enzymes\n\nImportance of enzymes in digestion:\n\n1. Speed up digestion:\n   - Without enzymes, digestion would take weeks\n   - With enzymes, completed in hours\n\n2. Work at body temperature:\n   - No need for high heat (would damage body)\n\n3. Specificity:\n   - Only target specific foods\n   - Prevents unwanted reactions\n\n4. Controllable:\n   - Secreted only when needed\n   - Activated at appropriate site\n\n5. Complete digestion:\n   - Ensure all nutrients broken down\n   - Prevent malabsorption\n\nEnzyme deficiencies:\n- Lactase deficiency → lactose intolerance\n- Pancreatic enzyme deficiency → malabsorption\n\nThus, enzymes are essential for efficient, complete, and controlled digestion."
        },
        {
            "type": "subjective",
            "q": "Describe the complete digestive system of humans with a labeled diagram.",
            "sample": "The human digestive system consists of the alimentary canal and associated digestive glands. It is responsible for ingesting food, digesting it, absorbing nutrients, and eliminating wastes.\n\nParts of the digestive system:\n\nA. Alimentary canal (gastrointestinal tract):\n\n1. Mouth (Buccal cavity):\n   - Contains teeth for chewing\n   - Contains tongue for tasting and mixing\n   - Salivary glands open here\n   - Site of ingestion and initial digestion\n\n2. Pharynx:\n   - Common passage for food and air\n   - Leads to oesophagus\n\n3. Oesophagus (Food pipe):\n   - Muscular tube about 25 cm long\n   - Moves food by peristalsis\n   - No digestion occurs here\n\n4. Stomach:\n   - J-shaped muscular organ\n   - Churns food and mixes with gastric juice\n   - Protein digestion begins\n   - Food becomes chyme\n\n5. Small intestine:\n   - Long coiled tube (6-7 m)\n   - Three parts: duodenum, jejunum, ileum\n   - Inner lining has villi for absorption\n   - Digestion completed here\n   - Most absorption occurs here\n\n6. Large intestine:\n   - Wider but shorter (1.5 m)\n   - Parts: caecum, colon, rectum\n   - Appendix attached to caecum\n   - Absorbs water and minerals\n   - Forms and stores faeces\n\n7. Rectum:\n   - Stores faeces temporarily\n   - Leads to anus\n\n8. Anus:\n   - Opening for egestion\n   - Controlled by sphincters\n\nB. Associated digestive glands:\n\n9. Salivary glands (3 pairs):\n   - Parotid, submandibular, sublingual\n   - Secrete saliva containing salivary amylase\n\n10. Liver:\n    - Largest gland in body\n    - Produces bile (stored in gall bladder)\n    - Bile emulsifies fats\n    - Performs many metabolic functions\n\n11. Pancreas:\n    - Leaf-shaped gland behind stomach\n    - Secretes pancreatic juice (enzymes + bicarbonate)\n    - Digestive enzymes for all food types\n\n12. Gall bladder:\n    - Stores and concentrates bile\n    - Releases bile when needed\n\nFlow of food:\nMouth → Pharynx → Oesophagus → Stomach → Small intestine (duodenum → jejunum → ileum) → Large intestine (caecum → colon → rectum) → Anus\n\n[Note: Students should draw a well-labeled diagram showing all parts with clear labels]\n\nKey points for diagram:\n- Show relative positions\n- Label all parts clearly\n- Indicate digestive glands\n- Show connections between parts\n- Include both alimentary canal and associated glands"
        },
        {
            "type": "subjective",
            "q": "What is the difference between mechanical and chemical digestion?",
            "sample": "Digestion involves both mechanical (physical) and chemical processes that work together to break down food.\n\nMechanical digestion:\nDefinition: Physical breakdown of food into smaller pieces without changing its chemical composition.\n\nProcesses:\n1. Chewing (mastication) in mouth:\n   - Teeth cut, tear, and grind food\n   - Increases surface area\n   - Breaks food into smaller particles\n\n2. Churning in stomach:\n   - Muscular contractions mix food\n   - Food broken into smaller pieces\n   - Forms semi-fluid chyme\n\n3. Segmentation in small intestine:\n   - Mixing movements\n   - Brings food in contact with enzymes\n   - Helps absorption\n\n4. Emulsification of fats:\n   - Bile breaks fat into tiny droplets\n   - Physical breakdown (no chemical change)\n\nFeatures of mechanical digestion:\n- No change in chemical structure\n- Increases surface area\n- Prepares food for chemical digestion\n- Uses physical force\n- Involves muscles and teeth\n\nChemical digestion:\nDefinition: Breakdown of complex food molecules into simpler ones by enzymes, changing chemical composition.\n\nProcesses:\n1. Carbohydrate digestion:\n   - Salivary amylase: Starch → Maltose\n   - Pancreatic amylase: Starch → Maltose\n   - Maltase: Maltose → Glucose\n   - Sucrase: Sucrose → Glucose + Fructose\n   - Lactase: Lactose → Glucose + Galactose\n\n2. Protein digestion:\n   - Pepsin: Proteins → Proteoses + Peptones\n   - Trypsin: Proteins → Polypeptides\n   - Erepsin: Polypeptides → Amino acids\n\n3. Fat digestion:\n   - Lipase: Fats → Fatty acids + Glycerol\n\nFeatures of chemical digestion:\n- Changes chemical composition\n- Uses enzymes\n- Produces absorbable molecules\n- Specific to each food type\n- Occurs at specific sites\n\nComparison table:\n\n| Aspect | Mechanical Digestion | Chemical Digestion |\n|--------|---------------------|-------------------|\n| Definition | Physical breakdown | Chemical breakdown |\n| Agents | Teeth, muscles, bile | Enzymes, acids |\n| Products | Smaller food pieces | Simple molecules |\n| Chemical change | No | Yes |\n| Examples | Chewing, churning | Starch → Glucose |\n| Site | Mouth, stomach | Mouth, stomach, small intestine |\n| Speed | Immediate | Slower, requires time |\n| Purpose | Increase surface area | Produce absorbable nutrients |\n\nInterdependence:\n- Mechanical digestion exposes more surface area for enzymes\n- Chemical digestion cannot occur efficiently without mechanical breakdown\n- Example: Whole potato vs mashed potato - enzymes work faster on mashed\n\nBoth types are essential for complete digestion."
        },
        {
            "type": "subjective",
            "q": "Write short notes on: a) Salivary glands b) Liver c) Pancreas",
            "sample": "a) Salivary glands:\n\nLocation and structure:\n- Three pairs of glands in and around mouth\n- Parotid glands: Near ears (largest)\n- Submandibular glands: Below lower jaw\n- Sublingual glands: Below tongue\n- Ducts open into mouth cavity\n\nSecretion:\n- Secrete saliva (about 1-1.5 litres daily)\n- Saliva contains:\n  * Water (99.5%)\n  * Salivary amylase (ptyalin) - digests starch\n  * Mucus - lubricates food\n  * Lysozyme - kills bacteria\n  * Salts - maintain pH\n\nFunctions:\n- Moistens and lubricates food\n- Begins starch digestion\n- Cleanses mouth and teeth\n- Helps in swallowing\n- Taste perception (dissolves food chemicals)\n\nb) Liver:\n\nLocation and structure:\n- Largest gland in body (about 1.5 kg)\n- Located in upper right abdomen\n- Protected by rib cage\n- Divided into right and left lobes\n- Receives blood from digestive tract\n\nFunctions:\n1. Digestive:\n   - Produces bile (600-1000 ml daily)\n   - Bile emulsifies fats\n   - Stored in gall bladder\n\n2. Metabolic:\n   - Carbohydrate metabolism (glycogen storage)\n   - Protein metabolism (deamination, urea formation)\n   - Fat metabolism\n\n3. Storage:\n   - Glycogen, vitamins (A, D, E, K, B12)\n   - Iron and copper\n\n4. Synthetic:\n   - Plasma proteins (albumin, clotting factors)\n   - Cholesterol\n\n5. Detoxification:\n   - Removes toxins and drugs\n   - Processes alcohol\n\n6. Excretory:\n   - Bile pigments (bilirubin) eliminated\n\nc) Pancreas:\n\nLocation and structure:\n- Leaf-shaped, yellowish gland\n- About 15-20 cm long\n- Lies behind stomach\n- Connected to duodenum by pancreatic duct\n- Both exocrine and endocrine gland\n\nExocrine functions (digestive):\n- Secretes pancreatic juice (1-1.5 litres daily)\n- Contains enzymes:\n  * Pancreatic amylase: Starch → Maltose\n  * Trypsin: Proteins → Polypeptides\n  * Lipase: Fats → Fatty acids + Glycerol\n- Contains sodium bicarbonate (alkaline)\n- Neutralizes acidic chyme\n\nEndocrine functions:\n- Islets of Langerhans produce hormones:\n  * Insulin (lowers blood sugar)\n  * Glucagon (raises blood sugar)\n- Regulate blood glucose level\n\nImportance:\n- Essential for digestion of all food types\n- Without pancreas, severe malnutrition\n- Diabetes when insulin deficient"
        },
        {
            "type": "subjective",
            "q": "Explain the process of egestion. What happens to undigested food?",
            "sample": "Egestion is the process of eliminating undigested, insoluble food materials from the body in the form of faeces.\n\nWhat remains undigested:\n- Cellulose (fiber) from plant foods\n- Some carbohydrates (resistant starch)\n- Dead bacteria\n- Sloughed-off intestinal cells\n- Bile pigments (give colour)\n- Water\n- Minerals\n\nJourney of undigested food:\n\n1. Entry into large intestine:\n   - Material enters caecum from ileum\n   - Through ileocaecal valve (prevents backflow)\n   - Material is still semi-fluid\n\n2. Movement through colon:\n   - Ascending colon (up right side)\n   - Transverse colon (across abdomen)\n   - Descending colon (down left side)\n   - Sigmoid colon (S-shaped before rectum)\n   - Slow peristalsis moves material\n   - Takes 12-24 hours to pass through\n\n3. Water absorption:\n   - About 90% of water reabsorbed\n   - Material becomes semi-solid\n   - Prevents dehydration\n   - If too fast: diarrhoea\n   - If too slow: constipation\n\n4. Bacterial action:\n   - Gut bacteria ferment remaining material\n   - Produce gases (flatulence)\n   - Synthesize vitamin K and B vitamins\n   - These vitamins are absorbed\n\n5. Formation of faeces:\n   - Brown colour from bile pigments (stercobilin)\n   - Characteristic odour from bacterial action\n   - Contains about 75% water, 25% solids\n   - Solids: bacteria, fiber, dead cells, fats\n\n6. Storage in rectum:\n   - Faeces stored temporarily\n   - Rectum stretches when full\n   - Stretch receptors signal brain\n   - Urge to defecate\n\n7. Egestion through anus:\n   - Internal anal sphincter (involuntary)\n   - External anal sphincter (voluntary)\n   - Relaxation of sphincters allows passage\n   - Abdominal muscles help push\n   - Faeces eliminated\n\nComposition of faeces:\n- Water: 75%\n- Bacteria: (dead) 10-20%\n- Fiber: 10%\n- Fat: 5%\n- Mucus, dead cells: 5%\n- Bile pigments, salts\n\nFactors affecting egestion:\n- Diet (fiber increases bulk)\n- Water intake\n- Physical activity\n- Stress\n- Medications\n\nAbnormalities:\n- Constipation: Too slow, hard stools\n- Diarrhoea: Too fast, watery stools\n- Steatorrhea: Fatty stools (malabsorption)\n- Blood in stools (bleeding)\n\nEgestion vs Excretion:\n- Egestion: Undigested food (never in body cells)\n- Excretion: Metabolic wastes (from body cells)"
        },
        {
            "type": "subjective",
            "q": "What is the function of mucus in the digestive system?",
            "sample": "Mucus is a thick, slippery secretion produced by mucous membranes throughout the digestive tract. It plays several crucial protective and lubricating roles.\n\nSources of mucus in digestive system:\n- Mouth (salivary glands)\n- Stomach (mucous cells)\n- Small intestine (goblet cells)\n- Large intestine (goblet cells)\n\nComposition of mucus:\n- Water (95%)\n- Mucin (glycoprotein that makes it sticky)\n- Electrolytes\n- Antibodies (IgA)\n- Antimicrobial substances\n\nFunctions of mucus:\n\n1. Protection from acid:\n   - In stomach, thick mucus layer (0.5-1.5 mm)\n   - Contains bicarbonate to neutralize acid\n   - Prevents stomach from digesting itself\n   - Barrier against HCl and pepsin\n\n2. Lubrication:\n   - Makes food slippery\n   - Eases passage through oesophagus\n   - Prevents friction damage\n   - Helps in smooth peristalsis\n   - Protects intestinal walls from rough food\n\n3. Protection from enzymes:\n   - Prevents digestive enzymes from attacking intestinal wall\n   - Especially important where enzymes are concentrated\n\n4. Traps bacteria:\n   - Sticky mucus traps pathogens\n   - Contains antibodies (IgA) that neutralize germs\n   - Removed with faeces\n\n5. Moisture maintenance:\n   - Keeps lining moist\n   - Prevents drying out\n   - Essential for cell function\n\n6. Facilitates movement:\n   - Helps food bolus slide easily\n   - Aids in formation of smooth stool\n   - Prevents constipation\n\n7. Protection from mechanical damage:\n   - Cushions against rough food particles\n   - Reduces friction during peristalsis\n   - Protects during passage of hard stools\n\n8. Protection from pathogens:\n   - Physical barrier against microbes\n   - Contains lysozyme (kills bacteria)\n   - Prevents infection\n\n9. Wound healing:\n   - Covers minor injuries\n   - Provides moist environment for healing\n   - Prevents further damage\n\n10. Buffering capacity:\n    - In stomach: Contains bicarbonate\n    - Maintains pH gradient (acid near food, neutral near wall)\n\nProblems with mucus deficiency:\n\n1. Gastric ulcers:\n   - If mucus layer breaks down\n   - Acid damages stomach lining\n   - Painful ulcers develop\n   - Can be caused by H. pylori bacteria or NSAIDs\n\n2. Increased friction:\n   - Food passage uncomfortable\n   - Difficulty swallowing\n\n3. Increased infection risk:\n   - Pathogens more likely to attach\n   - Higher chance of gastroenteritis\n\n4. Inflammatory bowel disease:\n   - Mucus layer abnormal\n   - Chronic inflammation\n\nConditions with excess mucus:\n- Irritable bowel syndrome\n- Some infections\n- Food intolerances\n\nThus, mucus is essential for protecting the digestive tract from self-digestion, infection, and mechanical damage while facilitating smooth passage of food."
        },
        {
            "type": "subjective",
            "q": "Why is the small intestine long and coiled? What adaptations help in absorption?",
            "sample": "The small intestine is long (6-7 metres) and coiled to fit in the abdominal cavity while providing maximum surface area for digestion and absorption.\n\nWhy the small intestine is long:\n\n1. Provides time for complete digestion:\n   - Food takes 3-5 hours to pass through\n   - Enzymes need time to act\n   - Allows sequential breakdown of all nutrients\n\n2. Provides surface area for absorption:\n   - Longer tube = more surface area\n   - Millions of nutrients must be absorbed\n   - Enough time for all to be taken up\n\n3. Allows for different digestive stages:\n   - Different enzymes act at different points\n   - Sequential digestion possible\n\nWhy it is coiled:\n\n1. Fits in abdominal cavity:\n   - Abdomen is limited space\n   - Straight tube would be too long\n   - Coiling packs 6-7 m into small space\n\n2. Slows down passage:\n   - Coils create resistance\n   - Prevents too rapid transit\n   - More time for absorption\n\n3. Allows mixing:\n   - Coils facilitate segmentation movements\n   - Food mixed with digestive juices\n   - Ensures all parts contact absorbing surface\n\nAdaptations for absorption:\n\n1. Villi:\n   - Finger-like projections (0.5-1.5 mm long)\n   - Millions present (20-40 per mm²)\n   - Increase surface area 10-15 times\n   - Contain blood capillaries and lacteal\n   - Thin walls (one cell thick)\n\n2. Microvilli (brush border):\n   - Microscopic projections on villi cells\n   - Further increase surface area 20 times\n   - Give brush-like appearance\n   - Contain digestive enzymes\n\n3. Total surface area:\n   - If flattened, about 200-300 m²\n   - Size of a tennis court!\n   - Enormous area for absorption\n\n4. Rich blood supply:\n   - Dense capillary network in each villus\n   - Quick removal of absorbed nutrients\n   - Maintains concentration gradient\n\n5. Lacteals:\n   - Lymph vessels in villi\n   - Absorb fats\n   - Transport to lymphatic system\n\n6. Thin walls:\n   - Epithelium one cell thick\n   - Short diffusion distance\n   - Rapid absorption\n\n7. Length:\n   - 6-7 metres total\n   - Provides time and area\n\n8. Circular folds:\n   - Permanent folds of mucosa\n   - Slow passage\n   - Increase surface area\n\n9. Intestinal glands (Crypts of Lieberkühn):\n   - Secrete intestinal juice\n   - Contain stem cells for renewal\n\n10. Constant movement:\n    - Villi move and sway\n    - Increases contact with nutrients\n    - Prevents stagnant layer\n\nSurface area calculation:\n- Smooth tube: 0.33 m²\n- With circular folds: 1 m²\n- With villi: 10 m²\n- With microvilli: 200+ m²\n\nThis enormous surface area ensures efficient absorption of all nutrients before food passes to large intestine."
        },
        {
            "type": "subjective",
            "q": "What is the role of bacteria in the large intestine?",
            "sample": "The large intestine hosts a diverse community of beneficial bacteria (gut microbiota) that play important roles in digestion, nutrition, and health.\n\nTypes of bacteria in large intestine:\n- Mostly anaerobic bacteria (don't need oxygen)\n- Common genera: Bacteroides, Lactobacillus, Bifidobacterium, Escherichia coli\n- About 100 trillion bacteria (10 times more than human cells)\n- Over 1000 different species\n\nFunctions of intestinal bacteria:\n\n1. Fermentation of undigested carbohydrates:\n   - Break down fiber (cellulose, pectin)\n   - Produce short-chain fatty acids (SCFAs)\n   - SCFAs: acetate, propionate, butyrate\n   - Butyrate is energy source for colon cells\n   - Provide about 10% of daily energy\n\n2. Vitamin synthesis:\n   - Vitamin K (essential for blood clotting)\n   - Biotin (vitamin B7)\n   - Vitamin B12 (cobalamin)\n   - Folic acid (vitamin B9)\n   - Thiamine (vitamin B1)\n   - Riboflavin (vitamin B2)\n   - These vitamins are absorbed and used by body\n\n3. Protection against pathogens:\n   - Compete with harmful bacteria for space and nutrients\n   - Produce substances that inhibit pathogens\n   - Maintain acidic pH (prevents pathogen growth)\n   - Strengthen gut barrier\n   - Train immune system\n\n4. Immune system development:\n   - Stimulate immune cell development\n   - Help distinguish friend from foe\n   - Prevent allergies (hygiene hypothesis)\n\n5. Gas production:\n   - Produce gases: hydrogen, methane, carbon dioxide\n   - Some gases absorbed, some expelled as flatulence\n   - Amount depends on diet\n\n6. Metabolism of bile acids:\n   - Break down bile acids\n   - Some reabsorbed (enterohepatic circulation)\n   - Some excreted\n\n7. Cholesterol metabolism:\n   - Some bacteria affect cholesterol levels\n   - Can convert cholesterol to coprostanol (excreted)\n\n8. Production of neurotransmitters:\n   - Produce GABA, serotonin precursors\n   - Gut-brain axis affects mood\n\nFactors affecting gut bacteria:\n\nDiet:\n- Fiber promotes beneficial bacteria (prebiotics)\n- Yogurt, fermented foods introduce probiotics\n- High fat/sugar diet reduces diversity\n- Antibiotics kill beneficial bacteria\n\nAge:\n- Infants acquire bacteria from mother\n- Diversity increases with age\n- Elderly have different profile\n\nHealth conditions:\n- Antibiotic use disrupts flora\n- Digestive diseases alter balance\n\nDysbiosis (imbalance) effects:\n- Diarrhoea or constipation\n- Gas and bloating\n- Increased infection risk\n- May contribute to:\n  * Irritable bowel syndrome\n  * Inflammatory bowel disease\n  * Allergies\n  * Obesity\n\nMaintaining healthy gut bacteria:\n- Eat fiber-rich foods (fruits, vegetables, whole grains)\n- Consume fermented foods (yogurt, kefir, kimchi)\n- Limit antibiotics to when necessary\n- Avoid excessive processed foods\n- Stay hydrated\n\nThus, gut bacteria are essential partners in digestion and health, not harmful invaders."
        },
        {
            "type": "subjective",
            "q": "Explain why a person can still eat while standing upside down.",
            "sample": "A person can eat while standing upside down because digestion does not rely on gravity - it uses muscular contractions called peristalsis.\n\nWhy gravity is not needed:\n\n1. Peristalsis:\n   - Wave-like contractions of smooth muscles\n   - Circular muscles contract behind food bolus\n   - Longitudinal muscles contract ahead\n   - This pushes food forward regardless of direction\n   - Works like squeezing toothpaste from tube\n\n2. Involuntary muscles:\n   - Oesophagus has two layers of muscles\n   - Controlled automatically (not voluntary)\n   - Continuous waves push food\n   - Cannot be consciously stopped\n\n3. Oesophageal structure:\n   - Muscular tube about 25 cm long\n   - Upper third: skeletal muscle (voluntary)\n   - Lower two-thirds: smooth muscle (involuntary)\n   - Coordinated contractions throughout\n\nDemonstration of peristalsis:\n- Swallow water while doing a handstand\n- Water still reaches stomach\n- Astronauts eat in zero gravity\n- Patients eat lying down in hospitals\n\nComparison with gravity:\n\nGravity would help if:\n- Oesophagus were a rigid tube\n- Food just fell through\n- But it's not - it's muscular and collapses\n\nPeristalsis is superior because:\n- Works in any body position\n- Works in zero gravity\n- Can push against pressure\n- Can move thick, solid food\n- Prevents backflow (reflux)\n\nAdditional factors that help:\n\n4. Swallowing reflex:\n   - Tongue pushes bolus to pharynx\n   - Soft palate rises (closes nasal passage)\n   - Epiglottis covers windpipe\n   - Upper oesophageal sphincter relaxes\n   - Bolus enters oesophagus\n   - All happens automatically\n\n5. Lower oesophageal sphincter:\n   - At junction with stomach\n   - Normally closed (prevents reflux)\n   - Opens when peristaltic wave arrives\n   - Closes after food passes\n\n6. Stomach position:\n   - Located in upper left abdomen\n   - Entry is above stomach (cardiac end)\n   - Food enters top, settles by gravity inside stomach\n   - But upside down, still enters because of peristalsis\n\nWhat would happen if only gravity worked:\n- Could only eat upright\n- Bedridden patients couldn't eat\n- Astronauts couldn't eat in space\n- Reflux would be more common\n- Thick foods would be difficult\n\nProof that peristalsis works:\n- X-ray videos show food moving upward in oesophagus when person is upside down\n- Patients with achalasia (no peristalsis) cannot swallow even upright\n- Oesophageal manometry measures pressure waves\n\nThus, the digestive system is designed to work in any orientation, making it possible to eat regardless of body position."
        },
        {
            "type": "subjective",
            "q": "What is the difference between milk teeth and permanent teeth?",
            "sample": "Humans have two sets of teeth in their lifetime: milk teeth (temporary) and permanent teeth.\n\nMilk teeth (Deciduous teeth):\n\nAppearance:\n- Begin to appear at 6-7 months of age\n- All 20 teeth usually present by 2-3 years\n\nNumber and types:\n- Total 20 teeth\n- Incisors: 8 (4 in each jaw)\n- Canines: 4 (2 in each jaw)\n- Premolars: 8 (4 in each jaw)\n- Molars: 0 (no molars in milk teeth)\n\nCharacteristics:\n- Smaller in size\n- Whiter in colour\n- Thinner enamel\n- Shorter roots\n- Fall out (shed) between 6-12 years\n- Also called temporary or deciduous teeth\n\nFunctions:\n- Allow child to chew food\n- Hold space for permanent teeth\n- Guide eruption of permanent teeth\n- Aid in speech development\n- Help in jaw development\n\nPermanent teeth:\n\nAppearance:\n- Begin to replace milk teeth around age 6\n- All usually present by 12-14 years (except wisdom teeth)\n- Wisdom teeth appear 17-25 years (or not at all)\n\nNumber and types:\n- Total 32 teeth\n- Incisors: 8 (4 in each jaw)\n- Canines: 4 (2 in each jaw)\n- Premolars: 8 (4 in each jaw)\n- Molars: 12 (6 in each jaw) including wisdom teeth\n\nCharacteristics:\n- Larger in size\n- Yellowish (darker than milk teeth)\n- Thicker enamel\n- Longer, stronger roots\n- Meant to last lifetime\n- Also called adult teeth\n\nFunctions:\n- Complete chewing of all foods\n- Maintain facial structure\n- Support lips and cheeks\n- Essential for clear speech\n\nComparison table:\n\n| Feature | Milk Teeth | Permanent Teeth |\n|---------|------------|-----------------|\n| Number | 20 | 32 |\n| When appear | 6 months - 2 years | 6 years onward |\n| Lifespan | Temporary (few years) | Lifetime |\n| Size | Smaller | Larger |\n| Colour | Whiter | More yellowish |\n| Enamel | Thinner | Thicker |\n| Roots | Shorter, weaker | Longer, stronger |\n| Molars | None | 12 (including wisdom) |\n| Shedding | Yes, all fall out | No (except if lost) |\n| Replacement | Replaced by permanent | Not replaced |\n\nProcess of replacement:\n- Permanent teeth develop beneath milk teeth\n- Roots of milk teeth dissolve\n- Milk teeth become loose and fall out\n- Permanent teeth erupt through gums\n- Takes several years (6-12 years)\n\nOrder of eruption (permanent):\n1. First molars (age 6)\n2. Central incisors (6-7 years)\n3. Lateral incisors (7-8 years)\n4. First premolars (9-10 years)\n5. Second premolars (10-12 years)\n6. Canines (11-12 years)\n7. Second molars (12-13 years)\n8. Third molars/wisdom (17-25 years)\n\nImportance of milk teeth:\n- Even though temporary, they are essential\n- Neglecting milk teeth affects permanent teeth\n- Early loss can cause crowding\n- Proper care of both sets important"
        },
        {
            "type": "subjective",
            "q": "Describe an activity to show the action of saliva on starch.",
            "sample": "Aim: To demonstrate that saliva contains an enzyme (salivary amylase) that digests starch.\n\nMaterials required:\n- Boiled and cooled rice or potato (source of starch)\n- Iodine solution (starch indicator - turns blue-black with starch)\n- Benedict's solution (tests for sugar)\n- Test tubes (2)\n- Dropper\n- Water\n- Fresh saliva (collected cleanly)\n- Mortar and pestle\n- Water bath\n\nProcedure:\n\nStep 1: Prepare starch solution\n- Take boiled rice or potato\n- Mash it in mortar with little water\n- Filter to get starch solution\n\nStep 2: Test for starch (control)\n- Take 2 ml starch solution in test tube A\n- Add 2-3 drops of iodine solution\n- Observation: Blue-black colour appears\n- Confirms presence of starch\n\nStep 3: Collect saliva\n- Rinse mouth thoroughly with water\n- Collect about 2 ml of saliva in clean container\n- Do not eat/drink for 30 minutes before\n\nStep 4: Prepare test\n- Take 2 ml starch solution in test tube B\n- Add 1 ml of saliva\n- Mix well\n- Keep in water bath at 37°C for 15-20 minutes\n\nStep 5: Test for starch disappearance\n- Take a few drops from test tube B\n- Add iodine solution\n- Observation: No blue-black colour\n- Indicates starch has been digested\n\nStep 6: Test for sugar formation\n- Take remaining solution from test tube B\n- Add Benedict's solution\n- Heat in water bath\n- Observation: Brick-red precipitate forms\n- Indicates presence of sugar (maltose)\n\nObservations:\n- Test tube A (starch + iodine): Blue-black (starch present)\n- Test tube B (after saliva action):\n  * Iodine test: No blue colour (starch gone)\n  * Benedict's test: Brick-red (sugar formed)\n\nConclusion:\n- Saliva contains an enzyme (salivary amylase)\n- This enzyme digests starch into sugar (maltose)\n- Digestion requires time and proper temperature\n\nPrecautions:\n- Collect saliva hygienically\n- Maintain 37°C temperature (body temperature)\n- Use boiled starch to kill any bacteria\n- Properly label test tubes\n- Clean equipment thoroughly\n\nAlternative method (chewing rice):\n- Take a small piece of boiled rice\n- Chew it for 2-3 minutes without swallowing\n- Notice taste change\n- Initially no taste, becomes sweet after chewing\n- Sweet taste is from sugar formed by saliva\n\nExplanation:\n- Salivary amylase breaks down starch\n- Starch (no taste) → Maltose (sweet taste)\n- Demonstrates digestion in mouth\n\nVariables to test:\n- Effect of temperature (try cold, hot)\n- Effect of boiling saliva (destroys enzyme)\n- Effect of acid/vinegar (enzyme inactive)\n\nThis activity clearly shows that chemical digestion begins in the mouth itself."
        },
        {
            "type": "subjective",
            "q": "Draw a labeled diagram of the digestive system and explain the function of each part.",
            "sample": "The human digestive system consists of the alimentary canal and associated glands. Here are the parts and their functions:\n\n[Students should draw a well-labeled diagram showing all parts]\n\nFunctions of each part:\n\n1. Mouth (Buccal cavity):\n   - Ingestion of food\n   - Chewing (mechanical digestion) by teeth\n   - Mixing with saliva by tongue\n   - Saliva contains salivary amylase for starch digestion\n   - Forms bolus for swallowing\n\n2. Pharynx:\n   - Common passage for food and air\n   - Swallowing reflex initiated\n   - Epiglottis prevents food from entering windpipe\n\n3. Oesophagus (Food pipe):\n   - Muscular tube connecting pharynx to stomach\n   - Moves food by peristalsis (wave-like contractions)\n   - No digestion occurs here\n\n4. Stomach:\n   - J-shaped muscular organ\n   - Churns food (mechanical digestion)\n   - Gastric glands secrete gastric juice\n   - HCl kills bacteria and provides acidic medium\n   - Pepsin digests proteins\n   - Rennin digests milk protein (in infants)\n   - Food becomes acidic chyme\n\n5. Small intestine:\n   - Long coiled tube (6-7 m)\n   - Three parts: duodenum, jejunum, ileum\n   - Receives bile from liver and pancreatic juice\n   - Completes digestion of all foods\n   - Villi absorb nutrients\n   - Most absorption occurs here\n\n6. Large intestine:\n   - Wider but shorter (1.5 m)\n   - Parts: caecum, colon, rectum\n   - Absorbs water and minerals\n   - Bacteria produce vitamin K and B vitamins\n   - Forms and stores faeces\n\n7. Rectum:\n   - Stores faeces temporarily\n   - Expands when full\n   - Signals urge to defecate\n\n8. Anus:\n   - Opening for egestion\n   - Controlled by sphincters (internal and external)\n   - Eliminates faeces\n\nAssociated glands:\n\n9. Salivary glands (3 pairs):\n   - Parotid, submandibular, sublingual\n   - Secrete saliva containing salivary amylase\n   - Moistens food, begins starch digestion\n\n10. Liver:\n    - Largest gland\n    - Produces bile (stored in gall bladder)\n    - Bile emulsifies fats\n    - Many metabolic functions\n\n11. Gall bladder:\n    - Stores and concentrates bile\n    - Releases bile when fatty food enters duodenum\n\n12. Pancreas:\n    - Leaf-shaped gland behind stomach\n    - Secretes pancreatic juice\n    - Contains enzymes for all food types\n    - Contains bicarbonate (neutralizes acid)\n\nFlow of food:\nMouth → Pharynx → Oesophagus → Stomach → Small intestine → Large intestine → Rectum → Anus\n\nTime taken:\n- Mouth to stomach: seconds\n- Stomach: 2-4 hours\n- Small intestine: 3-5 hours\n- Large intestine: 12-24 hours\n- Total: 24-48 hours"
        }
    ],

#Biology — Grade 6 ICSE
#Chapter 6: Circulatory System
#Comprehensive Practice Questions
#50 MCQ • 50 True/False • 40 Subjective
   
    "Chapter 6 — Circulatory System": [
        # ===== MCQ (50 questions) =====
        {
            "type": "mcq",
            "q": "What is the main function of the circulatory system?",
            "options": [
                "Digestion of food",
                "Transport of nutrients, gases, and wastes",
                "Production of energy",
                "Movement of body"
            ],
            "answer": "Transport of nutrients, gases, and wastes",
            "explanation": "The circulatory system transports nutrients, oxygen, carbon dioxide, hormones, and wastes throughout the body."
        },
        {
            "type": "mcq",
            "q": "The circulatory system in humans consists of:",
            "options": [
                "Heart only",
                "Blood and blood vessels only",
                "Heart, blood, and blood vessels",
                "Heart and lungs only"
            ],
            "answer": "Heart, blood, and blood vessels",
            "explanation": "The human circulatory system has three main components: blood, blood vessels, and the heart."
        },
        {
            "type": "mcq",
            "q": "How much blood does an average human adult have?",
            "options": [
                "2-3 litres",
                "4-6 litres",
                "7-8 litres",
                "10 litres"
            ],
            "answer": "4-6 litres",
            "explanation": "The human body on average has 4 to 6 litres of blood."
        },
        {
            "type": "mcq",
            "q": "Blood is a type of:",
            "options": [
                "Epithelial tissue",
                "Connective tissue",
                "Muscular tissue",
                "Nervous tissue"
            ],
            "answer": "Connective tissue",
            "explanation": "Blood is a fluid connective tissue."
        },
        {
            "type": "mcq",
            "q": "The liquid part of blood is called:",
            "options": [
                "Serum",
                "Plasma",
                "Cytoplasm",
                "Lymph"
            ],
            "answer": "Plasma",
            "explanation": "Plasma is the pale yellow liquid part of blood, constituting 55-60% of blood volume."
        },
        {
            "type": "mcq",
            "q": "What is the colour of plasma?",
            "options": [
                "Red",
                "Colourless",
                "Pale yellow",
                "White"
            ],
            "answer": "Pale yellow",
            "explanation": "Plasma is pale yellow in colour."
        },
        {
            "type": "mcq",
            "q": "What percentage of blood is plasma?",
            "options": [
                "40-45%",
                "55-60%",
                "70-75%",
                "80-85%"
            ],
            "answer": "55-60%",
            "explanation": "Plasma constitutes about 55-60% of total blood volume."
        },
        {
            "type": "mcq",
            "q": "Plasma consists of about what percentage of water?",
            "options": [
                "70-80%",
                "80-85%",
                "90-92%",
                "95-98%"
            ],
            "answer": "90-92%",
            "explanation": "Plasma consists of 90-92% water, along with proteins, inorganic salts, and other substances."
        },
        {
            "type": "mcq",
            "q": "The three types of blood cells are:",
            "options": [
                "RBCs, WBCs, and platelets",
                "RBCs, WBCs, and plasma",
                "Plasma, serum, and platelets",
                "RBCs, platelets, and serum"
            ],
            "answer": "RBCs, WBCs, and platelets",
            "explanation": "The three types of blood cells (corpuscles) are red blood cells (RBCs), white blood cells (WBCs), and blood platelets."
        },
        {
            "type": "mcq",
            "q": "What percentage of blood is made up of blood cells?",
            "options": [
                "40-45%",
                "55-60%",
                "30-35%",
                "20-25%"
            ],
            "answer": "40-45%",
            "explanation": "Blood cells (corpuscles) constitute 40-45% of total blood volume."
        },
        {
            "type": "mcq",
            "q": "Red blood cells are also called:",
            "options": [
                "Leucocytes",
                "Erythrocytes",
                "Thrombocytes",
                "Lymphocytes"
            ],
            "answer": "Erythrocytes",
            "explanation": "Red blood cells are scientifically called erythrocytes."
        },
        {
            "type": "mcq",
            "q": "White blood cells are also called:",
            "options": [
                "Erythrocytes",
                "Leucocytes",
                "Thrombocytes",
                "Granulocytes"
            ],
            "answer": "Leucocytes",
            "explanation": "White blood cells are scientifically called leucocytes."
        },
        {
            "type": "mcq",
            "q": "Blood platelets are also called:",
            "options": [
                "Erythrocytes",
                "Leucocytes",
                "Thrombocytes",
                "Lymphocytes"
            ],
            "answer": "Thrombocytes",
            "explanation": "Blood platelets are scientifically called thrombocytes."
        },
        {
            "type": "mcq",
            "q": "What is the shape of red blood cells?",
            "options": [
                "Spherical",
                "Biconcave disc-shaped",
                "Irregular",
                "Thread-like"
            ],
            "answer": "Biconcave disc-shaped",
            "explanation": "RBCs are biconcave, disc-shaped cells, as if pressed from the sides."
        },
        {
            "type": "mcq",
            "q": "Do mature red blood cells have a nucleus?",
            "options": [
                "Yes",
                "No",
                "Sometimes",
                "Only in some animals"
            ],
            "answer": "No",
            "explanation": "Mature red blood cells in humans do not have a nucleus, which provides more space for haemoglobin."
        },
        {
            "type": "mcq",
            "q": "Where are red blood cells produced?",
            "options": [
                "Liver",
                "Spleen",
                "Bone marrow",
                "Lymph nodes"
            ],
            "answer": "Bone marrow",
            "explanation": "RBCs are produced in the bone marrow."
        },
        {
            "type": "mcq",
            "q": "What is the average life span of a red blood cell?",
            "options": [
                "30 days",
                "60 days",
                "90 days",
                "120 days"
            ],
            "answer": "120 days",
            "explanation": "RBCs have an average life span of about 120 days (4 months)."
        },
        {
            "type": "mcq",
            "q": "How many RBCs are there in each cubic millimetre of blood?",
            "options": [
                "4-5 million",
                "5-6 million",
                "6-7 million",
                "7-8 million"
            ],
            "answer": "5-6 million",
            "explanation": "There are about 5-6 million RBCs in each mm³ of blood."
        },
        {
            "type": "mcq",
            "q": "The red colour of RBCs is due to:",
            "options": [
                "Iron",
                "Haemoglobin",
                "Oxygen",
                "Plasma"
            ],
            "answer": "Haemoglobin",
            "explanation": "RBCs are red due to the presence of haemoglobin, a red-coloured iron-containing protein."
        },
        {
            "type": "mcq",
            "q": "The function of haemoglobin is to:",
            "options": [
                "Fight infection",
                "Carry oxygen",
                "Clot blood",
                "Digest food"
            ],
            "answer": "Carry oxygen",
            "explanation": "Haemoglobin carries oxygen from lungs to all body cells."
        },
        {
            "type": "mcq",
            "q": "White blood cells are ________ than red blood cells.",
            "options": [
                "Smaller",
                "Larger",
                "Same size",
                "Half the size"
            ],
            "answer": "Larger",
            "explanation": "WBCs are larger than RBCs."
        },
        {
            "type": "mcq",
            "q": "Do white blood cells contain haemoglobin?",
            "options": [
                "Yes",
                "No",
                "Sometimes",
                "Only some types"
            ],
            "answer": "No",
            "explanation": "WBCs do not contain haemoglobin, so they are colourless."
        },
        {
            "type": "mcq",
            "q": "White blood cells have:",
            "options": [
                "No nucleus",
                "A nucleus",
                "Multiple nuclei",
                "No definite shape but have nucleus"
            ],
            "answer": "No definite shape but have nucleus",
            "explanation": "WBCs do not have a definite shape, change shape like Amoeba, and contain nuclei."
        },
        {
            "type": "mcq",
            "q": "Where are white blood cells produced?",
            "options": [
                "Bone marrow only",
                "Lymph nodes only",
                "Bone marrow and lymph nodes",
                "Spleen only"
            ],
            "answer": "Bone marrow and lymph nodes",
            "explanation": "WBCs are produced in the red bone marrow and lymph nodes."
        },
        {
            "type": "mcq",
            "q": "What is the life span of white blood cells?",
            "options": [
                "12 hours to 12 days",
                "30-40 days",
                "120 days",
                "1 year"
            ],
            "answer": "12 hours to 12 days",
            "explanation": "WBCs have a life span ranging from 12 hours to 12 days."
        },
        {
            "type": "mcq",
            "q": "How many WBCs are there in each cubic millimetre of blood?",
            "options": [
                "1000-2000",
                "4000-13000",
                "20000-30000",
                "50000-100000"
            ],
            "answer": "4000-13000",
            "explanation": "Normal WBC count is about 4000-13000 per mm³ of blood."
        },
        {
            "type": "mcq",
            "q": "An abnormal increase in WBC count above _______ indicates infection.",
            "options": [
                "10,000",
                "20,000",
                "50,000",
                "1,00,000"
            ],
            "answer": "50,000",
            "explanation": "WBC count above 50,000 per mm³ indicates infection in the body."
        },
        {
            "type": "mcq",
            "q": "The main function of white blood cells is to:",
            "options": [
                "Carry oxygen",
                "Clot blood",
                "Protect the body from infection",
                "Transport nutrients"
            ],
            "answer": "Protect the body from infection",
            "explanation": "WBCs protect the body by destroying germs and foreign bodies like bacteria and viruses."
        },
        {
            "type": "mcq",
            "q": "WBCs destroy germs by:",
            "options": [
                "Releasing chemicals",
                "Engulfing them",
                "Producing antibodies",
                "All of these"
            ],
            "answer": "All of these",
            "explanation": "WBCs can engulf germs (phagocytosis), produce antibodies, and release chemicals to fight infection."
        },
        {
            "type": "mcq",
            "q": "Blood platelets are:",
            "options": [
                "Colourless, nucleated cells",
                "Colourless, disc-shaped cells without nuclei",
                "Red, disc-shaped cells",
                "Irregular, coloured cells"
            ],
            "answer": "Colourless, disc-shaped cells without nuclei",
            "explanation": "Platelets are colourless, disc-shaped cells without nuclei."
        },
        {
            "type": "mcq",
            "q": "How many platelets are there in each cubic millimetre of blood?",
            "options": [
                "40,000-80,000",
                "1,00,000-2,00,000",
                "2,00,000-4,00,000",
                "5,00,000-10,00,000"
            ],
            "answer": "2,00,000-4,00,000",
            "explanation": "Platelet count is about 200,000-400,000 per mm³ of blood."
        },
        {
            "type": "mcq",
            "q": "What is the life span of blood platelets?",
            "options": [
                "1-2 days",
                "3-7 days",
                "10-15 days",
                "30 days"
            ],
            "answer": "3-7 days",
            "explanation": "Platelets have a life span of about 3-7 days."
        },
        {
            "type": "mcq",
            "q": "The main function of platelets is:",
            "options": [
                "Oxygen transport",
                "Immunity",
                "Blood clotting",
                "Nutrient transport"
            ],
            "answer": "Blood clotting",
            "explanation": "Platelets prevent blood loss by forming clots over wounds and cuts."
        },
        {
            "type": "mcq",
            "q": "About how many RBCs are destroyed every minute?",
            "options": [
                "1 million",
                "10 million",
                "20 million",
                "50 million"
            ],
            "answer": "20 million",
            "explanation": "About 20 million RBCs are destroyed every minute in the spleen and liver."
        },
        {
            "type": "mcq",
            "q": "Where are RBCs destroyed?",
            "options": [
                "Bone marrow",
                "Spleen and liver",
                "Kidneys",
                "Heart"
            ],
            "answer": "Spleen and liver",
            "explanation": "Old RBCs are destroyed in the spleen and liver."
        },
        {
            "type": "mcq",
            "q": "Granulocytes and agranulocytes are types of:",
            "options": [
                "RBCs",
                "WBCs",
                "Platelets",
                "Plasma proteins"
            ],
            "answer": "WBCs",
            "explanation": "WBCs are of two types: granulocytes (with granules) and agranulocytes (without granules)."
        },
        {
            "type": "mcq",
            "q": "Who developed the system of classification of blood groups?",
            "options": [
                "Robert Hooke",
                "Karl Landsteiner",
                "Louis Pasteur",
                "Alexander Fleming"
            ],
            "answer": "Karl Landsteiner",
            "explanation": "Karl Landsteiner developed the ABO blood group system and was awarded the Nobel Prize in 1930."
        },
        {
            "type": "mcq",
            "q": "Human blood is classified into four groups based on the presence of:",
            "options": [
                "Haemoglobin",
                "Antigens on RBCs",
                "Platelets",
                "White blood cells"
            ],
            "answer": "Antigens on RBCs",
            "explanation": "Blood groups are based on antigens (proteins) present on the surface of RBCs."
        },
        {
            "type": "mcq",
            "q": "The four blood groups are:",
            "options": [
                "A, B, C, D",
                "A, B, AB, O",
                "A, B, O, ABO",
                "Type 1, 2, 3, 4"
            ],
            "answer": "A, B, AB, O",
            "explanation": "The ABO blood group system has four types: A, B, AB, and O."
        },
        {
            "type": "mcq",
            "q": "Blood group A has:",
            "options": [
                "Antigen A and antibody B",
                "Antigen B and antibody A",
                "Both antigens A and B",
                "No antigens"
            ],
            "answer": "Antigen A and antibody B",
            "explanation": "Blood group A has antigen A on RBCs and antibody B in plasma."
        },
        {
            "type": "mcq",
            "q": "Blood group B has:",
            "options": [
                "Antigen A and antibody B",
                "Antigen B and antibody A",
                "Both antigens A and B",
                "No antibodies"
            ],
            "answer": "Antigen B and antibody A",
            "explanation": "Blood group B has antigen B on RBCs and antibody A in plasma."
        },
        {
            "type": "mcq",
            "q": "Blood group AB has:",
            "options": [
                "Antigen A and antibody B",
                "Antigen B and antibody A",
                "Both antigens A and B, no antibodies",
                "No antigens, both antibodies"
            ],
            "answer": "Both antigens A and B, no antibodies",
            "explanation": "Blood group AB has both antigens A and B on RBCs but no antibodies in plasma."
        },
        {
            "type": "mcq",
            "q": "Blood group O has:",
            "options": [
                "Both antigens, no antibodies",
                "No antigens, both antibodies A and B",
                "Antigen A only",
                "Antigen B only"
            ],
            "answer": "No antigens, both antibodies A and B",
            "explanation": "Blood group O has neither antigen A nor B, but both antibodies A and B in plasma."
        },
        {
            "type": "mcq",
            "q": "What is Rh-factor?",
            "options": [
                "A type of blood cell",
                "An antigen on RBCs",
                "A plasma protein",
                "A blood clotting factor"
            ],
            "answer": "An antigen on RBCs",
            "explanation": "Rh-factor is an antigen found on the surface of RBCs, first discovered in Rhesus monkeys."
        },
        {
            "type": "mcq",
            "q": "What percentage of people are Rh-positive?",
            "options": [
                "About 50%",
                "About 65%",
                "About 85%",
                "About 95%"
            ],
            "answer": "About 85%",
            "explanation": "About 85% of people have the Rh-factor and are Rh-positive."
        },
        {
            "type": "mcq",
            "q": "Blood vessels that carry blood away from the heart are called:",
            "options": [
                "Veins",
                "Arteries",
                "Capillaries",
                "Venules"
            ],
            "answer": "Arteries",
            "explanation": "Arteries carry blood away from the heart to different body parts."
        },
        {
            "type": "mcq",
            "q": "Blood vessels that carry blood towards the heart are called:",
            "options": [
                "Arteries",
                "Veins",
                "Capillaries",
                "Arterioles"
            ],
            "answer": "Veins",
            "explanation": "Veins carry blood towards the heart from different body parts."
        },
        {
            "type": "mcq",
            "q": "Which blood vessel carries blood from the heart to the lungs?",
            "options": [
                "Pulmonary vein",
                "Pulmonary artery",
                "Aorta",
                "Vena cava"
            ],
            "answer": "Pulmonary artery",
            "explanation": "The pulmonary artery carries deoxygenated (impure) blood from the heart to the lungs."
        },
        {
            "type": "mcq",
            "q": "Which blood vessel carries blood from the lungs to the heart?",
            "options": [
                "Pulmonary artery",
                "Pulmonary vein",
                "Aorta",
                "Coronary artery"
            ],
            "answer": "Pulmonary vein",
            "explanation": "The pulmonary vein carries oxygenated (pure) blood from the lungs to the heart."
        },
        {
            "type": "mcq",
            "q": "Which is the largest artery in the body?",
            "options": [
                "Pulmonary artery",
                "Coronary artery",
                "Aorta",
                "Carotid artery"
            ],
            "answer": "Aorta",
            "explanation": "The aorta is the largest artery in the body, arising from the left ventricle."
        },
        {
            "type": "mcq",
            "q": "Which blood vessels have valves to prevent backflow of blood?",
            "options": [
                "Arteries",
                "Veins",
                "Capillaries",
                "All blood vessels"
            ],
            "answer": "Veins",
            "explanation": "Veins have valves to prevent backflow of blood, especially in limbs against gravity."
        },
        {
            "type": "mcq",
            "q": "The walls of capillaries are:",
            "options": [
                "Thick and muscular",
                "Thin, one cell thick",
                "Elastic only",
                "Made of cartilage"
            ],
            "answer": "Thin, one cell thick",
            "explanation": "Capillary walls are only one cell thick to enable diffusion of gases and materials."
        },
        
        # ===== True/False (50 questions) =====
        {
            "type": "tf",
            "q": "The circulatory system transports only oxygen and carbon dioxide.",
            "answer": "False",
            "explanation": "It transports nutrients, hormones, wastes, and many other substances besides gases."
        },
        {
            "type": "tf",
            "q": "Blood is a solid tissue.",
            "answer": "False",
            "explanation": "Blood is a fluid connective tissue."
        },
        {
            "type": "tf",
            "q": "Plasma is the liquid part of blood and is red in colour.",
            "answer": "False",
            "explanation": "Plasma is pale yellow, not red. Red colour comes from RBCs."
        },
        {
            "type": "tf",
            "q": "Plasma contains digested nutrients, waste products, and chemicals.",
            "answer": "True",
            "explanation": "Plasma transports many substances including nutrients, wastes, and hormones."
        },
        {
            "type": "tf",
            "q": "Blood corpuscles make up 55-60% of blood volume.",
            "answer": "False",
            "explanation": "Plasma makes up 55-60%; blood corpuscles make up 40-45%."
        },
        {
            "type": "tf",
            "q": "Red blood cells are also called leucocytes.",
            "answer": "False",
            "explanation": "RBCs are erythrocytes; WBCs are leucocytes."
        },
        {
            "type": "tf",
            "q": "Mature red blood cells in humans have a nucleus.",
            "answer": "False",
            "explanation": "Mature human RBCs do not have a nucleus, providing more space for haemoglobin."
        },
        {
            "type": "tf",
            "q": "The biconcave shape of RBCs increases surface area for oxygen transport.",
            "answer": "True",
            "explanation": "The biconcave shape provides larger surface area for gas exchange."
        },
        {
            "type": "tf",
            "q": "Red blood cells are produced in the liver.",
            "answer": "False",
            "explanation": "RBCs are produced in the bone marrow, not the liver."
        },
        {
            "type": "tf",
            "q": "The average life span of an RBC is about 120 days.",
            "answer": "True",
            "explanation": "RBCs live for approximately 120 days before being destroyed."
        },
        {
            "type": "tf",
            "q": "Haemoglobin is an iron-containing protein.",
            "answer": "True",
            "explanation": "Haemoglobin contains iron, which binds to oxygen."
        },
        {
            "type": "tf",
            "q": "White blood cells are smaller than red blood cells.",
            "answer": "False",
            "explanation": "WBCs are larger than RBCs."
        },
        {
            "type": "tf",
            "q": "White blood cells have a definite shape like RBCs.",
            "answer": "False",
            "explanation": "WBCs are irregular and can change shape like Amoeba."
        },
        {
            "type": "tf",
            "q": "White blood cells contain haemoglobin.",
            "answer": "False",
            "explanation": "WBCs do not contain haemoglobin; they are colourless."
        },
        {
            "type": "tf",
            "q": "WBCs are produced in the bone marrow and lymph nodes.",
            "answer": "True",
            "explanation": "Both bone marrow and lymph nodes produce white blood cells."
        },
        {
            "type": "tf",
            "q": "The life span of WBCs is longer than that of RBCs.",
            "answer": "False",
            "explanation": "WBCs live 12 hours to 12 days, shorter than RBCs' 120 days."
        },
        {
            "type": "tf",
            "q": "Normal WBC count is about 4000-13000 per mm³ of blood.",
            "answer": "True",
            "explanation": "This is the normal range for WBC count."
        },
        {
            "type": "tf",
            "q": "A WBC count above 50,000 indicates infection.",
            "answer": "True",
            "explanation": "High WBC count (leukocytosis) indicates infection or inflammation."
        },
        {
            "type": "tf",
            "q": "WBCs protect the body by engulfing germs.",
            "answer": "True",
            "explanation": "This process is called phagocytosis."
        },
        {
            "type": "tf",
            "q": "Blood platelets are nucleated cells.",
            "answer": "False",
            "explanation": "Platelets are without nuclei."
        },
        {
            "type": "tf",
            "q": "Platelets are smaller than RBCs and WBCs.",
            "answer": "True",
            "explanation": "Platelets are the smallest blood cells."
        },
        {
            "type": "tf",
            "q": "Platelets are produced in the bone marrow.",
            "answer": "True",
            "explanation": "Platelets are formed from megakaryocytes in bone marrow."
        },
        {
            "type": "tf",
            "q": "The life span of platelets is about 3-7 days.",
            "answer": "True",
            "explanation": "Platelets have a short life span and are constantly replaced."
        },
        {
            "type": "tf",
            "q": "Platelets help in blood clotting.",
            "answer": "True",
            "explanation": "Platelets form clots to prevent blood loss."
        },
        {
            "type": "tf",
            "q": "About 20 million RBCs are destroyed every hour.",
            "answer": "False",
            "explanation": "About 20 million RBCs are destroyed every minute."
        },
        {
            "type": "tf",
            "q": "RBCs are destroyed in the spleen and liver.",
            "answer": "True",
            "explanation": "Old RBCs are broken down in the spleen and liver."
        },
        {
            "type": "tf",
            "q": "Karl Landsteiner discovered blood groups.",
            "answer": "True",
            "explanation": "He developed the ABO blood group system and won the Nobel Prize."
        },
        {
            "type": "tf",
            "q": "Blood group AB has both antibodies A and B.",
            "answer": "False",
            "explanation": "Blood group AB has no antibodies, but both antigens A and B."
        },
        {
            "type": "tf",
            "q": "Blood group O has both antibodies A and B.",
            "answer": "True",
            "explanation": "Group O has no antigens but both antibodies."
        },
        {
            "type": "tf",
            "q": "Rh-factor was first discovered in rabbits.",
            "answer": "False",
            "explanation": "It was discovered in Rhesus monkeys, hence the name Rh."
        },
        {
            "type": "tf",
            "q": "About 85% of people are Rh-positive.",
            "answer": "True",
            "explanation": "85% have Rh-factor; 15% are Rh-negative."
        },
        {
            "type": "tf",
            "q": "Arteries carry blood away from the heart.",
            "answer": "True",
            "explanation": "This is the definition of arteries."
        },
        {
            "type": "tf",
            "q": "Veins carry blood towards the heart.",
            "answer": "True",
            "explanation": "This is the definition of veins."
        },
        {
            "type": "tf",
            "q": "Arteries always carry oxygenated (pure) blood.",
            "answer": "False",
            "explanation": "Pulmonary artery carries deoxygenated blood to lungs."
        },
        {
            "type": "tf",
            "q": "Veins always carry deoxygenated (impure) blood.",
            "answer": "False",
            "explanation": "Pulmonary veins carry oxygenated blood from lungs to heart."
        },
        {
            "type": "tf",
            "q": "Arteries have thick, elastic, muscular walls.",
            "answer": "True",
            "explanation": "Arteries need thick walls to withstand high pressure."
        },
        {
            "type": "tf",
            "q": "Veins have valves to prevent backflow of blood.",
            "answer": "True",
            "explanation": "Valves are especially important in leg veins against gravity."
        },
        {
            "type": "tf",
            "q": "Capillaries have walls one cell thick.",
            "answer": "True",
            "explanation": "This thin wall allows diffusion of gases and nutrients."
        },
        {
            "type": "tf",
            "q": "The pulmonary artery carries pure blood.",
            "answer": "False",
            "explanation": "The pulmonary artery carries impure (deoxygenated) blood to lungs."
        },
        {
            "type": "tf",
            "q": "The pulmonary veins carry impure blood.",
            "answer": "False",
            "explanation": "Pulmonary veins carry pure (oxygenated) blood from lungs to heart."
        },
        {
            "type": "tf",
            "q": "The aorta is the largest artery in the body.",
            "answer": "True",
            "explanation": "The aorta arises from the left ventricle and supplies all body parts."
        },
        {
            "type": "tf",
            "q": "Blood transports hormones from their site of production to target organs.",
            "answer": "True",
            "explanation": "Blood carries chemical messengers (hormones) throughout the body."
        },
        {
            "type": "tf",
            "q": "Blood helps in regulating body temperature.",
            "answer": "True",
            "explanation": "Blood distributes heat from active organs to maintain constant temperature."
        },
        {
            "type": "tf",
            "q": "Granulocytes have granules in their cytoplasm.",
            "answer": "True",
            "explanation": "Granulocytes (neutrophils, basophils, eosinophils) contain visible granules."
        },
        {
            "type": "tf",
            "q": "Lymphocytes and monocytes are types of granulocytes.",
            "answer": "False",
            "explanation": "They are agranulocytes (without granules)."
        },
        {
            "type": "tf",
            "q": "Blood group AB is called the universal donor.",
            "answer": "False",
            "explanation": "Group O is universal donor; AB is universal recipient."
        },
        {
            "type": "tf",
            "q": "Blood group O can donate to any blood group.",
            "answer": "True",
            "explanation": "Group O has no antigens, so it can be given to anyone (universal donor)."
        },
        {
            "type": "tf",
            "q": "Blood group AB can receive from any blood group.",
            "answer": "True",
            "explanation": "Group AB has no antibodies, so it can receive from any type (universal recipient)."
        },
        {
            "type": "tf",
            "q": "Arteries are deep-seated in the body.",
            "answer": "True",
            "explanation": "Most arteries are deep for protection; veins are often superficial."
        },
        {
            "type": "tf",
            "q": "Veins are closer to the skin than arteries.",
            "answer": "True",
            "explanation": "This is why you can see veins through skin but not arteries."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "Describe the composition of blood with a labeled diagram.",
            "sample": "Blood is a fluid connective tissue composed of plasma and blood cells (corpuscles).\n\nComposition of blood:\n\n1. Plasma (55-60%):\n   - Pale yellow liquid\n   - 90-92% water\n   - 7-8% proteins (albumin, globulin, fibrinogen)\n   - 1% inorganic salts\n   - Traces of nutrients, wastes, hormones, enzymes\n\n2. Blood cells/corpuscles (40-45%):\n\n   A. Red Blood Cells (Erythrocytes):\n      - Biconcave, disc-shaped\n      - No nucleus in mature cells\n      - Contain haemoglobin (red colour)\n      - 5-6 million per mm³\n      - Life span: 120 days\n      - Produced in bone marrow\n      - Function: Transport oxygen\n\n   B. White Blood Cells (Leucocytes):\n      - Larger than RBCs\n      - Irregular shape\n      - Have nucleus\n      - No haemoglobin (colourless)\n      - 4000-13000 per mm³\n      - Life span: 12 hours to 12 days\n      - Produced in bone marrow and lymph nodes\n      - Function: Fight infection\n      - Types: Granulocytes and Agranulocytes\n\n   C. Blood Platelets (Thrombocytes):\n      - Smallest blood cells\n      - Colourless, disc-shaped\n      - No nucleus\n      - 200,000-400,000 per mm³\n      - Life span: 3-7 days\n      - Produced in bone marrow\n      - Function: Blood clotting\n\n[Students should draw a labeled diagram showing:\n- Test tube with blood (plasma at top, buffy coat of WBCs/platelets in middle, RBCs at bottom)\n- Individual diagrams of RBC (biconcave), WBC (irregular with nucleus), platelet (small disc)]"
        },
        {
            "type": "subjective",
            "q": "Explain the structure and function of red blood cells.",
            "sample": "Red blood cells (erythrocytes) are the most abundant cells in blood, specialized for oxygen transport.\n\nStructure of RBCs:\n\n1. Shape:\n   - Biconcave disc-shaped (depressed in centre, thick at edges)\n   - Like a doughnut without a hole\n   - This shape increases surface area\n\n2. Size:\n   - About 7-8 micrometres in diameter\n   - Smallest cells in human body\n\n3. Nucleus:\n   - Absent in mature human RBCs\n   - Lost during maturation\n   - Provides more space for haemoglobin\n\n4. Haemoglobin:\n   - Red, iron-containing protein\n   - About 250 million molecules per RBC\n   - Gives blood its red colour\n   - Binds reversibly with oxygen\n\n5. Cell membrane:\n   - Flexible and elastic\n   - Allows shape change to pass through capillaries\n\n6. Cytoplasm:\n   - Contains haemoglobin\n   - No other organelles\n   - Cannot divide or synthesize proteins\n\n7. Number:\n   - 5-6 million per mm³ of blood\n   - About 25 trillion in adult body\n\nProduction and destruction:\n- Produced in bone marrow at 2 million per second\n- Need iron, vitamin B12, folic acid for formation\n- Life span: about 120 days\n- Destroyed in spleen and liver\n- Iron recycled, haem converted to bilirubin\n\nFunctions of RBCs:\n\n1. Oxygen transport:\n   - Haemoglobin binds oxygen in lungs\n   - Forms oxyhaemoglobin (bright red)\n   - Releases oxygen in tissues\n   - Each RBC carries about 1 billion oxygen molecules\n\n2. Carbon dioxide transport:\n   - Carries about 20-30% of CO₂\n   - CO₂ binds to haemoglobin (carbaminohaemoglobin)\n   - Rest CO₂ transported as bicarbonate in plasma\n\n3. Buffer function:\n   - Haemoglobin helps maintain blood pH\n   - Acts as buffer against acid-base changes\n\nAdaptations for function:\n- Biconcave shape = large surface area\n- No nucleus = more space for haemoglobin\n- Flexible = can pass through narrow capillaries\n- Rich in haemoglobin = efficient oxygen binding\n\nDiseases related to RBCs:\n- Anaemia: Low haemoglobin or RBC count\n- Polycythemia: Too many RBCs\n- Sickle cell anaemia: Abnormal shaped RBCs\n\nThus, RBCs are perfectly adapted for their oxygen-carrying function."
        },
        {
            "type": "subjective",
            "q": "Explain the structure and function of white blood cells.",
            "sample": "White blood cells (leucocytes) are the defence cells of the body, protecting against infections and foreign materials.\n\nGeneral characteristics:\n- Larger than RBCs (10-18 micrometres)\n- Colourless (no haemoglobin)\n- Have nucleus\n- Irregular shape (can change shape like Amoeba)\n- Fewer in number (4000-13000 per mm³)\n- Shorter life span (hours to days)\n- Produced in bone marrow and lymph nodes\n- Can move like Amoeba (ameboid movement)\n- Can squeeze through capillary walls (diapedesis)\n\nTypes of WBCs:\n\nA. Granulocytes (with granules in cytoplasm):\n\n1. Neutrophils (60-70%):\n   - Multi-lobed nucleus\n   - Phagocytic (engulf bacteria)\n   - First to arrive at infection site\n   - Form pus\n\n2. Eosinophils (2-4%):\n   - Bilobed nucleus\n   - Fight parasitic infections\n   - Involved in allergic reactions\n\n3. Basophils (0.5-1%):\n   - Lobed nucleus\n   - Release histamine (inflammation)\n   - Involved in allergic responses\n\nB. Agranulocytes (without granules):\n\n4. Lymphocytes (20-30%):\n   - Large, round nucleus\n   - Produce antibodies (B-lymphocytes)\n   - Attack infected cells (T-lymphocytes)\n   - Provide immunity\n   - Memory cells provide long-term protection\n\n5. Monocytes (3-8%):\n   - Largest WBCs\n   - Kidney-shaped nucleus\n   - Become macrophages in tissues\n   - Phagocytic (engulf large particles)\n   - Clean up dead cells and debris\n\nFunctions of WBCs:\n\n1. Phagocytosis:\n   - Neutrophils and monocytes engulf bacteria\n   - Digest them with enzymes\n   - Form pus (dead WBCs + bacteria)\n\n2. Antibody production:\n   - B-lymphocytes produce antibodies\n   - Antibodies neutralize pathogens\n   - Mark them for destruction\n\n3. Cell-mediated immunity:\n   - T-lymphocytes kill infected cells\n   - Attack virus-infected cells\n   - Destroy cancer cells\n\n4. Allergic reactions:\n   - Basophils and eosinophils involved\n   - Release histamine\n\n5. Inflammation:\n   - Release chemicals that cause inflammation\n   - Increases blood flow to infected area\n   - Attracts more WBCs\n\n6. Memory:\n   - Some lymphocytes become memory cells\n   - Provide faster response to repeat infection\n\nWBC count indicates health:\n- High count (leukocytosis): Infection, inflammation\n- Very high count (leukemia): Blood cancer\n- Low count (leukopenia): Immunodeficiency\n\nThus, WBCs are essential for body's defence and immunity."
        },
        {
            "type": "subjective",
            "q": "Explain the structure and function of blood platelets.",
            "sample": "Blood platelets (thrombocytes) are tiny, disc-shaped cell fragments essential for blood clotting.\n\nStructure of platelets:\n\n1. Size and shape:\n   - Smallest blood cells (2-4 micrometres)\n   - Disc-shaped or oval\n   - No nucleus\n   - Colourless\n\n2. Origin:\n   - Formed from megakaryocytes in bone marrow\n   - Megakaryocytes fragment into thousands of platelets\n   - Released into blood\n\n3. Number:\n   - 200,000 to 400,000 per mm³ of blood\n   - Count varies with health\n\n4. Life span:\n   - About 3-7 days\n   - Constantly replaced\n   - Old platelets destroyed in spleen\n\n5. Contents:\n   - Contain granules with clotting factors\n   - Contain contractile proteins\n   - Have surface receptors for adhesion\n\nFunctions of platelets:\n\n1. Blood clotting (haemostasis):\n   - Primary function\n   - Prevent blood loss from injured vessels\n\nSteps in blood clotting:\n\nA. Platelet plug formation:\n   - Platelets adhere to exposed collagen at injury site\n   - Change shape (become spiky with pseudopods)\n   - Release chemicals (ADP, thromboxane)\n   - Attract more platelets (platelet aggregation)\n   - Form temporary platelet plug\n\nB. Coagulation (clotting):\n   - Platelets release clotting factors\n   - Activate clotting cascade\n   - Prothrombin → Thrombin\n   - Thrombin converts fibrinogen → fibrin\n   - Fibrin forms mesh that traps RBCs\n   - Forms stable clot\n\nC. Clot retraction:\n   - Platelet contractile proteins pull clot\n   - Squeezes out serum\n   - Brings wound edges together\n\nD. Clot dissolution:\n   - When healing complete, clot broken down\n   - Plasmin dissolves fibrin\n\n2. Vasoconstriction:\n   - Release serotonin\n   - Causes blood vessels to constrict\n   - Reduces blood flow to injured area\n\n3. Repair:\n   - Release growth factors\n   - Promote healing of damaged vessels\n   - Stimulate tissue repair\n\n4. Protection:\n   - Prevent entry of pathogens through wounds\n   - Maintain blood vessel integrity\n\nDisorders related to platelets:\n\n1. Thrombocytopenia (low platelets):\n   - Causes easy bruising\n   - Prolonged bleeding\n   - Petechiae (tiny red spots)\n\n2. Thrombocytosis (high platelets):\n   - Risk of inappropriate clotting\n   - May cause thrombosis\n\n3. Platelet function disorders:\n   - Platelets present but not working\n   - Bleeding tendency\n\nImportance of normal platelet count:\n- Too few: Bleeding risk\n- Too many: Clotting risk\n- Normal range essential for health\n\nThus, platelets are crucial for preventing blood loss and maintaining circulatory integrity."
        },
        {
            "type": "subjective",
            "q": "Differentiate between red blood cells, white blood cells, and platelets.",
            "sample": "Comparison of the three types of blood cells:\n\n| Feature | Red Blood Cells (Erythrocytes) | White Blood Cells (Leucocytes) | Platelets (Thrombocytes) |\n|---------|-------------------------------|-------------------------------|-------------------------|\n| Other name | Erythrocytes | Leucocytes | Thrombocytes |\n| Number per mm³ | 5-6 million | 4000-13000 | 200,000-400,000 |\n| Size | 7-8 micrometres | 10-18 micrometres | 2-4 micrometres |\n| Shape | Biconcave disc | Irregular, changes shape | Disc-shaped |\n| Nucleus | Absent (in mature) | Present | Absent |\n| Colour | Red (haemoglobin) | Colourless | Colourless |\n| Haemoglobin | Present | Absent | Absent |\n| Life span | 120 days | 12 hours to 12 days | 3-7 days |\n| Production site | Bone marrow | Bone marrow, lymph nodes | Bone marrow |\n| Destruction site | Spleen, liver | Spleen, tissues | Spleen |\n| Movement | Flow with blood | Amoeboid movement, can leave vessels | Flow with blood |\n| Main function | Oxygen transport | Immunity, fight infection | Blood clotting |\n| Types | One type | Several types (neutrophils, lymphocytes, etc.) | One type |\n| Can divide | No | Some can | No (fragments of megakaryocytes) |\n| Granules | No | Yes (in granulocytes) | Yes (clotting factors) |\n| Response to infection | No change in count | Count increases | Count may change |\n| In pus | Not present | Present (dead neutrophils) | Sometimes present |\n| In clot formation | Trapped in clot | May be involved | Essential for clot |\n\nSimilarities:\n- All formed in bone marrow\n- All circulate in blood\n- All essential for life\n- All have limited life span\n- All affected by diseases\n\nRelative abundance:\n- RBCs most numerous (about 1000:1 compared to WBCs)\n- Platelets second most numerous\n- WBCs least numerous\n\nBlood volume proportions:\n- RBCs: about 40-45% of blood volume\n- WBCs and platelets: about 1% (buffy coat)\n- Plasma: 55-60%\n\nWhen each is important:\n- RBCs: For oxygen delivery to tissues\n- WBCs: During infection, inflammation\n- Platelets: After injury, to prevent bleeding\n\nDisorders specific to each:\n- RBCs: Anaemia, polycythemia\n- WBCs: Leukemia, leukopenia\n- Platelets: Thrombocytopenia, thrombocytosis\n\nThus, each cell type has unique features perfectly suited to its specific function."
        },
        {
            "type": "subjective",
            "q": "List the functions of blood in the human body.",
            "sample": "Blood performs numerous vital functions in the human body:\n\n1. Transportation of nutrients:\n   - Carries digested food from small intestine to all cells\n   - Transports glucose, amino acids, fatty acids, vitamins, minerals\n   - Delivers building materials for growth and repair\n\n2. Transportation of respiratory gases:\n   - Carries oxygen from lungs to all body cells (via haemoglobin in RBCs)\n   - Carries carbon dioxide from tissues back to lungs for elimination\n   - About 97% of oxygen transported by RBCs\n\n3. Transportation of waste products:\n   - Carries metabolic wastes (urea, uric acid, creatinine) to kidneys\n   - Wastes excreted in urine\n   - Prevents toxic accumulation\n\n4. Distribution of hormones:\n   - Carries hormones from endocrine glands to target organs\n   - Enables chemical coordination of body functions\n   - Examples: Insulin to cells, adrenaline in emergencies\n\n5. Protection of body:\n   - WBCs destroy pathogens (bacteria, viruses)\n   - Antibodies in plasma neutralize toxins\n   - Memory cells provide immunity\n   - Phagocytes engulf germs and debris\n\n6. Blood clotting:\n   - Platelets form plugs at injury sites\n   - Clotting factors in plasma form fibrin mesh\n   - Prevents excessive blood loss\n   - Allows wound healing\n\n7. Regulation of body temperature:\n   - Blood distributes heat throughout body\n   - Carries heat from active organs (muscles, liver) to skin\n   - Heat lost through skin surface\n   - Maintains constant 37°C body temperature\n\n8. Maintenance of salt and water balance:\n   - Plasma proteins maintain osmotic pressure\n   - Balances fluid between blood and tissues\n   - Prevents oedema (swelling)\n   - Helps kidneys regulate water and electrolytes\n\n9. Maintenance of pH balance:\n   - Blood buffers (bicarbonate, haemoglobin, proteins) maintain pH 7.35-7.45\n   - Prevents acidosis or alkalosis\n   - Essential for enzyme function\n\n10. Communication:\n    - Transports chemical signals\n    - Carries hormones, cytokines, inflammatory mediators\n    - Coordinates body's response to stress, infection\n\n11. Storage:\n    - Carries some substances in bound form\n    - Iron stored as ferritin (in liver)\n    - Some vitamins transported\n\n12. Defence against foreign materials:\n    - Phagocytosis of debris\n    - Removal of old/damaged cells\n    - Inflammatory response\n\n13. Circulation maintenance:\n    - Blood volume maintains blood pressure\n    - Ensures continuous flow to all organs\n    - Prevents shock\n\nThus, blood is truly the 'river of life', essential for nearly all bodily functions."
        },
        {
            "type": "subjective",
            "q": "Explain the ABO blood group system. What are the four blood groups?",
            "sample": "The ABO blood group system, discovered by Karl Landsteiner, classifies human blood based on antigens present on red blood cells and antibodies in plasma.\n\nBasic concepts:\n- Antigens: Proteins on RBC surface (type A or B)\n- Antibodies: Proteins in plasma that react with foreign antigens\n- If incompatible blood is mixed, antibodies cause clumping (agglutination)\n\nFour blood groups:\n\n1. Blood group A:\n   - Antigen on RBC: A antigen\n   - Antibody in plasma: Anti-B antibody\n   - Can receive blood from: A and O\n   - Can donate blood to: A and AB\n   - Frequency: About 40% (varies by population)\n\n2. Blood group B:\n   - Antigen on RBC: B antigen\n   - Antibody in plasma: Anti-A antibody\n   - Can receive blood from: B and O\n   - Can donate blood to: B and AB\n   - Frequency: About 10%\n\n3. Blood group AB:\n   - Antigen on RBC: Both A and B antigens\n   - Antibody in plasma: No antibodies\n   - Can receive blood from: A, B, AB, and O (universal recipient)\n   - Can donate blood to: AB only\n   - Frequency: About 4%\n\n4. Blood group O:\n   - Antigen on RBC: No A or B antigens\n   - Antibody in plasma: Both anti-A and anti-B antibodies\n   - Can receive blood from: O only\n   - Can donate blood to: A, B, AB, and O (universal donor)\n   - Frequency: About 46%\n\nBlood transfusion compatibility:\n\n| Blood group | Can receive from | Can donate to |\n|-------------|------------------|---------------|\n| A | A, O | A, AB |\n| B | B, O | B, AB |\n| AB | A, B, AB, O (universal recipient) | AB |\n| O | O only | A, B, AB, O (universal donor) |\n\nWhy O is universal donor:\n- No A or B antigens on RBCs\n- Donor RBCs won't react with recipient's antibodies\n- But antibodies in donor plasma may cause minor reaction (washed RBCs used)\n\nWhy AB is universal recipient:\n- No anti-A or anti-B antibodies in plasma\n- Can receive any RBC type without reaction\n- But can only donate to AB\n\nAgglutination reaction:\n- If wrong blood type given:\n  * Recipient's antibodies attack donor RBCs\n  * RBCs clump together (agglutination)\n  * Clumps block blood vessels\n  * Haemoglobin released (haemolysis)\n  * Can cause kidney failure, shock, death\n\nImportance of blood typing:\n- Essential before transfusion\n- Prevents fatal reactions\n- Used in organ transplantation\n- Important in pregnancy (Rh factor)\n- Forensic medicine (blood at crime scenes)\n\nThus, ABO system ensures safe blood transfusion when properly matched."
        },
        {
            "type": "subjective",
            "q": "What is Rh-factor? Explain its importance in blood transfusion and pregnancy.",
            "sample": "Rh-factor (Rhesus factor) is an antigen present on the surface of red blood cells, first discovered in Rhesus monkeys.\n\nRh status:\n- Rh-positive: Have Rh antigen on RBCs (about 85% of people)\n- Rh-negative: Do not have Rh antigen (about 15%)\n- No natural antibodies against Rh in plasma (unlike ABO system)\n\nInheritance:\n- Rh-positive is dominant (Rh+ gene from either parent)\n- Rh-negative is recessive (needs two Rh- genes)\n- Child's Rh status depends on parents\n\nImportance in blood transfusion:\n\n1. First exposure:\n   - If Rh-negative person receives Rh-positive blood\n   - No immediate reaction (no pre-existing antibodies)\n   - But person becomes sensitized\n   - Develops anti-Rh antibodies\n\n2. Subsequent exposure:\n   - If same person receives Rh-positive blood again\n   - Anti-Rh antibodies attack donor RBCs\n   - Causes transfusion reaction\n   - Can be severe\n\n3. Compatibility:\n   - Rh-negative should receive Rh-negative blood\n   - Rh-positive can receive Rh-positive or Rh-negative\n   - But Rh-negative blood preferred for Rh-negative\n\nImportance in pregnancy:\n\n1. Rh incompatibility:\n   - Occurs when Rh-negative mother carries Rh-positive baby\n   - Father is Rh-positive\n   - Baby inherits Rh-positive from father\n\n2. Sensitization:\n   - During delivery, some baby's blood enters mother's circulation\n   - Mother's immune system develops anti-Rh antibodies\n   - Usually not a problem in first pregnancy\n\n3. Effect on subsequent pregnancies:\n   - In next pregnancy with Rh-positive baby\n   - Mother's anti-Rh antibodies cross placenta\n   - Attack baby's RBCs\n   - Causes haemolytic disease of newborn (HDN)\n   - Baby becomes anaemic, jaundiced\n   - Severe cases: brain damage, stillbirth\n\n4. Prevention:\n   - Anti-D immunoglobulin (RhoGAM) given to Rh-negative mother\n   - Given at 28 weeks pregnancy\n   - Given within 72 hours after delivery\n   - Also after miscarriage, abortion, amniocentesis\n   - Prevents mother from developing antibodies\n   - Protects future pregnancies\n\n5. Treatment of affected baby:\n   - Phototherapy for jaundice\n   - Exchange transfusion in severe cases\n   - Intrauterine transfusion for severe anaemia\n\nTesting for Rh-factor:\n- Simple blood test\n- Done routinely in pregnancy\n- Done before blood transfusion\n- Part of routine blood typing\n\nSummary table:\n\n| Situation | Compatibility |\n|-----------|---------------|\n| Blood transfusion | Rh-negative → Rh-negative preferred |\n| | Rh-positive → Rh-positive or Rh-negative |\n| Pregnancy (first) | Usually safe regardless |\n| Pregnancy (later with incompatibility) | Risk of HDN if mother sensitized |\n| Prevention | Anti-D immunoglobulin |\n\nThus, Rh-factor is crucial for safe transfusion and healthy pregnancies."
        },
        {
            "type": "subjective",
            "q": "Differentiate between arteries and veins.",
            "sample": "Arteries and veins are the two main types of blood vessels with distinct structures and functions.\n\n| Characteristic | Arteries | Veins |\n|----------------|----------|-------|\n| Direction of blood flow | Carry blood away from heart | Carry blood towards heart |\n| Blood type | Usually oxygenated (except pulmonary artery) | Usually deoxygenated (except pulmonary veins) |\n| Wall thickness | Thick, elastic, muscular | Thin, less muscular |\n| Lumen (cavity) | Narrow | Wide |\n| Valves | Absent | Present (to prevent backflow) |\n| Blood pressure | High, pulsatile | Low, steady |\n| Blood flow | Fast, with jerks | Slow, smooth |\n| Position in body | Deep-seated (for protection) | Superficial (closer to skin) |\n| Cross-section shape | Round (maintains shape) | Flatten when empty |\n| Ability to stretch | Highly elastic (withstand pressure) | Less elastic |\n| Pulse | Palpable | Not palpable |\n| Colour in diagrams | Usually red (oxygenated) | Usually blue (deoxygenated) |\n| Oxygen content | High (except pulmonary) | Low (except pulmonary) |\n| Carbon dioxide content | Low (except pulmonary) | High (except pulmonary) |\n| Major examples | Aorta, pulmonary artery | Vena cava, pulmonary veins |\n| Branching | Divide into smaller arteries (arterioles) | Formed from smaller veins (venules) |\n| Effect of gravity | Less affected | Affected (need valves in legs) |\n| Nutrient supply | Have their own vessels (vasa vasorum) in outer layer | Have vasa vasorum |\n| Tissue layers | Three layers: tunica intima, media, adventitia | Same three but thinner media |\n| Smooth muscle | Prominent in media | Sparse in media |\n| Elastic tissue | Abundant | Sparse |\n\nSimilarities:\n- Both are blood vessels\n- Both have three-layered walls\n- Both lined with endothelium\n- Both transport blood\n- Both can be affected by diseases\n\nExceptions to remember:\n- Pulmonary artery carries deoxygenated blood (only artery with impure blood)\n- Pulmonary veins carry oxygenated blood (only veins with pure blood)\n- Umbilical vessels in fetus have different patterns\n\nWhy arteries have thick walls:\n- Must withstand high pressure from heart pump\n- Need elasticity to expand with each heartbeat\n- Prevent bursting under pressure\n\nWhy veins have valves:\n- Low pressure cannot push blood upward against gravity\n- Valves prevent backflow in legs\n- Muscular contraction helps push blood\n\nClinical significance:\n- Arterial disease: Atherosclerosis (plaque buildup)\n- Arterial pulse: Used to measure heart rate\n- Venous disease: Varicose veins (valve failure)\n- Veins used for blood draw (superficial, lower pressure)\n\nThus, structure of each vessel type perfectly suits its function."
        },
        {
            "type": "subjective",
            "q": "Describe the structure and function of capillaries.",
            "sample": "Capillaries are the smallest and most numerous blood vessels that connect arteries to veins, forming networks throughout tissues.\n\nStructure of capillaries:\n\n1. Size:\n   - Extremely narrow (5-10 micrometres diameter)\n   - Just wide enough for RBCs to pass single file\n   - Length: about 0.5-1 mm each\n   - Total length in body: about 100,000 km!\n\n2. Wall thickness:\n   - Extremely thin (one cell thick)\n   - Single layer of endothelial cells\n   - No muscle or elastic tissue\n   - About 0.5 micrometres thick\n\n3. Basement membrane:\n   - Thin layer surrounding endothelium\n   - Provides support\n\n4. Pericytes:\n   - Cells wrapped around capillaries\n   - Help regulate blood flow\n   - Aid in repair\n\n5. Types of capillaries:\n   - Continuous: Most common, continuous lining\n   - Fenestrated: Have pores (in kidneys, intestines)\n   - Sinusoidal: Larger gaps (in liver, spleen)\n\n6. Network:\n   - Form capillary beds between arterioles and venules\n   - Dense networks in active tissues\n   - Precapillary sphincters control flow\n\nFunctions of capillaries:\n\n1. Exchange of materials (main function):\n   - Site of all exchange between blood and tissues\n   - Thin walls allow diffusion\n   - Slow blood flow allows time for exchange\n\n2. Oxygen delivery:\n   - Oxygen diffuses from RBCs to tissue cells\n   - Driven by concentration gradient\n   - Tissues have low O₂, blood has high O₂\n\n3. Carbon dioxide removal:\n   - CO₂ diffuses from tissues into blood\n   - Carried away to lungs\n\n4. Nutrient delivery:\n   - Glucose, amino acids diffuse to cells\n   - Small enough to pass through\n\n5. Waste pickup:\n   - Metabolic wastes (urea) enter blood\n   - Taken to kidneys\n\n6. Fluid exchange:\n   - Fluid filters out at arterial end (due to pressure)\n   - Fluid reabsorbed at venous end (due to osmotic pressure)\n   - Lymphatic system collects excess\n\n7. Hormone delivery:\n   - Hormones reach target cells via capillaries\n   - Diffuse out to bind receptors\n\n8. Temperature regulation:\n   - Blood flow through skin capillaries regulates heat loss\n   - Vasodilation (widen) = more heat loss\n   - Vasoconstriction (narrow) = conserve heat\n\n9. Immune surveillance:\n   - WBCs can leave through capillary walls (diapedesis)\n   - Reach sites of infection\n\nAdaptations for exchange:\n\n1. Large surface area:\n   - Billions of capillaries\n   - Total surface area about 600-1000 m²\n\n2. Slow blood flow:\n   - Blood slows down in capillaries\n   - More time for exchange\n\n3. Short diffusion distance:\n   - Wall one cell thick\n   - Cells close to capillaries\n\n4. Large number:\n   - Every cell near a capillary\n   - No cell more than 0.1 mm from capillary\n\nRegulation of capillary flow:\n- Precapillary sphincters open/close\n- Local factors (O₂, CO₂, pH) control flow\n- Active tissues get more blood\n\nThus, capillaries are the functional units of the circulatory system, where the real work of nutrient and gas exchange occurs."
        },
        {
            "type": "subjective",
            "q": "Explain the pulmonary circulation and systemic circulation.",
            "sample": "Blood circulates twice through the heart in one complete circuit - this is called double circulation, consisting of pulmonary and systemic circulation.\n\nPulmonary circulation (Heart → Lungs → Heart):\n\nDefinition: Circulation of blood between heart and lungs for oxygenation.\n\nPathway:\n1. Deoxygenated (impure) blood from body enters right atrium\n2. Right atrium → Right ventricle (through tricuspid valve)\n3. Right ventricle pumps blood to lungs through pulmonary artery\n4. Pulmonary artery divides into left and right branches to each lung\n5. In lung capillaries:\n   - CO₂ released from blood\n   - O₂ absorbed into blood\n   - Blood becomes oxygenated (pure)\n6. Oxygenated blood returns to heart through pulmonary veins\n7. Pulmonary veins enter left atrium\n\nFeatures:\n- Short circuit (only through lungs)\n- Low pressure (right ventricle thinner)\n- Only place where artery carries deoxygenated blood (pulmonary artery)\n- Only place where vein carries oxygenated blood (pulmonary veins)\n\nSystemic circulation (Heart → Body → Heart):\n\nDefinition: Circulation of blood between heart and all body tissues except lungs.\n\nPathway:\n1. Oxygenated blood from lungs enters left atrium\n2. Left atrium → Left ventricle (through bicuspid/mitral valve)\n3. Left ventricle pumps blood to body through aorta\n4. Aorta branches into arteries to all body parts\n5. Arteries → Arterioles → Capillaries in tissues:\n   - O₂ and nutrients delivered to cells\n   - CO₂ and wastes picked up\n   - Blood becomes deoxygenated (impure)\n6. Capillaries → Venules → Veins\n7. Veins collect into superior and inferior vena cava\n8. Venae cavae return blood to right atrium\n\nFeatures:\n- Long circuit (entire body)\n- High pressure (left ventricle thick-walled)\n- Supplies all organs and tissues\n\nComparison:\n\n| Feature | Pulmonary Circulation | Systemic Circulation |\n|---------|----------------------|---------------------|\n| Path | Heart → Lungs → Heart | Heart → Body → Heart |\n| Vessels involved | Pulmonary artery, pulmonary veins | Aorta, arteries, veins, vena cava |\n| Blood type in arteries | Deoxygenated | Oxygenated |\n| Blood type in veins | Oxygenated | Deoxygenated |\n| Pressure | Low (20-30 mmHg) | High (120/80 mmHg) |\n| Ventricle involved | Right ventricle | Left ventricle |\n| Ventricle wall | Thinner | Thicker |\n| Purpose | Gas exchange in lungs | Supply all tissues |\n| Distance | Short | Long |\n| Oxygenation | Blood becomes oxygenated | Blood becomes deoxygenated |\n| CO₂ removal | Yes, in lungs | No (picked up from tissues) |\n\nDouble circulation advantage:\n- Complete separation of oxygenated and deoxygenated blood\n- Higher pressure for systemic circulation\n- Efficient oxygen delivery\n- Maintains high metabolic rate\n\n[Students should draw a schematic diagram showing both circuits with heart, lungs, and body]"
        },
        {
            "type": "subjective",
            "q": "Describe the structure of the human heart with a labeled diagram.",
            "sample": "The heart is a pear-shaped muscular organ that pumps blood throughout the body.\n\nLocation and size:\n- Located in chest cavity, slightly towards left\n- Protected by rib cage\n- Size of a clenched fist (about 12 cm long, 9 cm wide)\n- Weighs about 250-350 grams\n\nExternal structure:\n\n1. Pericardium:\n   - Double-layered membrane enclosing heart\n   - Space between layers filled with pericardial fluid\n   - Fluid reduces friction during heartbeats\n\n2. Heart wall:\n   - Made of cardiac muscle (myocardium)\n   - Works tirelessly without fatigue\n   - Thickest in left ventricle\n\n3. Chambers (4):\n   - Two upper: Atria (auricles) - thin-walled\n   - Two lower: Ventricles - thick-walled\n\n4. Major blood vessels:\n   - Superior vena cava (brings blood from upper body)\n   - Inferior vena cava (brings blood from lower body)\n   - Pulmonary artery (takes blood to lungs)\n   - Pulmonary veins (bring blood from lungs)\n   - Aorta (takes blood to body)\n\nInternal structure:\n\n1. Right atrium:\n   - Receives deoxygenated blood from body via venae cavae\n   - Thin-walled\n   - Pumps blood to right ventricle\n\n2. Right ventricle:\n   - Receives blood from right atrium\n   - Pumps deoxygenated blood to lungs via pulmonary artery\n   - Wall thicker than atria, thinner than left ventricle\n\n3. Left atrium:\n   - Receives oxygenated blood from lungs via pulmonary veins\n   - Thin-walled\n   - Pumps blood to left ventricle\n\n4. Left ventricle:\n   - Receives blood from left atrium\n   - Thickest chamber (pumps to entire body)\n   - Pumps oxygenated blood to body via aorta\n\n5. Septum:\n   - Thick muscular wall dividing heart into left and right\n   - Prevents mixing of oxygenated and deoxygenated blood\n\nValves of the heart:\n\n6. Tricuspid valve:\n   - Between right atrium and right ventricle\n   - Three flaps (cusps)\n   - Prevents backflow into atrium\n\n7. Bicuspid (mitral) valve:\n   - Between left atrium and left ventricle\n   - Two flaps\n   - Prevents backflow into atrium\n\n8. Pulmonary semilunar valve:\n   - At exit of right ventricle into pulmonary artery\n   - Three half-moon shaped cusps\n   - Prevents backflow into ventricle\n\n9. Aortic semilunar valve:\n   - At exit of left ventricle into aorta\n   - Three cusps\n   - Prevents backflow into ventricle\n\nChordae tendineae:\n- Tendinous cords attaching valves to papillary muscles\n- Prevent valve inversion during ventricular contraction\n\nBlood flow through heart:\nBody → Venae cavae → Right atrium → Tricuspid valve → Right ventricle → Pulmonary valve → Pulmonary artery → Lungs → Pulmonary veins → Left atrium → Bicuspid valve → Left ventricle → Aortic valve → Aorta → Body\n\n[Students should draw a labeled diagram showing all chambers, valves, and major vessels]"
        },
        {
            "type": "subjective",
            "q": "Explain the flow of blood through the heart.",
            "sample": "Blood flows through the heart in a specific sequence, ensured by valves that prevent backflow.\n\nStep-by-step flow of blood:\n\nA. Deoxygenated blood returns to heart:\n\n1. Deoxygenated (impure) blood from all body parts collects into:\n   - Superior vena cava (from head, neck, arms, upper body)\n   - Inferior vena cava (from trunk, legs, lower body)\n\n2. Both venae cavae empty into right atrium\n   - Right atrium fills with deoxygenated blood\n\nB. Blood moves to right ventricle:\n\n3. Right atrium contracts (atrial systole)\n   - Tricuspid valve opens\n   - Blood flows into right ventricle\n\n4. Right ventricle fills\n   - Tricuspid valve closes after filling (prevents backflow)\n\nC. Blood pumped to lungs:\n\n5. Right ventricle contracts (ventricular systole)\n   - Pulmonary semilunar valve opens\n   - Blood pumped into pulmonary artery\n   - Pulmonary artery carries blood to lungs\n\n6. In lungs:\n   - Blood passes through lung capillaries\n   - CO₂ released, O₂ absorbed\n   - Blood becomes oxygenated (pure)\n\nD. Oxygenated blood returns to heart:\n\n7. Oxygenated blood returns via pulmonary veins\n   - Four pulmonary veins (two from each lung)\n   - Empty into left atrium\n\nE. Blood moves to left ventricle:\n\n8. Left atrium contracts\n   - Bicuspid (mitral) valve opens\n   - Blood flows into left ventricle\n\n9. Left ventricle fills\n   - Bicuspid valve closes after filling\n\nF. Blood pumped to body:\n\n10. Left ventricle contracts (powerful contraction)\n    - Aortic semilunar valve opens\n    - Blood pumped into aorta\n    - Aorta distributes blood to all body parts\n\n11. In body tissues:\n    - Oxygen and nutrients delivered\n    - CO₂ and wastes picked up\n    - Blood becomes deoxygenated again\n    - Cycle repeats\n\nSummary flow chart:\n\nBody → Venae cavae → Right atrium → Tricuspid valve → Right ventricle → Pulmonary valve → Pulmonary artery → Lungs (oxygenation) → Pulmonary veins → Left atrium → Bicuspid valve → Left ventricle → Aortic valve → Aorta → Body\n\nValve functions:\n- Tricuspid: Prevents backflow from right ventricle to right atrium\n- Bicuspid: Prevents backflow from left ventricle to left atrium\n- Pulmonary: Prevents backflow from pulmonary artery to right ventricle\n- Aortic: Prevents backflow from aorta to left ventricle\n\nTiming of events:\n- Atrial contraction: Both atria contract together\n- Ventricular contraction: Both ventricles contract together\n- Valves open/close based on pressure differences\n\nKey points:\n- Right side handles deoxygenated blood\n- Left side handles oxygenated blood\n- Septum prevents mixing\n- Valves ensure one-way flow\n- Left ventricle works hardest (pumps to entire body)\n\nThus, the heart's structure ensures efficient, one-way circulation of blood."
        },
        {
            "type": "subjective",
            "q": "What are heart valves? Name them and explain their functions.",
            "sample": "Heart valves are flap-like structures that ensure one-way flow of blood through the heart, preventing backflow.\n\nTypes of heart valves:\n\nA. Atrioventricular valves (between atria and ventricles):\n\n1. Tricuspid valve:\n   - Location: Between right atrium and right ventricle\n   - Structure: Three flaps or cusps\n   - Attached to papillary muscles by chordae tendineae\n   - Function: Prevents backflow of blood from right ventricle to right atrium during ventricular contraction\n\n2. Bicuspid (Mitral) valve:\n   - Location: Between left atrium and left ventricle\n   - Structure: Two flaps\n   - Also attached to chordae tendineae\n   - Function: Prevents backflow from left ventricle to left atrium\n   - Named 'mitral' because it resembles bishop's mitre (hat)\n\nB. Semilunar valves (at exits of ventricles):\n\n3. Pulmonary valve:\n   - Location: At exit of right ventricle into pulmonary artery\n   - Structure: Three half-moon shaped cusps\n   - No chordae tendineae\n   - Function: Prevents backflow of blood from pulmonary artery into right ventricle during ventricular relaxation\n\n4. Aortic valve:\n   - Location: At exit of left ventricle into aorta\n   - Structure: Three cusps (semilunar)\n   - Function: Prevents backflow from aorta into left ventricle\n\nSupporting structures:\n\nChordae tendineae:\n- Fibrous cords attached to valve flaps\n- Connect to papillary muscles in ventricles\n- Prevent valves from inverting into atria during ventricular contraction\n\nPapillary muscles:\n- Projections from ventricular wall\n- Contract during ventricular systole\n- Pull chordae tendineae to keep valves closed\n\nHow valves work:\n\nDuring atrial contraction (atrial systole):\n- Atrioventricular valves open\n- Blood flows from atria to ventricles\n- Semilunar valves closed (ventricles not contracting)\n\nDuring ventricular contraction (ventricular systole):\n- Pressure in ventricles rises\n- Atrioventricular valves close (prevent backflow to atria)\n- Chordae tendineae prevent valve inversion\n- Semilunar valves open\n- Blood ejected into arteries\n\nDuring ventricular relaxation (diastole):\n- Pressure in ventricles drops\n- Semilunar valves close (prevent backflow from arteries)\n- Atrioventricular valves open\n- Ventricles fill again\n\nHeart sounds:\n- 'Lub' sound: Closure of atrioventricular valves\n- 'Dub' sound: Closure of semilunar valves\n- Heard with stethoscope\n\nValve disorders:\n\n1. Stenosis:\n   - Valve opening narrowed\n   - Heart works harder to pump blood\n   - May need surgery\n\n2. Regurgitation/Incompetence:\n   - Valve doesn't close properly\n   - Blood leaks backward\n   - Causes heart murmur\n\n3. Prolapse:\n   - Valve flaps bulge backward\n   - May cause leakage\n\nTreatment:\n- Medications\n- Valve repair\n- Valve replacement (mechanical or tissue valves)\n\nThus, valves are essential for efficient, one-way circulation of blood through the heart."
        },
        {
            "type": "subjective",
            "q": "What is heartbeat? Explain the cardiac cycle.",
            "sample": "Heartbeat is the rhythmic contraction and relaxation of the heart muscles that pumps blood through the circulatory system.\n\nHeartbeat:\n- About 72 times per minute in resting adult\n- Faster in children, during exercise, emotion\n- Slower in athletes, during sleep\n- Each heartbeat = one cardiac cycle\n\nCardiac cycle:\nThe sequence of events in one complete heartbeat, lasting about 0.8 seconds.\n\nPhases of cardiac cycle:\n\n1. Atrial systole (0.1 seconds):\n   - Both atria contract simultaneously\n   - Blood forced into ventricles through open AV valves\n   - Ventricles already 70% filled from passive flow\n   - Atrial contraction adds final 30%\n   - AV valves open, semilunar valves closed\n\n2. Ventricular systole (0.3 seconds):\n   - Both ventricles contract\n   - Pressure in ventricles rises\n   - AV valves snap shut (prevents backflow to atria)\n   - Isovolumetric contraction (all valves closed, pressure rises)\n   - When ventricular pressure exceeds arterial pressure:\n     * Semilunar valves open\n     * Blood ejected into aorta and pulmonary artery\n   - Atria relax and start filling again\n\n3. Complete cardiac diastole (0.4 seconds):\n   - Both atria and ventricles relaxed\n   - Ventricular pressure drops below atrial\n   - Semilunar valves close (prevents backflow from arteries)\n   - AV valves open\n   - Ventricles fill passively from atria (70% filling)\n   - Cycle ready to repeat\n\nSummary of cardiac cycle:\n\n| Phase | Duration | Atria | Ventricles | AV valves | Semilunar valves | Blood flow |\n|-------|----------|-------|------------|-----------|------------------|------------|\n| Atrial systole | 0.1 sec | Contract | Relaxed | Open | Closed | Atria → Ventricles |\n| Ventricular systole | 0.3 sec | Relaxed | Contract | Closed | Open | Ventricles → Arteries |\n| Diastole | 0.4 sec | Relaxed | Relaxed | Open | Closed | Veins → Atria → Ventricles |\n\nTotal cycle: 0.1 + 0.3 + 0.4 = 0.8 seconds\n\nHeart sounds:\n\nFirst sound 'LUB':\n- Caused by closure of AV valves (tricuspid and bicuspid)\n- Occurs at beginning of ventricular systole\n- Longer, louder sound\n\nSecond sound 'DUB':\n- Caused by closure of semilunar valves (aortic and pulmonary)\n- Occurs at beginning of ventricular diastole\n- Shorter, sharper sound\n\nPressure changes:\n- Left ventricle: 120 mmHg (systole), 0-10 mmHg (diastole)\n- Aorta: 120/80 mmHg\n- Right ventricle: 25 mmHg (systole)\n- Pulmonary artery: 25/10 mmHg\n\nElectrical events:\n- SA node (pacemaker) initiates impulse\n- Spreads through atria → atrial contraction\n- AV node delays impulse\n- Conducts to ventricles via bundle of His\n- Ventricles contract from apex upward\n\nRegulation of heart rate:\n- Autonomic nervous system\n  * Sympathetic: Increases rate\n  * Parasympathetic: Decreases rate\n- Hormones (adrenaline)\n- Body temperature\n- Ions (Ca²⁺, K⁺)\n\nThus, the cardiac cycle ensures efficient, coordinated pumping of blood."
        },
        {
            "type": "subjective",
            "q": "What is pulse? How do you measure it?",
            "sample": "Pulse is the rhythmic expansion and contraction of an artery caused by the wave of pressure from each heartbeat.\n\nWhat causes pulse:\n- When left ventricle contracts (systole)\n- Blood forced into aorta under high pressure\n- Pressure wave travels along arteries\n- Arteries expand with each wave\n- Expansion felt as pulse\n- Between beats, arteries recoil\n\nCharacteristics of normal pulse:\n- Rate: 70-75 per minute in resting adult\n- Rhythm: Regular\n- Volume: Adequate\n- Character: Strong\n\nPulse rate varies with:\n- Age: Infants 100-160, children 70-120, adults 70-75\n- Gender: Slightly faster in females\n- Exercise: Increases\n- Emotions: Increases (fear, excitement)\n- Fever: Increases\n- Sleep: Decreases\n- Fitness: Athletes have slower resting pulse\n\nWhere to feel pulse:\n\nCommon sites (superficial arteries):\n\n1. Radial pulse (most common):\n   - At wrist, just below thumb\n   - Radial artery\n   - Easy to access\n\n2. Carotid pulse:\n   - At side of neck\n   - Carotid artery\n   - Strong pulse, used in emergencies\n\n3. Brachial pulse:\n   - Inner side of elbow\n   - Used for blood pressure measurement\n\n4. Temporal pulse:\n   - At temple, in front of ear\n\n5. Femoral pulse:\n   - In groin area\n\n6. Popliteal pulse:\n   - Behind knee\n\n7. Dorsalis pedis pulse:\n   - On top of foot\n\nHow to measure pulse:\n\nMaterials needed:\n- Stopwatch or clock with second hand\n- Your fingers (index and middle)\n\nProcedure:\n\n1. Find a quiet place, person should be relaxed\n\n2. Locate pulse site (radial is easiest):\n   - Turn hand palm up\n   - Place index and middle fingers on wrist below thumb\n   - Press gently until you feel pulse\n   - Do not use thumb (has its own pulse)\n\n3. Count beats:\n   - Count for 30 seconds\n   - Multiply by 2 for beats per minute\n   - Or count for full minute for accuracy\n\n4. Note regularity:\n   - Regular rhythm is normal\n   - Irregular rhythm may indicate problem\n\n5. Record:\n   - Rate: ___ beats per minute\n   - Rhythm: Regular/Irregular\n   - Character: Strong/Weak\n\n6. Repeat after exercise:\n   - Have person exercise (jog in place)\n   - Measure again immediately\n   - Note increase\n\nNormal pulse rates:\n\n| Age | Normal range (beats/min) |\n|-----|--------------------------|\n| Newborn | 100-160 |\n| 1-12 months | 80-140 |\n| 1-3 years | 80-130 |\n| 3-5 years | 80-120 |\n| 6-10 years | 70-110 |\n| 11-14 years | 60-105 |\n| Adults | 60-100 (typically 70-75) |\n| Athletes | 40-60 |\n\nAbnormal pulse:\n\nTachycardia: Rate > 100/min (resting)\n- Causes: Exercise, fever, anxiety, dehydration, heart conditions\n\nBradycardia: Rate < 60/min (resting)\n- Causes: Athletic training, hypothyroidism, heart block\n\nArrhythmia: Irregular rhythm\n- May indicate heart condition\n\nPulse deficit:\n- Difference between apical (heart) and peripheral pulse\n- May indicate inefficient heart contractions\n\nThus, pulse is a simple but important indicator of heart function and overall health."
        },
        {
            "type": "subjective",
            "q": "What is blood pressure? Explain systolic and diastolic pressure.",
            "sample": "Blood pressure is the force exerted by blood against the walls of arteries as the heart pumps it through the circulatory system.\n\nDefinition:\nBlood pressure = Cardiac output × Peripheral resistance\n\nMeasurement:\n- Measured in millimetres of mercury (mmHg)\n- Measured with sphygmomanometer\n- Two numbers recorded: Systolic/Diastolic\n- Normal adult: 120/80 mmHg\n\nSystolic pressure (upper number):\n\nDefinition:\n- Pressure in arteries when ventricles contract (systole)\n- Maximum pressure during cardiac cycle\n\nWhat happens:\n- Left ventricle contracts\n- Blood ejected into aorta\n- Arterial walls stretch to accommodate blood\n- Pressure peaks\n\nNormal range:\n- 100-140 mmHg (ideally around 120)\n- Varies with age, activity\n\nFactors affecting systolic pressure:\n- Force of ventricular contraction\n- Volume of blood ejected (stroke volume)\n- Elasticity of aorta\n- Age (increases with age as arteries stiffen)\n\nDiastolic pressure (lower number):\n\nDefinition:\n- Pressure in arteries when ventricles relax (diastole)\n- Minimum pressure during cardiac cycle\n- Maintained by elastic recoil of arteries\n\nWhat happens:\n- Ventricles relax\n- No blood pumped out\n- Arteries recoil, maintaining pressure\n- Blood continues to flow to tissues\n\nNormal range:\n- 60-90 mmHg (ideally around 80)\n- More stable than systolic\n\nFactors affecting diastolic pressure:\n- Peripheral resistance (arteriole diameter)\n- Elasticity of arteries\n- Blood volume\n- Heart rate (filling time)\n\nPulse pressure:\n- Difference between systolic and diastolic\n- Normal: 40 mmHg (120-80 = 40)\n- Indicates stroke volume and arterial compliance\n\nMean arterial pressure (MAP):\n- Average pressure driving blood to tissues\n- MAP = Diastolic + 1/3 (Systolic - Diastolic)\n- Normal: about 93 mmHg\n- Must be >60 for organ perfusion\n\nBlood pressure categories (adults):\n\n| Category | Systolic (mmHg) | Diastolic (mmHg) |\n|----------|-----------------|------------------|\n| Normal | <120 | <80 |\n| Elevated | 120-129 | <80 |\n| Hypertension Stage 1 | 130-139 | 80-89 |\n| Hypertension Stage 2 | ≥140 | ≥90 |\n| Hypertensive crisis | >180 | >120 |\n| Hypotension | <90 | <60 |\n\nFactors affecting blood pressure:\n\n1. Cardiac output:\n   - Increased heart rate = increased BP\n   - Increased stroke volume = increased BP\n\n2. Peripheral resistance:\n   - Vasoconstriction = increased BP\n   - Vasodilation = decreased BP\n\n3. Blood volume:\n   - Increased volume = increased BP\n   - Dehydration = decreased BP\n\n4. Blood viscosity:\n   - Thicker blood = higher BP\n\n5. Elasticity of arteries:\n   - Stiff arteries = higher BP (especially systolic)\n\n6. Age:\n   - BP tends to increase with age\n\n7. Emotions:\n   - Stress, anxiety increase BP\n\n8. Activity:\n   - Exercise increases BP temporarily\n\n9. Body position:\n   - Standing vs lying affects BP\n\n10. Time of day:\n    - Lowest during sleep, peaks in morning\n\nMeasurement technique:\n- Patient seated, arm at heart level\n- Cuff placed around arm\n- Inflate until artery compressed\n- Release slowly, listen with stethoscope\n- First sound heard = systolic\n- Last sound heard = diastolic\n\nThus, blood pressure is a vital sign indicating cardiovascular health."
        },
        {
            "type": "subjective",
            "q": "How can we keep our heart healthy? Suggest lifestyle and dietary measures.",
            "sample": "Keeping the heart healthy requires a combination of regular exercise, healthy diet, and good lifestyle habits.\n\nRegular physical activity:\n\n1. Aerobic exercise:\n   - Brisk walking (30 minutes daily)\n   - Jogging, running\n   - Swimming\n   - Cycling\n   - Dancing\n   - Benefits: Strengthens heart, lowers BP, improves cholesterol\n\n2. Strength training:\n   - Moderate weight training\n   - Builds muscle, improves metabolism\n   - 2-3 times per week\n\n3. Flexibility exercises:\n   - Stretching\n   - Yoga\n   - Improves circulation, reduces stress\n\n4. Daily activity:\n   - Take stairs instead of elevator\n   - Walk short distances instead of driving\n   - Garden, play with children\n   - Stand instead of sitting\n\nHealthy diet:\n\n5. Eat more fruits and vegetables:\n   - At least 5 servings daily\n   - Rich in vitamins, minerals, antioxidants\n   - Low in calories, high in fiber\n\n6. Choose whole grains:\n   - Whole wheat bread, brown rice\n   - Oats, quinoa, barley\n   - High fiber, lower cholesterol\n\n7. Include lean proteins:\n   - Fish (especially fatty fish like salmon)\n   - Skinless poultry\n   - Legumes, beans, lentils\n   - Nuts and seeds\n\n8. Healthy fats:\n   - Use olive oil, canola oil\n   - Avocados\n   - Nuts and seeds\n   - Limit saturated fats (red meat, butter)\n   - Avoid trans fats (fried foods, processed snacks)\n\n9. Limit salt intake:\n   - <5-6 grams per day\n   - Avoid processed foods\n   - Don't add salt at table\n   - Use herbs and spices for flavour\n\n10. Limit sugar:\n    - Reduce sugary drinks\n    - Limit sweets, desserts\n    - Choose water over soda\n\n11. Maintain healthy weight:\n    - BMI between 18.5-24.9\n    - Waist circumference: <90 cm (men), <80 cm (women)\n    - Prevents diabetes, hypertension\n\nLifestyle habits:\n\n12. No smoking:\n    - Smoking damages arteries\n    - Increases heart attack risk\n    - Quitting reduces risk rapidly\n\n13. Limit alcohol:\n    - Moderate: 1 drink/day (women), 2 drinks/day (men)\n    - Excessive alcohol damages heart\n\n14. Manage stress:\n    - Practice relaxation techniques\n    - Deep breathing, meditation\n    - Adequate sleep (7-8 hours)\n    - Hobbies, social connections\n\n15. Regular health checkups:\n    - Check blood pressure\n    - Check cholesterol levels\n    - Check blood sugar\n    - Detect problems early\n\n16. Know your numbers:\n    - Blood pressure: <120/80\n    - Total cholesterol: <200 mg/dL\n    - LDL (bad) cholesterol: <100 mg/dL\n    - HDL (good) cholesterol: >40 mg/dL (men), >50 mg/dL (women)\n    - Triglycerides: <150 mg/dL\n    - Blood sugar: <100 mg/dL fasting\n\n17. Take prescribed medications:\n    - If you have high BP, cholesterol, diabetes\n    - Take as directed\n    - Don't stop without consulting doctor\n\nWarning signs of heart problems:\n- Chest pain or discomfort\n- Shortness of breath\n- Pain in arm, jaw, back\n- Dizziness, lightheadedness\n- Irregular heartbeat\n- Swelling in legs, ankles\n- Seek medical help immediately\n\nFoods to limit/avoid:\n- Red meat (beef, pork, lamb)\n- Processed meats (bacon, sausage, ham)\n- Fried foods\n- Full-fat dairy\n- Bakery items (cookies, cakes, pastries)\n- Sugary drinks\n- Fast food\n- Excess salt\n\nHeart-healthy eating pattern:\n- Mediterranean diet\n- DASH diet (Dietary Approaches to Stop Hypertension)\n- Plant-based diets\n\nThus, heart health is largely within our control through daily choices."
        },
        {
            "type": "subjective",
            "q": "What is a stethoscope? How does it work?",
            "sample": "A stethoscope is a medical instrument used to listen to internal sounds of the body, especially heart and lung sounds.\n\nHistory:\n- Invented by René Laennec in 1816\n- Originally a rolled paper tube\n- Named from Greek: stethos (chest) + skopein (to examine)\n\nParts of a stethoscope:\n\n1. Chest piece (head):\n   - Contains diaphragm and/or bell\n   - Made of metal\n   - Placed on patient's body\n\n2. Diaphragm (flat side):\n   - Large flat disc\n   - Covered with thin plastic\n   - Picks up high-frequency sounds\n   - Used for: Heart sounds, lung sounds, bowel sounds\n\n3. Bell (cup-shaped side):\n   - Hollow cup\n   - Picks up low-frequency sounds\n   - Used for: Heart murmurs, bruits\n   - Requires light skin contact\n\n4. Tubing:\n   - Flexible rubber or vinyl tubes\n   - Conducts sound from chest piece to ears\n   - Usually double-lumen (two separate tubes)\n   - Length about 50-60 cm\n\n5. Ear tubes:\n   - Metal tubes connecting tubing to earpieces\n   - Angled to fit ear canals\n\n6. Earpieces:\n   - Soft tips that fit in ears\n   - Should seal well to block external noise\n   - Angled forward to match ear canal direction\n\n7. Spring:\n   - Metal piece connecting ear tubes\n   - Provides tension for comfortable fit\n\nHow a stethoscope works:\n\nPrinciple: Sound conduction through air in sealed tubes\n\n1. Sound production:\n   - Heartbeat creates vibrations\n   - Lungs create sounds during breathing\n   - Blood flow creates sounds in vessels\n\n2. Sound capture:\n   - Diaphragm or bell placed on skin\n   - Vibrations transmitted to air inside\n   - Diaphragm amplifies high frequencies\n   - Bell transmits low frequencies\n\n3. Sound transmission:\n   - Sound waves travel through air in tubing\n   - Minimal loss of energy\n   - Tubing sealed to prevent sound escape\n\n4. Sound delivery:\n   - Sound reaches earpieces\n   - Earpieces direct sound into ear canals\n   - Listener hears amplified internal sounds\n\nWhat can be heard:\n\nHeart sounds:\n- 'Lub-dub' normal heart sounds\n- Heart murmurs (abnormal flow)\n- Irregular rhythms\n- Valve problems\n\nLung sounds:\n- Normal breath sounds\n- Wheezing (asthma)\n- Crackles (pneumonia, fluid)\n- Absent sounds (collapse)\n\nBowel sounds:\n- Normal intestinal activity\n- Absent sounds (obstruction)\n- Hyperactive sounds (diarrhoea)\n\nBlood flow:\n- Bruits (turbulent flow in arteries)\n- In carotid, renal, femoral arteries\n\nBlood pressure measurement:\n- Used with sphygmomanometer\n- Listen for Korotkoff sounds\n- First sound = systolic pressure\n- Last sound = diastolic pressure\n\nTypes of stethoscopes:\n\n1. Acoustic (most common):\n   - No electronics\n   - Relies on sound conduction\n   - Affordable, durable\n\n2. Electronic:\n   - Amplifies sounds\n   - Can filter noise\n   - Can record sounds\n   - More expensive\n\n3. Fetal stethoscope (fetoscope):\n   - Used to hear fetal heartbeat\n   - Special design\n\n4. Doppler stethoscope:\n   - Uses ultrasound\n   - Detects blood flow\n   - Used for fetal heart, vascular exams\n\nCare of stethoscope:\n- Clean earpieces and diaphragm regularly\n- Avoid extreme temperatures\n- Don't bend tubing sharply\n- Store properly\n- Replace worn parts\n\nThus, the stethoscope is an essential diagnostic tool that allows doctors to 'hear' what's happening inside the body."
        },
        {
            "type": "subjective",
            "q": "What is a sphygmomanometer? How is blood pressure measured?",
            "sample": "A sphygmomanometer is a medical device used to measure blood pressure. The name comes from Greek: sphygmos (pulse) + manometer (pressure meter).\n\nTypes of sphygmomanometers:\n\n1. Mercury sphygmomanometer:\n   - Uses mercury column\n   - Most accurate, gold standard\n   - Being phased out due to mercury toxicity\n   - Reads in mmHg\n\n2. Aneroid sphygmomanometer:\n   - Uses mechanical gauge with dial\n   - No mercury\n   - Needs regular calibration\n   - Portable\n\n3. Digital/Electronic sphygmomanometer:\n   - Automatic inflation\n   - Digital display\n   - Easy to use at home\n   - May be less accurate\n\nParts of a sphygmomanometer:\n\n1. Cuff:\n   - Inflatable bladder inside cloth cover\n   - Wrapped around upper arm\n   - Various sizes (child, adult, large adult)\n   - Proper size essential for accuracy\n\n2. Inflation bulb:\n   - Rubber bulb with valve\n   - Used to pump air into cuff\n   - Valve controls release of air\n\n3. Pressure gauge:\n   - Mercury column or dial\n   - Shows pressure in mmHg\n   - Calibrated scale\n\n4. Tubing:\n   - Connects cuff to bulb and gauge\n\nMeasuring blood pressure (auscultatory method):\n\nEquipment needed:\n- Sphygmomanometer\n- Stethoscope\n- Patient resting comfortably\n\nProcedure:\n\nStep 1: Preparation\n- Patient seated, arm supported at heart level\n- No caffeine, smoking 30 minutes before\n- Rest for 5 minutes\n- Remove tight clothing from arm\n\nStep 2: Position cuff\n- Locate brachial artery (inner elbow)\n- Wrap cuff snugly around upper arm\n- Lower edge 2-3 cm above elbow crease\n- Center over brachial artery\n\nStep 3: Locate pulse\n- Palpate radial pulse at wrist\n- Inflate cuff while feeling pulse\n- Note pressure when pulse disappears\n- Deflate quickly\n- This estimates systolic pressure\n\nStep 4: Position stethoscope\n- Place stethoscope over brachial artery\n- Hold firmly but not too tight\n\nStep 5: Inflate cuff\n- Close valve on bulb\n- Inflate to 20-30 mmHg above estimated systolic\n- About 160-180 mmHg typically\n\nStep 6: Deflate slowly\n- Open valve slightly\n- Deflate at 2-3 mmHg per second\n- Listen carefully\n\nStep 7: Record systolic pressure\n- First sound heard (Korotkoff sound) = systolic\n- Sound is tapping, clear\n- Note pressure reading\n\nStep 8: Record diastolic pressure\n- Sounds become muffled then disappear\n- Point of disappearance = diastolic\n- Note pressure reading\n\nStep 9: Complete measurement\n- Continue deflating to zero\n- Remove cuff\n- Record as systolic/diastolic (e.g., 120/80)\n\nStep 10: Repeat if needed\n- Wait 1-2 minutes\n- Take second reading\n- Average if close\n\nKorotkoff sounds:\n\nPhase 1: First tapping sound (systolic)\nPhase 2: Swishing sound\nPhase 3: Crisper tapping\nPhase 4: Muffling\nPhase 5: Silence (diastolic)\n\nCommon errors in measurement:\n\n1. Cuff too small: Falsely high reading\n2. Cuff too large: Falsely low reading\n3. Arm not at heart level: Incorrect reading\n4. Deflating too fast: Inaccurate reading\n5. Talking during measurement: Increases BP\n6. Crossed legs: Increases BP\n7. Full bladder: Increases BP\n8. Recent exercise/smoking/caffeine: Increases BP\n\nHome BP monitoring tips:\n- Use validated device\n- Proper cuff size\n- Same time each day\n- Before medications\n- Empty bladder\n- Sit quietly 5 minutes before\n- Multiple readings, average\n- Keep log for doctor\n\nThus, accurate BP measurement is essential for diagnosing and managing hypertension."
        },
        {
            "type": "subjective",
            "q": "Why do veins have valves while arteries do not?",
            "sample": "Veins have valves while arteries do not because of differences in blood pressure, flow characteristics, and the need to overcome gravity.\n\nBlood pressure differences:\n\nArteries:\n- High pressure (about 120/80 mmHg in systemic arteries)\n- Pressure generated by heart pump\n- Blood flows with force\n- Pressure alone sufficient to push blood forward\n- No risk of backflow due to continuous forward pressure\n\nVeins:\n- Low pressure (about 2-10 mmHg)\n- Pressure drops after capillaries\n- By time blood reaches veins, pressure is very low\n- Not enough pressure to ensure forward flow\n- Especially in legs, must work against gravity\n\nWhy arteries don't need valves:\n\n1. High pressure:\n   - Heart generates enough force\n   - Blood always pushed forward\n   - Pressure pulse helps maintain flow\n\n2. Elastic walls:\n   - Arteries stretch and recoil\n   - Maintains pressure during diastole\n   - Continuous forward flow\n\n3. Position:\n   - Most arteries deep in body\n   - Protected from external compression\n   - Less affected by gravity\n\n4. Muscular walls:\n   - Can constrict and dilate\n   - Help regulate flow\n   - Maintain pressure\n\nWhy veins need valves:\n\n1. Low pressure:\n   - Insufficient to ensure forward flow\n   - Especially in veins against gravity (legs)\n\n2. Gravity:\n   - Blood must flow upward from legs to heart\n   - Without valves, blood would pool in feet\n\n3. Long distances:\n   - Leg veins long column of blood\n   - Pressure at bottom high due to gravity\n   - Valves break column into segments\n\n4. External compression:\n   - Veins squeezed by muscles during movement\n   - Valves ensure flow is toward heart\n   - Muscle pump works with valves\n\n5. Thin walls:\n   - Veins have thin walls, less muscle\n   - Cannot maintain pressure like arteries\n   - Need mechanical help from valves\n\nHow venous valves work:\n\nStructure:\n- Semilunar (half-moon shaped) folds of inner lining\n- Usually paired (two flaps)\n- Made of endothelium with fibrous tissue\n- Open toward heart, close away from heart\n\nMechanism:\n- Blood flowing toward heart pushes valves open\n- If blood tries to flow backward, valves fill with blood\n- Valve flaps meet, closing the lumen\n- Prevents backflow\n\nMuscle pump mechanism:\n1. Muscles contract during walking/exercise\n2. Compress veins\n3. Valves below contraction close (prevent backflow down)\n4. Valves above contraction open\n5. Blood squeezed upward toward heart\n6. When muscles relax, valves above close (prevent backflow)\n7. Valves below open, allowing more blood from below\n8. Cycle repeats with each step\n\nRespiratory pump:\n- Breathing creates pressure changes in chest\n- Inspiration decreases pressure in chest veins\n- Draws blood from abdominal veins\n- Valves ensure one-way flow\n\nConsequences of valve failure:\n\nVaricose veins:\n- Valves become incompetent (leaky)\n- Blood pools in veins\n- Veins become stretched, tortuous\n- Swelling, pain, heaviness in legs\n- More common in people who stand long hours\n\nVenous insufficiency:\n- Chronic valve failure\n- Blood pools in lower legs\n- Swelling (oedema)\n- Skin changes, ulcers\n\nDeep vein thrombosis risk:\n- Stagnant blood more likely to clot\n- Clots can travel to lungs (pulmonary embolism)\n\nThus, valves are essential adaptations in veins to ensure one-way blood flow back to heart against gravity."
        },
        {
            "type": "subjective",
            "q": "Describe an activity to measure pulse rate at rest and after exercise.",
            "sample": "Aim: To measure pulse rate at rest and after exercise, and observe the difference.\n\nMaterials required:\n- Stopwatch or clock with second hand\n- Partner to help\n- Comfortable clothing\n- Space for exercise\n\nProcedure:\n\nPart A: Measuring resting pulse\n\nStep 1: Prepare\n- Person should sit quietly for 5 minutes\n- Should be relaxed, not talking\n- Arm resting on table\n\nStep 2: Locate pulse\n- Turn hand palm up\n- Place index and middle fingers on wrist below thumb\n- Press gently until you feel pulse\n- Do not use thumb (has its own pulse)\n\nStep 3: Count beats\n- Once pulse is felt steadily, start stopwatch\n- Count beats for 30 seconds\n- Multiply by 2 for beats per minute\n- Or count for full 60 seconds for accuracy\n\nStep 4: Record\n- Resting pulse rate: _____ beats per minute\n- Note rhythm (regular/irregular)\n- Note character (strong/weak)\n\nPart B: Exercise\n\nStep 5: Perform exercise\n- Person jogs in place for 3-5 minutes\n- Or does jumping jacks\n- Or runs up and down stairs\n- Should exercise enough to breathe harder\n\nStep 6: Immediate post-exercise measurement\n- Immediately after stopping exercise\n- Find pulse again quickly\n- Count for 15 seconds\n- Multiply by 4 for beats per minute\n- (Because heart rate drops quickly after exercise)\n\nStep 7: Record\n- Exercise pulse rate: _____ beats per minute\n\nPart C: Recovery measurement\n\nStep 8: Measure recovery\n- Wait 2 minutes after exercise\n- Measure pulse again for 30 seconds\n- Multiply by 2\n\nStep 9: Wait another 2 minutes\n- Measure again\n- Continue until pulse returns to near resting rate\n\nObservations table:\n\n| Time | Pulse rate (beats/min) |\n|------|------------------------|\n| Resting | |\n| Immediately after exercise | |\n| 2 minutes after | |\n| 4 minutes after | |\n| 6 minutes after | |\n| Return to resting | |\n\nExpected results:\n- Resting pulse: 70-80 bpm (varies with age, fitness)\n- After exercise: Increases significantly (120-160 bpm)\n- Recovery: Gradually returns to resting\n- Fitter individuals recover faster\n\nCalculations:\n- Increase = Exercise rate - Resting rate\n- % increase = (Increase ÷ Resting rate) × 100\n- Recovery time = Time to return to resting\n\nInterpretation:\n\nNormal response:\n- Heart rate increases with exercise\n- Increase proportional to exercise intensity\n- Gradual return to resting (recovery)\n\nAbnormal responses:\n- Excessive increase (poor fitness)\n- Insufficient increase (heart problem, medications)\n- Very slow recovery (poor fitness)\n- Irregular rhythm during/after exercise\n\nFactors affecting pulse rate:\n- Age (younger = faster)\n- Gender (females slightly faster)\n- Fitness level (fitter = slower resting, faster recovery)\n- Emotions (stress increases rate)\n- Temperature (heat increases rate)\n- Medications (some slow heart rate)\n- Caffeine, nicotine increase rate\n\nConclusion:\n- Exercise increases heart rate to meet oxygen demand\n- Heart rate returns to normal as oxygen demand decreases\n- Regular exercise improves heart efficiency (lower resting rate, faster recovery)\n\nPrecautions:\n- Stop if feeling dizzy, chest pain, severe shortness of breath\n- Not suitable for people with certain heart conditions\n- Consult doctor before starting exercise program\n\nThis activity demonstrates how the heart responds to increased demand during exercise."
        },
        {
            "type": "subjective",
            "q": "What is the importance of iron in our diet? How is it related to blood?",
            "sample": "Iron is an essential mineral that plays a critical role in blood formation and oxygen transport throughout the body.\n\nWhat is iron?\n- Essential trace mineral\n- Required in small amounts (daily requirement: 8-18 mg)\n- Cannot be made by body, must come from diet\n- Stored in liver, spleen, bone marrow\n\nRole of iron in blood:\n\n1. Haemoglobin formation:\n   - Iron is core component of haemoglobin\n   - Each haemoglobin molecule has 4 iron atoms\n   - Iron binds oxygen reversibly\n   - Without iron, haemoglobin cannot form\n\n2. Oxygen transport:\n   - Iron in haemoglobin binds oxygen in lungs\n   - Forms oxyhaemoglobin\n   - Releases oxygen in tissues\n   - Enables all cells to receive oxygen\n\n3. Myoglobin:\n   - Iron-containing protein in muscles\n   - Stores oxygen in muscle cells\n   - Provides oxygen during intense activity\n\n4. RBC production:\n   - Iron essential for RBC formation in bone marrow\n   - Without iron, RBC production decreases\n\nIron deficiency effects on blood:\n\nIron deficiency anaemia:\n- Most common nutritional deficiency worldwide\n- Characterized by:\n  * Low haemoglobin levels\n  * Small, pale RBCs (microcytic, hypochromic)\n  * Reduced oxygen-carrying capacity\n\nSymptoms of iron deficiency anaemia:\n- Fatigue, weakness\n- Pale skin\n- Shortness of breath\n- Dizziness\n- Cold hands and feet\n- Brittle nails\n- Poor concentration\n- Restless legs\n- Pica (craving non-food items like ice, dirt)\n\nBlood tests for iron status:\n- Haemoglobin (Hb): Low in anaemia\n- Haematocrit (Hct): Low\n- RBC count: May be low\n- Serum iron: Low\n- Ferritin (storage iron): Low\n- Transferrin saturation: Low\n\nDaily iron requirements:\n\n| Group | Daily requirement |\n|-------|-------------------|\n| Infants (7-12 months) | 11 mg |\n| Children (1-3 years) | 7 mg |\n| Children (4-8 years) | 10 mg |\n| Children (9-13 years) | 8 mg |\n| Adolescent boys (14-18) | 11 mg |\n| Adolescent girls (14-18) | 15 mg |\n| Adult men | 8 mg |\n| Adult women (19-50) | 18 mg |\n| Pregnant women | 27 mg |\n| Lactating women | 9-10 mg |\n\nDietary sources of iron:\n\nHaem iron (better absorbed, 15-35%):\n- Red meat (beef, lamb)\n- Organ meats (liver, kidney)\n- Poultry (chicken, turkey)\n- Fish and shellfish\n\nNon-haem iron (less absorbed, 2-20%):\n- Dark leafy greens (spinach, kale)\n- Legumes (lentils, beans, chickpeas)\n- Fortified cereals\n- Nuts and seeds\n- Dried fruits (raisins, apricots)\n- Whole grains\n- Tofu\n- Blackstrap molasses\n\nFactors affecting iron absorption:\n\nEnhancers (increase absorption):\n- Vitamin C (citrus fruits, tomatoes, bell peppers)\n- Meat, fish, poultry (contain 'MFP factor')\n- Acidic foods\n- Cooking in cast iron pots\n\nInhibitors (decrease absorption):\n- Tannins in tea, coffee\n- Phytates in whole grains, legumes\n- Calcium in dairy\n- Oxalates in spinach\n- Antacids\n\nTips to improve iron absorption:\n- Eat iron foods with vitamin C (e.g., spinach with lemon)\n- Avoid tea/coffee with meals\n- Cook in iron pots\n- Combine haem and non-haem sources\n\nIron overload (haemochromatosis):\n- Too much iron can be toxic\n- Damages liver, heart, pancreas\n- Genetic condition\n- Treated by blood removal\n\nThus, iron is essential for healthy blood and preventing anaemia."
        },
        {
            "type": "subjective",
            "q": "Write a note on the discovery of blood groups by Karl Landsteiner.",
            "sample": "Karl Landsteiner (1868-1943) was an Austrian biologist and physician who discovered the ABO blood group system, revolutionizing blood transfusion medicine.\n\nEarly life and education:\n- Born in Vienna, Austria\n- Studied medicine at University of Vienna\n- Interested in chemistry and immunology\n- Worked at Vienna Pathological Institute\n\nBackground before discovery:\n- Blood transfusion often resulted in death\n- Doctors didn't know why some transfusions worked, others failed\n- Some patients had severe reactions, clumping of blood\n- Cause was unknown\n\nLandsteiner's key experiment (1900):\n\nHypothesis:\n- Blood of different people might have different properties\n- Mixing incompatible blood causes clumping (agglutination)\n\nMethod:\n- Collected blood samples from himself and colleagues\n- Separated red blood cells from serum\n- Mixed serum from one person with RBCs from another\n- Observed under microscope\n\nObservations:\n- Some mixtures showed clumping (agglutination)\n- Others remained smooth\n- Pattern emerged: People could be grouped\n\nDiscovery:\n- Identified three blood groups: A, B, and C (later called O)\n- Fourth group AB discovered later by colleagues\n- Named ABO system (A, B, AB, O)\n\nExplanation:\n- RBCs have antigens (A or B) on surface\n- Serum contains antibodies against opposite antigens\n- Incompatible mixing causes antibody-antigen reaction\n- Clumping blocks blood vessels, causes death\n\nPublication (1901):\n- Published findings in paper \"Agglutination phenomena of normal human blood\"\n- Showed that blood transfusions should match types\n- Explained why some transfusions succeeded, others failed\n\nLater discoveries:\n- 1902: Colleagues von Decastello and Sturli discovered AB group\n- 1930s: Landsteiner discovered Rh factor with Alexander Wiener\n- Rh named after Rhesus monkeys used in experiments\n\nImpact on medicine:\n\n1. Safe blood transfusion:\n   - Matching blood types before transfusion\n   - Prevents fatal reactions\n   - Enabled routine blood transfusion\n\n2. Blood banks:\n   - Blood could be stored and typed\n   - World War II: Saved countless lives\n   - Modern blood banking possible\n\n3. Organ transplantation:\n   - Blood typing essential for transplants\n   - Prevents rejection\n\n4. Forensic medicine:\n   - Blood typing at crime scenes\n   - Paternity testing\n\n5. Anthropology:\n   - Blood group distribution studied in populations\n   - Migration patterns traced\n\n6. Pregnancy:\n   - Rh incompatibility understood\n   - Prevention of haemolytic disease of newborn\n\nAwards and recognition:\n- 1930: Nobel Prize in Physiology or Medicine\n- For discovery of human blood groups\n- Lasker Award (1946, posthumous)\n\nLegacy:\n- Father of transfusion medicine\n- His birthday (June 14) is World Blood Donor Day\n- ABO system still used worldwide\n- Estimated 1 billion transfusions safely performed due to his work\n\nLater life:\n- Moved to USA (Rockefeller Institute)\n- Continued research on immunology\n- Worked on polio, discovered blood factors\n- Died 1943, but his work saves millions of lives annually\n\nThus, Landsteiner's simple but brilliant experiment transformed medicine and enabled safe blood transfusion."
        },
        {
            "type": "subjective",
            "q": "Explain why a person with blood group O is called a universal donor.",
            "sample": "A person with blood group O is called a universal donor because their red blood cells can be safely transfused to people of any ABO blood group.\n\nUnderstanding blood groups:\n\nBlood group antigens:\n- Type A: Has A antigen on RBCs\n- Type B: Has B antigen on RBCs\n- Type AB: Has both A and B antigens\n- Type O: Has neither A nor B antigens\n\nBlood group antibodies:\n- Type A: Has anti-B antibodies in plasma\n- Type B: Has anti-A antibodies in plasma\n- Type AB: Has no antibodies\n- Type O: Has both anti-A and anti-B antibodies\n\nTransfusion reaction:\n- If incompatible blood given:\n  * Recipient's antibodies attack donor's RBCs\n  * Causes agglutination (clumping)\n  * Blocks blood vessels\n  * Can cause kidney failure, shock, death\n\nWhy group O can donate to anyone:\n\n1. No antigens on RBCs:\n   - Group O RBCs have NO A or B antigens\n   - Therefore, they cannot be attacked by:\n     * Anti-A antibodies (in type B and O recipients)\n     * Anti-B antibodies (in type A and O recipients)\n   - RBCs are 'invisible' to recipient's immune system\n\n2. Safe for all recipients:\n   - Type A recipient: Anti-B antibodies (no B antigen in O blood)\n   - Type B recipient: Anti-A antibodies (no A antigen in O blood)\n   - Type AB recipient: No antibodies at all\n   - Type O recipient: Both antibodies, but O blood has no antigens\n\n3. RBCs only:\n   - In transfusion, packed RBCs are usually given\n   - Plasma (containing antibodies) is removed\n   - So donor antibodies don't affect recipient\n\nConsideration of antibodies in donor plasma:\n\nIf whole blood is given (not packed cells):\n- Group O blood contains anti-A and anti-B antibodies\n- These could attack recipient's RBCs if:\n  * Recipient is type A (has A antigens)\n  * Recipient is type B (has B antigens)\n  * Recipient is type AB (has both antigens)\n\nBut:\n- Donor antibodies get diluted in recipient's blood volume\n- Usually not a problem unless large volume given\n- Modern transfusion uses packed RBCs (plasma removed)\n- So group O packed RBCs are truly universal\n\nWhy other groups are not universal donors:\n\nGroup A:\n- Has A antigens on RBCs\n- Would be attacked by:\n  * Anti-A antibodies in type B recipients\n  * Anti-A antibodies in type O recipients\n- Can only donate to A and AB\n\nGroup B:\n- Has B antigens on RBCs\n- Would be attacked by:\n  * Anti-B antibodies in type A recipients\n  * Anti-B antibodies in type O recipients\n- Can only donate to B and AB\n\nGroup AB:\n- Has both A and B antigens\n- Would be attacked by both anti-A and anti-B antibodies\n- Can only donate to AB recipients\n\nUniversal recipient (group AB):\n- Has no antibodies in plasma\n- Can receive from any blood type\n- But can only donate to AB\n\nPractical applications:\n\nEmergency transfusions:\n- When blood type unknown\n- Group O negative blood used\n- 'Universal donor' saves lives in emergencies\n- Trauma, accidents, battlefield\n\nBlood banks:\n- Group O blood in high demand\n- Often in short supply\n- Donors encouraged to give regularly\n\nRh factor consideration:\n- O negative: Universal donor (no Rh antigen)\n- O positive: Can donate to Rh positive recipients only\n- O negative blood given to Rh negative or unknown\n\nSummary:\n\n| Blood group | Antigens on RBC | Antibodies in plasma | Can donate to | Can receive from |\n|-------------|-----------------|----------------------|---------------|------------------|\n| A | A | Anti-B | A, AB | A, O |\n| B | B | Anti-A | B, AB | B, O |\n| AB | A and B | None | AB | All (universal recipient) |\n| O | None | Anti-A and Anti-B | All (universal donor) | O |\n\nThus, group O is universal donor because their RBCs lack antigens that could trigger reactions in recipients."
        },
        {
            "type": "subjective",
            "q": "Draw a labeled diagram of the human heart showing all chambers and major blood vessels.",
            "sample": "The human heart is a four-chambered muscular organ that pumps blood throughout the body.\n\n[Students should draw a well-labeled diagram showing the following structures]\n\nExternal features to label:\n\n1. Right atrium:\n   - Upper right chamber\n   - Thin-walled\n   - Receives deoxygenated blood from body\n\n2. Right ventricle:\n   - Lower right chamber\n   - Thicker wall than atria\n   - Pumps blood to lungs\n\n3. Left atrium:\n   - Upper left chamber\n   - Thin-walled\n   - Receives oxygenated blood from lungs\n\n4. Left ventricle:\n   - Lower left chamber\n   - Thickest wall\n   - Pumps blood to body\n\n5. Superior vena cava:\n   - Large vein bringing blood from upper body\n   - Enters right atrium from above\n\n6. Inferior vena cava:\n   - Large vein bringing blood from lower body\n   - Enters right atrium from below\n\n7. Pulmonary artery:\n   - Takes blood from right ventricle to lungs\n   - Only artery carrying deoxygenated blood\n   - Branches to left and right lungs\n\n8. Pulmonary veins:\n   - Four veins (two from each lung)\n   - Bring oxygenated blood to left atrium\n   - Only veins carrying oxygenated blood\n\n9. Aorta:\n   - Largest artery\n   - Takes blood from left ventricle to body\n   - Arches then descends\n\n10. Coronary arteries:\n    - Supply blood to heart muscle itself\n    - Branch from aorta\n\nInternal structures to label:\n\n11. Tricuspid valve:\n    - Between right atrium and right ventricle\n    - Three flaps\n\n12. Bicuspid (mitral) valve:\n    - Between left atrium and left ventricle\n    - Two flaps\n\n13. Pulmonary semilunar valve:\n    - At exit of right ventricle into pulmonary artery\n    - Three half-moon shaped cusps\n\n14. Aortic semilunar valve:\n    - At exit of left ventricle into aorta\n    - Three cusps\n\n15. Chordae tendineae:\n    - Tendinous cords\n    - Attach valves to papillary muscles\n    - Prevent valve inversion\n\n16. Papillary muscles:\n    - Projections from ventricular wall\n    - Contract to pull chordae tendineae\n\n17. Septum:\n    - Muscular wall dividing left and right sides\n    - Prevents mixing of blood\n\n18. Pericardium:\n    - Double membrane covering heart\n    - Space with pericardial fluid\n\nDirection of blood flow (show with arrows):\n\nDeoxygenated blood (blue arrows):\nSuperior/Inferior vena cava → Right atrium → Tricuspid valve → Right ventricle → Pulmonary valve → Pulmonary artery → Lungs\n\nOxygenated blood (red arrows):\nPulmonary veins → Left atrium → Bicuspid valve → Left ventricle → Aortic valve → Aorta → Body\n\nKey features to emphasize:\n- Right side (blue) carries deoxygenated blood\n- Left side (red) carries oxygenated blood\n- Septum separates them\n- Valves ensure one-way flow\n- Left ventricle has thickest wall\n- Pulmonary vessels are exceptions (artery carries deoxygenated, veins carry oxygenated)\n\nColour coding:\n- Red: Oxygenated blood (left side, pulmonary veins, aorta)\n- Blue: Deoxygenated blood (right side, pulmonary artery, venae cavae)\n- Purple: Mixing (none - completely separated in healthy heart)\n\nLabel all parts clearly with leader lines.\n\nThis diagram helps visualize the heart's structure and understand how blood flows through it."
        }
    ],

#Biology — Grade 6 ICSE
#Chapter 7: Health and Hygiene
#Comprehensive Practice Questions
#50 MCQ • 50 True/False • 40 Subjective


    "Chapter 7 — Health and Hygiene": [
        # ===== MCQ (50 questions) =====
        {
            "type": "mcq",
            "q": "According to WHO, health is a state of complete physical, mental, and:",
            "options": [
                "Financial well-being",
                "Social well-being",
                "Educational well-being",
                "Spiritual well-being"
            ],
            "answer": "Social well-being",
            "explanation": "WHO defines health as 'a state of complete physical, mental and social well-being and not merely absence of disease'."
        },
        {
            "type": "mcq",
            "q": "Disease can be defined as:",
            "options": [
                "A state of complete well-being",
                "A deviation from normal state causing discomfort",
                "A state of fitness",
                "Absence of hunger"
            ],
            "answer": "A deviation from normal state causing discomfort",
            "explanation": "Disease is any physical or functional change from normal state that causes discomfort or affects health."
        },
        {
            "type": "mcq",
            "q": "Diseases present from birth are called:",
            "options": [
                "Acquired diseases",
                "Communicable diseases",
                "Congenital diseases",
                "Infectious diseases"
            ],
            "answer": "Congenital diseases",
            "explanation": "Congenital diseases are present from birth, caused by genetic abnormality or underdevelopment of organs."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a congenital disease?",
            "options": [
                "Cholera",
                "Colour-blindness",
                "Malaria",
                "Tuberculosis"
            ],
            "answer": "Colour-blindness",
            "explanation": "Colour-blindness is inherited from parents and present from birth, making it congenital."
        },
        {
            "type": "mcq",
            "q": "Haemophilia is also known as:",
            "options": [
                "Royal disease",
                "Common cold",
                "Fever",
                "Diabetes"
            ],
            "answer": "Royal disease",
            "explanation": "Haemophilia is called 'Royal disease' as Queen Victoria of England carried and passed the gene to descendants."
        },
        {
            "type": "mcq",
            "q": "Diseases that develop after birth are called:",
            "options": [
                "Congenital diseases",
                "Acquired diseases",
                "Hereditary diseases",
                "Genetic diseases"
            ],
            "answer": "Acquired diseases",
            "explanation": "Acquired diseases develop after birth and can be communicable or non-communicable."
        },
        {
            "type": "mcq",
            "q": "Diseases that can be passed from an infected person to a healthy person are called:",
            "options": [
                "Non-communicable diseases",
                "Congenital diseases",
                "Communicable diseases",
                "Hereditary diseases"
            ],
            "answer": "Communicable diseases",
            "explanation": "Communicable (infectious) diseases can be transmitted directly or indirectly from infected to healthy persons."
        },
        {
            "type": "mcq",
            "q": "Diseases that cannot be transmitted from one person to another are called:",
            "options": [
                "Communicable diseases",
                "Infectious diseases",
                "Non-communicable diseases",
                "Contagious diseases"
            ],
            "answer": "Non-communicable diseases",
            "explanation": "Non-communicable diseases are not caused by pathogens and cannot spread between people."
        },
        {
            "type": "mcq",
            "q": "Microorganisms that cause diseases are called:",
            "options": [
                "Antibodies",
                "Pathogens",
                "Vectors",
                "Vaccines"
            ],
            "answer": "Pathogens",
            "explanation": "Pathogens are disease-causing microorganisms like bacteria, viruses, fungi, and protozoa."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a bacterial disease?",
            "options": [
                "Measles",
                "Cholera",
                "Influenza",
                "Polio"
            ],
            "answer": "Cholera",
            "explanation": "Cholera is caused by bacterium Vibrio cholerae, while measles, influenza, and polio are viral diseases."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a viral disease?",
            "options": [
                "Tuberculosis",
                "Cholera",
                "Measles",
                "Tetanus"
            ],
            "answer": "Measles",
            "explanation": "Measles is caused by a virus; tuberculosis, cholera, and tetanus are bacterial diseases."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a protozoal disease?",
            "options": [
                "Ringworm",
                "Malaria",
                "Typhoid",
                "Diphtheria"
            ],
            "answer": "Malaria",
            "explanation": "Malaria is caused by protozoan Plasmodium; ringworm is fungal, typhoid and diphtheria are bacterial."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a fungal disease?",
            "options": [
                "Cholera",
                "Malaria",
                "Ringworm",
                "Polio"
            ],
            "answer": "Ringworm",
            "explanation": "Ringworm is a fungal infection of the skin; others are bacterial, protozoal, and viral respectively."
        },
        {
            "type": "mcq",
            "q": "Tuberculosis affects which part of the body?",
            "options": [
                "Intestine",
                "Lungs",
                "Liver",
                "Skin"
            ],
            "answer": "Lungs",
            "explanation": "Tuberculosis primarily affects the lungs, though it can affect other body parts."
        },
        {
            "type": "mcq",
            "q": "Typhoid spreads through:",
            "options": [
                "Air droplets",
                "Contaminated food and water",
                "Insect bite",
                "Direct contact"
            ],
            "answer": "Contaminated food and water",
            "explanation": "Typhoid spreads through contaminated food and water, or direct contact with infected faeces."
        },
        {
            "type": "mcq",
            "q": "Cholera causes:",
            "options": [
                "Cough and fever",
                "Acute diarrhoea and vomiting",
                "Skin rashes",
                "Paralysis"
            ],
            "answer": "Acute diarrhoea and vomiting",
            "explanation": "Cholera causes severe diarrhoea, vomiting, and dehydration due to bacterial infection."
        },
        {
            "type": "mcq",
            "q": "Botulism affects which body system?",
            "options": [
                "Digestive system",
                "Respiratory system",
                "Nervous system",
                "Circulatory system"
            ],
            "answer": "Nervous system",
            "explanation": "Botulism affects the nervous system, causing fatigue, dizziness, muscular weakness, and paralysis."
        },
        {
            "type": "mcq",
            "q": "Diphtheria affects the:",
            "options": [
                "Intestine",
                "Throat and upper trachea",
                "Skin",
                "Liver"
            ],
            "answer": "Throat and upper trachea",
            "explanation": "Diphtheria causes sore throat, pain, fever, and nasal discharge, affecting throat and upper trachea."
        },
        {
            "type": "mcq",
            "q": "Polio affects which body system?",
            "options": [
                "Digestive system",
                "Respiratory system",
                "Nervous system",
                "Circulatory system"
            ],
            "answer": "Nervous system",
            "explanation": "Polio attacks the nervous system, causing irreversible paralysis in limbs."
        },
        {
            "type": "mcq",
            "q": "Hepatitis affects which organ?",
            "options": [
                "Heart",
                "Lungs",
                "Liver",
                "Kidneys"
            ],
            "answer": "Liver",
            "explanation": "Hepatitis is inflammation of the liver, causing jaundice, fever, nausea, and pain in liver region."
        },
        {
            "type": "mcq",
            "q": "Chickenpox is characterized by:",
            "options": [
                "High fever only",
                "Itchy rashes with pink spots and blisters",
                "Persistent cough",
                "Joint pain"
            ],
            "answer": "Itchy rashes with pink spots and blisters",
            "explanation": "Chickenpox causes fever followed by itchy rashes with pink spots that become blisters and then scabs."
        },
        {
            "type": "mcq",
            "q": "Measles first shows:",
            "options": [
                "Red rashes all over body",
                "Small whitish spots on inner cheeks",
                "Blisters on skin",
                "Yellowing of eyes"
            ],
            "answer": "Small whitish spots on inner cheeks",
            "explanation": "Measles first shows small whitish spots on inner walls of cheeks before red rashes appear."
        },
        {
            "type": "mcq",
            "q": "Ringworm causes:",
            "options": [
                "Red, itchy, scaly patches",
                "High fever",
                "Vomiting",
                "Paralysis"
            ],
            "answer": "Red, itchy, scaly patches",
            "explanation": "Ringworm causes red, itchy, scaly patches that may develop blisters and resemble a ring."
        },
        {
            "type": "mcq",
            "q": "Diseases that spread through air are called:",
            "options": [
                "Waterborne diseases",
                "Vector-borne diseases",
                "Droplet infections",
                "Contagious diseases"
            ],
            "answer": "Droplet infections",
            "explanation": "Air-borne diseases spread through droplets from coughs and sneezes, e.g., cold, influenza, tuberculosis."
        },
        {
            "type": "mcq",
            "q": "Diseases that spread through contaminated water are called:",
            "options": [
                "Air-borne diseases",
                "Waterborne diseases",
                "Vector-borne diseases",
                "Contagious diseases"
            ],
            "answer": "Waterborne diseases",
            "explanation": "Waterborne diseases like cholera and typhoid spread through contaminated drinking water."
        },
        {
            "type": "mcq",
            "q": "Insects and animals that carry disease-causing germs are called:",
            "options": [
                "Pathogens",
                "Vectors",
                "Hosts",
                "Carriers"
            ],
            "answer": "Vectors",
            "explanation": "Vectors like mosquitoes, flies, rats carry and transmit disease-causing germs."
        },
        {
            "type": "mcq",
            "q": "Malaria is caused by the bite of:",
            "options": [
                "Male Anopheles mosquito",
                "Female Anopheles mosquito",
                "Housefly",
                "Rat flea"
            ],
            "answer": "Female Anopheles mosquito",
            "explanation": "Female Anopheles mosquito transmits Plasmodium protozoan causing malaria."
        },
        {
            "type": "mcq",
            "q": "Dengue is spread by:",
            "options": [
                "Anopheles mosquito",
                "Aedes mosquito",
                "Culex mosquito",
                "Housefly"
            ],
            "answer": "Aedes mosquito",
            "explanation": "Aedes mosquito transmits dengue virus, causing high fever and haemorrhage."
        },
        {
            "type": "mcq",
            "q": "Plague is spread by:",
            "options": [
                "Mosquito",
                "Rat flea",
                "Housefly",
                "Tse-tse fly"
            ],
            "answer": "Rat flea",
            "explanation": "Rat flea transmits Yersinia pestis bacteria causing plague."
        },
        {
            "type": "mcq",
            "q": "Sleeping sickness is spread by:",
            "options": [
                "Mosquito",
                "Rat flea",
                "Tse-tse fly",
                "Housefly"
            ],
            "answer": "Tse-tse fly",
            "explanation": "Tse-tse fly transmits Trypanosoma protozoan causing sleeping sickness."
        },
        {
            "type": "mcq",
            "q": "Filariasis is caused by:",
            "options": [
                "Virus",
                "Bacteria",
                "Roundworm",
                "Protozoan"
            ],
            "answer": "Roundworm",
            "explanation": "Filariasis is caused by roundworm Wuchereria bancrofti transmitted by Culex mosquito."
        },
        {
            "type": "mcq",
            "q": "Diseases spread by direct contact are called:",
            "options": [
                "Air-borne diseases",
                "Waterborne diseases",
                "Contagious diseases",
                "Vector-borne diseases"
            ],
            "answer": "Contagious diseases",
            "explanation": "Contagious diseases like conjunctivitis and scabies spread through direct contact or sharing personal items."
        },
        {
            "type": "mcq",
            "q": "Scabies is caused by:",
            "options": [
                "Bacteria",
                "Virus",
                "Mite",
                "Fungus"
            ],
            "answer": "Mite",
            "explanation": "Scabies is caused by a tiny mite that burrows into skin, causing intense itching."
        },
        {
            "type": "mcq",
            "q": "BCG vaccine is for:",
            "options": [
                "Polio",
                "Tuberculosis",
                "Measles",
                "Tetanus"
            ],
            "answer": "Tuberculosis",
            "explanation": "BCG (Bacillus Calmette-Guérin) vaccine provides immunity against tuberculosis."
        },
        {
            "type": "mcq",
            "q": "DPT vaccine protects against:",
            "options": [
                "Diphtheria, Polio, Tetanus",
                "Diphtheria, Pertussis, Tetanus",
                "Diphtheria, Pertussis, Typhoid",
                "Diphtheria, Polio, Typhoid"
            ],
            "answer": "Diphtheria, Pertussis, Tetanus",
            "explanation": "DPT vaccine protects against Diphtheria, Pertussis (whooping cough), and Tetanus."
        },
        {
            "type": "mcq",
            "q": "MMR vaccine protects against:",
            "options": [
                "Measles, Mumps, Rubella",
                "Measles, Malaria, Rabies",
                "Mumps, Measles, Rickets",
                "Mumps, Malaria, Rubella"
            ],
            "answer": "Measles, Mumps, Rubella",
            "explanation": "MMR vaccine protects against Measles, Mumps, and Rubella (German measles)."
        },
        {
            "type": "mcq",
            "q": "Kwashiorkor is caused by deficiency of:",
            "options": [
                "Carbohydrates",
                "Fats",
                "Proteins",
                "Vitamins"
            ],
            "answer": "Proteins",
            "explanation": "Kwashiorkor is protein deficiency disease in young children, causing stunted growth and swollen belly."
        },
        {
            "type": "mcq",
            "q": "Marasmus is caused by deficiency of:",
            "options": [
                "Proteins only",
                "Carbohydrates only",
                "Proteins and carbohydrates",
                "Fats only"
            ],
            "answer": "Proteins and carbohydrates",
            "explanation": "Marasmus occurs due to deficiency of both proteins and carbohydrates in children under one year."
        },
        {
            "type": "mcq",
            "q": "Night blindness is caused by deficiency of vitamin:",
            "options": [
                "A",
                "B",
                "C",
                "D"
            ],
            "answer": "A",
            "explanation": "Vitamin A deficiency causes night blindness, where person cannot see in dim light."
        },
        {
            "type": "mcq",
            "q": "Beriberi is caused by deficiency of vitamin:",
            "options": [
                "A",
                "B",
                "C",
                "D"
            ],
            "answer": "B",
            "explanation": "Vitamin B1 (thiamine) deficiency causes beriberi, affecting nerves and heart."
        },
        {
            "type": "mcq",
            "q": "Scurvy is caused by deficiency of vitamin:",
            "options": [
                "A",
                "B",
                "C",
                "D"
            ],
            "answer": "C",
            "explanation": "Vitamin C deficiency causes scurvy, with symptoms like bleeding gums and swollen joints."
        },
        {
            "type": "mcq",
            "q": "Rickets is caused by deficiency of vitamin:",
            "options": [
                "A",
                "B",
                "C",
                "D"
            ],
            "answer": "D",
            "explanation": "Vitamin D deficiency causes rickets, where bones become soft and bent."
        },
        {
            "type": "mcq",
            "q": "Goitre is caused by deficiency of:",
            "options": [
                "Iron",
                "Iodine",
                "Calcium",
                "Phosphorus"
            ],
            "answer": "Iodine",
            "explanation": "Iodine deficiency causes goitre - enlargement of thyroid gland in neck."
        },
        {
            "type": "mcq",
            "q": "Anaemia is caused by deficiency of:",
            "options": [
                "Iodine",
                "Calcium",
                "Iron",
                "Phosphorus"
            ],
            "answer": "Iron",
            "explanation": "Iron deficiency causes anaemia - low haemoglobin and reduced RBC count."
        },
        {
            "type": "mcq",
            "q": "Diabetes is caused by insufficient secretion of:",
            "options": [
                "Insulin",
                "Glucagon",
                "Adrenaline",
                "Thyroxine"
            ],
            "answer": "Insulin",
            "explanation": "Diabetes mellitus results from inadequate insulin production by pancreas, causing high blood sugar."
        },
        {
            "type": "mcq",
            "q": "Type 1 diabetes is also called:",
            "options": [
                "Insulin-dependent diabetes",
                "Non-insulin-dependent diabetes",
                "Gestational diabetes",
                "Diabetes insipidus"
            ],
            "answer": "Insulin-dependent diabetes",
            "explanation": "Type 1 diabetes requires insulin injections as pancreas produces little or no insulin."
        },
        {
            "type": "mcq",
            "q": "Arthritis is a disease of the:",
            "options": [
                "Bones",
                "Muscles",
                "Joints",
                "Nerves"
            ],
            "answer": "Joints",
            "explanation": "Arthritis causes inflammation, pain, and stiffness in joints."
        },
        {
            "type": "mcq",
            "q": "Osteoarthritis is caused by:",
            "options": [
                "Autoimmune reaction",
                "Breakdown of cartilage at joints",
                "Bacterial infection",
                "Viral infection"
            ],
            "answer": "Breakdown of cartilage at joints",
            "explanation": "Osteoarthritis results from degeneration of cartilage due to ageing, heredity, or injury."
        },
        {
            "type": "mcq",
            "q": "Cancer is:",
            "options": [
                "Controlled growth of cells",
                "Uncontrolled growth of abnormal cells",
                "Death of cells",
                "Inflammation of cells"
            ],
            "answer": "Uncontrolled growth of abnormal cells",
            "explanation": "Cancer involves uncontrolled division of abnormal cells that invade other tissues."
        },
        {
            "type": "mcq",
            "q": "Normal human body temperature is:",
            "options": [
                "37°C or 98.4°F",
                "40°C or 104°F",
                "35°C or 95°F",
                "42°C or 107.6°F"
            ],
            "answer": "37°C or 98.4°F",
            "explanation": "Normal body temperature is 37°C or 98.4°F; fever is rise above this."
        },
        
        # ===== True/False (50 questions) =====
        {
            "type": "tf",
            "q": "Health means only absence of disease.",
            "answer": "False",
            "explanation": "Health includes complete physical, mental, and social well-being, not just absence of disease."
        },
        {
            "type": "tf",
            "q": "Congenital diseases are present from birth.",
            "answer": "True",
            "explanation": "Congenital diseases are inherited or caused by underdevelopment at birth."
        },
        {
            "type": "tf",
            "q": "Haemophilia is an acquired disease.",
            "answer": "False",
            "explanation": "Haemophilia is a congenital (inherited) bleeding disorder."
        },
        {
            "type": "tf",
            "q": "Communicable diseases can be passed from one person to another.",
            "answer": "True",
            "explanation": "Communicable diseases spread through air, water, food, vectors, or direct contact."
        },
        {
            "type": "tf",
            "q": "Non-communicable diseases are caused by pathogens.",
            "answer": "False",
            "explanation": "Non-communicable diseases are not caused by pathogens but by deficiencies, organ malfunction, etc."
        },
        {
            "type": "tf",
            "q": "All bacteria are harmful and cause diseases.",
            "answer": "False",
            "explanation": "Many bacteria are beneficial (e.g., gut flora, in food production); only some are pathogenic."
        },
        {
            "type": "tf",
            "q": "Viruses can reproduce only inside living cells.",
            "answer": "True",
            "explanation": "Viruses are obligate parasites that need host cells to multiply."
        },
        {
            "type": "tf",
            "q": "Tuberculosis is caused by a virus.",
            "answer": "False",
            "explanation": "Tuberculosis is caused by bacterium Mycobacterium tuberculosis."
        },
        {
            "type": "tf",
            "q": "Polio causes irreversible paralysis.",
            "answer": "True",
            "explanation": "Polio virus attacks nervous system, causing permanent paralysis in limbs."
        },
        {
            "type": "tf",
            "q": "Chickenpox rashes appear as small whitish spots on inner cheeks first.",
            "answer": "False",
            "explanation": "That is measles; chickenpox has itchy rashes with pink spots and blisters."
        },
        {
            "type": "tf",
            "q": "Ringworm is caused by a bacterium.",
            "answer": "False",
            "explanation": "Ringworm is a fungal infection of the skin."
        },
        {
            "type": "tf",
            "q": "Droplet infection spreads through coughs and sneezes.",
            "answer": "True",
            "explanation": "Air-borne diseases spread via droplets from respiratory tract of infected person."
        },
        {
            "type": "tf",
            "q": "Cholera is a waterborne disease.",
            "answer": "True",
            "explanation": "Cholera spreads through contaminated drinking water."
        },
        {
            "type": "tf",
            "q": "Malaria is spread by male Anopheles mosquito.",
            "answer": "False",
            "explanation": "Female Anopheles mosquito transmits malaria; males don't bite."
        },
        {
            "type": "tf",
            "q": "Aedes mosquito spreads dengue and yellow fever.",
            "answer": "True",
            "explanation": "Aedes mosquito transmits viruses causing dengue and yellow fever."
        },
        {
            "type": "tf",
            "q": "Plague is spread by rat flea.",
            "answer": "True",
            "explanation": "Rat flea transmits Yersinia pestis bacteria causing plague."
        },
        {
            "type": "tf",
            "q": "Contagious diseases spread through direct contact.",
            "answer": "True",
            "explanation": "Contagious diseases like conjunctivitis spread by touching infected person or sharing items."
        },
        {
            "type": "tf",
            "q": "Vaccines are made from weakened or killed pathogens.",
            "answer": "True",
            "explanation": "Vaccines contain weakened or killed germs to stimulate immunity without causing disease."
        },
        {
            "type": "tf",
            "q": "BCG vaccine protects against polio.",
            "answer": "False",
            "explanation": "BCG protects against tuberculosis; polio has separate oral vaccine."
        },
        {
            "type": "tf",
            "q": "Kwashiorkor is caused by protein deficiency.",
            "answer": "True",
            "explanation": "Kwashiorkor results from protein deficiency in young children."
        },
        {
            "type": "tf",
            "q": "Marasmus occurs in children over 5 years.",
            "answer": "False",
            "explanation": "Marasmus affects children under one year due to protein-calorie deficiency."
        },
        {
            "type": "tf",
            "q": "Night blindness is caused by vitamin A deficiency.",
            "answer": "True",
            "explanation": "Vitamin A deficiency impairs vision in dim light (night blindness)."
        },
        {
            "type": "tf",
            "q": "Scurvy causes bleeding gums.",
            "answer": "True",
            "explanation": "Vitamin C deficiency causes scurvy with bleeding gums and swollen joints."
        },
        {
            "type": "tf",
            "q": "Rickets causes softening of bones.",
            "answer": "True",
            "explanation": "Vitamin D deficiency causes rickets with soft, bent bones."
        },
        {
            "type": "tf",
            "q": "Goitre is enlargement of thyroid gland.",
            "answer": "True",
            "explanation": "Iodine deficiency causes thyroid gland enlargement (goitre)."
        },
        {
            "type": "tf",
            "q": "Anaemia is caused by iodine deficiency.",
            "answer": "False",
            "explanation": "Anaemia is caused by iron deficiency; iodine deficiency causes goitre."
        },
        {
            "type": "tf",
            "q": "Diabetes is caused by insulin deficiency.",
            "answer": "True",
            "explanation": "Diabetes mellitus results from insufficient insulin production or ineffective use."
        },
        {
            "type": "tf",
            "q": "Type 2 diabetes is related to obesity and inactivity.",
            "answer": "True",
            "explanation": "Type 2 diabetes is often linked to lifestyle factors like obesity and physical inactivity."
        },
        {
            "type": "tf",
            "q": "Atherosclerosis is plaque buildup in arteries.",
            "answer": "True",
            "explanation": "Atherosclerosis involves fatty plaque deposition in artery walls, narrowing them."
        },
        {
            "type": "tf",
            "q": "Rheumatoid arthritis affects joints of fingers.",
            "answer": "True",
            "explanation": "Rheumatoid arthritis causes swelling, pain, and deformity in finger joints."
        },
        {
            "type": "tf",
            "q": "Osteoarthritis affects knees and hips.",
            "answer": "True",
            "explanation": "Osteoarthritis commonly affects weight-bearing joints like knees and hips."
        },
        {
            "type": "tf",
            "q": "Cancer is always caused by smoking.",
            "answer": "False",
            "explanation": "Cancer has many causes including genetics, radiation, chemicals, viruses; smoking is one risk factor."
        },
        {
            "type": "tf",
            "q": "Malignant tumor is cancerous growth.",
            "answer": "True",
            "explanation": "Malignant tumors are cancerous, invading nearby tissues and spreading."
        },
        {
            "type": "tf",
            "q": "Allergy is normal response to allergens.",
            "answer": "False",
            "explanation": "Allergy is an unusual hypersensitivity to normally harmless substances."
        },
        {
            "type": "tf",
            "q": "Fever itself is a disease.",
            "answer": "False",
            "explanation": "Fever is a symptom indicating disease or infection, not a disease itself."
        },
        {
            "type": "tf",
            "q": "Temperature above 105°F is dangerous.",
            "answer": "True",
            "explanation": "Very high fever (above 105°F) can be dangerous and requires medical attention."
        },
        {
            "type": "tf",
            "q": "Personal hygiene includes bathing regularly.",
            "answer": "True",
            "explanation": "Personal hygiene involves keeping body clean through regular bathing, clean clothes, etc."
        },
        {
            "type": "tf",
            "q": "Washing hands prevents infections.",
            "answer": "True",
            "explanation": "Hand washing removes germs and is most effective way to prevent infection spread."
        },
        {
            "type": "tf",
            "q": "Teeth should be brushed once daily.",
            "answer": "False",
            "explanation": "Teeth should be brushed twice daily (morning and before bed) for good oral hygiene."
        },
        {
            "type": "tf",
            "q": "Crunchy vegetables like carrot clean teeth naturally.",
            "answer": "True",
            "explanation": "Crunchy vegetables help scrub teeth and stimulate saliva production."
        },
        {
            "type": "tf",
            "q": "Myopia is difficulty seeing nearby objects.",
            "answer": "False",
            "explanation": "Myopia (nearsightedness) is difficulty seeing distant objects; hypermetropia is difficulty seeing nearby."
        },
        {
            "type": "tf",
            "q": "Reading in dim light harms eyes.",
            "answer": "True",
            "explanation": "Reading in dim light strains eyes and can cause headaches and fatigue."
        },
        {
            "type": "tf",
            "q": "Community hygiene is individual responsibility only.",
            "answer": "False",
            "explanation": "Community hygiene involves collective efforts and civic bodies for public health."
        },
        {
            "type": "tf",
            "q": "Boiling water kills germs.",
            "answer": "True",
            "explanation": "Boiling water for 15 minutes kills most disease-causing microorganisms."
        },
        {
            "type": "tf",
            "q": "Chlorine tablets purify water.",
            "answer": "True",
            "explanation": "Chlorine tablets kill microorganisms in water, making it safe for drinking."
        },
        {
            "type": "tf",
            "q": "Sedimentation removes suspended impurities.",
            "answer": "True",
            "explanation": "Sedimentation allows heavy particles to settle at bottom, clarifying water."
        },
        {
            "type": "tf",
            "q": "Composting uses microorganisms to decompose waste.",
            "answer": "True",
            "explanation": "Composting is natural decomposition of organic waste into manure by microorganisms."
        },
        {
            "type": "tf",
            "q": "Vermicomposting uses earthworms.",
            "answer": "True",
            "explanation": "Earthworms speed up decomposition in vermicomposting, producing nutrient-rich compost."
        },
        {
            "type": "tf",
            "q": "Sewage should flow directly into water bodies.",
            "answer": "False",
            "explanation": "Sewage must be treated before release to prevent water pollution and disease spread."
        },
        {
            "type": "tf",
            "q": "Garbage dumps should be away from human habitation.",
            "answer": "True",
            "explanation": "Proper disposal away from homes prevents disease spread and nuisance."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "Define health according to WHO. Explain the difference between congenital and acquired diseases with examples.",
            "sample": "According to WHO (World Health Organization), 'Health is a state of complete physical, mental and social well-being and not merely an absence of disease or infirmity.'\n\nThis means:\n- Physical well-being: Body functions properly, no illness\n- Mental well-being: Healthy mind, able to cope with stress\n- Social well-being: Good relationships, ability to function in society\n\nCongenital diseases:\n- Present from birth\n- Caused by genetic abnormalities or underdevelopment of organs\n- Cannot be transmitted to others\n- Examples:\n  * Colour-blindness: Inability to distinguish certain colours\n  * Thalassemia: Blood disorder affecting haemoglobin production\n  * Haemophilia: Bleeding disorder due to clotting factor deficiency\n\nAcquired diseases:\n- Develop after birth\n- Can be communicable or non-communicable\n- Examples:\n  * Communicable: Cholera, malaria, tuberculosis\n  * Non-communicable: Diabetes, heart disease, deficiency diseases\n\nKey difference:\nCongenital diseases are inherited or present at birth; acquired diseases develop during lifetime due to various factors."
        },
        {
            "type": "subjective",
            "q": "What are pathogens? Name the different types of pathogens with examples of diseases caused by each.",
            "sample": "Pathogens are disease-causing microorganisms that invade the body and cause infections.\n\nTypes of pathogens with examples:\n\n1. Bacteria:\n   - Single-celled organisms\n   - Diseases caused:\n     * Cholera: Vibrio cholerae (severe diarrhoea)\n     * Tuberculosis: Mycobacterium tuberculosis (lung infection)\n     * Typhoid: Salmonella typhi (fever, intestinal issues)\n     * Diphtheria: Corynebacterium diphtheriae (throat infection)\n     * Tetanus: Clostridium tetani (muscle stiffness)\n     * Plague: Yersinia pestis (spread by rat fleas)\n\n2. Viruses:\n   - Smaller than bacteria, need host cells to multiply\n   - Diseases caused:\n     * Measles: (rash, fever)\n     * Chickenpox: (itchy blisters)\n     * Polio: (paralysis)\n     * Hepatitis: (liver inflammation)\n     * Influenza: (flu)\n     * Common cold\n     * AIDS: (immune deficiency)\n     * Rabies: (fatal neurological disease)\n\n3. Fungi:\n   - Can cause skin infections\n   - Diseases caused:\n     * Ringworm: (circular itchy patches)\n     * Athlete's foot: (foot infection)\n     * Food poisoning (some fungi)\n\n4. Protozoa:\n   - Single-celled, more complex than bacteria\n   - Diseases caused:\n     * Malaria: Plasmodium (spread by mosquitoes)\n     * Amoebic dysentery: Entamoeba (diarrhoea)\n     * Sleeping sickness: Trypanosoma (spread by tse-tse fly)\n\n5. Worms (Helminths):\n   - Multicellular parasites\n   - Diseases caused:\n     * Filariasis (elephantiasis)\n     * Taeniasis (tapeworm infection)\n     * Ascariasis (roundworm)"
        },
        {
            "type": "subjective",
            "q": "Explain the different modes of transmission of communicable diseases with examples.",
            "sample": "Communicable diseases spread through various modes:\n\n1. Through air (Droplet infection):\n   - Germs released through coughs, sneezes, talking\n   - Inhaled by healthy persons\n   - Examples:\n     * Common cold\n     * Influenza\n     * Tuberculosis\n     * Measles\n     * Diphtheria\n\n2. Through water (Waterborne diseases):\n   - Contaminated drinking water\n   - Water contaminated with infected faeces\n   - Swimming in infected water\n   - Examples:\n     * Cholera\n     * Typhoid\n     * Dysentery\n     * Hepatitis A\n\n3. Through food (Food-borne diseases):\n   - Contaminated or improperly cooked food\n   - Food handled by infected persons\n   - Stale or spoiled food\n   - Examples:\n     * Food poisoning\n     * Botulism\n     * Typhoid\n\n4. Through vectors (Vector-borne diseases):\n   - Insects and animals carry germs\n   - Transfer through bites or contact\n   - Examples:\n     * Malaria (Anopheles mosquito)\n     * Dengue (Aedes mosquito)\n     * Plague (rat flea)\n     * Sleeping sickness (tse-tse fly)\n     * Filariasis (Culex mosquito)\n\n5. Through direct contact (Contagious diseases):\n   - Direct physical contact with infected person\n   - Sharing personal items (towels, combs, glasses)\n   - Examples:\n     * Conjunctivitis\n     * Scabies\n     * Ringworm\n     * Chickenpox\n     * Measles\n\n6. Through blood and body fluids:\n   - Blood transfusion with infected blood\n   - Sharing needles\n   - Mother to baby during pregnancy/birth\n   - Examples:\n     * Hepatitis B and C\n     * HIV/AIDS\n\nPrevention depends on understanding these transmission modes and taking appropriate precautions."
        },
        {
            "type": "subjective",
            "q": "What are vectors? Name five vector-borne diseases, their pathogens, and the vectors that transmit them.",
            "sample": "Vectors are insects and animals that carry disease-causing germs from infected to healthy persons without getting sick themselves.\n\nCommon vector-borne diseases:\n\n| Disease | Pathogen | Vector |\n|---------|----------|--------|\n| Malaria | Plasmodium (protozoan) | Female Anopheles mosquito |\n| Dengue | DENV virus | Aedes mosquito |\n| Yellow fever | Yellow fever virus | Aedes mosquito |\n| Chikungunya | CHIKV virus | Aedes mosquito |\n| Filariasis (Elephantiasis) | Wuchereria bancrofti (roundworm) | Culex mosquito |\n| Plague | Yersinia pestis (bacteria) | Rat flea |\n| Sleeping sickness | Trypanosoma (protozoan) | Tse-tse fly |\n| Typhus | Rickettsia bacteria | Louse, flea, mite |\n| Japanese encephalitis | JE virus | Culex mosquito |\n| Lyme disease | Borrelia bacteria | Tick |\n\nDetailed information on major vector-borne diseases:\n\n1. Malaria:\n   - Pathogen: Plasmodium protozoan\n   - Vector: Female Anopheles mosquito\n   - Symptoms: Periodic fever with chills, anaemia\n   - Prevention: Mosquito nets, repellents, eliminate breeding\n\n2. Dengue:\n   - Pathogen: Dengue virus\n   - Vector: Aedes mosquito (day-biting)\n   - Symptoms: High fever, severe joint pain, bleeding, drop in platelets\n   - Prevention: Prevent water stagnation, use repellents\n\n3. Filariasis:\n   - Pathogen: Wuchereria bancrofti (roundworm)\n   - Vector: Culex mosquito\n   - Symptoms: Swelling of limbs, genitals (elephantiasis)\n   - Prevention: Mosquito control, anti-helminthic drugs\n\n4. Plague:\n   - Pathogen: Yersinia pestis bacteria\n   - Vector: Rat flea (Xenopsylla cheopis)\n   - Symptoms: Swollen lymph nodes, fever, pneumonia\n   - Prevention: Rodent control, flea control\n\n5. Yellow fever:\n   - Pathogen: Yellow fever virus\n   - Vector: Aedes mosquito\n   - Symptoms: Fever, jaundice, vomiting\n   - Prevention: Vaccination, mosquito control\n\nControl of vectors:\n- Eliminate breeding sites (stagnant water)\n- Use mosquito nets and repellents\n- Insecticide spraying\n- Biological control (Gambusia fish eat mosquito larvae)\n- Proper waste management\n- Community participation"
        },
        {
            "type": "subjective",
            "q": "Differentiate between communicable and non-communicable diseases with examples.",
            "sample": "Differences between communicable and non-communicable diseases:\n\n| Aspect | Communicable Diseases | Non-communicable Diseases |\n|--------|----------------------|--------------------------|\n| Definition | Diseases that can spread from infected to healthy person | Diseases that cannot spread from person to person |\n| Cause | Pathogens (bacteria, viruses, fungi, protozoa, worms) | Deficiencies, organ malfunction, genetic factors, lifestyle, allergies |\n| Transmission | Through air, water, food, vectors, contact | Not transmitted |\n| Prevention | Hygiene, vaccination, vector control | Balanced diet, healthy lifestyle, regular checkups |\n| Treatment | Antibiotics, antivirals, antifungals | Diet management, medication, surgery, lifestyle changes |\n| Contagiousness | Highly contagious | Not contagious |\n| Onset | Often sudden | Often gradual |\n| Duration | Usually acute (short duration) | Often chronic (long duration) |\n| Examples | Cholera, TB, malaria, cold, flu | Diabetes, heart disease, cancer, arthritis |\n\nExamples of communicable diseases:\n1. Cholera: Bacterial, waterborne, causes severe diarrhoea\n2. Tuberculosis: Bacterial, airborne, affects lungs\n3. Malaria: Protozoal, mosquito-borne, causes fever with chills\n4. Measles: Viral, airborne, causes rash and fever\n5. Ringworm: Fungal, contact, causes itchy skin patches\n\nExamples of non-communicable diseases:\n1. Diabetes: Insulin deficiency or resistance\n2. Heart disease: Atherosclerosis, hypertension\n3. Cancer: Uncontrolled cell growth\n4. Arthritis: Joint inflammation\n5. Deficiency diseases: Scurvy (vitamin C), rickets (vitamin D)\n6. Allergies: Hypersensitivity to allergens\n\nBoth types require different approaches for prevention and management.\n\nSimilarities:\n- Both affect health and well-being\n- Both may require medical attention\n- Both can be prevented with appropriate measures\n- Both can be acute or chronic"
        },
        {
            "type": "subjective",
            "q": "Explain the importance of vaccination in preventing communicable diseases.",
            "sample": "Vaccination is one of the most effective methods to prevent communicable diseases by building immunity.\n\nWhat is a vaccine?\n- Biological preparation made from weakened or killed pathogens\n- Stimulates body's immune system\n- Creates memory cells without causing disease\n- Provides long-term protection\n\nHow vaccines work:\n\n1. Vaccine introduced into body:\n   - Contains antigens (weakened/killed germs)\n   - Safe, cannot cause disease\n\n2. Immune response:\n   - Body produces antibodies against antigens\n   - Creates memory B-cells and T-cells\n   - Builds immunity without suffering from disease\n\n3. Future exposure:\n   - If actual pathogen enters body\n   - Memory cells recognize it quickly\n   - Rapid antibody production\n   - Pathogen destroyed before causing illness\n\nTypes of vaccines:\n1. Killed/inactivated vaccines (polio injection)\n2. Live attenuated (weakened) vaccines (MMR, oral polio)\n3. Toxoid vaccines (tetanus, diphtheria)\n4. Subunit vaccines (Hepatitis B)\n5. mRNA vaccines (some COVID-19 vaccines)\n\nCommon vaccines and diseases prevented:\n\n| Vaccine | Diseases prevented |\n|---------|-------------------|\n| BCG | Tuberculosis |\n| DPT | Diphtheria, Pertussis, Tetanus |\n| MMR | Measles, Mumps, Rubella |\n| OPV/IPV | Polio |\n| Hepatitis B | Hepatitis B |\n| TT | Tetanus |\n| Typhoid | Typhoid fever |\n| Chickenpox | Varicella |\n| HPV | Cervical cancer |\n| COVID-19 | Coronavirus disease |\n\nBenefits of vaccination:\n\n1. Individual protection:\n   - Prevents serious illness\n   - Reduces complications\n   - Saves lives\n\n2. Herd immunity:\n   - When enough people vaccinated\n   - Protects vulnerable who cannot vaccinate\n   - Breaks disease transmission chain\n\n3. Disease eradication:\n   - Smallpox eradicated globally (1980)\n   - Polio nearly eradicated\n   - Measles, rubella targeted\n\n4. Economic benefits:\n   - Reduces healthcare costs\n   - Prevents lost work/school days\n   - More cost-effective than treatment\n\n5. Safe:\n   - Rigorously tested\n   - Monitored for safety\n   - Side effects usually mild\n\nVaccination schedule (India):\n- Birth: BCG, OPV, Hepatitis B\n- 6 weeks: DPT, OPV, Hepatitis B\n- 10 weeks: DPT, OPV\n- 14 weeks: DPT, OPV\n- 9 months: Measles, Vitamin A\n- 16-24 months: DPT, OPV booster\n- 5-6 years: DT booster\n- 10 years: TT\n- 16 years: TT\n\nThus, vaccination is a safe, effective way to protect individuals and communities from deadly diseases."
        },
        {
            "type": "subjective",
            "q": "What are deficiency diseases? Explain protein-energy malnutrition (PEM) with its two types.",
            "sample": "Deficiency diseases are conditions caused by lack of one or more essential nutrients in the diet over a period of time.\n\nCauses:\n- Inadequate food intake\n- Poor quality diet lacking specific nutrients\n- Malabsorption of nutrients\n- Increased nutrient requirements (growth, pregnancy)\n\nProtein-Energy Malnutrition (PEM):\n- Most common nutritional deficiency worldwide\n- Affects mainly infants and young children (1-5 years)\n- Deficiency of proteins, carbohydrates, and fats\n- Two main forms: Kwashiorkor and Marasmus\n\nKwashiorkor:\n\nCause:\n- Primarily protein deficiency\n- Carbohydrate intake may be adequate\n- Usually occurs after weaning\n\nSymptoms:\n- Stunted growth\n- Swollen belly (oedema due to fluid retention)\n- Thin, stick-like legs\n- Bulging eyes\n- Mental retardation\n- Discoloured, thinning hair\n- Skin lesions and peeling\n- Frequent diarrhoea\n- Irritability, apathy\n- Fatty liver\n\nAge group: Usually 1-3 years\n\nMarasmus:\n\nCause:\n- Deficiency of both proteins and calories\n- Severe malnutrition\n- Often in infants under one year\n- Due to starvation or chronic illness\n\nSymptoms:\n- Severe wasting (skin and bones appearance)\n- Prominent ribs and bones\n- Dry, thin, wrinkled skin (old man appearance)\n- Lean and weak body\n- No oedema (no swelling)\n- Mental retardation\n- Constant hunger\n- Weak cry\n- Low body temperature\n\nAge group: Usually under 1 year\n\nComparison of Kwashiorkor and Marasmus:\n\n| Feature | Kwashiorkor | Marasmus |\n|---------|-------------|----------|\n| Main deficiency | Protein | Protein and calories |\n| Age | 1-3 years | Under 1 year |\n| Oedema | Present (swollen belly) | Absent |\n| Subcutaneous fat | Some present | Absent |\n| Muscle wasting | Moderate | Severe |\n| Appetite | Poor | Often good |\n| Skin changes | Present | Minimal |\n| Hair changes | Present | May be normal |\n| Fatty liver | Present | Absent |\n\nPrevention of PEM:\n- Adequate nutrition during pregnancy\n- Exclusive breastfeeding for 6 months\n- Proper complementary feeding after 6 months\n- Balanced diet with proteins, carbs, fats\n- Regular growth monitoring\n- Education on nutrition\n- Food supplementation programs\n\nTreatment:\n- Gradual nutritional rehabilitation\n- High-protein, high-energy foods\n- Vitamin and mineral supplements\n- Treat infections\n- Long-term follow-up"
        },
        {
            "type": "subjective",
            "q": "List the vitamins, their deficiency diseases, and sources in a table.",
            "sample": "Vitamins are essential nutrients required in small amounts for proper body functioning.\n\n| Vitamin | Deficiency Disease | Symptoms | Major Sources |\n|---------|-------------------|----------|---------------|\n| Vitamin A (Retinol) | Night blindness, Xerophthalmia | Poor vision in dim light, dry eyes, dry skin | Carrots, papaya, mango, spinach, fish, egg, milk |\n| Vitamin B1 (Thiamine) | Beriberi | Weakness, fatigue, nerve damage, heart problems | Yeast, unpolished rice, whole grains, eggs, pork |\n| Vitamin B2 (Riboflavin) | Ariboflavinosis | Cracks at mouth corners, sore throat, red tongue | Milk, eggs, green vegetables, liver |\n| Vitamin B3 (Niacin) | Pellagra | Diarrhoea, dermatitis, dementia | Meat, fish, peanuts, whole grains |\n| Vitamin B5 (Pantothenic acid) | Rare (burning feet syndrome) | Fatigue, numbness | Almost all foods |\n| Vitamin B6 (Pyridoxine) | Anaemia, skin disorders | Irritability, depression, confusion | Meat, fish, poultry, bananas, potatoes |\n| Vitamin B7 (Biotin) | Rare | Hair loss, skin rash | Eggs, liver, yeast |\n| Vitamin B9 (Folic acid) | Anaemia (megaloblastic) | Weakness, fatigue, birth defects | Green leafy vegetables, legumes, nuts |\n| Vitamin B12 (Cobalamin) | Pernicious anaemia | Weakness, nerve damage, memory loss | Meat, fish, eggs, dairy (not in plants) |\n| Vitamin C (Ascorbic acid) | Scurvy | Bleeding gums, swollen joints, poor wound healing | Citrus fruits (orange, lemon), amla, tomato, leafy veg |\n| Vitamin D (Calciferol) | Rickets (children), Osteomalacia (adults) | Soft, bent bones, bone pain | Sunlight, milk, eggs, liver, fish |\n| Vitamin E (Tocopherol) | Rare (nerve problems) | Muscle weakness, reproductive issues | Wheat germ, vegetable oils, nuts, seeds |\n| Vitamin K | Bleeding disorders | Excessive bleeding, haemorrhage | Green leafy veg (cabbage, spinach), soybean, liver |\n\nFat-soluble vitamins (A, D, E, K):\n- Stored in body (especially liver)\n- Excess can be toxic\n- Need fat for absorption\n\nWater-soluble vitamins (B-complex, C):\n- Not stored (excreted in urine)\n- Need regular intake\n- Excess usually not toxic\n\nGeneral symptoms of vitamin deficiencies:\n- Fatigue, weakness\n- Poor growth\n- Skin problems\n- Nerve issues\n- Anaemia\n- Weakened immunity\n\nPrevention:\n- Balanced diet with variety\n- Include fruits, vegetables, whole grains\n- Adequate sunlight for vitamin D\n- Fortified foods when needed\n- Supplements if deficient (under medical advice)"
        },
        {
            "type": "subjective",
            "q": "List the minerals, their functions, deficiency diseases, and sources in a table.",
            "sample": "Minerals are inorganic nutrients essential for various body functions.\n\n| Mineral | Functions | Deficiency Disease/Symptoms | Sources |\n|---------|-----------|----------------------------|---------|\n| Calcium | Bones and teeth formation, blood clotting, muscle contraction, nerve function | Rickets (children), Osteomalacia (adults), osteoporosis, muscle cramps | Milk, cheese, yoghurt, eggs, fish, green leafy veg |\n| Phosphorus | Bones and teeth, energy metabolism, cell membranes | Weak bones, poor teeth, weakness | Milk, meat, nuts, beans, grains, fish |\n| Iron | Haemoglobin formation, oxygen transport | Anaemia: fatigue, weakness, pale skin, shortness of breath | Green leafy veg, egg yolk, liver, meat, beans, fortified cereals |\n| Iodine | Thyroid hormone (thyroxine) production, metabolism | Goitre (enlarged thyroid), cretinism in children | Iodized salt, seafood, fish, seaweed |\n| Sodium | Nerve function, muscle contraction, water balance | Muscle cramps, weakness, dehydration (rare) | Table salt, processed foods, seafood |\n| Potassium | Nerve function, muscle contraction, heart rhythm | Muscle weakness, paralysis, irregular heartbeat | Bananas, potatoes, vegetables, milk, meat |\n| Chlorine | Fluid balance, stomach acid (HCl) production | Weakness, dehydration (rare) | Table salt, seafood |\n| Magnesium | Enzyme activation, muscle function, bone health | Muscle cramps, weakness, irregular heartbeat | Nuts, seeds, whole grains, green veg |\n| Zinc | Immunity, wound healing, growth, enzyme function | Poor growth, delayed healing, hair loss | Meat, shellfish, nuts, seeds, legumes |\n| Fluorine | Tooth enamel strength, prevents cavities | Tooth decay, weak bones | Fluoridated water, tea, seafood |\n| Copper | Iron metabolism, RBC formation, nerve function | Anaemia, bone abnormalities | Liver, nuts, seeds, whole grains |\n| Selenium | Antioxidant, thyroid function | Muscle weakness, heart problems | Brazil nuts, fish, meat, eggs |\n\nMajor minerals (required >100mg/day):\n- Calcium, Phosphorus, Sodium, Potassium, Chlorine, Magnesium\n\nTrace minerals (required <100mg/day):\n- Iron, Iodine, Zinc, Copper, Fluorine, Selenium, Manganese, etc.\n\nImportance of minerals:\n\n1. Structural:\n   - Calcium, phosphorus: Bones and teeth\n   - Sulphur: Hair, skin, nails\n\n2. Regulatory:\n   - Sodium, potassium: Fluid balance, nerve impulses\n   - Calcium: Muscle contraction, blood clotting\n\n3. Component of essential molecules:\n   - Iron: Haemoglobin\n   - Iodine: Thyroid hormone\n   - Zinc: Enzymes\n\nDeficiency effects:\n- Impaired growth and development\n- Weakened immunity\n- Metabolic disorders\n- Specific disease conditions\n\nPrevention:\n- Balanced diet with variety\n- Include dairy, vegetables, fruits\n- Use iodized salt\n- Fortified foods when needed\n- Supplements if deficient (medical advice)\n\nInteractions:\n- Vitamin D helps calcium absorption\n- Vitamin C helps iron absorption\n- Calcium and phosphorus need proper ratio\n- Excess of one mineral can affect another"
        },
        {
            "type": "subjective",
            "q": "What is diabetes? Explain its types, causes, symptoms, and management.",
            "sample": "Diabetes mellitus is a metabolic disorder characterized by high blood sugar levels due to problems with insulin production or action.\n\nWhat is insulin?\n- Hormone produced by pancreas (beta cells of Islets of Langerhans)\n- Regulates blood glucose level\n- Helps cells take up glucose from blood\n- Converts excess glucose to glycogen in liver\n\nTypes of diabetes:\n\n1. Type 1 Diabetes (Insulin-dependent):\n   Cause:\n   - Autoimmune destruction of insulin-producing cells\n   - Body produces little or no insulin\n   - Usually develops in childhood/adolescence\n   - Accounts for 5-10% of cases\n   \n   Treatment:\n   - Requires daily insulin injections\n   - Cannot be prevented\n   - Blood sugar monitoring essential\n\n2. Type 2 Diabetes (Non-insulin-dependent):\n   Cause:\n   - Insulin resistance (cells don't respond properly)\n   - Relative insulin deficiency\n   - Linked to obesity, inactivity, genetics\n   - Usually develops in adults (increasing in youth)\n   - Accounts for 90-95% of cases\n   \n   Treatment:\n   - Lifestyle changes (diet, exercise)\n   - Oral medications\n   - May need insulin eventually\n   - Can be prevented or delayed\n\n3. Gestational Diabetes:\n   - Develops during pregnancy\n   - Usually resolves after delivery\n   - Increases risk of type 2 later\n\n4. Other types:\n   - Genetic defects\n   - Drug-induced\n   - Pancreatic disease\n\nSymptoms of diabetes:\n- Frequent urination (polyuria)\n- Excessive thirst (polydipsia)\n- Excessive hunger (polyphagia)\n- Unexplained weight loss\n- Fatigue, weakness\n- Blurred vision\n- Slow wound healing\n- Frequent infections\n- Numbness or tingling in hands/feet\n\nComplications (long-term):\n- Cardiovascular disease\n- Kidney disease (nephropathy)\n- Nerve damage (neuropathy)\n- Eye damage (retinopathy) - blindness\n- Foot problems (amputation risk)\n- Skin conditions\n- Hearing impairment\n- Alzheimer's risk increased\n\nDiagnosis:\n- Fasting blood sugar: ≥126 mg/dL\n- Random blood sugar: ≥200 mg/dL with symptoms\n- HbA1c: ≥6.5% (average 3-month sugar)\n- Oral glucose tolerance test\n\nManagement of diabetes:\n\n1. Diet:\n   - Balanced meals\n   - Control carbohydrate intake\n   - High fiber foods\n   - Limit sugar, sweets\n   - Regular meal timing\n   - Portion control\n\n2. Exercise:\n   - Regular physical activity\n   - At least 30 minutes daily\n   - Helps insulin sensitivity\n   - Weight management\n\n3. Medications:\n   - Insulin injections (Type 1, some Type 2)\n   - Oral hypoglycaemic drugs (Type 2)\n   - As prescribed by doctor\n\n4. Blood sugar monitoring:\n   - Regular self-monitoring\n   - Keep records\n   - Adjust treatment accordingly\n\n5. Weight management:\n   - Maintain healthy weight\n   - Especially important in Type 2\n\n6. Education:\n   - Learn about condition\n   - Recognize symptoms of high/low sugar\n   - Know what to do in emergencies\n\n7. Regular checkups:\n   - HbA1c every 3-6 months\n   - Eye exams\n   - Foot exams\n   - Kidney function tests\n   - Cholesterol checks\n\nPrevention of Type 2 diabetes:\n- Healthy weight\n- Regular exercise\n- Balanced diet\n- Avoid sugary drinks\n- Don't smoke\n- Limit alcohol\n- Regular screening if at risk"
        },
        {
            "type": "subjective",
            "q": "What are heart diseases? Explain atherosclerosis, coronary heart disease, and heart attack.",
            "sample": "Heart diseases (cardiovascular diseases) are disorders of the heart and blood vessels, often related to atherosclerosis.\n\nAtherosclerosis:\n\nDefinition:\n- Build-up of plaque inside arteries\n- Plaque consists of fat, cholesterol, calcium, and other substances\n- Arteries become hard, thick, and narrow\n\nProcess:\n1. Damage to artery lining (from smoking, high BP, high cholesterol)\n2. Cholesterol and fats accumulate at damage site\n3. Inflammatory cells gather\n4. Plaque forms and grows\n5. Artery narrows, blood flow reduced\n6. Plaque may rupture, causing clot\n\nRisk factors:\n- High cholesterol\n- High blood pressure\n- Smoking\n- Diabetes\n- Obesity\n- Physical inactivity\n- Unhealthy diet\n- Family history\n- Age\n\nCoronary Heart Disease (CHD):\n\nDefinition:\n- Atherosclerosis in coronary arteries (arteries supplying heart muscle)\n- Reduced blood flow to heart muscle\n\nEffects:\n- Angina (chest pain):\n  * Temporary chest pain or pressure\n  * Occurs when heart works harder (exercise, stress)\n  * Relieved by rest or medication\n- Shortness of breath\n- Fatigue\n- May lead to heart attack\n\nHeart Attack (Myocardial Infarction):\n\nDefinition:\n- Complete blockage of coronary artery\n- Part of heart muscle deprived of oxygen\n- Heart muscle begins to die\n\nCause:\n- Plaque rupture in coronary artery\n- Blood clot forms at rupture site\n- Artery completely blocked\n- No blood flow to heart muscle beyond blockage\n\nSymptoms:\n- Chest pain or discomfort (pressure, squeezing, fullness)\n- Pain spreading to shoulder, arm, back, neck, jaw\n- Shortness of breath\n- Cold sweat\n- Nausea, vomiting\n- Lightheadedness, dizziness\n- Women may have atypical symptoms\n\nEmergency: Call for help immediately\n\nTreatment:\n- Emergency angioplasty (open blocked artery)\n- Clot-busting drugs\n- Aspirin\n- Oxygen\n- Pain relief\n- Long-term medications\n\nOther heart conditions:\n\n1. Heart failure:\n   - Heart can't pump enough blood\n   - Not sudden stop, but gradual weakening\n   - Causes shortness of breath, swelling in legs\n\n2. Arrhythmias:\n   - Irregular heartbeat\n   - Too fast (tachycardia), too slow (bradycardia)\n   - May cause palpitations, dizziness\n\n3. Valve problems:\n   - Stenosis (narrowing)\n   - Regurgitation (leaking)\n   - May need repair or replacement\n\nPrevention of heart disease:\n\n1. Healthy diet:\n   - Low in saturated fats, trans fats\n   - High in fruits, vegetables, whole grains\n   - Limit salt, sugar\n   - Omega-3 fatty acids (fish)\n\n2. Regular exercise:\n   - At least 150 minutes moderate activity weekly\n   - Aerobic exercise\n\n3. No smoking:\n   - Single most important preventable risk factor\n\n4. Healthy weight:\n   - Maintain BMI <25\n   - Waist circumference control\n\n5. Manage conditions:\n   - Control blood pressure\n   - Control cholesterol\n   - Control diabetes\n\n6. Limit alcohol\n\n7. Manage stress\n\n8. Regular checkups\n\nStatistics:\n- Leading cause of death worldwide\n- About 45 million Indians affected by CHD\n- India projected to have highest number by 2020"
        },
        {
            "type": "subjective",
            "q": "What is arthritis? Explain the two main types: rheumatoid arthritis and osteoarthritis.",
            "sample": "Arthritis is inflammation of one or more joints, causing pain, swelling, stiffness, and reduced movement.\n\nTypes of arthritis:\n\n1. Osteoarthritis:\n   - Most common type\n   - Degenerative joint disease\n   - 'Wear and tear' arthritis\n\n   Cause:\n   - Breakdown of cartilage (cushioning at joints)\n   - Cartilage wears away over time\n   - Bone rubs against bone\n   - Risk factors: Ageing, obesity, injury, genetics, overuse\n\n   Affected joints:\n   - Weight-bearing joints: knees, hips, spine\n   - Hands (especially fingers)\n\n   Symptoms:\n   - Pain during movement, better with rest\n   - Stiffness, especially morning or after inactivity\n   - Swelling\n   - Grating sensation (crepitus)\n   - Bone spurs (osteophytes)\n   - Limited range of motion\n\n   Progression:\n   - Gradual onset\n   - Worsens over years\n   - Not symmetrical (may affect one knee more)\n\n2. Rheumatoid Arthritis:\n   - Autoimmune disease\n   - Body's immune system attacks joint lining\n   - Chronic inflammatory condition\n\n   Cause:\n   - Immune system attacks synovium (joint lining)\n   - Inflammation damages cartilage and bone\n   - Exact trigger unknown (genetic + environmental)\n   - Autoantibodies (rheumatoid factor)\n\n   Affected joints:\n   - Small joints of hands and feet first\n   - Usually symmetrical (both sides)\n   - Wrists, elbows, shoulders, knees, ankles\n\n   Symptoms:\n   - Swollen, tender, warm joints\n   - Morning stiffness lasting >30 minutes\n   - Fatigue, fever, weight loss\n   - Rheumatoid nodules (under skin)\n   - Joint deformity over time\n   - Fingers may become twisted\n\n   Systemic effects:\n   - Can affect other organs: eyes, lungs, heart, blood vessels\n\nComparison:\n\n| Feature | Osteoarthritis | Rheumatoid Arthritis |\n|---------|----------------|----------------------|\n| Type | Degenerative | Autoimmune |\n| Cause | Wear and tear | Immune attack on joints |\n| Age onset | Usually older (>50) | Any age (30-50 common) |\n| Onset | Gradual | Can be sudden |\n| Joints affected | Weight-bearing, hands | Small joints, symmetrical |\n| Morning stiffness | Brief (<30 min) | Prolonged (>30 min) |\n| Swelling | Mild, bony | Soft, inflammatory |\n| Systemic symptoms | No | Yes (fatigue, fever) |\n| Blood tests | Normal | Rheumatoid factor, anti-CCP |\n| X-ray findings | Joint space narrowing, bone spurs | Erosions, joint damage |\n\nOther types of arthritis:\n\n3. Gout:\n   - Caused by uric acid crystals in joints\n   - Sudden, severe pain (often big toe)\n   - Related to diet, genetics\n\n4. Psoriatic arthritis:\n   - Associated with psoriasis (skin condition)\n\n5. Ankylosing spondylitis:\n   - Affects spine\n   - Causes fusion of vertebrae\n\n6. Juvenile arthritis:\n   - Arthritis in children\n\nTreatment:\n\n1. Medications:\n   - Pain relievers (paracetamol)\n   - NSAIDs (ibuprofen, naproxen)\n   - Disease-modifying drugs (for rheumatoid)\n   - Biologics\n   - Corticosteroids\n\n2. Physical therapy:\n   - Exercises to maintain mobility\n   - Strengthen muscles around joints\n   - Range of motion exercises\n\n3. Lifestyle:\n   - Weight management (reduces joint stress)\n   - Low-impact exercise (swimming, walking)\n   - Assistive devices (canes, splints)\n   - Heat/cold therapy\n\n4. Surgery:\n   - Joint replacement (knee, hip)\n   - Joint fusion\n   - Synovectomy (remove inflamed lining)\n\n5. Alternative therapies:\n   - Acupuncture\n   - Supplements (glucosamine - controversial)\n   - Always consult doctor first\n\nThus, arthritis is a common but manageable condition with proper treatment and lifestyle adjustments."
        },
        {
            "type": "subjective",
            "q": "What is cancer? Explain the causes, types, and warning signs.",
            "sample": "Cancer is a disease characterized by uncontrolled growth and spread of abnormal cells in the body.\n\nWhat is cancer?\n- Normal cells grow, divide, and die in controlled manner\n- Cancer cells lose this control\n- They divide uncontrollably\n- Can invade nearby tissues\n- Can spread to other parts (metastasis)\n\nHow cancer develops:\n\n1. Initiation:\n   - Genetic mutation in a cell\n   - DNA damage from various causes\n   - Cell begins to divide abnormally\n\n2. Promotion:\n   - Mutated cells multiply\n   - Form mass of abnormal cells\n\n3. Progression:\n   - Cells become more abnormal\n   - Acquire ability to invade\n   - Can spread (metastasize)\n\nTypes of tumors:\n\n1. Benign tumors:\n   - Not cancerous\n   - Grow slowly\n   - Do not invade nearby tissue\n   - Do not spread\n   - Usually not life-threatening\n   - Can be removed, rarely recur\n\n2. Malignant tumors:\n   - Cancerous\n   - Grow rapidly\n   - Invade nearby tissues\n   - Can spread through blood/lymph\n   - Life-threatening\n   - May recur after removal\n\nTypes of cancer (named by origin):\n\n1. Carcinoma:\n   - Most common type\n   - Originates in skin or lining of organs\n   - Examples: Lung, breast, colon, prostate cancer\n\n2. Sarcoma:\n   - Originates in bone, cartilage, fat, muscle, blood vessels\n   - Less common\n   - Examples: Osteosarcoma (bone), liposarcoma (fat)\n\n3. Leukaemia:\n   - Cancer of blood-forming tissues (bone marrow)\n   - Abnormal white blood cells\n   - Not solid tumors\n   - Types: Acute lymphoblastic, acute myeloid, etc.\n\n4. Lymphoma:\n   - Originates in lymphatic system\n   - Affects lymphocytes\n   - Types: Hodgkin lymphoma, Non-Hodgkin lymphoma\n\n5. Myeloma:\n   - Cancer of plasma cells in bone marrow\n\nCauses and risk factors:\n\n1. Genetic factors:\n   - Inherited gene mutations\n   - Family history\n   - Only 5-10% of cancers\n\n2. Lifestyle factors:\n   - Tobacco use (leading cause): lung, mouth, throat, bladder\n   - Alcohol: liver, oesophagus, breast\n   - Diet: processed meats, low fiber\n   - Obesity: several cancers\n   - Physical inactivity\n\n3. Environmental exposures:\n   - UV radiation: skin cancer\n   - Ionizing radiation: various cancers\n   - Chemicals: asbestos (lung), benzene (leukaemia)\n   - Air pollution\n\n4. Infections:\n   - HPV: cervical cancer\n   - Hepatitis B/C: liver cancer\n   - H. pylori: stomach cancer\n   - Epstein-Barr: lymphoma\n\n5. Age:\n   - Risk increases with age\n   - Most cancers in older adults\n\nCommon warning signs (CAUTION):\n\nC - Change in bowel or bladder habits\nA - A sore that does not heal\nU - Unusual bleeding or discharge\nT - Thickening or lump in breast or elsewhere\nI - Indigestion or difficulty swallowing\nO - Obvious change in wart or mole\nN - Nagging cough or hoarseness\n\nOther signs:\n- Unexplained weight loss\n- Persistent fatigue\n- Persistent pain\n- Night sweats\n- Fever without infection\n\nPrevention:\n\n1. Avoid tobacco (smoking, chewing)\n2. Healthy diet: fruits, vegetables, whole grains\n3. Maintain healthy weight\n4. Regular physical activity\n5. Limit alcohol\n6. Protect skin from sun (sunscreen, clothing)\n7. Avoid carcinogens when possible\n8. Vaccination (HPV, Hepatitis B)\n9. Regular screenings:\n   - Breast: mammogram\n   - Cervical: Pap smear\n   - Colon: colonoscopy\n   - Skin: skin checks\n10. Know family history\n\nTreatment:\n\n1. Surgery: Remove tumor\n2. Radiation therapy: High-energy rays kill cancer cells\n3. Chemotherapy: Drugs kill cancer cells\n4. Immunotherapy: Boost immune system to fight cancer\n5. Targeted therapy: Drugs target specific cancer genes\n6. Hormone therapy: For hormone-sensitive cancers\n7. Stem cell transplant: For blood cancers\n\nPrognosis depends on:\n- Type and stage of cancer\n- Early detection\n- Patient's overall health\n- Response to treatment\n\nThus, cancer is a complex group of diseases, but early detection and modern treatments improve outcomes."
        },
        {
            "type": "subjective",
            "q": "What is an allergy? Name common allergens and their effects.",
            "sample": "An allergy is an abnormal or hypersensitive reaction of the body's immune system to normally harmless substances called allergens.\n\nWhat happens in an allergic reaction?\n\n1. First exposure:\n   - Immune system mistakenly identifies allergen as harmful\n   - Produces specific antibodies (IgE)\n   - Antibodies attach to mast cells\n   - Person becomes sensitized (no symptoms yet)\n\n2. Subsequent exposure:\n   - Allergen binds to IgE on mast cells\n   - Mast cells release chemicals (histamine, etc.)\n   - These chemicals cause allergic symptoms\n   - Reaction occurs within minutes to hours\n\nCommon allergens and their effects:\n\n| Allergen Type | Examples | Effects/Symptoms |\n|---------------|----------|------------------|\n| Foods | Peanuts, tree nuts, milk, eggs, wheat, soy, shellfish, fish | Hives, swelling, vomiting, diarrhoea, anaphylaxis |\n| Pollen | Grass, tree, weed pollen (hay fever) | Sneezing, runny nose, itchy eyes, congestion |\n| Dust mites | Microscopic mites in house dust | Sneezing, runny nose, asthma, eczema |\n| Animal dander | Cats, dogs, horses, rodents | Sneezing, wheezing, itchy eyes, skin rash |\n| Moulds | Fungal spores indoors/outdoors | Nasal congestion, wheezing, itchy eyes |\n| Insect stings | Bee, wasp, hornet, ant | Local swelling, hives, anaphylaxis |\n| Medications | Penicillin, aspirin, sulfa drugs | Rash, hives, fever, anaphylaxis |\n| Latex | Gloves, balloons, medical devices | Skin rash, hives, wheezing |\n| Cosmetics | Perfumes, makeup, hair products | Contact dermatitis (rash, itching) |\n| Metals | Nickel (jewellery), cobalt | Contact dermatitis |\n\nTypes of allergic reactions:\n\n1. Respiratory allergies:\n   - Allergic rhinitis (hay fever): sneezing, runny nose, itchy eyes\n   - Asthma: wheezing, coughing, shortness of breath\n\n2. Skin allergies:\n   - Eczema (atopic dermatitis): itchy, red, dry skin\n   - Urticaria (hives): raised, itchy welts\n   - Contact dermatitis: rash from skin contact with allergen\n\n3. Food allergies:\n   - Can affect skin, breathing, digestion\n   - Symptoms: hives, swelling, vomiting, diarrhoea\n   - Severe: anaphylaxis\n\n4. Drug allergies:\n   - Rash, hives, fever\n   - Severe: anaphylaxis, Stevens-Johnson syndrome\n\n5. Insect sting allergies:\n   - Local swelling, pain\n   - Severe: anaphylaxis\n\nSevere allergic reaction: Anaphylaxis\n\nSymptoms:\n- Difficulty breathing\n- Swelling of throat, tongue\n- Drop in blood pressure\n- Rapid pulse\n- Dizziness, fainting\n- Loss of consciousness\n\nEmergency: Life-threatening, requires immediate epinephrine injection and medical attention\n\nDiagnosis of allergies:\n- Medical history\n- Skin prick test: small amount of allergen placed on skin, pricked, observe reaction\n- Blood test: measure specific IgE antibodies\n- Elimination diet: remove suspected foods, then reintroduce\n- Patch test: for contact dermatitis\n\nTreatment and management:\n\n1. Avoidance:\n   - Best approach - avoid known allergens\n   - Read food labels carefully\n   - Keep home clean, reduce dust mites\n   - Use air purifiers\n   - Avoid pets if allergic\n\n2. Medications:\n   - Antihistamines: block histamine (cetirizine, loratadine)\n   - Decongestants: relieve nasal congestion\n   - Nasal corticosteroids: reduce inflammation\n   - Eye drops: for allergic conjunctivitis\n   - Bronchodilators: for asthma\n   - Epinephrine (adrenaline): for anaphylaxis (EpiPen)\n\n3. Immunotherapy (allergy shots):\n   - Gradual exposure to increasing allergen doses\n   - Builds tolerance over time\n   - Effective for pollen, dust mites, insect stings\n\n4. Emergency plan:\n   - People with severe allergies carry epinephrine auto-injector\n   - Wear medical alert bracelet\n   - Inform friends, family, school\n\nThus, allergies are common but manageable with proper identification and treatment."
        },
        {
            "type": "subjective",
            "q": "Explain the importance of personal hygiene in preventing diseases.",
            "sample": "Personal hygiene refers to practices that keep our body clean and healthy, preventing the spread of diseases.\n\nImportance of personal hygiene:\n- Prevents infections\n- Reduces disease transmission\n- Promotes overall health\n- Improves self-esteem\n- Social acceptance\n\nKey aspects of personal hygiene:\n\n1. Skin hygiene (Bathing):\n   - Bathe daily with soap and water\n   - Removes sweat, dirt, dead skin cells\n   - Prevents body odour\n   - Removes germs from skin surface\n   - Prevents skin infections\n   - Keeps skin healthy\n\n2. Hand hygiene:\n   - Most important for preventing infection spread\n   - Wash hands:\n     * Before and after meals\n     * After using toilet\n     * After touching animals\n     * After coughing/sneezing\n     * After touching garbage\n     * After playing outdoors\n     * Before preparing food\n   - Scrub for at least 20 seconds with soap\n   - Cover all surfaces: palms, back, between fingers, nails\n   - Rinse well, dry with clean towel\n   - Hand sanitizer when soap not available\n\n3. Oral hygiene:\n   - Brush teeth twice daily (morning and before bed)\n   - Use fluoride toothpaste\n   - Brush for 2-3 minutes\n   - Clean all tooth surfaces\n   - Floss daily to remove food between teeth\n   - Rinse mouth after meals\n   - Visit dentist regularly\n   - Prevents tooth decay, gum disease, bad breath\n\n4. Hair hygiene:\n   - Wash hair with shampoo at least weekly\n   - Removes dirt, oil, dandruff\n   - Prevents lice infestation\n   - Comb hair daily\n   - Keep hair clean and tidy\n   - Massage scalp with oil for health\n\n5. Nail hygiene:\n   - Keep nails short and clean\n   - Trim regularly\n   - Clean under nails\n   - Prevent dirt and germ accumulation\n   - Avoid biting nails\n\n6. Foot hygiene:\n   - Wash feet daily\n   - Dry thoroughly, especially between toes\n   - Wear clean socks\n   - Change socks daily\n   - Wear breathable footwear\n   - Prevents fungal infections (athlete's foot)\n\n7. Clothing hygiene:\n   - Wear clean clothes daily\n   - Change undergarments daily\n   - Wash clothes regularly\n   - Especially important for socks and underwear\n   - Prevents skin infections\n\n8. Toilet hygiene:\n   - Use clean toilets\n   - Flush after use\n   - Wash hands thoroughly after\n   - Keep toilet area clean\n\nHow poor hygiene leads to disease:\n\n1. Direct transmission:\n   - Germs on hands contaminate food\n   - Enter body through mouth\n   - Causes diarrhoea, typhoid, etc.\n\n2. Skin infections:\n   - Dirty skin allows bacterial/fungal growth\n   - Causes boils, rashes, ringworm\n\n3. Respiratory infections:\n   - Coughing/sneezing without covering mouth\n   - Spreads droplets to others\n\n4. Dental problems:\n   - Poor oral hygiene causes cavities\n   - Gum disease, tooth loss\n\n5. Parasitic infections:\n   - Dirty hair can have lice\n   - Dirty feet can get fungal infections\n\nDiseases prevented by good hygiene:\n- Diarrhoea, cholera, typhoid\n- Common cold, flu\n- Conjunctivitis\n- Skin infections\n- Tooth decay\n- Lice infestation\n- Food poisoning\n- Hepatitis A\n- Many others\n\nThus, personal hygiene is the first line of defence against many infectious diseases."
        },
        {
            "type": "subjective",
            "q": "What is oral hygiene? Explain how to maintain healthy teeth and gums.",
            "sample": "Oral hygiene is the practice of keeping the mouth, teeth, and gums clean and healthy to prevent dental problems.\n\nWhy oral hygiene is important:\n- Prevents tooth decay (cavities)\n- Prevents gum disease (gingivitis, periodontitis)\n- Prevents bad breath (halitosis)\n- Maintains ability to eat properly\n- Affects overall health\n- Saves money on dental treatment\n- Improves appearance and confidence\n\nDaily oral hygiene routine:\n\n1. Brushing teeth:\n   - Brush twice daily (morning and before bed)\n   - Use soft-bristled toothbrush\n   - Use fluoride toothpaste\n   - Brush for at least 2-3 minutes\n   - Correct technique:\n     * Hold brush at 45° angle to gums\n     * Use gentle circular motions\n     * Brush outer surfaces of all teeth\n     * Brush inner surfaces\n     * Brush chewing surfaces\n     * Brush tongue to remove bacteria\n   - Don't brush too hard (damages gums)\n   - Replace toothbrush every 3-4 months\n\n2. Flossing:\n   - Floss once daily\n   - Removes plaque and food between teeth\n   - Where brush cannot reach\n   - Prevents gum disease\n   - Correct technique:\n     * Use about 45 cm floss\n     * Gently slide between teeth\n     * Curve around tooth, go below gumline\n     * Use clean section for each gap\n\n3. Mouthwash:\n   - Use antiseptic mouthwash\n   - Kills bacteria\n   - Freshens breath\n   - Reaches areas brush misses\n   - Not a substitute for brushing/flossing\n\n4. Rinse after meals:\n   - Swish water in mouth after eating\n   - Removes loose food particles\n   - Dilutes acids\n   - Especially important after sugary foods\n\nDietary habits for healthy teeth:\n\n5. Limit sugary foods:\n   - Reduce sweets, candies, chocolates\n   - Avoid sticky sweets that cling to teeth\n   - Limit sugary drinks (soda, juice)\n   - If eating sweets, have with meals not between\n   - Sugar feeds bacteria that cause decay\n\n6. Eat tooth-friendly foods:\n   - Crunchy vegetables (carrot, celery, apple) clean teeth\n   - Cheese and milk (calcium for strong teeth)\n   - Water (washes away food)\n   - Fiber-rich foods stimulate saliva\n   - Green tea (contains fluoride)\n\n7. Avoid frequent snacking:\n   - Each snack = acid attack on teeth\n   - Constant eating = constant acid\n   - Better to eat at meal times\n   - Saliva needs time to neutralize acid\n\nProfessional dental care:\n\n8. Regular dental checkups:\n   - Visit dentist every 6 months\n   - Professional cleaning removes tartar\n   - Early detection of cavities\n   - X-rays if needed\n   - Gum health assessment\n\n9. Fluoride treatments:\n   - Fluoride strengthens enamel\n   - In toothpaste, water, or professional application\n   - Makes teeth more resistant to acid\n   - Can reverse early decay\n\n10. Dental sealants:\n    - Protective coating on chewing surfaces\n    - Prevents food trapping in grooves\n    - Especially for children\n    - Lasts several years\n\nWhat is tooth decay?\n- Caused by bacteria acting on sugars\n- Produces acid that dissolves enamel\n- Forms cavities (holes)\n- Can reach pulp, cause pain\n- If untreated, tooth may be lost\n\nWhat is gum disease?\n- Gingivitis: early stage, gums red, swollen, bleed\n- Periodontitis: advanced, gums pull away, bone loss\n- Can lead to tooth loss\n- Linked to heart disease, diabetes\n\nSigns of dental problems:\n- Toothache\n- Bleeding gums when brushing\n- Persistent bad breath\n- Loose teeth\n- Mouth sores\n- Sensitivity to hot/cold\n- See dentist promptly\n\nAdditional tips:\n\n- Don't use teeth as tools (opening bottles)\n- Don't bite nails or pens\n- Use mouthguard for sports\n- Don't smoke (stains teeth, causes gum disease)\n- Limit coffee/tea (staining)\n- Chew sugar-free gum after meals (stimulates saliva)\n\nThus, good oral hygiene = healthy teeth for lifetime = proper chewing = good digestion"
        },
        {
            "type": "subjective",
            "q": "Explain the dos and don'ts for eye care.",
            "sample": "Eyes are delicate sense organs that need proper care to maintain good vision and prevent infections.\n\nDos for eye care:\n\n1. Splash eyes with clean water:\n   - 2-3 times daily\n   - Removes dust and irritants\n   - Keeps eyes moist\n\n2. Maintain proper distance:\n   - When reading: 25-30 cm from book\n   - When using computer: 50-60 cm from screen\n   - TV: at least 3 metres away\n\n3. Take regular breaks:\n   - Follow 20-20-20 rule\n   - Every 20 minutes, look at something 20 feet away for 20 seconds\n   - Reduces eye strain\n\n4. Wear sunglasses:\n   - On bright sunny days\n   - Protects from UV rays\n   - Prevents cataract, macular degeneration\n   - Choose sunglasses that block 100% UV\n\n5. Look at distant objects:\n   - Periodically look outside\n   - Relaxes eye muscles\n   - Reduces strain from near work\n\n6. Eat eye-healthy foods:\n   - Vitamin A: carrots, papaya, mango, spinach\n   - Vitamin C: citrus fruits, amla\n   - Vitamin E: nuts, seeds\n   - Lutein: green leafy vegetables\n   - Omega-3: fish\n\n7. Have adequate lighting:\n   - Read in good light\n   - Light should come from behind\n   - Avoid glare\n\n8. Blink frequently:\n   - Keeps eyes moist\n   - Especially important when using screens\n   - Prevents dry eyes\n\n9. Use protective eyewear:\n   - Safety glasses when playing sports\n   - Goggles when swimming\n   - Safety glasses for hazardous work\n\n10. Visit eye specialist regularly:\n    - If you have problem reading blackboard\n    - If you get headaches after reading\n    - For regular checkups\n    - Especially if family history of eye problems\n\n11. Remove contact lenses properly:\n    - Wash hands before handling\n    - Clean as directed\n    - Don't wear longer than recommended\n    - Don't sleep in contacts\n\n12. Use prescribed glasses:\n    - If prescribed, wear regularly\n    - Get power checked periodically\n\nDon'ts for eye care:\n\n1. Don't rub eyes:\n   - Can damage cornea\n   - Transfers germs from hands\n   - Can worsen irritation\n   - If itchy, wash with clean water\n\n2. Don't read in dim light:\n   - Strains eyes\n   - Causes headaches\n   - Can't see properly\n\n3. Don't read in moving vehicles:\n   - Constant focusing and refocusing\n   - Causes eye strain, headache\n   - Motion sickness\n\n4. Don't lie down while reading:\n   - Wrong angle for eyes\n   - Uneven lighting\n   - Neck strain\n\n5. Don't watch TV/computer for long periods:\n   - Take breaks every 20-30 minutes\n   - Don't sit too close\n   - Ensure proper lighting\n\n6. Don't see eclipse directly:\n   - Can cause permanent retinal damage\n   - Use proper filters or pinhole projection\n   - Never look directly at sun\n\n7. Don't try to clean eyes with objects:\n   - Never put sharp objects near eyes\n   - Don't use dirty cloth\n   - If something gets in, ask adult for help\n   - Blink quickly to start tears\n\n8. Don't share eye makeup:\n   - Can spread infections\n   - Replace mascara regularly\n   - Don't use expired products\n\n9. Don't ignore symptoms:\n   - Redness, pain, discharge\n   - Blurred vision\n   - Floaters, flashes\n   - Seek medical help promptly\n\n10. Don't use others' glasses:\n    - Each prescription is different\n    - Can cause headaches, strain\n\nCommon eye problems:\n- Myopia (nearsightedness): can't see distant objects\n- Hypermetropia (farsightedness): can't see nearby objects\n- Conjunctivitis: pink eye (infection)\n- Cataract: cloudy lens\n- Glaucoma: increased eye pressure\n- Dry eyes\n\nThus, proper eye care from childhood helps maintain good vision throughout life."
        },
        {
            "type": "subjective",
            "q": "What is community hygiene? Explain the importance of safe drinking water and waste disposal.",
            "sample": "Community hygiene (community health) refers to all programmes and activities aimed at improving public health through collective efforts and civic amenities.\n\nImportance of community hygiene:\n- Prevents spread of infectious diseases\n- Provides clean environment\n- Ensures safe water supply\n- Proper waste management\n- Reduces disease burden\n- Improves quality of life\n\nKey components of community hygiene:\n\n1. Safe drinking water supply:\n\nWhy safe water is essential:\n- Water is basic necessity\n- Contaminated water causes many diseases\n- Over 80% diseases in developing countries linked to unsafe water\n\nDiseases from unsafe water:\n- Cholera: severe diarrhoea\n- Typhoid: fever, intestinal issues\n- Hepatitis A: liver infection\n- Dysentery: bloody diarrhoea\n- Diarrhoea: leading cause of child death\n- Polio (water-borne transmission)\n\nMethods to make water safe:\n\nA. Boiling:\n   - Most reliable method\n   - Boil for at least 15 minutes\n   - Kills all germs\n   - Cool and store in clean container\n\nB. Chlorination:\n   - Add chlorine tablets to water\n   - Kills microorganisms\n   - Residual chlorine protects from recontamination\n   - Follow proper dosage\n\nC. Filtration:\n   - Water filters with porous candles\n   - Remove suspended impurities\n   - Some remove bacteria\n   - RO systems remove dissolved impurities\n\nD. Sedimentation:\n   - Store water in tanks/pots\n   - Suspended impurities settle down\n   - Decant clear water\n   - Alum crystals speed up settling\n\nE. UV treatment:\n   - Ultraviolet radiation kills germs\n   - Used in modern water purifiers\n   - No chemicals added\n\nF. Reverse Osmosis (RO):\n   - Removes dissolved salts and impurities\n   - Good for high TDS water\n   - Wastes some water\n\nStorage of water:\n- Store in clean, covered containers\n- Use narrow-mouthed vessels\n- Clean containers regularly\n- Use long-handled dipper to avoid hand contact\n- Don't store for too long\n\n2. Waste disposal and treatment:\n\nTypes of waste:\n- Solid waste: garbage, rubbish\n- Liquid waste: sewage, wastewater\n- Hazardous waste: medical, industrial\n\nProper waste disposal methods:\n\nA. Sewage disposal:\n   - Wastewater from kitchens, toilets\n   - Carried through underground sewers\n   - Treated at sewage treatment plants\n   - Before release into water bodies\n   - Treatment removes pollutants\n\nB. Garbage collection:\n   - Civic bodies collect household waste\n   - Regular collection schedules\n   - Segregation at source (biodegradable, non-biodegradable)\n   - Dustbins with covers\n\nC. Landfills:\n   - Garbage dumped in low-lying areas\n   - Away from human habitation\n   - Covered with soil when full\n   - Prevents scattering by animals\n   - After years, land can be used for parks\n\nD. Composting:\n   - Kitchen and garden waste\n   - Dumped in pits, covered with soil\n   - Microorganisms decompose waste\n   - Produces manure-rich compost\n   - Environmentally friendly\n\nE. Vermicomposting:\n   - Earthworms added to compost pits\n   - Speed up decomposition\n   - Produce nutrient-rich compost\n   - Worms eat organic waste\n\nF. Recycling:\n   - Separate recyclable materials\n   - Paper, plastic, glass, metal\n   - Sent for recycling\n   - Reduces landfill burden\n\nG. Incineration:\n   - Burning waste at high temperature\n   - For medical, hazardous waste\n   - Reduces volume\n   - Requires pollution control\n\nCommunity participation:\n- Keep surroundings clean\n- Don't litter\n- Use dustbins\n- Segregate waste at home\n- Don't allow stagnant water (mosquito breeding)\n- Report broken drains\n- Participate in cleanliness drives\n- Educate others\n\nRole of civic bodies:\n- Panchayats in villages\n- Municipalities in towns\n- Provide safe drinking water\n- Collect and dispose waste\n- Maintain drainage systems\n- Control disease vectors\n- Health education\n\nThus, community hygiene requires collective effort for public health."
        },
        {
            "type": "subjective",
            "q": "What is composting? Explain vermicomposting and its advantages.",
            "sample": "Composting is a natural process of decomposing organic waste into nutrient-rich manure by microorganisms.\n\nWhat is composting?\n- Method of recycling organic waste\n- Kitchen waste, garden waste decomposed\n- Microorganisms break down material\n- Produces compost (humus)\n- Used as fertilizer\n- Environmentally friendly\n\nMaterials that can be composted:\n- Fruit and vegetable peels\n- Eggshells\n- Tea leaves, coffee grounds\n- Leaves, grass clippings\n- Twigs, small branches\n- Paper (non-glossy)\n- Sawdust\n- Cow dung\n\nMaterials NOT to compost:\n- Meat, fish, bones (attract pests)\n- Dairy products\n- Oily, fatty foods\n- Diseased plants\n- Weed seeds\n- Pet waste\n- Glossy paper\n- Non-biodegradable items\n\nTraditional composting process:\n\n1. Dig a pit in ground\n2. Layer green waste (nitrogen-rich) and brown waste (carbon-rich)\n3. Add some soil\n4. Keep moist but not wet\n5. Turn occasionally for aeration\n6. Microorganisms decompose material\n7. In 2-3 months, compost ready\n8. Dark, crumbly, earthy-smelling\n\nVermicomposting:\n\nDefinition:\n- Composting using earthworms\n- Worms accelerate decomposition\n- Produce superior quality compost\n\nWorms used:\n- Red wiggler (Eisenia fetida)\n- African nightcrawler\n- Not regular earthworms\n\nProcess of vermicomposting:\n\n1. Container:\n   - Use bin with holes for aeration\n   - Keep in shady place\n   - Add bedding (coconut coir, shredded paper)\n\n2. Add worms:\n   - Introduce composting worms\n   - About 1 kg worms per bin\n\n3. Add waste:\n   - Kitchen waste (vegetable peels, fruit scraps)\n   - Avoid citrus, onion, garlic in excess\n   - Bury waste in bedding\n\n4. Maintain conditions:\n   - Keep moist (like wrung-out sponge)\n   - Maintain temperature 20-30°C\n   - Avoid direct sunlight\n   - Cover to protect from rain\n\n5. Harvesting:\n   - Worms convert waste into castings\n   - After 2-3 months, compost ready\n   - Separate worms from compost\n   - Compost is dark, granular, odorless\n\nAdvantages of vermicomposting:\n\n1. Faster decomposition:\n   - Worms eat organic waste\n   - Speed up process (2-3 months vs 6 months)\n   - More efficient than traditional composting\n\n2. Superior compost quality:\n   - Worm castings are nutrient-rich\n   - Higher NPK (nitrogen, phosphorus, potassium)\n   - Contains beneficial microbes\n   - Plant growth hormones\n   - Improves soil structure\n\n3. Waste reduction:\n   - Reduces kitchen waste going to landfill\n   - Up to 50% household waste can be composted\n   - Decreases methane from landfills\n\n4. Environmentally friendly:\n   - No chemicals\n   - Reduces need for chemical fertilizers\n   - Lowers carbon footprint\n   - Sustainable practice\n\n5. Cost-effective:\n   - Free fertilizer for garden\n   - Saves money on buying compost\n   - Low setup cost\n\n6. Improves soil:\n   - Adds organic matter\n   - Improves water retention\n   - Enhances soil aeration\n   - Prevents soil erosion\n   - Promotes root growth\n\n7. Safe and easy:\n   - Can be done at home\n   - No foul smell if done properly\n   - Children can participate\n   - Educational\n\n8. Worms multiply:\n   - Population increases\n   - Can share with others\n   - Sustainable system\n\nUses of compost/vermicompost:\n- Garden fertilizer\n- Potting mix\n- Soil amendment\n- Organic farming\n- Lawn dressing\n- Plant nursery\n\nThus, vermicomposting is an excellent way to manage waste and produce organic fertilizer."
        }
    ],
    
#Biology — Grade 6 ICSE
#Chapter 8: Adaptations in Plants and Animals
#Comprehensive Practice Questions
#50 MCQ • 50 True/False • 40 Subjective


       "Chapter 8 — Adaptations in Plants and Animals": [
        # ===== MCQ (50 questions) =====
        {
            "type": "mcq",
            "q": "The natural home of an organism is called its:",
            "options": [
                "Habitat",
                "Ecosystem",
                "Environment",
                "Community"
            ],
            "answer": "Habitat",
            "explanation": "Habitat is the natural home of an organism where it gets food, shelter, and suitable climatic conditions."
        },
        {
            "type": "mcq",
            "q": "The ability of an organism to change for better adjustment with the environment is called:",
            "options": [
                "Habitat",
                "Adaptation",
                "Evolution",
                "Modification"
            ],
            "answer": "Adaptation",
            "explanation": "Adaptation helps an organism live successfully in its habitat through changes in body structure and behaviour."
        },
        {
            "type": "mcq",
            "q": "Habitat consists of:",
            "options": [
                "Only living components",
                "Only non-living components",
                "Both biotic (living) and abiotic (non-living) components",
                "Only plants and animals"
            ],
            "answer": "Both biotic (living) and abiotic (non-living) components",
            "explanation": "Habitat includes biotic (plants, animals) and abiotic (water, soil, temperature, sunlight) components."
        },
        {
            "type": "mcq",
            "q": "Plants that live in water are called:",
            "options": [
                "Xerophytes",
                "Mesophytes",
                "Hydrophytes",
                "Halophytes"
            ],
            "answer": "Hydrophytes",
            "explanation": "Hydrophytes are aquatic plants that live in water, e.g., water hyacinth, Hydrilla, lotus."
        },
        {
            "type": "mcq",
            "q": "Plants that live on land with sufficient water are called:",
            "options": [
                "Xerophytes",
                "Mesophytes",
                "Hydrophytes",
                "Epiphytes"
            ],
            "answer": "Mesophytes",
            "explanation": "Mesophytes grow in terrestrial habitats with good moisture, e.g., rose, sunflower, mango."
        },
        {
            "type": "mcq",
            "q": "Plants that live in dry and hot environments are called:",
            "options": [
                "Hydrophytes",
                "Mesophytes",
                "Xerophytes",
                "Halophytes"
            ],
            "answer": "Xerophytes",
            "explanation": "Xerophytes are adapted to dry, hot conditions with water scarcity, e.g., cactus, Acacia."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a free-floating hydrophyte?",
            "options": [
                "Lotus",
                "Hydrilla",
                "Water hyacinth",
                "Vallisneria"
            ],
            "answer": "Water hyacinth",
            "explanation": "Water hyacinth floats freely on water surface, not attached to soil."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a rooted floating hydrophyte?",
            "options": [
                "Water hyacinth",
                "Duckweed",
                "Lotus",
                "Hydrilla"
            ],
            "answer": "Lotus",
            "explanation": "Lotus has roots fixed in soil but leaves float on water surface due to long petioles."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a submerged rooted hydrophyte?",
            "options": [
                "Water hyacinth",
                "Lotus",
                "Hydrilla",
                "Duckweed"
            ],
            "answer": "Hydrilla",
            "explanation": "Hydrilla remains completely submerged in water and is rooted to the soil."
        },
        {
            "type": "mcq",
            "q": "The submerged parts of hydrophytes are covered with ________ to prevent decay.",
            "options": [
                "Wax",
                "Mucilage",
                "Cuticle",
                "Spines"
            ],
            "answer": "Mucilage",
            "explanation": "Mucilage coating protects aquatic plants from decaying in water."
        },
        {
            "type": "mcq",
            "q": "The stems of aquatic plants like lotus have:",
            "options": [
                "Solid structure",
                "Large tunnels and holes for air",
                "No air spaces",
                "Thick waxy coating"
            ],
            "answer": "Large tunnels and holes for air",
            "explanation": "Air spaces in stems help aquatic plants float and exchange gases."
        },
        {
            "type": "mcq",
            "q": "Leaves of submerged plants like Hydrilla are:",
            "options": [
                "Broad and flat",
                "Long, narrow, and ribbon-shaped",
                "Reduced to spines",
                "Thick and fleshy"
            ],
            "answer": "Long, narrow, and ribbon-shaped",
            "explanation": "Ribbon-shaped leaves allow water to pass through easily, preventing damage."
        },
        {
            "type": "mcq",
            "q": "Floating leaves like those of lotus have stomata on:",
            "options": [
                "Lower surface",
                "Upper surface",
                "Both surfaces",
                "No stomata"
            ],
            "answer": "Upper surface",
            "explanation": "Stomata on upper surface of floating leaves are exposed to air for gas exchange."
        },
        {
            "type": "mcq",
            "q": "The special tissue that provides buoyancy to aquatic plants is called:",
            "options": [
                "Parenchyma",
                "Collenchyma",
                "Aerenchyma",
                "Sclerenchyma"
            ],
            "answer": "Aerenchyma",
            "explanation": "Aerenchyma has large air spaces that provide buoyancy and flexibility to aquatic plants."
        },
        {
            "type": "mcq",
            "q": "In xerophytes like cactus, leaves are reduced to:",
            "options": [
                "Thorns",
                "Spines",
                "Scales",
                "Buds"
            ],
            "answer": "Spines",
            "explanation": "Leaves reduced to spines prevent water loss through transpiration."
        },
        {
            "type": "mcq",
            "q": "In cactus, the ________ becomes green and takes up the function of leaves.",
            "options": [
                "Root",
                "Stem",
                "Flower",
                "Spine"
            ],
            "answer": "Stem",
            "explanation": "Cactus stem is green and performs photosynthesis since leaves are reduced to spines."
        },
        {
            "type": "mcq",
            "q": "Cactus stems become fleshy to:",
            "options": [
                "Store water",
                "Store food",
                "Absorb sunlight",
                "Reduce transpiration"
            ],
            "answer": "Store water",
            "explanation": "Fleshy stems store water for survival in dry conditions."
        },
        {
            "type": "mcq",
            "q": "Stomata in xerophytes are:",
            "options": [
                "Numerous and raised",
                "Few and sunken",
                "Absent",
                "Only on upper surface"
            ],
            "answer": "Few and sunken",
            "explanation": "Fewer, sunken stomata reduce water loss in dry conditions."
        },
        {
            "type": "mcq",
            "q": "The surface of xerophytes becomes shiny and glazed to:",
            "options": [
                "Attract insects",
                "Reflect light and heat",
                "Absorb more water",
                "Store food"
            ],
            "answer": "Reflect light and heat",
            "explanation": "Shiny surface reflects sunlight, reducing heat absorption and water loss."
        },
        {
            "type": "mcq",
            "q": "Plants growing in mountains are ________ shaped with sloping branches.",
            "options": [
                "Cone",
                "Round",
                "Spreading",
                "Irregular"
            ],
            "answer": "Cone",
            "explanation": "Cone shape with sloping branches helps snow slide off easily without damaging branches."
        },
        {
            "type": "mcq",
            "q": "Mountain plants like pine have ________ leaves.",
            "options": [
                "Broad",
                "Needle-like",
                "Fleshy",
                "Ribbon-shaped"
            ],
            "answer": "Needle-like",
            "explanation": "Needle-like leaves reduce surface area and help snow slide off."
        },
        {
            "type": "mcq",
            "q": "Plants that grow on other plants for support are called:",
            "options": [
                "Parasites",
                "Epiphytes",
                "Xerophytes",
                "Hydrophytes"
            ],
            "answer": "Epiphytes",
            "explanation": "Epiphytes like orchids grow on other plants for support, not nutrition."
        },
        {
            "type": "mcq",
            "q": "Orchids obtain water and nutrients from:",
            "options": [
                "Soil",
                "Host plant",
                "Moisture in air and debris on host",
                "Rainwater only"
            ],
            "answer": "Moisture in air and debris on host",
            "explanation": "Orchids absorb moisture and nutrients from air and organic debris accumulating on host plants."
        },
        {
            "type": "mcq",
            "q": "The body of fish is ________ to offer least resistance to water.",
            "options": [
                "Flat",
                "Streamlined",
                "Round",
                "Irregular"
            ],
            "answer": "Streamlined",
            "explanation": "Streamlined body reduces water resistance and helps in swimming."
        },
        {
            "type": "mcq",
            "q": "Fish respire through:",
            "options": [
                "Lungs",
                "Gills",
                "Skin",
                "Trachea"
            ],
            "answer": "Gills",
            "explanation": "Gills extract oxygen dissolved in water."
        },
        {
            "type": "mcq",
            "q": "The ________ fin in fish acts as a rudder for changing direction.",
            "options": [
                "Tail",
                "Dorsal",
                "Pectoral",
                "Pelvic"
            ],
            "answer": "Tail",
            "explanation": "Tail fin (caudal fin) helps change direction while swimming."
        },
        {
            "type": "mcq",
            "q": "Some fish have ________ to help in buoyancy.",
            "options": [
                "Gills",
                "Air bladder",
                "Scales",
                "Fins"
            ],
            "answer": "Air bladder",
            "explanation": "Air bladder helps fish maintain buoyancy at different depths."
        },
        {
            "type": "mcq",
            "q": "Animals that live on land are called:",
            "options": [
                "Aquatic animals",
                "Terrestrial animals",
                "Aerial animals",
                "Amphibians"
            ],
            "answer": "Terrestrial animals",
            "explanation": "Terrestrial animals live on land, e.g., humans, tigers, deer."
        },
        {
            "type": "mcq",
            "q": "Terrestrial animals have ________ claws for walking and running.",
            "options": [
                "Pentadactyl (five digits)",
                "Three digits",
                "Webbed",
                "Hoofed"
            ],
            "answer": "Pentadactyl (five digits)",
            "explanation": "Most terrestrial animals have five-toed (pentadactyl) limbs."
        },
        {
            "type": "mcq",
            "q": "The ability to stand and move on two legs is called:",
            "options": [
                "Quadrupedal locomotion",
                "Bipedal locomotion",
                "Arboreal locomotion",
                "Aquatic locomotion"
            ],
            "answer": "Bipedal locomotion",
            "explanation": "Bipedal animals like humans walk on two legs."
        },
        {
            "type": "mcq",
            "q": "Desert animals that come out at night to avoid heat are called:",
            "options": [
                "Diurnal",
                "Nocturnal",
                "Crepuscular",
                "Hibernating"
            ],
            "answer": "Nocturnal",
            "explanation": "Nocturnal animals are active at night when temperatures are cooler."
        },
        {
            "type": "mcq",
            "q": "The camel is often called the:",
            "options": [
                "King of desert",
                "Ship of the desert",
                "Desert horse",
                "Desert runner"
            ],
            "answer": "Ship of the desert",
            "explanation": "Camel is called 'ship of the desert' because it can travel long distances in desert."
        },
        {
            "type": "mcq",
            "q": "The hump of a camel stores:",
            "options": [
                "Water",
                "Fat",
                "Food",
                "Air"
            ],
            "answer": "Fat",
            "explanation": "Camel's hump stores fat, which can be converted to energy and water when needed."
        },
        {
            "type": "mcq",
            "q": "A camel can go without food and water for up to:",
            "options": [
                "2-3 days",
                "5-7 days",
                "10 days",
                "15 days"
            ],
            "answer": "10 days",
            "explanation": "Camel can survive up to 10 days without food and water due to adaptations."
        },
        {
            "type": "mcq",
            "q": "A camel's large fleshy soles help it to:",
            "options": [
                "Run fast",
                "Walk on hot, slippery sand",
                "Dig burrows",
                "Climb rocks"
            ],
            "answer": "Walk on hot, slippery sand",
            "explanation": "Broad, fleshy soles prevent sinking in sand and protect from heat."
        },
        {
            "type": "mcq",
            "q": "Long eyelashes in camel protect from:",
            "options": [
                "Sunlight",
                "Wind-blown sand",
                "Predators",
                "Cold"
            ],
            "answer": "Wind-blown sand",
            "explanation": "Long eyelashes keep sand out of eyes during sandstorms."
        },
        {
            "type": "mcq",
            "q": "Mountain goats have ________ to help them climb rocky slopes.",
            "options": [
                "Webbed feet",
                "Strong hooves",
                "Padded paws",
                "Claws"
            ],
            "answer": "Strong hooves",
            "explanation": "Strong hooves provide grip on rocky mountain slopes."
        },
        {
            "type": "mcq",
            "q": "Mountain animals have thick fur to:",
            "options": [
                "Protect from cold",
                "Camouflage",
                "Attract mates",
                "Store food"
            ],
            "answer": "Protect from cold",
            "explanation": "Thick fur insulates against low temperatures in mountains."
        },
        {
            "type": "mcq",
            "q": "Birds have ________ bones to make their body light for flight.",
            "options": [
                "Solid",
                "Hollow with air cavities",
                "Heavy",
                "Cartilaginous"
            ],
            "answer": "Hollow with air cavities",
            "explanation": "Hollow, air-filled bones reduce weight for flight."
        },
        {
            "type": "mcq",
            "q": "Forelimbs of birds are modified into:",
            "options": [
                "Legs",
                "Wings",
                "Fins",
                "Claws"
            ],
            "answer": "Wings",
            "explanation": "Forelimbs are modified into wings for flying."
        },
        {
            "type": "mcq",
            "q": "Birds have ________ lungs with air sacs for efficient breathing.",
            "options": [
                "Simple",
                "Balloon-like",
                "Spongy",
                "Small"
            ],
            "answer": "Balloon-like",
            "explanation": "Air sacs increase breathing efficiency and make body lighter."
        },
        {
            "type": "mcq",
            "q": "Hibernation is a deep sleep during:",
            "options": [
                "Summer",
                "Winter",
                "Rainy season",
                "Spring"
            ],
            "answer": "Winter",
            "explanation": "Animals hibernate during winter to save energy when food is scarce."
        },
        {
            "type": "mcq",
            "q": "Which animal hibernates during winter?",
            "options": [
                "Camel",
                "Frog",
                "Fish",
                "Bird"
            ],
            "answer": "Frog",
            "explanation": "Frogs hibernate in winter to survive cold when insects (their food) are scarce."
        },
        
        # ===== True/False (50 questions) =====
        {
            "type": "tf",
            "q": "Habitat provides organisms with food, shelter, and suitable climatic conditions.",
            "answer": "True",
            "explanation": "Habitat is the natural home meeting all needs of an organism."
        },
        {
            "type": "tf",
            "q": "All organisms in a habitat have the same adaptations.",
            "answer": "False",
            "explanation": "Different organisms have different adaptations suited to their specific needs."
        },
        {
            "type": "tf",
            "q": "Adaptation includes changes in body structure and behaviour.",
            "answer": "True",
            "explanation": "Adaptation involves both structural and behavioural changes for survival."
        },
        {
            "type": "tf",
            "q": "Cactus and camels are adapted to live in water.",
            "answer": "False",
            "explanation": "Cactus and camels are adapted to live in deserts, not water."
        },
        {
            "type": "tf",
            "q": "Hydrophytes are plants that live in dry areas.",
            "answer": "False",
            "explanation": "Hydrophytes live in water; xerophytes live in dry areas."
        },
        {
            "type": "tf",
            "q": "Mesophytes require a sufficient amount of water to live on land.",
            "answer": "True",
            "explanation": "Mesophytes grow in moderate moisture conditions."
        },
        {
            "type": "tf",
            "q": "Xerophytes are adapted to cope with dry and hot environments.",
            "answer": "True",
            "explanation": "Xerophytes have adaptations to conserve water and tolerate heat."
        },
        {
            "type": "tf",
            "q": "Water hyacinth is a rooted floating hydrophyte.",
            "answer": "False",
            "explanation": "Water hyacinth is free-floating, not rooted. Lotus is rooted floating."
        },
        {
            "type": "tf",
            "q": "Lotus has roots fixed in soil and leaves that float on water.",
            "answer": "True",
            "explanation": "Lotus is a rooted floating hydrophyte with long petioles."
        },
        {
            "type": "tf",
            "q": "Hydrilla is completely submerged and rooted in soil.",
            "answer": "True",
            "explanation": "Hydrilla is a submerged rooted hydrophyte."
        },
        {
            "type": "tf",
            "q": "Submerged parts of hydrophytes are covered with waxy coating.",
            "answer": "False",
            "explanation": "They are covered with mucilage, not wax. Wax is for xerophytes."
        },
        {
            "type": "tf",
            "q": "Stems of aquatic plants have air spaces for buoyancy.",
            "answer": "True",
            "explanation": "Air spaces (aerenchyma) help plants float."
        },
        {
            "type": "tf",
            "q": "Leaves of submerged plants are broad and flat.",
            "answer": "False",
            "explanation": "They are long, narrow, and ribbon-shaped to reduce water resistance."
        },
        {
            "type": "tf",
            "q": "Floating leaves have stomata on their upper surface.",
            "answer": "True",
            "explanation": "Stomata on upper surface are exposed to air for gas exchange."
        },
        {
            "type": "tf",
            "q": "Aerenchyma provides buoyancy to aquatic plants.",
            "answer": "True",
            "explanation": "Aerenchyma tissue has large air spaces for flotation."
        },
        {
            "type": "tf",
            "q": "In cactus, leaves are reduced to spines to store water.",
            "answer": "False",
            "explanation": "Spines reduce water loss; stem stores water."
        },
        {
            "type": "tf",
            "q": "Cactus stem is green and performs photosynthesis.",
            "answer": "True",
            "explanation": "Green stem takes over leaf function."
        },
        {
            "type": "tf",
            "q": "Xerophytes have numerous stomata on leaf surfaces.",
            "answer": "False",
            "explanation": "They have few, sunken stomata to reduce water loss."
        },
        {
            "type": "tf",
            "q": "Shiny surface of xerophytes reflects light and heat.",
            "answer": "True",
            "explanation": "Shiny coating reduces heat absorption."
        },
        {
            "type": "tf",
            "q": "Mountain trees are cone-shaped to collect more sunlight.",
            "answer": "False",
            "explanation": "Cone shape helps snow slide off, preventing branch damage."
        },
        {
            "type": "tf",
            "q": "Pine trees have needle-like leaves to reduce water loss.",
            "answer": "True",
            "explanation": "Needle-like leaves reduce surface area and water loss."
        },
        {
            "type": "tf",
            "q": "Orchids are parasites that take food from host plants.",
            "answer": "False",
            "explanation": "Orchids are epiphytes, not parasites. They use host only for support."
        },
        {
            "type": "tf",
            "q": "Orchids obtain water and nutrients from air and debris.",
            "answer": "True",
            "explanation": "They absorb moisture and nutrients from air and organic matter on host."
        },
        {
            "type": "tf",
            "q": "Fish have streamlined bodies to reduce water resistance.",
            "answer": "True",
            "explanation": "Streamlined shape helps in efficient swimming."
        },
        {
            "type": "tf",
            "q": "Fish breathe through lungs like humans.",
            "answer": "False",
            "explanation": "Fish breathe through gills, extracting oxygen from water."
        },
        {
            "type": "tf",
            "q": "The tail fin of fish acts as a rudder for changing direction.",
            "answer": "True",
            "explanation": "Tail fin helps steer while swimming."
        },
        {
            "type": "tf",
            "q": "Air bladder helps fish sink to the bottom.",
            "answer": "False",
            "explanation": "Air bladder helps in buoyancy, not sinking."
        },
        {
            "type": "tf",
            "q": "Terrestrial animals live on land.",
            "answer": "True",
            "explanation": "Terrestrial means land-dwelling."
        },
        {
            "type": "tf",
            "q": "All terrestrial animals have webbed feet for swimming.",
            "answer": "False",
            "explanation": "Webbed feet are for aquatic animals; terrestrial have pentadactyl limbs."
        },
        {
            "type": "tf",
            "q": "Bipedal locomotion means walking on two legs.",
            "answer": "True",
            "explanation": "Humans are bipedal."
        },
        {
            "type": "tf",
            "q": "Desert animals are usually active during the day.",
            "answer": "False",
            "explanation": "Many desert animals are nocturnal to avoid daytime heat."
        },
        {
            "type": "tf",
            "q": "Nocturnal animals come out at night.",
            "answer": "True",
            "explanation": "Nocturnal animals are active at night."
        },
        {
            "type": "tf",
            "q": "Camel's hump stores water.",
            "answer": "False",
            "explanation": "Hump stores fat, not water."
        },
        {
            "type": "tf",
            "q": "A camel can go without water for up to 10 days.",
            "answer": "True",
            "explanation": "Camel adaptations allow long periods without water."
        },
        {
            "type": "tf",
            "q": "Camel's large fleshy soles prevent sinking in sand.",
            "answer": "True",
            "explanation": "Broad soles distribute weight on soft sand."
        },
        {
            "type": "tf",
            "q": "Long eyelashes in camel protect from sunlight.",
            "answer": "False",
            "explanation": "They protect from wind-blown sand."
        },
        {
            "type": "tf",
            "q": "Mountain goats have strong hooves for climbing.",
            "answer": "True",
            "explanation": "Hooves provide grip on rocky slopes."
        },
        {
            "type": "tf",
            "q": "Mountain animals have thin fur to stay cool.",
            "answer": "False",
            "explanation": "They have thick fur for insulation against cold."
        },
        {
            "type": "tf",
            "q": "Birds have hollow bones to make them lighter for flight.",
            "answer": "True",
            "explanation": "Hollow, air-filled bones reduce weight."
        },
        {
            "type": "tf",
            "q": "Birds' forelimbs are modified into wings.",
            "answer": "True",
            "explanation": "Wings are modified forelimbs for flying."
        },
        {
            "type": "tf",
            "q": "Birds have heavy, solid bones for strength.",
            "answer": "False",
            "explanation": "Bones are hollow with air cavities for lightness."
        },
        {
            "type": "tf",
            "q": "Birds have air sacs connected to lungs for efficient breathing.",
            "answer": "True",
            "explanation": "Air sacs increase oxygen intake and reduce weight."
        },
        {
            "type": "tf",
            "q": "Hibernation is sleep during summer.",
            "answer": "False",
            "explanation": "Hibernation is winter sleep; summer sleep is aestivation."
        },
        {
            "type": "tf",
            "q": "Frogs hibernate during winter.",
            "answer": "True",
            "explanation": "Frogs hibernate to survive cold when food is scarce."
        },
        {
            "type": "tf",
            "q": "Cactus stems are fleshy to store water.",
            "answer": "True",
            "explanation": "Fleshy stems store water for dry periods."
        },
        {
            "type": "tf",
            "q": "All aquatic plants have well-developed root systems.",
            "answer": "False",
            "explanation": "Some aquatic plants have poorly developed or absent roots."
        },
        {
            "type": "tf",
            "q": "Mechanical tissues are well-developed in hydrophytes.",
            "answer": "False",
            "explanation": "Mechanical tissues are poorly developed as water supports the plant."
        },
        {
            "type": "tf",
            "q": "Xerophytes have deep root systems to absorb water.",
            "answer": "True",
            "explanation": "Deep roots reach underground water sources."
        },
        {
            "type": "tf",
            "q": "Epiphytes like orchids grow on soil.",
            "answer": "False",
            "explanation": "Epiphytes grow on other plants for support."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "Define habitat and adaptation. Explain with examples why adaptation is necessary for survival.",
            "sample": "Habitat is the natural home or environment of an organism where it gets food, shelter, and suitable climatic conditions to survive, breed, and flourish.\n\nExamples of habitats:\n- Desert: cactus, camel\n- Pond: lotus, fish, frog\n- Forest: tiger, elephant\n- Mountain: pine, mountain goat\n\nHabitat has two components:\n1. Biotic (living): plants, animals, microorganisms\n2. Abiotic (non-living): water, soil, temperature, sunlight, air\n\nAdaptation is the ability of an organism to change its body structure and behaviour for better adjustment with its environment over time.\n\nWhy adaptation is necessary:\n\n1. Survival in extreme conditions:\n   - Desert: high temperature, scarce water\n   - Polar: freezing cold\n   - Aquatic: water environment\n   Without adaptations, organisms cannot survive in these conditions.\n\n2. Protection from predators:\n   - Camouflage (chameleon changes colour)\n   - Spines (porcupine, cactus)\n   - Speed (deer runs fast)\n\n3. Obtaining food:\n   - Long neck of giraffe to reach leaves\n   - Sharp teeth of carnivores\n   - Streamlined body of fish to catch prey\n\n4. Reproduction:\n   - Bright colours of flowers attract pollinators\n   - Scent to attract mates\n\n5. Climate regulation:\n   - Thick fur in cold regions\n   - Large ears in desert animals (elephant, jackrabbit) to dissipate heat\n\nExamples of adaptations:\n\nCactus (desert plant):\n- Leaves reduced to spines (reduce water loss)\n- Fleshy stem (stores water)\n- Deep roots (absorb water)\n- Sunken stomata (reduce transpiration)\n\nCamel (desert animal):\n- Hump stores fat (energy source)\n- Can drink large quantity at once\n- Sweats very little\n- Long eyelashes protect from sand\n- Broad soles prevent sinking\n\nFish (aquatic animal):\n- Streamlined body (reduce water resistance)\n- Gills (breathe underwater)\n- Fins (for swimming and balance)\n- Scales with mucus (protection)\n\nThus, adaptation is essential for survival, growth, and reproduction in specific habitats."
        },
        {
            "type": "subjective",
            "q": "Classify plants based on water availability. Explain each category with examples and adaptations.",
            "sample": "Based on water availability in habitat, plants are classified into three categories:\n\n1. Hydrophytes (Aquatic plants):\n   - Plants that live in water\n   - Found in ponds, lakes, rivers\n   \n   Types of hydrophytes:\n   a. Free-floating: Water hyacinth, duckweed\n   b. Rooted floating: Lotus, water lily\n   c. Submerged rooted: Hydrilla, Vallisneria\n   d. Submerged floating: Utricularia\n   \n   Adaptations of hydrophytes:\n   - Submerged parts covered with mucilage (prevents decay)\n   - Stems spongy with air spaces (aerenchyma for buoyancy)\n   - Leaves: ribbon-shaped (submerged) or broad flat (floating)\n   - Floating leaves have stomata on upper surface\n   - Roots poorly developed or absent\n   - Mechanical tissues poorly developed (water supports)\n\n2. Mesophytes:\n   - Plants that grow on land with sufficient moisture\n   - Moderate temperature and humidity\n   - Neither very wet nor very dry conditions\n   \n   Examples:\n   - Rose, sunflower, mango, peepal\n   - Tomato, potato, mustard\n   - Gulmohar, clove, rosewood\n   \n   Adaptations of mesophytes:\n   - Leaves broad but thin\n   - Epidermis with thin cuticle\n   - Stomata numerous on lower surface\n   - Well-developed roots and stems\n   - Well-developed mechanical and conducting tissues\n   - Normal growth in ideal conditions\n\n3. Xerophytes (Desert plants):\n   - Plants adapted to dry, hot conditions\n   - Water scarcity, high temperature\n   \n   Examples:\n   - Cactus, Opuntia\n   - Acacia, babool\n   - Aloe, Agave\n   \n   Adaptations of xerophytes:\n   - Leaves reduced to spines (reduce water loss)\n   - Few, sunken stomata (reduce transpiration)\n   - Thick waxy coating on stems and leaves (reflects heat)\n   - Green stems perform photosynthesis\n   - Fleshy stems store water\n   - Deep root system (reach underground water)\n   - Some have shallow widespread roots (absorb surface moisture)\n\nComparison table:\n\n| Feature | Hydrophytes | Mesophytes | Xerophytes |\n|---------|-------------|------------|------------|\n| Habitat | Water | Moderate moisture | Dry, hot |\n| Leaves | Ribbon/broad | Broad | Spines |\n| Stomata | Upper surface (floating) | Lower surface | Few, sunken |\n| Roots | Poor | Well-developed | Deep/extensive |\n| Stem | Spongy with air spaces | Normal | Fleshy, green |\n| Cuticle | Thin | Thin | Thick waxy |\n| Examples | Lotus, Hydrilla | Rose, mango | Cactus, Acacia |\n\nThus, plants show remarkable adaptations to their water environment."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of hydrophytes (aquatic plants) with examples.",
            "sample": "Hydrophytes are plants that live in water. They show various adaptations to survive in aquatic environment.\n\nTypes of hydrophytes with examples:\n\n1. Free-floating plants:\n   - Float freely on water surface\n   - Not attached to soil\n   - Examples: Water hyacinth, duckweed, Pistia\n\n2. Rooted floating plants:\n   - Roots fixed in soil\n   - Leaves float on surface\n   - Long petioles (leaf stalks)\n   - Examples: Lotus, water lily\n\n3. Submerged rooted plants:\n   - Completely under water\n   - Roots fixed in soil\n   - Examples: Hydrilla, Vallisneria\n\n4. Submerged floating plants:\n   - Completely under water\n   - Not rooted in soil\n   - Examples: Utricularia, Ceratophyllum\n\nAdaptations of hydrophytes:\n\nA. Morphological adaptations (structure):\n\n1. Roots:\n   - Poorly developed or absent\n   - No root hairs\n   - Function mainly for anchorage, not absorption\n   - In floating plants, roots may hang freely\n\n2. Stems:\n   - Soft, spongy, flexible\n   - Large air spaces (aerenchyma) for buoyancy\n   - Hollow in some (lotus)\n   - Long and slender in submerged plants\n\n3. Leaves:\n   - Submerged plants: thin, narrow, ribbon-shaped (Hydrilla)\n     * Allows water to pass easily\n     * Prevents damage from water currents\n   - Floating plants: large, flat, broad (lotus, water lily)\n     * Float on surface\n     * Waxy upper surface (waterproof)\n     * Stomata only on upper surface (exposed to air)\n\n4. Mucilage coating:\n   - Submerged parts covered with mucilage\n   - Protects from decay in water\n\nB. Anatomical adaptations (internal structure):\n\n5. Aerenchyma tissue:\n   - Specialized tissue with large air spaces\n   - Provides buoyancy (helps float)\n   - Facilitates gas exchange\n   - Present in stems, roots, leaves\n\n6. Mechanical tissues:\n   - Poorly developed\n   - Water supports the plant\n   - No need for strong supporting tissues\n\n7. Conducting tissues:\n   - Reduced (xylem and phloem)\n   - Water easily available\n\nC. Physiological adaptations (functions):\n\n8. Gas exchange:\n   - Through entire plant surface\n   - Air spaces store oxygen\n   - Floating leaves exchange gases through stomata\n\n9. Reproduction:\n   - Many reproduce vegetatively (rapid growth)\n   - Flowers raised above water (lotus) for pollination\n\nSpecial features of lotus (example):\n- Roots in mud\n- Long hollow petioles (air channels) bring air to roots\n- Large floating leaves\n- Showy flowers above water\n- Seeds can survive years\n\nThus, hydrophytes are perfectly adapted to life in water."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of xerophytes (desert plants) with examples.",
            "sample": "Xerophytes are plants adapted to survive in dry, hot environments with scarce water. They show remarkable adaptations to conserve water and tolerate heat.\n\nExamples of xerophytes:\n- Cactus (various species)\n- Opuntia (prickly pear)\n- Acacia (babool)\n- Aloe vera\n- Agave\n- Euphorbia\n\nAdaptations of xerophytes:\n\nA. Morphological adaptations (structure):\n\n1. Leaves:\n   - Reduced to spines or scales\n   - Prevents water loss through transpiration\n   - Spines also protect from herbivores\n   - In some, leaves absent altogether\n\n2. Stem:\n   - Becomes green and fleshy\n   - Performs photosynthesis (since leaves are reduced)\n   - Stores water in succulent stems\n   - Thick, waxy coating (cuticle) on stem\n   - Ribbed or fluted (can expand when water available)\n\n3. Roots:\n   - Two types of adaptations:\n     a. Deep root system: taproots reach deep groundwater (Acacia)\n     b. Shallow widespread roots: absorb surface moisture from dew/light rain (cactus)\n   - Extensive root system covers large area\n\n4. Surface features:\n   - Shiny, glazed surface (reflects light and heat)\n   - Thick waxy cuticle (reduces water loss)\n   - Hairy or woolly covering (traps moist air, reduces transpiration)\n\nB. Anatomical adaptations (internal structure):\n\n5. Stomata:\n   - Few in number (reduces transpiration)\n   - Sunken in pits (protected from dry wind)\n   - Open at night (in some) to fix CO₂ (CAM plants)\n   - Close during day to conserve water\n\n6. Tissues:\n   - Thick cuticle on epidermis\n   - Multiple layered epidermis\n   - Palisade cells well-developed for photosynthesis\n   - Water storage tissue in stem (parenchyma)\n   - Reduced intercellular spaces\n\nC. Physiological adaptations (functions):\n\n7. CAM photosynthesis:\n   - Stomata open at night to take in CO₂\n   - CO₂ stored as organic acids\n   - Stomata close during day\n   - Photosynthesis occurs during day using stored CO₂\n   - Minimizes water loss\n\n8. Water conservation:\n   - Very low transpiration rate\n   - Can tolerate losing 50% of water content\n   - Rapid water uptake when available\n   - Store water in stem for dry periods\n\n9. Metabolic adaptations:\n   - Produce mucilage (holds water)\n   - Some have salt glands to excrete excess salt\n   - Can survive long droughts\n\nSpecific examples:\n\nCactus:\n- Leaves modified into spines\n- Green fleshy stem for photosynthesis and water storage\n- Shallow, widespread roots\n- Waxy coating on stem\n- CAM photosynthesis\n\nOpuntia:\n- Flattened stem segments (cladodes) look like leaves\n- Actually stems performing photosynthesis\n- Spines on stems\n- Stores water\n\nAcacia (babool):\n- Deep taproots reach groundwater\n- Small leaves reduce surface area\n- Thick cuticle\n- Some have thorns\n\nAloe vera:\n- Thick fleshy leaves store water\n- Leaf margins have teeth\n- Gel inside stores water\n- Waxy leaf surface\n\nThus, xerophytes have multiple adaptations to survive in harsh desert conditions."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of plants growing in mountains with examples.",
            "sample": "Plants growing in mountains face extreme conditions: low temperature, strong winds, snow, and reduced oxygen. They have special adaptations to survive.\n\nExamples of mountain plants:\n- Pine\n- Fir\n- Deodar\n- Spruce\n- Cedar\n- Juniper\n\nAdaptations of mountain plants:\n\nA. Morphological adaptations (structure):\n\n1. Shape of tree:\n   - Cone-shaped (pyramidal)\n   - Sloping branches\n   - Advantage: Snow slides off easily\n   - Prevents branches from breaking under snow weight\n\n2. Leaves:\n   - Needle-like or scale-like\n   - Small surface area\n   - Reduces water loss\n   - Helps snow slide off\n   - Thick, waxy cuticle\n   - Some have sunken stomata\n\n3. Bark:\n   - Thick bark\n   - Protects from cold\n   - Insulation\n\n4. Branches:\n   - Flexible\n   - Bend under snow without breaking\n   - Sloping downward\n\n5. Roots:\n   - Shallow but widespread\n   - Anchors tree in rocky soil\n   - Absorbs nutrients from thin soil layer\n\nB. Anatomical adaptations (internal structure):\n\n6. Leaves:\n   - Thick cuticle (reduces water loss)\n   - Sunken stomata (protects from cold winds)\n   - Resin canals (produces sticky resin)\n   - Resin prevents freezing\n   - Resin also protects from fungi\n\n7. Wood:\n   - Dense wood\n   - Strong to withstand snow and wind\n   - Resin in wood prevents decay\n\nC. Physiological adaptations (functions):\n\n8. Evergreen nature:\n   - Most conifers are evergreen\n   - Don't shed all leaves in winter\n   - Can photosynthesize whenever conditions allow\n   - Saves energy of producing new leaves each spring\n\n9. Cold tolerance:\n   - Produce antifreeze compounds\n   - Prevent ice crystal formation in cells\n   - Can survive freezing temperatures\n\n10. Reduced metabolism:\n    - Slow growth\n    - Conserves energy\n    - Can survive harsh winters\n\nSpecific examples:\n\nPine tree:\n- Needle-like leaves in bundles\n- Thick bark\n- Cone-shaped\n- Produces resin\n- Evergreen\n\nFir tree:\n- Flat needles\n- Upright cones\n- Pyramid shape\n- Aromatic resin\n\nDeodar:\n- Drooping branches\n- Needle-like leaves\n- Tall, conical shape\n- Found in Himalayas\n\nAdaptations at different altitudes:\n\nLower slopes:\n- Dense forests\n- Tall trees\n\nHigher slopes:\n- Stunted growth (krummholz)\n- Wind-pruned shapes\n- Ground-hugging shrubs\n- Mosses and lichens\n\nAlpine plants (above tree line):\n- Very short growing season\n- Grow close to ground\n- Hairy leaves (trap heat)\n- Dark colours (absorb heat)\n- Cushion growth form\n- Rapid flowering when snow melts\n\nThus, mountain plants are adapted to cold, snow, and wind through shape, leaf structure, and physiological mechanisms."
        },
        {
            "type": "subjective",
            "q": "What are epiphytes? Explain with examples how orchids are adapted as aerial plants.",
            "sample": "Epiphytes are plants that grow on other plants (usually trees) for physical support, but not for nutrition. They are also called aerial plants.\n\nEtymology:\n- 'Epi' means 'on top'\n- 'Phyte' means 'plant'\n\nCharacteristics of epiphytes:\n- Grow on trunks, branches of trees\n- Not parasites (don't take food from host)\n- Obtain water and nutrients from air, rain, and debris\n- Found mostly in tropical rainforests\n- Common in upper canopy for better light\n\nExamples of epiphytes:\n- Orchids\n- Mosses\n- Ferns\n- Bromeliads\n- Lichens\n- Some cacti\n\nOrchids as epiphytes:\n\nOrchids are the most common and well-adapted epiphytes. They show remarkable adaptations:\n\nA. Root adaptations:\n\n1. Two types of roots:\n   - Clinging roots: wrap around host tree for support\n   - Aerial roots: hang freely in air\n\n2. Velamen tissue:\n   - Thick, spongy covering on aerial roots\n   - Multiple layers of dead cells\n   - Absorbs moisture from air like a sponge\n   - Becomes white when dry, green when wet\n   - Protects root from damage\n\n3. Photosynthetic roots:\n   - Some orchid roots contain chlorophyll\n   - Can perform photosynthesis\n   - Helps when leaves are shaded\n\nB. Stem adaptations:\n\n4. Pseudobulbs:\n   - Swollen stem structures\n   - Store water and nutrients\n   - Help survive dry periods\n   - Present in many orchids\n\n5. Creeping stems (rhizomes):\n   - Grow along host branches\n   - Produce new shoots\n\nC. Leaf adaptations:\n\n6. Thick, waxy leaves:\n   - Reduce water loss\n   - Leathery texture\n   - Store water\n\n7. Succulent leaves:\n   - Some orchids have fleshy leaves\n   - Store water\n\n8. Curled leaves:\n   - Some species have leaves that curl\n   - Reduces surface area\n   - Minimizes transpiration\n\n9. CAM photosynthesis:\n   - Many orchids use CAM pathway\n   - Stomata open at night\n   - Reduces water loss\n\nD. Nutritional adaptations:\n\n10. Absorbing nutrients:\n    - From rain water\n    - From dust and debris on host\n    - From decaying organic matter collected around roots\n    - Some have special structures to trap leaf litter\n\n11. Mycorrhizal association:\n    - Orchid roots have fungal association\n    - Fungi help absorb nutrients\n    - Essential for seed germination\n    - Symbiotic relationship\n\nE. Reproductive adaptations:\n\n12. Tiny seeds:\n    - Millions of dust-like seeds\n    - Lightweight, carried by wind\n    - Can reach high branches\n\n13. Flowers:\n    - Bright colours attract pollinators\n    - Complex shapes for specific pollinators\n    - Long-lasting blooms\n\nAdvantages of epiphytic life:\n- Better access to sunlight (in canopy)\n- Less competition for light\n- Escape from ground herbivores\n- Better air circulation\n- Less fungal disease\n\nDisadvantages:\n- Limited water and nutrients\n- Exposure to wind\n- Risk of falling\n- Dependence on rain\n\nThus, orchids are perfectly adapted as epiphytes with specialized roots, water storage, and nutritional strategies."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of fish for living in water.",
            "sample": "Fish are aquatic animals perfectly adapted for life in water. Their adaptations include body shape, fins, gills, and other features.\n\nA. Body shape and external features:\n\n1. Streamlined body:\n   - Tapering at both ends\n   - Reduced water resistance (drag)\n   - Allows fast, efficient swimming\n   - Minimum energy expenditure\n\n2. Body covering:\n   - Covered with scales\n   - Scales overlap like roof tiles\n   - Provide protection\n   - Reduce friction\n   - Mucus coating on scales\n   - Mucus reduces friction\n   - Protects from infection\n\n3. Colouration:\n   - Dark on top, light below (countershading)\n   - Camouflage from predators\n   - Blends with water when viewed from above/below\n\nB. Locomotory adaptations (movement):\n\n4. Fins:\n   - Different types for different functions:\n   \n   a. Tail fin (caudal fin):\n      - Provides propulsion\n      - Acts as rudder for steering\n      - Powerful strokes push fish forward\n   \n   b. Dorsal fin (on back):\n      - Prevents rolling\n      - Provides stability\n   \n   c. Pectoral fins (side, behind gills):\n      - Balancing\n      - Braking\n      - Turning\n      - Slow swimming\n   \n   d. Pelvic fins (lower front):\n      - Stability\n      - Steering\n   \n   e. Anal fin (lower rear):\n      - Stability\n\n5. Body muscles:\n   - Segmented muscles (myotomes)\n   - Wave-like contractions\n   - Produce side-to-side movement\n\nC. Respiratory adaptations (breathing):\n\n6. Gills:\n   - Respiratory organs for underwater breathing\n   - Located on sides of head\n   - Covered by operculum (gill cover)\n   - Rich blood supply\n   - Large surface area\n   - Extract oxygen dissolved in water\n   - Water enters mouth, passes over gills, exits through operculum\n\n7. Counter-current exchange:\n   - Blood flows opposite to water flow\n   - Maximizes oxygen extraction\n   - Up to 80-90% oxygen extracted\n\nD. Sensory adaptations:\n\n8. Lateral line system:\n   - Row of sense organs along sides\n   - Detects water currents and vibrations\n   - Helps detect prey and predators\n   - Avoids obstacles\n\n9. Eyes:\n   - Large, on sides of head\n   - Wide field of vision\n   - No eyelids (always open)\n   - Adapted for underwater vision\n\n10. Olfactory organs (smell):\n    - Detect chemicals in water\n    - Find food, mates\n\n11. Inner ear:\n    - Detects sound vibrations\n    - Balance and orientation\n\nE. Buoyancy adaptations (floating/sinking):\n\n12. Swim bladder (air bladder):\n    - Gas-filled sac in body cavity\n    - Can adjust gas volume\n    - Increases or decreases buoyancy\n    - Fish can maintain depth without swimming\n    - Some fish lack swim bladder (sharks) and must swim constantly\n\n13. Fats and oils:\n    - Some fish store oils\n    - Lighter than water\n    - Aid buoyancy\n\nF. Other adaptations:\n\n14. Osmoregulation:\n    - Freshwater fish: excrete excess water, conserve salts\n    - Saltwater fish: drink water, excrete excess salt\n    - Maintain salt-water balance\n\n15. Reproduction:\n    - Many lay large numbers of eggs\n    - External fertilization in many\n    - Some guard eggs\n    - Some have live birth\n\n16. Feeding adaptations:\n    - Mouth position varies with feeding habit\n    - Teeth types suited to diet\n    - Filter feeders have gill rakers\n\nThus, fish are exquisitely adapted for aquatic life with streamlined body, fins for movement, gills for breathing, and swim bladder for buoyancy."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of camel for living in desert.",
            "sample": "Camel is called the 'ship of the desert' because it is perfectly adapted to survive in harsh desert conditions with extreme heat, sand, and scarce water.\n\nAdaptations of camel:\n\nA. Adaptations for water conservation:\n\n1. Water storage and use:\n   - Can drink up to 100 litres of water at once\n   - Water distributed throughout body tissues\n   - Can go without water for 10 days or more\n   - Loses water very slowly\n\n2. Minimal sweating:\n   - Sweats very little\n   - Body temperature can fluctuate (34°C to 41°C)\n   - Only sweats when temperature exceeds 41°C\n   - Conserves water by not cooling through sweat\n\n3. Concentrated urine:\n   - Kidneys produce highly concentrated urine\n   - Reabsorb most water\n   - Very little water lost in urine\n\n4. Dry faeces:\n   - Faeces contain very little water\n   - Can be used as fuel (dry)\n   - Reabsorbs water from intestines\n\n5. Slow breathing:\n   - Breathing rhythm is slow\n   - Loses little water through breath\n   - Nostrils can close to keep out sand\n\nB. Adaptations for food and energy:\n\n6. Hump:\n   - Stores fat, not water (common misconception)\n   - Fat can be converted to energy when food scarce\n   - Also produces water when fat metabolized\n   - Hump shrinks when camel uses fat\n   - Can survive up to 10 days without food\n\n7. Mouth and lips:\n   - Thick, leathery mouth lining\n   - Can eat thorny desert plants\n   - Split upper lip helps grasp plants\n   - Can close nostrils to keep out sand\n\nC. Adaptations for sand and heat:\n\n8. Feet:\n   - Large, fleshy, padded soles\n   - Spread weight on soft sand\n   - Prevent sinking\n   - Insulate from hot sand\n   - Wide surface area like snowshoes\n\n9. Legs:\n   - Long legs keep body away from hot ground\n   - Knees have thick pads for kneeling on hot sand\n\n10. Eyes:\n    - Long, thick eyelashes\n    - Protect eyes from wind-blown sand\n    - Two rows of eyelashes\n    - Third eyelid (nictitating membrane) can close to clear sand\n\n11. Nostrils:\n    - Can close completely\n    - Prevent sand inhalation during sandstorms\n    - Slit-like nostrils reduce water loss\n\n12. Ears:\n    - Small and hairy\n    - Hair prevents sand entry\n\n13. Coat:\n    - Thick coat reflects sunlight\n    - Light colour (tan/beige) reflects heat\n    - Coat insulates from both heat and cold\n    - Sheds thick winter coat in summer\n\nD. Behavioural adaptations:\n\n14. Resting posture:\n    - Sits facing sun (minimizes exposure)\n    - Keeps body close together\n\n15. Activity pattern:\n    - Feeds in early morning and evening\n    - Rests during hottest part of day\n\nE. Physiological adaptations:\n\n16. Temperature regulation:\n    - Allows body temperature to rise during day\n    - Reduces need for sweating\n    - Cools at night when temperature drops\n\n17. Blood cells:\n    - Oval-shaped RBCs (unlike humans' round)\n    - Can flow even when blood thick (dehydrated)\n    - Can rehydrate quickly without cell damage\n\n18. Kidney function:\n    - Highly efficient kidneys\n    - Reabsorb almost all water\n    - Produce very concentrated urine\n\nCamels can survive:\n- Loss of 25% body water (humans die at 12-15%)\n- Temperature from -20°C to 50°C\n- Days without food and water\n\nThus, camels have multiple adaptations - structural, physiological, and behavioural - that make them perfectly suited for desert life."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of mountain animals with examples.",
            "sample": "Mountain animals live in harsh conditions: low temperature, strong winds, snow, rugged terrain, and low oxygen. They have special adaptations to survive.\n\nExamples of mountain animals:\n- Mountain goat (ibex, markhor)\n- Yak\n- Snow leopard\n- Himalayan thar\n- Pika\n- Marmot\n- Blue sheep (bharal)\n\nAdaptations of mountain animals:\n\nA. Adaptations for cold:\n\n1. Thick fur or hair:\n   - Dense, woolly undercoat\n   - Long, coarse outer hair\n   - Traps air for insulation\n   - Yaks have long shaggy hair\n   - Snow leopards have thick fur\n\n2. Thick layer of fat:\n   - Subcutaneous fat under skin\n   - Insulates against cold\n   - Energy reserve\n\n3. Small ears and noses:\n   - Reduced surface area\n   - Minimizes heat loss\n   - Compare: Arctic animals have tiny ears\n\n4. Compact body shape:\n   - Rounded, stocky bodies\n   - Less surface area relative to volume\n   - Retains heat better\n\n5. Fur on feet:\n   - Provides insulation from snow\n   - Acts like snowshoes\n   - Prevents slipping\n\nB. Adaptations for locomotion on slopes:\n\n6. Strong hooves:\n   - Mountain goats have specialized hooves\n   - Hard outer edge for grip on rocks\n   - Soft, rubbery inner pad for traction on smooth surfaces\n   - Hooves spread when weight applied\n   - Acts like suction cup\n\n7. Cloven hooves:\n   - Split into two toes\n   - Can spread wide\n   - Provides stability\n\n8. Powerful legs:\n   - Strong muscles for climbing\n   - Can jump from rock to rock\n   - Excellent balance\n\n9. Dewclaws:\n   - Extra toes on back of legs\n   - Provide additional grip when descending\n\nC. Adaptations for breathing (low oxygen):\n\n10. Large lungs:\n     - Increased lung capacity\n     - More efficient oxygen extraction\n\n11. More red blood cells:\n     - Higher haemoglobin concentration\n     - Carries more oxygen\n\n12. Deep breathing:\n     - Slow, deep breaths\n     - Efficient gas exchange\n\nD. Adaptations for food:\n\n13. Ability to digest tough plants:\n     - Specialized stomach (ruminants)\n     - Can digest lichens, mosses\n\n14. Food storage:\n     - Some animals store food\n     - Marmots hoard food\n\n15. Migration:\n     - Move to lower slopes in winter\n     - Return to higher slopes in summer\n\nE. Behavioural adaptations:\n\n16. Hibernation:\n     - Some animals hibernate in winter\n     - Marmots, some rodents\n     - Sleep through cold months\n     - Live on stored fat\n\n17. Burrowing:\n     - Dig burrows for shelter\n     - Protect from cold and predators\n     - Pikas live in rock crevices\n\n18. Herding:\n     - Live in groups for warmth\n     - Protection from predators\n\nF. Camouflage:\n\n19. Coat colour:\n     - Snow leopards have spotted fur\n     - Blends with rocky terrain\n     - Mountain hares turn white in winter\n     - Ptarmigan (bird) changes colour seasonally\n\nSpecific examples:\n\nMountain goat (Ibex):\n- Incredible climbers\n- Specialized hooves\n- Can climb near-vertical cliffs\n- Avoids predators by reaching inaccessible places\n\nYak:\n- Long, shaggy hair\n- Large lungs\n- Sure-footed on slopes\n- Used by local people\n\nSnow leopard:\n- Thick, spotted fur\n- Long tail for balance\n- Powerful legs for jumping\n- Camouflaged in rocky terrain\n- Solitary and elusive\n\nMarmot:\n- Hibernates in winter\n- Lives in colonies\n- Whistles to warn of danger\n- Stores fat before hibernation\n\nThus, mountain animals have multiple adaptations for cold, low oxygen, and rugged terrain."
        },
        {
            "type": "subjective",
            "q": "Describe the adaptations of birds for flight (aerial adaptations).",
            "sample": "Birds are adapted for aerial life with numerous modifications in their body structure, making flight possible and efficient.\n\nA. Body shape and external features:\n\n1. Streamlined body:\n   - Boat-shaped body\n   - Tapering at both ends\n   - Reduces air resistance (drag)\n   - Allows smooth airflow\n\n2. Body covered with feathers:\n   - Feathers are modified scales\n   - Types of feathers:\n     a. Flight feathers (remiges): on wings\n     b. Tail feathers (rectrices): for steering\n     c. Contour feathers: give shape\n     d. Down feathers: insulation\n\n3. Lightweight construction:\n   - Hollow bones\n   - Air sacs\n   - No heavy teeth or jaw muscles\n   - Light beak instead of heavy jaws\n\nB. Skeletal adaptations (bones):\n\n4. Hollow bones (pneumatic bones):\n   - Bones with air cavities\n   - Strong but very light\n   - Filled with air sac extensions\n   - Reduce weight without losing strength\n   - Example: Featherweight skeleton\n\n5. No bone marrow in many bones:\n   - Further reduces weight\n   - Air spaces instead\n\n6. Fusion of bones:\n   - Some bones fused for strength\n   - Provides rigid frame for flight muscles\n   - Furcula (wishbone) acts as spring\n\n7. Keel (carina) on sternum:\n   - Large breastbone with keel\n   - Provides attachment for flight muscles\n   - Well-developed in flying birds\n   - Reduced in flightless birds\n\nC. Muscular adaptations:\n\n8. Powerful flight muscles:\n   - Pectoralis major (downstroke)\n     * Largest muscle\n     * Pulls wings down\n   - Supracoracoideus (upstroke)\n     * Lifts wings up\n   - Breast muscles can be 1/3 of body weight\n\n9. Strong leg muscles:\n   - For take-off and landing\n   - Perching\n\nD. Wing adaptations:\n\n10. Forelimbs modified into wings:\n    - Arm bones (humerus, radius, ulna)\n    - Hand bones reduced and fused\n    - Support flight feathers\n\n11. Wing shape:\n    - Curved upper surface, flat lower\n    - Creates lift (aerofoil)\n    - Air moves faster over top, slower below\n    - Pressure difference creates lift\n\n12. Different wing types:\n    - Long, narrow: soaring (albatross)\n    - Broad, rounded: maneuverability (forest birds)\n    - Pointed, swept-back: speed (swift)\n\nE. Respiratory adaptations:\n\n13. Air sacs:\n    - Balloon-like extensions of lungs\n    - 7-9 air sacs in body\n    - Extend into hollow bones\n    - Make body lighter\n    - Act as bellows\n\n14. Efficient breathing:\n    - Flow-through lungs (not in-and-out)\n    - Air flows in one direction through lungs\n    - Oxygen extracted during both inhalation and exhalation\n    - Highly efficient for flight energy needs\n\nF. Other adaptations:\n\n15. Beak instead of teeth:\n    - Lightweight\n    - Various shapes for different diets\n    - No heavy jaw muscles\n\n16. Reduced digestive system:\n    - Fast digestion\n    - Lightweight\n    - Frequent elimination\n\n17. Absence of urinary bladder:\n    - Reduces weight\n    - Urine excreted with faeces\n\n18. Reproductive adaptations:\n    - Lay eggs (not heavy developing young inside)\n    - One ovary functional (reduces weight)\n\n19. Sensory adaptations:\n    - Excellent vision\n    - Eyes large relative to head\n    - Binocular vision in many\n    - Can see UV light\n\n20. Tail feathers:\n    - Act as rudder for steering\n    - Braking during landing\n    - Balance\n\nEnergy requirements:\n- High metabolic rate\n- Warm-blooded (endothermic)\n- Eat frequently (high energy food)\n- Efficient circulation\n\nFlightless birds (ostrich, emu, penguin):\n- Reduced keel\n- Smaller flight muscles\n- Adapted for running or swimming instead\n\nThus, birds have evolved numerous adaptations - skeletal, muscular, respiratory, and others - making them masters of the air."
        }
    ]
}
