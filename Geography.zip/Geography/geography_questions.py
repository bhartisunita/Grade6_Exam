"""
Geography — Grade 6 ICSE
Comprehensive Practice Questions
Based on: Geography Textbook Chapters 3-7
5 Chapters • 120 Questions Each (40 MCQ, 40 TF, 40 Subjective)
"""

QUESTIONS = {

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 3: Major Landforms of the Earth
    # ──────────────────────────────────────────────────────────────────
    "Chapter 3 — Major Landforms of the Earth": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "What is a landform?",
            "options": [
                "A large water body",
                "A natural or artificial feature of the solid surface of the earth",
                "A type of climate",
                "A weather pattern"
            ],
            "answer": "A natural or artificial feature of the solid surface of the earth",
            "explanation": "A landform is a natural or artificial feature of the solid surface of the earth. Landforms together make up a terrain."
        },
        {
            "type": "mcq",
            "q": "What percentage of the earth's surface is covered by land?",
            "options": [
                "71%",
                "29%",
                "50%",
                "40%"
            ],
            "answer": "29%",
            "explanation": "Land covers nearly 29 per cent of the surface area of the earth, while water covers 71%."
        },
        {
            "type": "mcq",
            "q": "Internal processes that lead to the formation of landforms are called:",
            "options": [
                "Exogenous processes",
                "Endogenous processes",
                "Erosional processes",
                "Depositional processes"
            ],
            "answer": "Endogenous processes",
            "explanation": "Internal processes (endogenous) lead to the upliftment and sinking of the earth's surface, resulting in folding and faulting."
        },
        {
            "type": "mcq",
            "q": "External processes that cause wearing down of land surfaces are called:",
            "options": [
                "Endogenous processes",
                "Exogenous processes",
                "Volcanic processes",
                "Tectonic processes"
            ],
            "answer": "Exogenous processes",
            "explanation": "External processes (exogenous) cause continuous wearing down (erosion) and rebuilding (deposition) of land surfaces."
        },
        {
            "type": "mcq",
            "q": "The single big landmass that existed millions of years ago was called:",
            "options": [
                "Gondwana",
                "Laurasia",
                "Pangaea",
                "Eurasia"
            ],
            "answer": "Pangaea",
            "explanation": "Millions of years ago, there was only one big land mass called Pangaea on the surface of the earth."
        },
        {
            "type": "mcq",
            "q": "According to plate tectonics, the earth's outer shell is divided into several:",
            "options": [
                "Continents",
                "Plates",
                "Layers",
                "Crusts"
            ],
            "answer": "Plates",
            "explanation": "Plate Tectonics is a scientific theory that says the earth's outer shell or crust is divided into several plates that glide over the semi-solid mantle."
        },
        {
            "type": "mcq",
            "q": "Which is the largest continent in the world?",
            "options": [
                "Africa",
                "North America",
                "Asia",
                "Europe"
            ],
            "answer": "Asia",
            "explanation": "Asia is the largest continent, occupying about one-third of the land area of our planet."
        },
        {
            "type": "mcq",
            "q": "The combined land mass of Asia and Europe is called:",
            "options": [
                "Afro-Eurasia",
                "Eurasia",
                "Indo-Europe",
                "Supercontinent"
            ],
            "answer": "Eurasia",
            "explanation": "Asia is joined to the land mass of Europe, and we use the term Eurasia for this combined land mass."
        },
        {
            "type": "mcq",
            "q": "Which mountains separate Asia and Europe?",
            "options": [
                "The Himalayas",
                "The Alps",
                "The Ural Mountains",
                "The Andes"
            ],
            "answer": "The Ural Mountains",
            "explanation": "The Ural Mountains, the Black Sea and the Caspian Sea separate the two continents of Asia and Europe."
        },
        {
            "type": "mcq",
            "q": "Which is the second largest continent after Asia?",
            "options": [
                "Africa",
                "North America",
                "South America",
                "Antarctica"
            ],
            "answer": "Africa",
            "explanation": "Africa is the second largest continent after Asia. It is surrounded by water bodies on all sides."
        },
        {
            "type": "mcq",
            "q": "The largest hot desert in the world, the Sahara Desert, is located in:",
            "options": [
                "Asia",
                "Australia",
                "Africa",
                "North America"
            ],
            "answer": "Africa",
            "explanation": "In Africa lies the largest hot desert of the world, the Sahara Desert."
        },
        {
            "type": "mcq",
            "q": "Which continent is the third largest in size?",
            "options": [
                "Africa",
                "North America",
                "South America",
                "Europe"
            ],
            "answer": "North America",
            "explanation": "North America is the third largest continent in size. It is joined to South America by the Isthmus of Panama."
        },
        {
            "type": "mcq",
            "q": "North America is joined to South America by:",
            "options": [
                "The Isthmus of Suez",
                "The Isthmus of Panama",
                "The Bering Strait",
                "The Palk Strait"
            ],
            "answer": "The Isthmus of Panama",
            "explanation": "North America is joined to South America by a narrow stretch of land called the Isthmus of Panama."
        },
        {
            "type": "mcq",
            "q": "Which continent is shaped roughly like an inverted triangle?",
            "options": [
                "North America",
                "South America",
                "Africa",
                "Australia"
            ],
            "answer": "South America",
            "explanation": "South America is shaped roughly like an inverted triangle. On its east lies the Atlantic Ocean and on the west is the Pacific Ocean."
        },
        {
            "type": "mcq",
            "q": "Which continent is the most bleak and barren part of the world?",
            "options": [
                "Australia",
                "Antarctica",
                "Arctic",
                "Africa"
            ],
            "answer": "Antarctica",
            "explanation": "Antarctica, a large frozen land mass located in the extreme south, is the most bleak and barren part of the world."
        },
        {
            "type": "mcq",
            "q": "What percentage of the world's ice does Antarctica contain?",
            "options": [
                "50%",
                "70%",
                "90%",
                "95%"
            ],
            "answer": "90%",
            "explanation": "Antarctica contains 90 per cent of the world's ice. It is even colder than the Arctic region."
        },
        {
            "type": "mcq",
            "q": "Which continent has the most indented coastline and numerous ports?",
            "options": [
                "Asia",
                "North America",
                "Europe",
                "Australia"
            ],
            "answer": "Europe",
            "explanation": "Europe has the most indented coastline among the continents, which is why it has numerous ports and some of the finest harbours."
        },
        {
            "type": "mcq",
            "q": "Australia is sometimes called:",
            "options": [
                "The Land Above",
                "The Land Down Under",
                "The Island Above",
                "The Frozen Continent"
            ],
            "answer": "The Land Down Under",
            "explanation": "Australia is sometimes called 'the Land Down Under' as it lies to the south of the main land masses."
        },
        {
            "type": "mcq",
            "q": "Australia is also called the 'island continent' because:",
            "options": [
                "It is very small",
                "It has water on all sides",
                "It has many islands around it",
                "It is connected to Asia"
            ],
            "answer": "It has water on all sides",
            "explanation": "As there is water on all sides of Australia, it is an island and is, therefore, also called the 'island continent'."
        },
        {
            "type": "mcq",
            "q": "Mountains that are formed due to the compression of tectonic plates are called:",
            "options": [
                "Block mountains",
                "Volcanic mountains",
                "Fold mountains",
                "Residual mountains"
            ],
            "answer": "Fold mountains",
            "explanation": "Fold mountains are formed when the layers of the earth's tectonic plates get folded due to compression."
        },
        {
            "type": "mcq",
            "q": "Which of the following is an example of old fold mountains?",
            "options": [
                "The Himalayas",
                "The Andes",
                "The Appalachians",
                "The Rockies"
            ],
            "answer": "The Appalachians",
            "explanation": "Old fold mountains have gentle slopes and low altitude. Examples: Aravallis in India, Appalachians in North America, and Urals in Russia."
        },
        {
            "type": "mcq",
            "q": "Which of the following is an example of young fold mountains?",
            "options": [
                "The Aravallis",
                "The Appalachians",
                "The Urals",
                "The Himalayas"
            ],
            "answer": "The Himalayas",
            "explanation": "Young fold mountains have steep slopes and high altitude. Examples: Himalayas, Rockies, Andes, and Alps."
        },
        {
            "type": "mcq",
            "q": "The process of rupturing or fracturing of rock strata due to strain is called:",
            "options": [
                "Folding",
                "Faulting",
                "Erosion",
                "Deposition"
            ],
            "answer": "Faulting",
            "explanation": "Faulting is the rupturing or fracturing of rock strata due to strain, which leads to the formation of block mountains."
        },
        {
            "type": "mcq",
            "q": "Mountains formed due to faulting are called:",
            "options": [
                "Fold mountains",
                "Volcanic mountains",
                "Block mountains",
                "Residual mountains"
            ],
            "answer": "Block mountains",
            "explanation": "Block mountains are formed when large blocks of the earth's crust are uplifted or tilted due to faulting."
        },
        {
            "type": "mcq",
            "q": "The Vosges mountain in Europe is an example of:",
            "options": [
                "Fold mountain",
                "Block mountain",
                "Volcanic mountain",
                "Residual mountain"
            ],
            "answer": "Block mountain",
            "explanation": "The Vosges mountain in Europe and the Vindhyas in India are examples of block mountains."
        },
        {
            "type": "mcq",
            "q": "The depression formed when the land between two parallel faults sinks is called:",
            "options": [
                "Valley",
                "Rift valley",
                "Gorge",
                "Canyon"
            ],
            "answer": "Rift valley",
            "explanation": "When the land between two parallel faults sinks, it forms a rift valley. The Narmada Valley in India is an example."
        },
        {
            "type": "mcq",
            "q": "The opening through which lava and other materials come to the surface in a volcano is called:",
            "options": [
                "Crater",
                "Vent",
                "Magma chamber",
                "Fissure"
            ],
            "answer": "Vent",
            "explanation": "The opening through which lava and other materials come to the surface is called a vent."
        },
        {
            "type": "mcq",
            "q": "The funnel-shaped depression at the top of a volcano's vent is called:",
            "options": [
                "Vent",
                "Crater",
                "Caldera",
                "Fissure"
            ],
            "answer": "Crater",
            "explanation": "The funnel-shaped depression at the top of a vent is called a crater."
        },
        {
            "type": "mcq",
            "q": "Mt Fuji in Japan is an example of which type of mountain?",
            "options": [
                "Fold mountain",
                "Block mountain",
                "Volcanic mountain",
                "Residual mountain"
            ],
            "answer": "Volcanic mountain",
            "explanation": "Volcanic mountains include Mt Fuji in Japan, Mt Mayon in the Philippines, and Mt Kilimanjaro in Tanzania."
        },
        {
            "type": "mcq",
            "q": "Which plateau is called the 'roof of the world'?",
            "options": [
                "Deccan Plateau",
                "Tibetan Plateau",
                "Colorado Plateau",
                "East African Plateau"
            ],
            "answer": "Tibetan Plateau",
            "explanation": "The Tibetan Plateau is the highest plateau in the world, surrounded by the Himalayan Mountains and the Kunlun Shan."
        },
        {
            "type": "mcq",
            "q": "The Deccan Plateau in India is an example of which type of plateau?",
            "options": [
                "Tectonic plateau",
                "Volcanic plateau",
                "Dissected plateau",
                "Intermontane plateau"
            ],
            "answer": "Volcanic plateau",
            "explanation": "The north-western part of the Deccan Plateau and the Malwa Plateau are examples of volcanic plateaus."
        },
        {
            "type": "mcq",
            "q": "The Colorado Plateau, through which the Grand Canyon passes, is an example of:",
            "options": [
                "Tectonic plateau",
                "Volcanic plateau",
                "Dissected plateau",
                "Piedmont plateau"
            ],
            "answer": "Dissected plateau",
            "explanation": "Dissected plateaus have irregular surfaces marked by canyons, gorges, and steep valleys. The Colorado Plateau is an example."
        },
        {
            "type": "mcq",
            "q": "A plateau that lies between a mountain and a plain is called:",
            "options": [
                "Intermontane plateau",
                "Piedmont plateau",
                "Volcanic plateau",
                "Tectonic plateau"
            ],
            "answer": "Piedmont plateau",
            "explanation": "Piedmont plateau lies between a mountain and a plain. Examples: Patagonia Plateau in South America, Piedmont Plateau of North America."
        },
        {
            "type": "mcq",
            "q": "Low-lying lands between hills or mountains are called:",
            "options": [
                "Plains",
                "Plateaus",
                "Valleys",
                "Basins"
            ],
            "answer": "Valleys",
            "explanation": "Valleys are low-lying lands between hills or mountains formed by exogenous processes like rivers or plate movements."
        },
        {
            "type": "mcq",
            "q": "The Narmada Valley in India is an example of which type of valley?",
            "options": [
                "River valley",
                "Glacial valley",
                "Rift valley",
                "U-shaped valley"
            ],
            "answer": "Rift valley",
            "explanation": "The Narmada Valley in India and the Nile Valley in Egypt are examples of rift valleys."
        },
        {
            "type": "mcq",
            "q": "Valleys formed by rivers are usually shaped like:",
            "options": [
                "U",
                "V",
                "W",
                "S"
            ],
            "answer": "V",
            "explanation": "River valleys are usually V-shaped. The Rhine Valley in Europe and the Damodar Valley in India are examples."
        },
        {
            "type": "mcq",
            "q": "Valleys formed by glaciers are shaped like:",
            "options": [
                "V",
                "U",
                "W",
                "S"
            ],
            "answer": "U",
            "explanation": "Valleys formed by glaciers are U-shaped. Many such glaciers are present in the Alps and the Himalayas."
        },
        {
            "type": "mcq",
            "q": "Vast, nearly flat expanses of land less than 200 metres above sea level are called:",
            "options": [
                "Plateaus",
                "Plains",
                "Valleys",
                "Mountains"
            ],
            "answer": "Plains",
            "explanation": "Plains or lowlands are vast, nearly flat expanses of land which are usually less than 200 metres above sea level."
        },
        {
            "type": "mcq",
            "q": "Plains built by alluvium deposited by rivers are called:",
            "options": [
                "Structural plains",
                "Erosional plains",
                "Depositional plains",
                "River plains"
            ],
            "answer": "Depositional plains",
            "explanation": "Depositional plains are formed by sediments brought down by natural agents from mountains. River plains are depositional plains."
        },
        {
            "type": "mcq",
            "q": "A piece of land surrounded on all sides by water is called:",
            "options": [
                "Peninsula",
                "Isthmus",
                "Island",
                "Strait"
            ],
            "answer": "Island",
            "explanation": "An island is a piece of land which is surrounded on all sides by water. India has two groups of islands - Lakshadweep and Andaman & Nicobar."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "Landforms are only natural features of the earth's surface.",
            "answer": "False",
            "explanation": "A landform is a natural or artificial feature of the solid surface of the earth. Some landforms can be man-made."
        },
        {
            "type": "tf",
            "q": "Topography refers to the arrangement of landforms in the landscape.",
            "answer": "True",
            "explanation": "Landforms together make up a terrain, and their arrangements in the landscape is known as topography."
        },
        {
            "type": "tf",
            "q": "Internal processes of the earth are also called exogenous processes.",
            "answer": "False",
            "explanation": "Internal processes are called endogenous processes. External processes are called exogenous processes."
        },
        {
            "type": "tf",
            "q": "Erosion is the rebuilding of a lowered surface.",
            "answer": "False",
            "explanation": "Erosion is the wearing away of the earth's surface. Deposition is the rebuilding of a lowered surface."
        },
        {
            "type": "tf",
            "q": "Pangaea was the single big land mass that existed millions of years ago.",
            "answer": "True",
            "explanation": "Millions of years ago, there was only one big land mass called Pangaea on the surface of the earth."
        },
        {
            "type": "tf",
            "q": "The movement of tectonic plates can only cause earthquakes, not volcanic eruptions.",
            "answer": "False",
            "explanation": "The movement of tectonic plates can cause earthquakes, volcanic eruptions, and the formation of mountains."
        },
        {
            "type": "tf",
            "q": "Continents are surrounded by vast water bodies called oceans on all sides.",
            "answer": "True",
            "explanation": "Continents are very large land masses that are surrounded by vast water bodies called oceans on all sides."
        },
        {
            "type": "tf",
            "q": "There are eight continents in the world.",
            "answer": "False",
            "explanation": "There are seven continents in the world: Asia, Africa, North America, South America, Antarctica, Europe, and Australia."
        },
        {
            "type": "tf",
            "q": "Asia occupies about half of the land area of our planet.",
            "answer": "False",
            "explanation": "Asia occupies about one-third of the land area of our planet, not half."
        },
        {
            "type": "tf",
            "q": "The Mediterranean Sea separates Africa from Europe.",
            "answer": "True",
            "explanation": "In the north, the Mediterranean Sea separates Africa from Europe."
        },
        {
            "type": "tf",
            "q": "Antarctica is the most bleak and barren part of the world.",
            "answer": "True",
            "explanation": "Antarctica is almost circular in shape, contains 90% of the world's ice, and is the most bleak and barren part of the world."
        },
        {
            "type": "tf",
            "q": "Europe is larger than Australia but smaller than Antarctica.",
            "answer": "False",
            "explanation": "Europe is smaller in size compared to other continents but has some of the most developed nations."
        },
        {
            "type": "tf",
            "q": "Australia is both a country and a continent.",
            "answer": "True",
            "explanation": "Australia is the smallest continent and also a country. It is called the 'island continent'."
        },
        {
            "type": "tf",
            "q": "Subduction is the process where the heavier plate goes below the lighter plate during collision.",
            "answer": "False",
            "explanation": "Subduction is when the collision of two plates pushes the lighter plate below the heavier plate, not the other way around."
        },
        {
            "type": "tf",
            "q": "Old fold mountains have steep slopes and high altitude.",
            "answer": "False",
            "explanation": "Old fold mountains have gentle slopes and low altitude. Young fold mountains have steep slopes and high altitude."
        },
        {
            "type": "tf",
            "q": "The Aravallis in India are an example of young fold mountains.",
            "answer": "False",
            "explanation": "The Aravallis are old fold mountains. The Himalayas are young fold mountains."
        },
        {
            "type": "tf",
            "q": "Faulting is the rupturing or fracturing of rock strata due to strain.",
            "answer": "True",
            "explanation": "Faulting leads to the formation of block mountains and rift valleys."
        },
        {
            "type": "tf",
            "q": "Block mountains are formed when land between two faults sinks.",
            "answer": "False",
            "explanation": "When land between two faults sinks, it forms a rift valley. Block mountains are uplifted blocks."
        },
        {
            "type": "tf",
            "q": "The Narmada Valley in India is a rift valley.",
            "answer": "True",
            "explanation": "The Narmada Valley in India and the Nile Valley in Egypt are examples of rift valleys."
        },
        {
            "type": "tf",
            "q": "Volcanic mountains are built by the accumulation of lava, ash, and cinder.",
            "answer": "True",
            "explanation": "Volcanic mountains are built when molten lava, ash, cinder, and dust accumulate in the shape of high cones."
        },
        {
            "type": "tf",
            "q": "Mountains store water in the form of glaciers, which are sources of rivers.",
            "answer": "True",
            "explanation": "Many rivers originate in the glaciers in the mountains. Reservoirs store this water for irrigation and hydroelectricity."
        },
        {
            "type": "tf",
            "q": "The Himalayas cause rainfall in India by blocking the north-east monsoon winds.",
            "answer": "False",
            "explanation": "The Himalayas cause rainfall in India by blocking the south-west monsoon winds, not the north-east monsoon."
        },
        {
            "type": "tf",
            "q": "Plateaux are uplifted sections of the earth's crust that are almost flat or level.",
            "answer": "True",
            "explanation": "Plateaux are uplifted sections of the earth's crust that are almost flat and usually descend steeply to surrounding lowlands."
        },
        {
            "type": "tf",
            "q": "The Plateau of Tibet is an example of a tectonic plateau.",
            "answer": "False",
            "explanation": "The Plateau of Tibet is an intermontane plateau, enclosed by the Himalayan Mountains and the Kunlun Shan."
        },
        {
            "type": "tf",
            "q": "The Columbia Plateau in the USA is an example of a volcanic plateau.",
            "answer": "True",
            "explanation": "The extensive Columbia Plateau in the north-western part of the USA is an example of a volcanic plateau."
        },
        {
            "type": "tf",
            "q": "The Chota Nagpur Plateau in India is a storehouse of mineral wealth.",
            "answer": "True",
            "explanation": "The Deccan Plateau is fertile, while the Chota Nagpur Plateau is a storehouse of mineral wealth."
        },
        {
            "type": "tf",
            "q": "A basin is a depressed section of the earth's crust surrounded by higher land.",
            "answer": "True",
            "explanation": "The Tarim and Tsaidam Basins of Asia and the Chad Basin of north-central Africa are basins of inland drainage."
        },
        {
            "type": "tf",
            "q": "The rivers flowing in inland drainage basins eventually reach the sea.",
            "answer": "False",
            "explanation": "In inland drainage basins, the rivers flowing in the basin do not reach the sea."
        },
        {
            "type": "tf",
            "q": "River plains are fertile and easy for constructing roads and railways.",
            "answer": "True",
            "explanation": "River plains are fertile due to alluvium. The flat nature of land makes it easy to construct roads and railways."
        },
        {
            "type": "tf",
            "q": "Structural plains are formed by the uplift of a part of the seafloor.",
            "answer": "True",
            "explanation": "Structural plains are mainly formed by the uplift of a part of the seafloor or continental shelf due to endogenetic movements."
        },
        {
            "type": "tf",
            "q": "Erosional plains are formed by sediments brought down by natural agents.",
            "answer": "False",
            "explanation": "Erosional plains result from the erosion of mountains, hills, and plateaux. Depositional plains are formed by sediments."
        },
        {
            "type": "tf",
            "q": "A peneplain is a level land surface produced by erosion over a long period.",
            "answer": "True",
            "explanation": "Peneplain is a level land surface produced by erosion over a long period, undisturbed by crustal movement."
        },
        {
            "type": "tf",
            "q": "The Indo-Gangetic Plain is one of the most sparsely populated regions in the world.",
            "answer": "False",
            "explanation": "The Indo-Gangetic Plain, Mississippi Plain, and Yangtze Plain support large populations and are granaries of the world."
        },
        {
            "type": "tf",
            "q": "Plains are the cradles of ancient civilizations.",
            "answer": "True",
            "explanation": "Plains of the world were the cradles of ancient civilizations like the Indus Valley, Mesopotamian, and Chinese civilizations."
        },
        {
            "type": "tf",
            "q": "India has only one group of islands - the Andaman and Nicobar Islands.",
            "answer": "False",
            "explanation": "India has two groups of islands - the Lakshadweep Islands in the Arabian Sea and the Andaman and Nicobar Islands in the Bay of Bengal."
        },
        {
            "type": "tf",
            "q": "A peninsula is a piece of land surrounded by water on three sides.",
            "answer": "True",
            "explanation": "A peninsula is surrounded by water on three sides and joined to a larger land mass. The peninsular plateau of India is an example."
        },
        {
            "type": "tf",
            "q": "The Malay Peninsula and the Indian peninsula are examples of islands.",
            "answer": "False",
            "explanation": "They are examples of peninsulas attached to the continent of Asia, not islands."
        },
        {
            "type": "tf",
            "q": "An isthmus is an elongated narrow piece of land joining two large land masses.",
            "answer": "True",
            "explanation": "The Isthmus of Panama joins North America and South America. The Isthmus of Suez joins Africa to Asia."
        },
        {
            "type": "tf",
            "q": "Sri Lanka is an island located off the coast of India.",
            "answer": "True",
            "explanation": "Sri Lanka is an island just south of India, in the Indian Ocean. Madagascar is another big island in the same ocean."
        },
        {
            "type": "tf",
            "q": "The Isthmus of Suez separates the Mediterranean Sea and the Red Sea.",
            "answer": "True",
            "explanation": "The Isthmus of Suez joins Africa to Asia and separates the Mediterranean Sea and the Red Sea."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "What are landforms? Explain the two processes that result in the formation of landforms.",
            "sample": "A landform is a natural or artificial feature of the solid surface of the earth. Landforms together make up a terrain, and their arrangement in the landscape is known as topography.\n\nLandforms are a result of two processes:\n\n1. Internal processes (Endogenous):\n   - These processes lead to the upliftment (upward movement) and sinking (downward movement) of the earth's surface.\n   - The movement results in the formation of folding and faulting.\n   - Examples: Formation of mountains, plateaus, etc.\n\n2. External processes (Exogenous):\n   - These processes cause the continuous wearing down and rebuilding of the land surfaces.\n   - They include:\n     a. Erosion: The wearing away of the earth's surface\n     b. Deposition: The rebuilding of a lowered surface\n   - These processes are carried out by running water, ice, wind, the atmosphere, and human activities.\n   - Examples: Formation of valleys, deltas, etc.\n\nLand covers nearly 29 per cent of the surface area of the earth, but it is not the same everywhere. At some places the land is flat and low-lying, while at other places, it may be hilly or mountainous. All these features play an important role in sustaining life on earth."
        },
        {
            "type": "subjective",
            "q": "What is Pangaea? Explain the theory of plate tectonics briefly.",
            "sample": "Pangaea was the single big land mass that existed on the surface of the earth millions of years ago. It was surrounded by a vast ocean called Panthalassa.\n\nOver millions of years, Pangaea broke apart due to tectonic forces, and the fragments drifted to form the continents we see today.\n\nPlate Tectonics theory:\n\n- The earth's outer shell or the crust is divided into several plates (large blocks of crust).\n- These plates glide over the semi-solid mantle (the layer below the crust).\n- The movement of these plates can cause:\n  * Earthquakes: When plates suddenly slip past each other\n  * Volcanic eruptions: When magma rises through cracks between plates\n  * Formation of mountains: When plates collide and push up land\n\nKey points about plate tectonics:\n- Plates move very slowly (a few centimetres per year)\n- There are major plates like the Eurasian Plate, Indo-Australian Plate, Pacific Plate, North American Plate, etc.\n- The boundaries where plates meet are called plate boundaries\n- Three types of plate boundaries:\n  * Convergent (plates moving towards each other)\n  * Divergent (plates moving apart)\n  * Transform (plates sliding past each other)\n\nThis theory helps explain the distribution of earthquakes, volcanoes, and mountain ranges around the world."
        },
        {
            "type": "subjective",
            "q": "List the seven continents according to size. Describe the largest continent in detail.",
            "sample": "The seven continents in order of size (largest to smallest):\n\n1. Asia\n2. Africa\n3. North America\n4. South America\n5. Antarctica\n6. Europe\n7. Australia\n\nAsia - The Largest Continent:\n\nSize and location:\n- Asia is the largest continent, occupying about one-third of the land area of our planet.\n- It is joined to the land mass of Europe, forming Eurasia.\n- The Ural Mountains, the Black Sea and the Caspian Sea separate the two continents.\n\nSurrounding oceans:\n- To its north lies the Arctic Ocean\n- To its east is the Pacific Ocean\n- To its south is the Indian Ocean\n\nPhysical features:\n- Home to the world's highest mountain range - the Himalayas\n- Contains Mount Everest, the world's highest peak\n- Has vast plains like the Indo-Gangetic Plain\n- Includes large plateaus like the Tibetan Plateau (called the 'roof of the world')\n- Major rivers: Yangtze, Ganga, Indus, Mekong\n\nClimate:\n- Extremely diverse, from the frozen tundra of Siberia to tropical rainforests of Southeast Asia\n- Experiences monsoon winds that bring seasonal rainfall\n\nCountries and population:\n- Largest population among all continents\n- Home to China and India, the two most populous countries\n- Includes Russia (partly), Japan, Indonesia, and many other nations\n\nEconomic importance:\n- Rich in mineral resources\n- Major agricultural producer (rice, wheat, tea)\n- Industrial powerhouses like China, Japan, South Korea\n- Important trade routes through the Indian Ocean and South China Sea"
        },
        {
            "type": "subjective",
            "q": "Describe the continent of Africa. What are its major features?",
            "sample": "Africa is the second largest continent after Asia. It is surrounded by water bodies on all sides.\n\nLocation and boundaries:\n- In the north, the Mediterranean Sea separates it from Europe\n- To its east is the Indian Ocean\n- The Atlantic Ocean in the west separates it from the two Americas\n\nMajor physical features:\n\n1. Deserts:\n   - The Sahara Desert: Largest hot desert in the world\n   - Covers much of North Africa\n   - Area about 9.2 million square kilometres\n\n2. Rivers:\n   - The Nile: World's longest river (6,695 km)\n   - Flows through Uganda, South Sudan, Sudan, Egypt\n   - Drains into the Mediterranean Sea\n   - Congo River: Second largest in Africa by volume\n\n3. Mountains:\n   - Mount Kilimanjaro: Highest peak in Africa (5,895 m)\n   - A volcanic mountain in Tanzania\n   - Atlas Mountains in North Africa\n\n4. Plateaus:\n   - East African Plateau\n   - Contains the Great Rift Valley\n   - Rich in minerals\n\n5. Lakes:\n   - Lake Victoria: Largest lake in Africa\n   - Main reservoir of the Nile River\n   - Lies mainly in Tanzania and Uganda, bordering Kenya\n\n6. Forests:\n   - Congo Basin rainforest\n   - Second largest rainforest in the world\n\nClimate:\n- Extremely diverse\n- Equatorial regions have tropical rainforest climate\n- North and south have desert and semi-arid regions\n- Mediterranean climate in extreme north and south\n\nNatural resources:\n- Rich in minerals: gold, diamonds, copper, manganese, chromium\n- South African Plateau yields gold and diamond\n- Oil and gas in Nigeria, Angola, Algeria\n\nCountries and culture:\n- 54 countries\n- Diverse cultures, languages, and ethnic groups\n- Egypt has ancient civilization (pyramids)\n\nChallenges:\n- Desertification in Sahara region\n- Deforestation in Congo Basin\n- Some regions face food and water scarcity"
        },
        {
            "type": "subjective",
            "q": "Describe the continent of Antarctica. Why is it important for scientific research?",
            "sample": "Antarctica is a large frozen land mass located in the extreme south, surrounding the South Pole. It is the most bleak and barren part of the world.\n\nPhysical features:\n- Almost circular in shape\n- Contains 90 per cent of the world's ice\n- Ice sheet averages about 2,000 metres in thickness\n- If all ice melted, sea levels would rise about 60 metres\n- It is even colder than the Arctic region\n- Surrounded by the stormiest seas in the world\n\nClimate:\n- Coldest place on Earth\n- Lowest recorded temperature: -89.2°C\n- Extremely dry (technically a desert)\n- Strong katabatic winds\n- Six months of continuous daylight, six months of darkness\n\nFlora and fauna:\n- Very few plants (mosses, lichens)\n- No land mammals\n- Rich marine life around coasts\n- Penguins (Emperor, Adélie)\n- Seals (Weddell, Leopard, Elephant)\n- Whales, krill\n\nResearch stations:\n- Several countries have set up research stations\n- India has research stations: Dakshin Gangotri, Maitri, Bharati\n- Conduct research in various fields\n\nScientific importance:\n\n1. Climate research:\n   - Ice cores reveal past climate (up to 800,000 years)\n   - Helps understand global warming\n   - Study of ozone layer (ozone hole discovered here)\n\n2. Earth sciences:\n   - Study of plate tectonics\n   - Geology of Gondwana supercontinent\n   - Meteorites preserved in ice\n\n3. Biology:\n   - Unique ecosystems\n   - Extremophiles (organisms living in extreme conditions)\n   - Marine biology studies\n\n4. Astronomy:\n   - Clear, dry air excellent for telescopes\n   - South Pole telescope\n\n5. Human physiology and medicine:\n   - Effects of isolation and extreme cold\n   - Circadian rhythm studies\n\nInternational cooperation:\n- Antarctic Treaty (1959)\n- Dedicated to peaceful purposes only\n- No military activities\n- Freedom of scientific investigation\n- No nuclear explosions or waste disposal\n- 54 countries have signed\n\nEnvironmental concerns:\n- Climate change affecting ice sheets\n- Ozone depletion\n- Potential for tourism impact\n- Pollution from research stations\n\nAntarctica remains a unique continent dedicated to science and peace, holding keys to understanding our planet's past, present, and future."
        },
        {
            "type": "subjective",
            "q": "What are fold mountains? Explain their formation and give examples of old and young fold mountains.",
            "sample": "Fold mountains are mountains that are formed when the layers of the earth's tectonic plates get folded due to compression. They are the most common type of mountains.\n\nFormation of fold mountains:\n\n1. Plate collision:\n   - When two tectonic plates move towards each other (convergent boundary)\n   - The sedimentary rocks between them are compressed\n   - Instead of breaking, they fold like a rug pushed from both ends\n\n2. Folding process:\n   - Layers of rock bend into folds\n   - Upward folds are called anticlines\n   - Downward folds are called synclines\n   - Repeated folding over millions of years\n   - Rocks are uplifted to great heights\n\n3. Example of formation:\n   - The Himalayas formed when the Indo-Australian Plate collided with the Eurasian Plate\n   - The Tethys Sea sediments were compressed and folded\n   - Process started about 50 million years ago and continues today\n\nCharacteristics of fold mountains:\n- Long chains (mountain ranges)\n- Parallel ridges and valleys\n- Often have volcanic activity\n- Rich in minerals\n\nTypes of fold mountains based on age:\n\nA. Old fold mountains:\n   - Formed millions of years ago\n   - Have gentle slopes\n   - Lower altitude due to erosion over time\n   - Rounded peaks\n   \n   Examples:\n   - The Aravallis in India\n   - The Appalachians in North America\n   - The Urals in Russia\n   - The Scottish Highlands\n\nB. Young fold mountains:\n   - Formed relatively recently (last few million years)\n   - Have steep slopes\n   - High altitude\n   - Sharp peaks\n   - Still rising\n   \n   Examples:\n   - The Himalayas in Asia\n   - The Rockies in North America\n   - The Andes in South America\n   - The Alps in Europe\n   - The Atlas in Africa\n\nImportance of fold mountains:\n- Sources of rivers (glaciers)\n- Mineral deposits\n- Tourist attractions\n- Climate barriers (cause rainfall on windward side)\n- Biodiversity hotspots\n\nThus, fold mountains are dynamic features that continue to shape our planet's landscape."
        },
        {
            "type": "subjective",
            "q": "What are block mountains? How are they formed? Give examples.",
            "sample": "Block mountains are mountains formed when large blocks of the earth's crust are uplifted or tilted due to faulting. They are also called fault-block mountains.\n\nFormation of block mountains:\n\n1. Faulting:\n   - Faulting is the rupturing or fracturing of rock strata due to strain\n   - Tectonic forces create tension or compression in the crust\n   - The crust cracks along lines of weakness called faults\n\n2. Types of faulting:\n   - Normal fault: When rocks are pulled apart (tension)\n   - Reverse fault: When rocks are pushed together (compression)\n   - Strike-slip fault: When rocks slide past each other\n\n3. Formation process:\n   - Due to tension, the crust cracks into blocks\n   - Some blocks are uplifted (horsts)\n   - Some blocks sink down (grabens)\n   - The uplifted blocks form block mountains\n   - The sunken blocks form rift valleys\n\n4. Types of block mountains:\n   \n   a. Horst mountains:\n      - Block uplifted between two parallel faults\n      - Example: The Vosges mountains in Europe\n   \n   b. Tilted block mountains:\n      - Block tilted along a fault\n      - One side steep, other side gentle slope\n      - Example: Sierra Nevada in USA\n\nCharacteristics of block mountains:\n- Steep sides\n- Flat or gently sloping tops\n- Associated with rift valleys\n- Often have steep escarpments\n\nExamples of block mountains:\n\n1. The Vosges mountains (Europe):\n   - Located in eastern France\n   - Formed by faulting\n   - Associated with the Rhine Rift Valley\n\n2. The Black Forest (Germany):\n   - Located in southwestern Germany\n   - Also called Schwarzwald\n   - Uplifted block\n\n3. The Vindhyas (India):\n   - Range in central India\n   - Example of block mountains in India\n\n4. The Satpuras (India):\n   - Also in central India\n   - Associated with the Narmada Rift Valley\n\n5. Sierra Nevada (USA):\n   - Tilted block mountain\n   - Located in California\n   - Steep east face, gentle west slope\n\n6. The Harz mountains (Germany):\n   - Uplifted block\n\nAssociated features - Rift valleys:\n- When the block between two parallel faults sinks, it forms a rift valley\n- Examples:\n  * The Rhine Rift Valley (between Vosges and Black Forest)\n  * The Narmada Valley in India\n  * The East African Rift Valley\n\nThus, block mountains are formed by vertical movements of the earth's crust along faults, creating spectacular landscapes."
        },
        {
            "type": "subjective",
            "q": "What are volcanic mountains? Describe their formation with examples and a labeled diagram.",
            "sample": "Volcanic mountains are mountains built when molten lava, ash, cinder, and dust from deep inside the earth come out on the surface through cracks in the earth's crust and accumulate in the shape of high cones.\n\nFormation of volcanic mountains:\n\n1. Magma formation:\n   - Inside the earth, temperatures are extremely high\n   - Rocks melt to form magma (molten rock)\n   - Magma is lighter than surrounding rocks\n   - It rises towards the surface through cracks and weak points\n\n2. Volcanic eruption:\n   - Magma reaches the surface through a vent\n   - Erupts as lava, ash, cinder, and dust\n   - Materials accumulate around the vent\n\n3. Cone formation:\n   - Successive eruptions build up layers\n   - Lava cools and solidifies\n   - Ash and cinder add to the height\n   - Over time, a cone-shaped mountain forms\n\nParts of a volcanic mountain (with diagram):\n\n1. Vent:\n   - The opening through which lava and other materials come to the surface\n   - Acts as a passage for magma\n\n2. Crater:\n   - Funnel-shaped depression at the top of the vent\n   - Bowl-like hollow at the summit\n\n3. Magma chamber:\n   - Underground reservoir of magma\n   - Source of volcanic material\n\n4. Lava layers:\n   - Successive layers of solidified lava\n   - Build the cone\n\n5. Ash and cinder layers:\n   - Alternate with lava layers\n   - Contribute to the cone structure\n\n6. Secondary cone:\n   - Smaller cone formed by side eruptions\n\nCharacteristics of volcanic mountains:\n- Cone-shaped\n- Have a crater at the top\n- Often isolated (not in ranges)\n- Found along plate boundaries\n- Can be active, dormant, or extinct\n\nExamples of volcanic mountains:\n\n1. Mount Fuji (Japan):\n   - Iconic symbol of Japan\n   - 3,776 metres high\n   - Beautiful symmetrical cone\n   - Last erupted in 1707\n\n2. Mount Mayon (Philippines):\n   - Known for perfect cone shape\n   - Most active volcano in Philippines\n\n3. Mount Kilimanjaro (Tanzania):\n   - Highest peak in Africa (5,895 m)\n   - Three volcanic cones (Kibo, Mawenzi, Shira)\n   - Snow-capped despite being near equator\n\n4. Mount Vesuvius (Italy):\n   - Famous for destroying Pompeii in 79 AD\n   - Only active volcano in mainland Europe\n\n5. Mount Etna (Italy):\n   - One of the most active volcanoes\n   - In Sicily\n\n6. Mount Krakatoa (Indonesia):\n   - Famous for catastrophic 1883 eruption\n\nTypes based on activity:\n- Active: Erupting frequently (Etna)\n- Dormant: Not erupted recently but may erupt (Fuji)\n- Extinct: Not expected to erupt again (Kilimanjaro)\n\nThus, volcanic mountains are created by the accumulation of erupted materials, forming some of the world's most spectacular peaks."
        },
        {
            "type": "subjective",
            "q": "Explain the importance of mountains in our life.",
            "sample": "Mountains are extremely important for life on Earth and provide numerous benefits to humanity. Their importance can be understood through various aspects:\n\n1. Storehouse of water:\n   - Mountains receive heavy snowfall and rainfall\n   - Snow accumulates as glaciers\n   - Glaciers melt slowly, providing water throughout the year\n   - Many rivers originate in the glaciers in the mountains\n   - Examples: Ganga, Yamuna, Indus originate in Himalayas\n\n2. Source of rivers:\n   - Mountain glaciers and springs feed rivers\n   - Rivers flow down to plains, providing water for millions\n   - River water used for drinking, irrigation, and industry\n\n3. Hydroelectric power generation:\n   - Reservoirs are made in mountains\n   - Fast-flowing rivers generate hydroelectricity\n   - Clean, renewable energy source\n\n4. Irrigation and agriculture:\n   - River valleys and terraces are most suitable for farming\n   - Land is very fertile due to silt deposition\n   - Terrace farming practiced on mountain slopes\n   - Crops like tea, coffee, apples grown in mountains\n\n5. Rich biodiversity:\n   - Mountains support a rich variety of flora and fauna\n   - Different altitudes have different ecosystems\n   - Many endemic species found only in mountains\n   - National parks and sanctuaries protect wildlife\n\n6. Climate regulation:\n   - Mountains affect the climate of an area\n   - The Himalayas cause rainfall in India by blocking the south-west monsoon winds\n   - They force moist winds to rise and cool, causing rain\n   - They protect us from the cold winds of Central Asia in winter\n\n7. Mineral and metal deposits:\n   - Mountains are rich in mineral and metal deposits\n   - Essential for industries\n   - Examples: Coal, iron ore, copper, gold\n\n8. Home to people:\n   - According to UNDP, mountains provide home for around 720 million people\n   - Indigenous communities have unique cultures\n   - Traditional knowledge of mountain ecosystems\n\n9. Forest products:\n   - Forests in mountainous regions provide fuel, fodder, shelter\n   - Other products like gum, wild fruits, mushrooms, resins\n   - Medicinal plants found in mountains\n\n10. Tourism and recreation:\n    - Mountains provide ideal holiday destinations\n    - Natural scenic beauty attracts tourists\n    - Recreation, sporting, and tourism activities:\n      * Paragliding, hang gliding\n      * River rafting\n      * Skiing\n      * Trekking and mountaineering\n      * Wildlife viewing\n\n11. Spiritual and cultural significance:\n    - Many mountains considered sacred\n    - Pilgrimage sites in mountains\n    - Monasteries and temples\n    - Source of inspiration for art and literature\n\n12. Defence and strategic importance:\n    - Mountains form natural boundaries between countries\n    - Difficult terrain provides strategic advantage\n    - Border outposts in high mountains\n\nThus, mountains are not just landforms but vital resources that sustain life, economy, and culture. Despite their harsh conditions, they are indispensable for human civilization."
        },
        {
            "type": "subjective",
            "q": "Though mountains offer many advantages, people still prefer to live in plains. Why?",
            "sample": "Although mountains offer numerous advantages, most people prefer to live in plains due to several practical reasons related to livelihood, accessibility, and comfort.\n\nReasons why people prefer plains:\n\n1. Agriculture and food production:\n   - Plains have fertile soil (alluvial soil)\n   - Flat land is easy to cultivate\n   - Can use modern machinery (tractors, harvesters)\n   - Higher agricultural yield\n   - Can grow a variety of crops\n   - Mountains have limited flat land (only terraces)\n\n2. Ease of construction:\n   - Soft and flat surface of plains makes it easy for:\n     * Building houses and buildings\n     * Constructing roads and highways\n     * Laying railway tracks\n     * Building airports\n   - Mountains require cutting, tunneling, and expensive engineering\n\n3. Transportation and connectivity:\n   - Plains have well-developed road and rail networks\n   - Easy to travel between places\n   - Transportation of goods is cheaper and faster\n   - Mountains have winding roads, risk of landslides\n   - Many areas inaccessible in winter\n\n4. Industrialization:\n   - Scope for industrialization is much more in plains\n   - Factories need flat land\n   - Easy transport of raw materials and finished goods\n   - Availability of workers\n   - Access to markets\n\n5. Urbanization:\n   - Large cities and towns are located mostly in the plains\n   - Better infrastructure (electricity, water, sanitation)\n   - More educational institutions\n   - Better healthcare facilities\n   - More employment opportunities\n\n6. Climate:\n   - Plains have moderate climate in many regions\n   - Mountains have extreme cold, heavy snowfall\n   - Harsh winters make life difficult\n   - Limited growing season\n\n7. Population density:\n   - Plains can support large populations\n   - Indo-Gangetic Plain, Mississippi Plain, Yangtze Plain are densely populated\n   - Mountains have low population density\n\n8. Economic opportunities:\n   - More diverse jobs in plains (industry, services, trade)\n   - Mountains have limited livelihood options\n   - Mostly tourism, forestry, and limited agriculture\n\n9. Accessibility to services:\n   - Schools, colleges, hospitals easily accessible\n   - Mountains require traveling long distances\n   - Emergency services may be far away\n\n10. Communication:\n    - Better telecom and internet connectivity in plains\n    - Mountains have terrain interference\n\n11. Cost of living:\n    - Transportation of goods to mountains is expensive\n    - Food and essentials cost more\n    - Construction costs higher\n\n12. Safety and security:\n    - Plains less prone to natural disasters\n    - Mountains face landslides, avalanches, flash floods\n    - Steep slopes can be dangerous\n\nHowever, mountains have their own advantages:\n- Clean air and environment\n- Scenic beauty\n- Peace and quiet\n- Adventure opportunities\n- Unique cultures\n\nThus, while some people choose mountains for tourism, retirement, or specific livelihoods, the majority prefer plains for practical reasons related to ease of living and economic opportunities."
        },
        {
            "type": "subjective",
            "q": "What are plateaux? Explain the different types of plateaux with examples.",
            "sample": "Plateaux (plural of plateau) are the uplifted sections of the earth's crust that are almost flat or level and usually descend steeply to the surrounding lowlands. A plateau is also sometimes referred to as a plain-in-the-air or tableland.\n\nExamples of well-known plateaus:\n- The plateau of Tibet in Asia\n- The East African Plateau in Africa\n- The Colorado Plateau in North America\n- The Deccan Plateau and Chota Nagpur Plateau in India\n\nEconomic value of plateaus:\n- Rich in mineral deposits (gold, diamond, copper, manganese, chromium, iron)\n- South African Plateau yields gold and diamond\n- Western Australian Plateau rich in gold and iron\n- Chota Nagpur Plateau in India is a storehouse of mineral wealth\n\nTypes of Plateaux:\n\nBased on their formation, appearance, and location, plateaus are classified into the following categories:\n\n1. Tectonic Plateau:\n   - Formed by the movement of the earth's crustal plates\n   - Tectonic movement causes a huge portion of the earth's surface to rise\n   - Broad, flat areas uplifted by earth movements\n   \n   Examples:\n   - The plateau of South Africa\n   - The Turkish-Iranian Plateau\n   - The Tibetan Plateau (also intermontane)\n\n2. Volcanic Plateau:\n   - Formed by the spread of successive layers of lava on a particular region\n   - When lava cools, it solidifies\n   - Successive sheets of lava finally form a raised tableland over time\n   - Also called lava plateaus\n   \n   Examples:\n   - The extensive Columbia Plateau (north-western USA)\n   - The north-western part of the Deccan Plateau\n   - The Malwa Plateau\n   - The Antrim Plateau (Northern Ireland)\n\n3. Dissected Plateau:\n   - Have irregular surface marked by canyons, gorges, and steep, narrow valleys\n   - Formed by the process of erosion over millions of years\n   - Mostly common in dry and desert regions\n   - Rivers cut deep channels into the plateau\n   \n   Examples:\n   - The Colorado Plateau (Grand Canyon passes through it)\n   - The Brazilian Plateau (Mato Grosso)\n   - The Chota Nagpur Plateau in India\n\n4. Intermontane Plateau:\n   - Surrounded by mountains on all sides\n   - Most common types of plateau\n   - Formed between mountain ranges\n   - Often at high altitudes\n   \n   Examples:\n   - The Tibetan Plateau (enclosed by the Himalayan Mountains to its south and the Kunlun Shan to its north)\n   - The Bolivian Plateau (Altiplano) in South America\n   - The Plateau of Iran\n\n5. Piedmont Plateau:\n   - Lies between a mountain and a plain or an ocean\n   - One side bounded by mountains, other side by lowlands\n   - Formed by erosion from mountains\n   \n   Examples:\n   - The Patagonia Plateau in South America\n   - The Piedmont Plateau of North America (east of Appalachian Mountains)\n   - The Malwa Plateau in India (partly)\n\nThus, plateaus are important landforms with great economic value, especially for mineral resources, and show diverse characteristics based on their formation."
        },
        {
            "type": "subjective",
            "q": "Why do plateaus have great economic value? Explain with examples.",
            "sample": "Plateaus have great economic value due to their rich mineral resources, agricultural potential, and other economic benefits. Their importance can be understood through various aspects:\n\n1. Mineral wealth:\n   - Plateaus are storehouses of minerals and metals\n   - Formed by volcanic activity and tectonic movements that bring minerals close to surface\n   - Sedimentary layers in plateaus contain fossil fuels\n   \n   Examples:\n   - South African Plateau: Yields gold, diamond, copper, manganese, and chromium\n   - Western Australian Plateau: Rich in gold and iron\n   - Chota Nagpur Plateau (India): Storehouse of mineral wealth (coal, iron ore, mica, bauxite)\n   - Deccan Plateau (India): Contains coal, iron ore, manganese\n   - Colorado Plateau (USA): Uranium, copper, coal\n   - Katanga Plateau (Congo): Copper, cobalt\n\n2. Agricultural potential:\n   - Some plateaus have fertile soil\n   - Lava plateaus develop fertile black soil\n   - Suitable for certain crops\n   \n   Examples:\n   - Deccan Plateau (India): Black cotton soil, ideal for cotton\n   - Ethiopian Plateau: Fertile for coffee cultivation\n   - Mexican Plateau: Agriculture in valleys\n   - Columbia Plateau: Wheat farming\n\n3. Water resources:\n   - Plateaus are sources of many rivers\n   - Waterfalls on plateaus provide hydroelectric power\n   - Rivers cutting through plateaus create deep gorges\n   \n   Examples:\n   - The Deccan Plateau: Source of many peninsular rivers\n   - The Colorado Plateau: Hydroelectric power from dams\n   - The Brazilian Plateau: Hydroelectric potential\n\n4. Forests and biodiversity:\n   - Plateaus often support forests\n   - Provide timber, fuel wood, and forest products\n   - Biodiversity hotspots\n   \n   Examples:\n   - Chota Nagpur Plateau: Forests with valuable timber\n   - Ethiopian Plateau: Unique flora and fauna\n\n5. Tourism and scenic value:\n   - Plateaus with deep canyons attract tourists\n   - Waterfalls, gorges, and rock formations\n   - Hill stations on plateaus\n   \n   Examples:\n   - Colorado Plateau: Grand Canyon (UNESCO World Heritage)\n   - Deccan Plateau: Ajanta and Ellora caves\n   - Tibetan Plateau: 'Roof of the World' tourism\n   - Brazilian Plateau: Iguaçu Falls\n\n6. Settlement and agriculture:\n   - Flat tops suitable for settlements\n   - Terraced farming on slopes\n   - Cooler climate than surrounding lowlands\n   \n   Examples:\n   - Mexican Plateau: Major population center\n   - Iranian Plateau: Ancient civilizations\n   - Ethiopian Plateau: Major population center\n\n7. Strategic importance:\n   - High plateaus provide strategic advantage\n   - Difficult to access, natural forts\n   \n   Examples:\n   - Deccan Plateau: Historical forts\n   - Tibetan Plateau: Strategic location\n\n8. Climate regulation:\n   - Plateaus affect regional climate\n   - Cause rainfall on windward side\n   - Rain shadow on leeward side\n\n9. Cultural significance:\n   - Many plateaus have indigenous cultures\n   - Traditional ways of life\n   - Historical monuments\n\nThus, plateaus are economically valuable landforms contributing significantly to mineral resources, agriculture, energy, tourism, and culture of regions where they are located."
        },
        {
            "type": "subjective",
            "q": "What is a basin? Explain with examples of basins of inland drainage.",
            "sample": "A basin is a depressed section of the earth's crust surrounded by higher land. It is a low-lying area where water collects, often forming lakes or marshes.\n\nCharacteristics of basins:\n- Surrounded by higher land (mountains, hills, plateaus)\n- Generally bowl-shaped or circular depression\n- May contain rivers, lakes, or be dry\n- Often have rich soil due to sediment accumulation\n\nTypes of basins:\n\n1. Drainage basins (exorheic basins):\n   - Rivers drain into oceans or seas\n   - Water reaches the sea\n   - Most river basins are of this type\n   - Example: Ganga Basin drains into Bay of Bengal\n\n2. Inland drainage basins (endorheic basins):\n   - Rivers flowing in the basin do not reach the sea\n   - Water evaporates or sinks into the ground\n   - Common in arid and semi-arid regions\n   - Often contain salt lakes or playas\n\nMany basins are found alongside plateau edges and form areas of inland drainage.\n\nExamples of basins of inland drainage:\n\n1. Tarim Basin (Asia):\n   - Located in Xinjiang, China\n   - Surrounded by Tien Shan and Kunlun mountains\n   - One of the largest endorheic basins in the world\n   - Contains the Taklamakan Desert\n   - Rivers drain into Lop Nur (salt lake)\n\n2. Tsaidam Basin (Asia):\n   - Located in Qinghai Province, China\n   - Between Kunlun Mountains and Qilian Mountains\n   - High-altitude desert basin\n   - Salt lakes and marshes\n   - Rich in mineral resources\n\n3. Chad Basin (north-central Africa):\n   - Located in Chad, Niger, Nigeria, Cameroon\n   - Centered around Lake Chad\n   - Lake Chad is shallow and varies in size seasonally\n   - Rivers drain into Lake Chad but don't reach the sea\n   - Supports millions of people\n\n4. Great Basin (USA):\n   - Largest endorheic basin in North America\n   - Covers Nevada, Utah, Oregon, Idaho, California\n   - Contains Great Salt Lake (Utah)\n   - Death Valley (lowest point in North America)\n   - Basin and Range province with many smaller basins\n\n5. Caspian Depression (Eurasia):\n   - Surrounds the Caspian Sea\n   - Caspian Sea is actually a lake (largest lake in world)\n   - Rivers Volga and Ural drain into it\n   - Below sea level in some areas\n\n6. Dead Sea Basin (Middle East):\n   - Lowest point on Earth's surface\n   - Jordan River drains into Dead Sea\n   - High salinity (no outlet)\n   - Shared by Israel, Jordan, Palestine\n\n7. Lake Eyre Basin (Australia):\n   - One of the largest endorheic basins in the world\n   - Covers much of central Australia\n   - Lake Eyre fills only occasionally\n   - Mostly dry, salt flats\n\nImportance of basins:\n- Agriculture: Fertile soil in river basins\n- Water resources: Lakes and groundwater\n- Mineral resources: Salt, evaporites\n- Unique ecosystems: Adapted to saline conditions\n- Human settlement: Oases in desert basins\n\nThus, basins, especially inland drainage basins, are unique features where water never reaches the ocean, creating distinctive landscapes and ecosystems."
        },
        {
            "type": "subjective",
            "q": "What are plains? Explain the different types of plains with examples.",
            "sample": "Plains or lowlands are vast, nearly flat, expanses of land which are usually less than 200 metres above sea level. They are mostly built by alluvium deposited by big rivers and their tributaries and are, therefore, also called river plains.\n\nCharacteristics of plains:\n- Flat or gently rolling land\n- Low elevation (usually <200 m)\n- Fertile soil (alluvial soil)\n- Densely populated\n- Ideal for agriculture\n- Easy for construction\n\nImportance of plains:\n- Granaries of the world (food production)\n- Support large populations\n- Location of large cities\n- Easy transportation and industrialization\n\nTypes of plains based on formation:\n\n1. Structural Plains:\n   - Plains that lie near the coast of a sea or an ocean\n   - Mainly formed by the uplift of a part of the seafloor or continental shelf\n   - Due to endogenetic movements, large, broad, flat areas of the sea floor are raised and appear on the surface\n   - Very flat and broad\n   - Addition of sediments by sea waves makes them broader and flatter over time\n   - Border all countries\n   \n   Examples:\n   - The coastal plains of south-eastern USA near the Gulf Coast (part of the Great Plains)\n   - The plains of northern Russia\n   - The central lowlands of Australia\n   - The coastal plains of India (eastern and western)\n\n2. Erosional Plains:\n   - Result of the erosion of mountains, hills, and plateaux\n   - Eroded material is brought down to a low level by wind, rivers, rain, and glacier\n   - Erosion caused by various agents gives rise to several types of plains\n   - Over long periods, mountains are worn down to form plains\n   \n   Examples:\n   - The plains of northern Canada\n   - The plains of northern Europe\n   - The plains of Kashmir in India\n   - The peneplains (level land produced by erosion over long periods)\n\n3. Depositional Plains:\n   - Formed by sediments brought down on a large scale by natural agents such as moving ice, water, and wind from the upper regions of mountains\n   - Sediments deposited in low-lying areas\n   - Also called river plains or alluvial plains\n   - Most fertile plains\n   \n   Types of depositional plains:\n   \n   a. Alluvial plains:\n      - Formed by river deposits\n      - Very fertile\n      - Example: Indo-Gangetic Plain, Nile Delta\n   \n   b. Coastal plains:\n      - Found along the edges of continents adjacent to seas\n      - Formed by marine deposits\n      - Example: Eastern and western coastal plains of India\n   \n   c. Lacustrine plains:\n      - Formed by lake deposits\n      - Example: Valley of Kashmir\n   \n   d. Loess plains:\n      - Formed by wind deposits\n      - Example: Plains of northern China\n\nMajor plains of the world:\n- The Indo-Gangetic Plain (India, Pakistan, Bangladesh)\n- The Mississippi Plain (USA)\n- The Yangtze Plain (China)\n- The Great Plains (USA and Canada)\n- The Amazon Plain (South America)\n- The Siberian Plain (Russia)\n- The European Plain (Europe)\n\nThus, plains, especially depositional plains, are the most suitable for human habitation and agriculture, supporting large populations and civilizations."
        },
        {
            "type": "subjective",
            "q": "Why are plains the most suitable landform for human habitation? Explain.",
            "sample": "Of all the landforms on earth, the most suitable for both humans and animals are the plains. Plains have always been the areas that support large populations, for example, the Indo-Gangetic Plain, the Mississippi Plain, and the Yangtze Plain.\n\nReasons why plains are most suitable for human habitation:\n\n1. Agriculture and food production:\n   - Plains have fertile soil (alluvial soil deposited by rivers)\n   - Rich in nutrients for crop growth\n   - Crops such as rice, wheat, and sugar cane are grown in the plains\n   - High agricultural productivity\n   - Plains are the granaries of the world\n   - Can support large populations through food production\n\n2. Flat terrain:\n   - Soft and flat surface of the plains makes it easy for construction\n   - Building houses, buildings, and infrastructure is easier\n   - No need for expensive terracing or levelling\n\n3. Transportation:\n   - Easy to construct roads, railway tracks, and airports\n   - Well-developed transportation networks\n   - Cheaper to build and maintain roads\n   - Easy movement of goods and people\n   - Connectivity between settlements\n\n4. Industrialization:\n   - Scope for industrialization is much more in the plains than in any other terrain\n   - Factories require flat land for construction\n   - Easy transport of raw materials and finished goods\n   - Availability of workers from nearby settlements\n   - Access to markets\n\n5. Urbanization:\n   - Large cities and towns are located mostly in the plains\n   - Can support large populations\n   - Better infrastructure development\n   - Concentration of economic activities\n   - Examples: Delhi, Kolkata, Mumbai (partly), New York, London\n\n6. Water availability:\n   - Rivers flow through plains, providing water\n   - Easy access to water for drinking, irrigation, and industry\n   - Groundwater easily accessible\n   - Canals can be constructed easily\n\n7. Climate:\n   - Generally moderate climate in many plains\n   - Not as extreme as mountains or deserts\n   - Suitable for year-round habitation\n\n8. Settlement patterns:\n   - Easy to plan and develop settlements\n   - Grid pattern possible for streets\n   - Efficient land use\n\n9. Historical significance:\n   - Plains of the world were the cradles of ancient civilizations\n   - Indus Valley civilization in Indo-Gangetic Plain\n   - Mesopotamian civilization in Tigris-Euphrates plain\n   - Chinese civilization in Yangtze and Yellow River plains\n   - Egyptian civilization in Nile Valley\n\n10. Economic activities:\n    - Diverse economic activities possible\n    - Agriculture, industry, trade, services\n    - More employment opportunities\n\n11. Social and cultural development:\n    - Dense populations lead to cultural exchange\n    - Educational institutions, healthcare facilities\n    - Social services easily accessible\n\n12. Defense and security:\n    - Easy to defend settlements\n    - Open terrain allows visibility\n    - Quick movement of defense forces\n\n13. Resource availability:\n    - Fertile soil for agriculture\n    - Water resources from rivers\n    - Proximity to markets\n\n14. Quality of life:\n    - Access to amenities and services\n    - Better healthcare and education\n    - Economic opportunities\n    - Social and cultural activities\n\nThus, plains offer the most favorable conditions for human habitation, economic development, and cultural growth, making them the most densely populated landforms on Earth."
        },
        {
            "type": "subjective",
            "q": "What is the difference between a peninsula and an island? Give examples.",
            "sample": "Peninsulas and islands are both landforms surrounded by water, but they differ in their connection to larger land masses.\n\nPeninsula:\n\nDefinition:\n- A peninsula is a piece of land that is surrounded by water on three sides and joined to a larger land mass on the fourth side.\n- The word comes from Latin 'paene' (almost) and 'insula' (island) - meaning 'almost an island'\n\nCharacteristics:\n- Connected to mainland by an isthmus or broad base\n- Juts out into water\n- Can be large (entire continents like Europe) or small\n- Three sides water, one side land\n\nExamples of peninsulas:\n\n1. Indian Peninsula (Deccan Peninsula):\n   - Surrounded by Arabian Sea (west), Bay of Bengal (east), and Indian Ocean (south)\n   - Joined to Asian mainland in the north\n\n2. Malay Peninsula:\n   - In Southeast Asia\n   - Includes parts of Myanmar, Thailand, Malaysia\n   - Surrounded by Andaman Sea and South China Sea\n\n3. Europe:\n   - Sometimes called a 'peninsula of peninsulas'\n   - Surrounded by Arctic Ocean, Atlantic Ocean, Mediterranean Sea\n   - Smaller peninsulas jut out: Scandinavian, Iberian, Italian, Balkan\n\n4. Arabian Peninsula:\n   - Largest peninsula in the world\n   - Surrounded by Red Sea, Arabian Sea, Persian Gulf\n   - Connected to Asian mainland\n\n5. Korean Peninsula:\n   - Between Yellow Sea and Sea of Japan\n   - Connected to Asian mainland\n\n6. Florida Peninsula (USA):\n   - Between Gulf of Mexico and Atlantic Ocean\n\nIsland:\n\nDefinition:\n- An island is a piece of land which is surrounded on all sides by water.\n- Can be continental (connected to mainland in past) or oceanic (formed by volcanoes)\n\nCharacteristics:\n- Completely surrounded by water\n- No land connection to mainland\n- Can be large (Greenland) or small (islets)\n\nExamples of islands:\n\n1. Sri Lanka:\n   - Island just south of India in the Indian Ocean\n   - Separated from India by Palk Strait\n\n2. Madagascar:\n   - Large island in Indian Ocean (off Africa)\n   - Fourth largest island in the world\n\n3. Andaman and Nicobar Islands (India):\n   - Group of islands in Bay of Bengal\n\n4. Lakshadweep Islands (India):\n   - Group of islands in Arabian Sea\n\n5. Greenland:\n   - Largest island in the world\n   - Mostly ice-covered\n\n6. Great Britain:\n   - Largest of the British Isles\n\n7. Japan:\n   - Archipelago of many islands\n\n8. Indonesia:\n   - World's largest archipelago (thousands of islands)\n\n9. Maldives:\n   - Small island nation in Indian Ocean\n\n10. Australia:\n    - Often considered a continent, but also an island\n    - Sometimes called the 'island continent'\n\nComparison table:\n\n| Feature | Peninsula | Island |\n|---------|-----------|--------|\n| Water sides | Three sides | All four sides |\n| Land connection | Connected to mainland | No connection |\n| Access | By land on one side | Only by water/air |\n| Size range | Can be very large | Varies widely |\n| Formation | Part of continental shelf | Continental or oceanic |\n| Examples | India, Arabia, Korea | Sri Lanka, Madagascar |\n\nThus, the key difference is that a peninsula is connected to a larger landmass on one side, while an island is completely surrounded by water with no land connection."
        },
        {
            "type": "subjective",
            "q": "What is an isthmus? Give examples and explain its importance.",
            "sample": "An isthmus is an elongated narrow piece of land, with water on each side, that joins two large land masses. It is a narrow strip of land connecting two larger land areas, with water on both sides.\n\nCharacteristics of an isthmus:\n- Narrow strip of land\n- Connects two larger land masses\n- Water on both sides\n- Often forms a natural land bridge\n- Strategic location for trade and transport\n\nExamples of isthmuses:\n\n1. Isthmus of Panama:\n   - Joins North America and South America\n   - Separates the Pacific Ocean and the Atlantic Ocean (Caribbean Sea)\n   - Location of the Panama Canal\n   - Length: about 80 km at its narrowest\n   - Width: varies from 50 to 200 km\n   - Vital for global maritime trade\n\n2. Isthmus of Suez:\n   - Joins Africa to Asia\n   - Separates the Mediterranean Sea and the Red Sea\n   - Location of the Suez Canal\n   - About 125 km wide\n   - Egypt controls this isthmus\n   - Connects Sinai Peninsula to mainland Egypt\n\n3. Isthmus of Corinth (Greece):\n   - Connects the Peloponnese peninsula to mainland Greece\n   - Separates the Gulf of Corinth and the Saronic Gulf\n   - Corinth Canal cut through it (6 km long)\n\n4. Isthmus of Kra (Thailand):\n   - Narrowest part of Malay Peninsula\n   - Joins mainland Asia to Malay Peninsula\n   - Proposed site for a canal (Kra Canal)\n   - Would connect Andaman Sea and Gulf of Thailand\n\n5. Isthmus of Avalon (Canada):\n   - Connects Avalon Peninsula to Newfoundland mainland\n\n6. Isthmus of Tehuantepec (Mexico):\n   - Narrowest part of Mexico\n   - Between Gulf of Mexico and Pacific Ocean\n   - Important trade route\n\nImportance of isthmuses:\n\n1. Strategic location:\n   - Control over trade routes\n   - Military importance\n   - Choke points for global shipping\n\n2. Canals:\n   - Ideal locations for canals\n   - Shorten sea routes dramatically\n   - Panama Canal saves 12,000 km around South America\n   - Suez Canal saves 8,000 km around Africa\n   - Boost global trade\n\n3. Trade and commerce:\n   - Land routes connecting continents\n   - Trans-shipment points\n   - Ports developed on both sides\n\n4. Biodiversity:\n   - Land bridges for species migration\n   - Great American Interchange (via Panama)\n   - Exchange of flora and fauna between continents\n\n5. Human migration:\n   - Pathways for ancient human migration\n   - Cultural exchange\n\n6. Economic development:\n   - Canal revenues (Panama, Suez)\n   - Port cities develop\n   - Tourism\n\n7. Geopolitical importance:\n   - Control of isthmus = control of trade\n   - Panama Canal Zone history\n   - Suez Crisis (1956)\n\n8. Climate:\n   - Affect local climate patterns\n   - Rain shadows\n\nThus, isthmuses are narrow but incredibly important landforms that connect continents, separate oceans, and host some of the world's most vital shipping canals."
        }
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 4: Major Water Bodies
    # ──────────────────────────────────────────────────────────────────
    "Chapter 4 — Major Water Bodies": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "What percentage of the earth's surface is covered by water?",
            "options": [
                "29%",
                "50%",
                "71%",
                "80%"
            ],
            "answer": "71%",
            "explanation": "Water covers 71 per cent of the earth's surface in the form of large and small water bodies."
        },
        {
            "type": "mcq",
            "q": "How many oceans are there in the world?",
            "options": [
                "3",
                "4",
                "5",
                "7"
            ],
            "answer": "5",
            "explanation": "There are five oceans in the world - the Pacific, the Atlantic, the Indian, the Arctic, and the Southern Ocean."
        },
        {
            "type": "mcq",
            "q": "Which is the largest ocean in the world?",
            "options": [
                "Atlantic Ocean",
                "Indian Ocean",
                "Pacific Ocean",
                "Arctic Ocean"
            ],
            "answer": "Pacific Ocean",
            "explanation": "The Pacific Ocean is the largest ocean and covers over one third of the globe. It is almost circular in shape."
        },
        {
            "type": "mcq",
            "q": "The Pacific Ocean is bordered by new fold mountains with active volcanoes called:",
            "options": [
                "The Alpine Belt",
                "The Ring of Fire",
                "The Volcanic Arc",
                "The Pacific Ridge"
            ],
            "answer": "The Ring of Fire",
            "explanation": "The Pacific Ocean is bordered by new fold mountains that have the maximum concentration of active volcanoes, called the 'Ring of Fire'."
        },
        {
            "type": "mcq",
            "q": "The deepest part of the earth's crust, the Mariana Trench, lies in which ocean?",
            "options": [
                "Atlantic Ocean",
                "Indian Ocean",
                "Pacific Ocean",
                "Arctic Ocean"
            ],
            "answer": "Pacific Ocean",
            "explanation": "The deepest part of the earth's crust—the Mariana Trench—lies in the Pacific Ocean near the Philippines."
        },
        {
            "type": "mcq",
            "q": "How deep is the Mariana Trench?",
            "options": [
                "About 6,000 metres",
                "About 8,000 metres",
                "About 11,000 metres",
                "About 15,000 metres"
            ],
            "answer": "About 11,000 metres",
            "explanation": "The Mariana Trench in the Pacific Ocean is about 11,000 metres deep. A large stone would take more than an hour to reach the bottom!"
        },
        {
            "type": "mcq",
            "q": "The Atlantic Ocean is shaped like which letter?",
            "options": [
                "C",
                "S",
                "V",
                "U"
            ],
            "answer": "S",
            "explanation": "The Atlantic Ocean is shaped like the letter 'S' and is much smaller than the Pacific Ocean."
        },
        {
            "type": "mcq",
            "q": "Which is the busiest ocean in the world?",
            "options": [
                "Pacific Ocean",
                "Atlantic Ocean",
                "Indian Ocean",
                "Arctic Ocean"
            ],
            "answer": "Atlantic Ocean",
            "explanation": "The Atlantic Ocean is the busiest ocean in the world as many trade and transportation routes pass across it."
        },
        {
            "type": "mcq",
            "q": "The underwater mountain range in the middle of the Atlantic Ocean is called:",
            "options": [
                "The Mid-Atlantic Ridge",
                "The Atlantic Rise",
                "The Oceanic Ridge",
                "The Atlantic Plateau"
            ],
            "answer": "The Mid-Atlantic Ridge",
            "explanation": "In the middle of the Atlantic Ocean is a submerged mountain range called the Mid-Atlantic Ridge. Some peaks form islands like Iceland."
        },
        {
            "type": "mcq",
            "q": "The Indian Ocean is roughly which shape?",
            "options": [
                "Circular",
                "Rectangular",
                "Triangular",
                "S-shaped"
            ],
            "answer": "Triangular",
            "explanation": "The Indian Ocean is roughly triangular in shape and covers one fifth of the total area under the oceans."
        },
        {
            "type": "mcq",
            "q": "Why is the Indian Ocean named after India?",
            "options": [
                "India is the largest country in the region",
                "India is located at the head of this ocean",
                "India has the longest coastline",
                "India discovered this ocean"
            ],
            "answer": "India is located at the head of this ocean",
            "explanation": "India is located at the head of the Indian Ocean, which is why this ocean has been named after this country."
        },
        {
            "type": "mcq",
            "q": "Two important parts of the Indian Ocean to its north are:",
            "options": [
                "Red Sea and Mediterranean Sea",
                "Arabian Sea and Bay of Bengal",
                "Persian Gulf and Gulf of Oman",
                "Andaman Sea and South China Sea"
            ],
            "answer": "Arabian Sea and Bay of Bengal",
            "explanation": "The Arabian Sea and the Bay of Bengal are two important parts of the Indian Ocean to its north."
        },
        {
            "type": "mcq",
            "q": "Which is the smallest and shallowest ocean?",
            "options": [
                "Arctic Ocean",
                "Southern Ocean",
                "Indian Ocean",
                "Atlantic Ocean"
            ],
            "answer": "Arctic Ocean",
            "explanation": "The Arctic Ocean is the smallest and shallowest ocean surrounding the North Pole. It remains frozen for most part of the year."
        },
        {
            "type": "mcq",
            "q": "The Southern Ocean surrounds which continent?",
            "options": [
                "Australia",
                "South America",
                "Antarctica",
                "Africa"
            ],
            "answer": "Antarctica",
            "explanation": "The Southern Ocean or the Antarctic Ocean surrounds the continent of Antarctica. It is the fourth largest ocean."
        },
        {
            "type": "mcq",
            "q": "What percentage of ocean pollution is made up of plastic waste?",
            "options": [
                "50%",
                "60%",
                "70%",
                "80%"
            ],
            "answer": "80%",
            "explanation": "Plastic waste makes up 80 per cent of all marine pollution and millions of tons of plastic is thrown in our ocean each year."
        },
        {
            "type": "mcq",
            "q": "A part of an ocean that is smaller and shallower, usually close to land, is called:",
            "options": [
                "Gulf",
                "Bay",
                "Sea",
                "Strait"
            ],
            "answer": "Sea",
            "explanation": "A sea is a part of an ocean that is smaller and shallower. It is usually located close to the edge of a land mass or continent."
        },
        {
            "type": "mcq",
            "q": "The Caribbean Sea, Bering Sea, and Arabian Sea are examples of:",
            "options": [
                "Oceans",
                "Seas",
                "Gulfs",
                "Bays"
            ],
            "answer": "Seas",
            "explanation": "These are examples of seas located along the edges of continents."
        },
        {
            "type": "mcq",
            "q": "A deep inlet of the sea almost surrounded by land, with a narrow mouth, is called:",
            "options": [
                "Bay",
                "Gulf",
                "Strait",
                "Sea"
            ],
            "answer": "Gulf",
            "explanation": "A gulf is a deep inlet of the sea almost surrounded by land, with a narrow mouth. Gulfs are more indented than bays."
        },
        {
            "type": "mcq",
            "q": "An open, curving indentation made by the sea or a lake into a coastline is called:",
            "options": [
                "Gulf",
                "Bay",
                "Strait",
                "Sea"
            ],
            "answer": "Bay",
            "explanation": "A bay is an open, curving indentation made by the sea or a lake into a coastline."
        },
        {
            "type": "mcq",
            "q": "Which of the following is an example of a gulf?",
            "options": [
                "Bay of Bengal",
                "Hudson Bay",
                "Persian Gulf",
                "Bay of Biscay"
            ],
            "answer": "Persian Gulf",
            "explanation": "The Persian Gulf is an example of a gulf. The Bay of Bengal, Hudson Bay, and Bay of Biscay are examples of bays."
        },
        {
            "type": "mcq",
            "q": "The Palk Strait connects which two water bodies?",
            "options": [
                "Arabian Sea and Indian Ocean",
                "Bay of Bengal and Gulf of Mannar",
                "Red Sea and Mediterranean Sea",
                "Pacific Ocean and Atlantic Ocean"
            ],
            "answer": "Bay of Bengal and Gulf of Mannar",
            "explanation": "The Palk Strait connects the Bay of Bengal in the north-east with the Gulf of Mannar in the south-west."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a saline water body cut off from the open ocean?",
            "options": [
                "Bay of Bengal",
                "Arabian Sea",
                "Caspian Sea",
                "Pacific Ocean"
            ],
            "answer": "Caspian Sea",
            "explanation": "The Caspian Sea and the Dead Sea are large saline water bodies cut off from the open ocean, but they are called 'sea'."
        },
        {
            "type": "mcq",
            "q": "Small bodies of water surrounded by land on all sides are called:",
            "options": [
                "Seas",
                "Oceans",
                "Lakes",
                "Rivers"
            ],
            "answer": "Lakes",
            "explanation": "Lakes are small bodies of water which are surrounded by land on all sides. Lakes are bigger and deeper than ponds."
        },
        {
            "type": "mcq",
            "q": "Which is the oldest and deepest lake in the world?",
            "options": [
                "Lake Superior",
                "Lake Victoria",
                "Lake Baikal",
                "Lake Titicaca"
            ],
            "answer": "Lake Baikal",
            "explanation": "Lake Baikal is located in south-east Siberia, and is the oldest and the deepest (1,700 m) lake in the world."
        },
        {
            "type": "mcq",
            "q": "What percentage of the world's total unfrozen freshwater reserve does Lake Baikal contain?",
            "options": [
                "10%",
                "20%",
                "30%",
                "40%"
            ],
            "answer": "20%",
            "explanation": "Lake Baikal contains 20 per cent of the world's total unfrozen freshwater reserve which is not frozen."
        },
        {
            "type": "mcq",
            "q": "The five Great Lakes of the USA are:",
            "options": [
                "Superior, Michigan, Huron, Erie, Ontario",
                "Baikal, Onega, Ladoga, Victoria, Titicaca",
                "Caspian, Aral, Black, Dead, Red",
                "Chilika, Wular, Dal, Nainital, Bhimtal"
            ],
            "answer": "Superior, Michigan, Huron, Erie, Ontario",
            "explanation": "The five Great Lakes of the USA are Superior, Huron, Michigan, Ontario, and Erie. They are between the United States and Canada."
        },
        {
            "type": "mcq",
            "q": "The Great Lakes comprise the largest body of:",
            "options": [
                "Salt water",
                "Fresh water",
                "Brackish water",
                "Mineral water"
            ],
            "answer": "Fresh water",
            "explanation": "The Great Lakes comprise the largest body of fresh water on earth, with around 34 million people in the region."
        },
        {
            "type": "mcq",
            "q": "Lake Titicaca is located in which mountain range?",
            "options": [
                "The Himalayas",
                "The Alps",
                "The Andes",
                "The Rockies"
            ],
            "answer": "The Andes",
            "explanation": "Lake Titicaca is a large, deep lake in the Andes Mountain bordering Bolivia and Peru. It is the largest lake in South America."
        },
        {
            "type": "mcq",
            "q": "Lake Victoria is the main reservoir of which river?",
            "options": [
                "Amazon River",
                "Nile River",
                "Congo River",
                "Zambezi River"
            ],
            "answer": "Nile River",
            "explanation": "Lake Victoria is the largest lake in Africa and is the main reservoir of the Nile River."
        },
        {
            "type": "mcq",
            "q": "Chilika Lake is located in which Indian state?",
            "options": [
                "Tamil Nadu",
                "Andhra Pradesh",
                "Odisha",
                "West Bengal"
            ],
            "answer": "Odisha",
            "explanation": "Chilika Lake is a saltwater lake in the state of Odisha in the eastern part of India."
        },
        {
            "type": "mcq",
            "q": "Chilika Lake is famous for:",
            "options": [
                "Being the deepest lake in India",
                "Migratory birds in winter",
                "Having the largest area",
                "Being a freshwater lake"
            ],
            "answer": "Migratory birds in winter",
            "explanation": "In winter, Chilika Lake becomes the largest ground for migratory birds in the Indian subcontinent."
        },
        {
            "type": "mcq",
            "q": "A stream of water flowing from high ground to low ground and finally to a lake or sea is called:",
            "options": [
                "Lake",
                "River",
                "Canal",
                "Stream"
            ],
            "answer": "River",
            "explanation": "A river is a stream of water which flows in a channel from high ground to low ground and finally to a lake or a sea."
        },
        {
            "type": "mcq",
            "q": "The place where a river originates is called its:",
            "options": [
                "Mouth",
                "Source",
                "Delta",
                "Tributary"
            ],
            "answer": "Source",
            "explanation": "The place where a river originates is called its source, which normally lies in a hill or a mountain."
        },
        {
            "type": "mcq",
            "q": "The place where a river ends its journey is called its:",
            "options": [
                "Source",
                "Mouth",
                "Delta",
                "Estuary"
            ],
            "answer": "Mouth",
            "explanation": "The place where a river ends its journey is called its mouth. The mouth is normally where the river enters the sea."
        },
        {
            "type": "mcq",
            "q": "Which is the world's longest river?",
            "options": [
                "Amazon River",
                "Nile River",
                "Yangtze River",
                "Mississippi River"
            ],
            "answer": "Nile River",
            "explanation": "The river Nile in Africa, 6,695 km in length, is the world's longest river. It flows out into the Mediterranean Sea."
        },
        {
            "type": "mcq",
            "q": "Which is the second longest river in the world?",
            "options": [
                "Nile River",
                "Amazon River",
                "Yangtze River",
                "Mississippi River"
            ],
            "answer": "Amazon River",
            "explanation": "The Amazon River, 6,640 km in length, flows through South America and is the second longest river in the world."
        },
        {
            "type": "mcq",
            "q": "The Rhine River flows through how many European countries?",
            "options": [
                "3",
                "4",
                "5",
                "6"
            ],
            "answer": "6",
            "explanation": "The Rhine River flows through six European countries and has its source in the Alps Mountains in Switzerland."
        },
        {
            "type": "mcq",
            "q": "The Danube River flows through or along the borders of how many European countries?",
            "options": [
                "5",
                "8",
                "10",
                "12"
            ],
            "answer": "10",
            "explanation": "The Danube River is located in Central and Eastern Europe and flows through or along the borders of ten European countries."
        },
        {
            "type": "mcq",
            "q": "The Indus River was the cradle of which ancient civilization?",
            "options": [
                "Mesopotamian civilization",
                "Egyptian civilization",
                "Indus Valley civilization",
                "Chinese civilization"
            ],
            "answer": "Indus Valley civilization",
            "explanation": "The Indus River was the cradle of the Indus Valley civilization."
        },
        {
            "type": "mcq",
            "q": "Huang He, also known as the Yellow River, is the main river of:",
            "options": [
                "Japan",
                "India",
                "China",
                "Mongolia"
            ],
            "answer": "China",
            "explanation": "Huang He, also known as the Yellow River, is the main river of northern China and is believed to be the cradle of Chinese civilization."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "Oceans contain about 97% of the earth's water.",
            "answer": "True",
            "explanation": "Oceans contain about 97 per cent of the earth's water."
        },
        {
            "type": "tf",
            "q": "The Pacific Ocean covers over half of the globe.",
            "answer": "False",
            "explanation": "The Pacific Ocean covers over one third of the globe, not half."
        },
        {
            "type": "tf",
            "q": "The 'Ring of Fire' around the Pacific Ocean has the maximum concentration of active volcanoes.",
            "answer": "True",
            "explanation": "The Pacific Ocean is bordered by new fold mountains that have the maximum concentration of active volcanoes, called the 'Ring of Fire'."
        },
        {
            "type": "tf",
            "q": "The Mariana Trench is located in the Atlantic Ocean.",
            "answer": "False",
            "explanation": "The Mariana Trench is located in the Pacific Ocean near the Philippines."
        },
        {
            "type": "tf",
            "q": "The Atlantic Ocean is the busiest ocean in the world.",
            "answer": "True",
            "explanation": "The Atlantic Ocean is the busiest ocean in the world as many trade and transportation routes pass across it."
        },
        {
            "type": "tf",
            "q": "The Mid-Atlantic Ridge is a submerged mountain range in the Pacific Ocean.",
            "answer": "False",
            "explanation": "The Mid-Atlantic Ridge is in the middle of the Atlantic Ocean, not the Pacific."
        },
        {
            "type": "tf",
            "q": "The Indian Ocean lies mainly in the Northern Hemisphere.",
            "answer": "False",
            "explanation": "The Indian Ocean lies mainly in the Southern Hemisphere."
        },
        {
            "type": "tf",
            "q": "The Arctic Ocean is the largest and deepest ocean.",
            "answer": "False",
            "explanation": "The Arctic Ocean is the smallest and shallowest ocean."
        },
        {
            "type": "tf",
            "q": "The Southern Ocean surrounds the continent of Antarctica.",
            "answer": "True",
            "explanation": "The Southern Ocean or the Antarctic Ocean surrounds the continent of Antarctica."
        },
        {
            "type": "tf",
            "q": "Oceans do not affect the climate of coastal areas.",
            "answer": "False",
            "explanation": "Oceans moderate the climate of coastal areas."
        },
        {
            "type": "tf",
            "q": "By 2050, plastic will likely outweigh all fish in the sea.",
            "answer": "True",
            "explanation": "Reliable data suggest that, by 2050, plastic will likely outweigh all fish in the sea."
        },
        {
            "type": "tf",
            "q": "Plastic takes thousands of years to degrade completely.",
            "answer": "True",
            "explanation": "Plastic takes thousands of years to degrade. Even then, it becomes microplastics without fully degrading."
        },
        {
            "type": "tf",
            "q": "A sea is larger and deeper than an ocean.",
            "answer": "False",
            "explanation": "A sea is a part of an ocean that is smaller and shallower, usually close to land."
        },
        {
            "type": "tf",
            "q": "Gulfs are more indented than bays and also more enclosed.",
            "answer": "True",
            "explanation": "Gulfs are more indented than bays and also more enclosed."
        },
        {
            "type": "tf",
            "q": "The Bay of Bengal is an example of a gulf.",
            "answer": "False",
            "explanation": "The Bay of Bengal is an example of a bay, not a gulf. The Persian Gulf is an example of a gulf."
        },
        {
            "type": "tf",
            "q": "The Palk Strait connects India and Sri Lanka.",
            "answer": "True",
            "explanation": "The Palk Strait connects the Bay of Bengal with the Gulf of Mannar and separates India and Sri Lanka."
        },
        {
            "type": "tf",
            "q": "The Caspian Sea and the Dead Sea are actually lakes.",
            "answer": "True",
            "explanation": "They are large saline water bodies cut off from the open ocean, so they are technically lakes though called 'sea'."
        },
        {
            "type": "tf",
            "q": "Lakes are always made by nature, never by humans.",
            "answer": "False",
            "explanation": "There are man-made lakes like reservoirs constructed along with dams, e.g., Bhakra Nangal dam reservoir."
        },
        {
            "type": "tf",
            "q": "Lake Baikal contains 20% of the world's unfrozen freshwater.",
            "answer": "True",
            "explanation": "Lake Baikal in Siberia contains 20 per cent of the world's total unfrozen freshwater reserve."
        },
        {
            "type": "tf",
            "q": "The five Great Lakes are located entirely within the United States.",
            "answer": "False",
            "explanation": "The Great Lakes are located between the United States and Canada, shared by both countries."
        },
        {
            "type": "tf",
            "q": "Lake Titicaca is the largest lake in South America.",
            "answer": "True",
            "explanation": "Lake Titicaca is the largest lake in South America in terms of volume of water and surface area."
        },
        {
            "type": "tf",
            "q": "Lake Victoria is located in North America.",
            "answer": "False",
            "explanation": "Lake Victoria is the largest lake in Africa, lying mainly in Tanzania and Uganda bordering Kenya."
        },
        {
            "type": "tf",
            "q": "Chilika Lake is a freshwater lake in Odisha.",
            "answer": "False",
            "explanation": "Chilika Lake is a saltwater lake (brackish water) in Odisha."
        },
        {
            "type": "tf",
            "q": "Chilika Lake is a World Heritage Site in India.",
            "answer": "True",
            "explanation": "Chilika Lake is a World Heritage Site in Odisha, famous for its beauty and rich cultural heritage."
        },
        {
            "type": "tf",
            "q": "The source of a river is normally in the plains.",
            "answer": "False",
            "explanation": "The source of a river normally lies in a hill or a mountain, not in plains."
        },
        {
            "type": "tf",
            "q": "The mouth of a river is where it enters the sea.",
            "answer": "True",
            "explanation": "The mouth is normally the place where the river enters the sea."
        },
        {
            "type": "tf",
            "q": "The Nile River is the longest river in the world.",
            "answer": "True",
            "explanation": "The Nile River in Africa, 6,695 km long, is the world's longest river."
        },
        {
            "type": "tf",
            "q": "The Amazon River flows through North America.",
            "answer": "False",
            "explanation": "The Amazon River flows through South America, not North America."
        },
        {
            "type": "tf",
            "q": "The Rhine River has its source in the Alps Mountains.",
            "answer": "True",
            "explanation": "The Rhine River has its source in the Alps Mountains in Switzerland."
        },
        {
            "type": "tf",
            "q": "The Danube River flows through six European countries.",
            "answer": "False",
            "explanation": "The Danube River flows through or along the borders of ten European countries."
        },
        {
            "type": "tf",
            "q": "The Indus Valley civilization developed along the Ganga River.",
            "answer": "False",
            "explanation": "The Indus Valley civilization developed along the Indus River, not the Ganga."
        },
        {
            "type": "tf",
            "q": "The Yellow River (Huang He) is believed to be the cradle of Chinese civilization.",
            "answer": "True",
            "explanation": "Huang He, also known as the Yellow River, is believed to be the cradle of the Chinese civilization."
        },
        {
            "type": "tf",
            "q": "The Yangtze River is the longest river in Asia.",
            "answer": "True",
            "explanation": "The Yangtze River in China is the longest river in Asia and the third-longest in the world."
        },
        {
            "type": "tf",
            "q": "The Murray River is Australia's longest river.",
            "answer": "True",
            "explanation": "The Murray River is Australia's longest river, and rises in the Australian Alps."
        },
        {
            "type": "tf",
            "q": "Rivers are not important for generating electricity.",
            "answer": "False",
            "explanation": "River water is an important source of energy, used to power hydroelectric plants."
        },
        {
            "type": "tf",
            "q": "Water pollution occurs only in rivers, not in oceans.",
            "answer": "False",
            "explanation": "Water pollution affects all forms of water resources - oceans, seas, rivers, and lakes."
        },
        {
            "type": "tf",
            "q": "Surface run-off from farms carries fertilizers into water bodies.",
            "answer": "True",
            "explanation": "Surface run-off from farms carries organic and inorganic fertilizers into water bodies, promoting algae growth."
        },
        {
            "type": "tf",
            "q": "Untreated sewage discharged into rivers can cause diseases like typhoid and cholera.",
            "answer": "True",
            "explanation": "Untreated sewage exposes people to diseases such as typhoid, cholera, and amoebic dysentery."
        },
        {
            "type": "tf",
            "q": "Plastic pollution in oceans has no effect on marine life.",
            "answer": "False",
            "explanation": "Plastic waste causes tremendous harm to animals - suffocation, entanglement, laceration, infections, and internal injuries."
        },
        {
            "type": "tf",
            "q": "The Arctic Ocean remains frozen for most part of the year.",
            "answer": "True",
            "explanation": "The Arctic Ocean is located mostly within the Arctic Circle and remains frozen for most part of the year."
        },
        
        # ===== Subjective (40 questions) =====
        {
            "type": "subjective",
            "q": "Name the five oceans of the world. Describe the Pacific Ocean in detail.",
            "sample": "The five oceans of the world are:\n1. Pacific Ocean\n2. Atlantic Ocean\n3. Indian Ocean\n4. Arctic Ocean\n5. Southern Ocean (Antarctic Ocean)\n\nPacific Ocean - The Largest Ocean:\n\nSize and shape:\n- The Pacific Ocean is the largest ocean and covers over one third of the globe\n- It is almost circular in shape\n- Covers an area of about 165 million square kilometres\n\nLocation:\n- Bordered by Asia and Australia to the west\n- Bordered by the Americas to the east\n- Extends from the Arctic Ocean in the north to the Southern Ocean in the south\n\nPhysical features:\n- The deepest part of the earth's crust—the Mariana Trench—lies in this ocean near the Philippines\n- The Mariana Trench is about 11,000 metres deep\n- Other significant trenches: Philippine (Mindanao) Trench, Japan Trench, Kuril Trench\n- Has numerous islands (more than 25,000)\n- Includes the Great Barrier Reef (largest coral reef system)\n\nRing of Fire:\n- The Pacific Ocean is bordered on its edges by new fold mountains\n- These mountains have the maximum concentration of active volcanoes\n- Therefore, these mountain ranges have been termed the 'Ring of Fire'\n- Also has frequent earthquakes\n\nSeas:\n- Includes many important seas: South China Sea, East China Sea, Sea of Japan, Coral Sea, Tasman Sea, Bering Sea, etc.\n\nClimate:\n- Influences weather patterns globally\n- El Niño and La Niña phenomena originate here\n- Typhoons form in the western Pacific\n\nEconomic importance:\n- Rich fishing grounds\n- Major shipping routes\n- Oil and gas resources\n- Mineral resources (manganese nodules)\n- Tourism (islands, beaches)\n\nBiodiversity:\n- Home to diverse marine life\n- Coral reefs, whales, dolphins, turtles\n- Unique species in deep trenches\n\nThe southern part of the Pacific Ocean merges with the Atlantic and the Indian oceans."
        },
        {
            "type": "subjective",
            "q": "Describe the Atlantic Ocean and its importance.",
            "sample": "The Atlantic Ocean is the second largest ocean in the world, after the Pacific.\n\nSize and shape:\n- Shaped like the letter 'S'\n- Much smaller than the Pacific (about half its size)\n- Covers about 106 million square kilometres\n- Average depth about 3,646 metres\n\nLocation:\n- On its east coast, lie Europe and Africa\n- On its western border, lie the two Americas\n- Extends from the Arctic Ocean in the north to the Southern Ocean in the south\n\nPhysical features:\n- The Mid-Atlantic Ridge is a submerged mountain range in the middle\n- Some high peaks form islands, such as Iceland (volcanic)\n- Puerto Rico Trench is the deepest point (about 8,400 m)\n- Has several important seas: Mediterranean Sea, Caribbean Sea, North Sea, Baltic Sea\n\nWhy it is the busiest ocean:\n\n1. Trade routes:\n   - Most trade and transportation routes pass across it\n   - Connects Europe and Africa to the Americas\n   - Major shipping lanes for goods\n\n2. Ports and harbours:\n   - Has the longest coastline of all oceans\n   - The total length of its coastline is longer than the combined coastlines of the Pacific and the Indian oceans\n   - Numerous major ports: New York, Rotterdam, London, Hamburg, Santos, Cape Town\n\n3. Historical importance:\n   - Crossed by Columbus (1492) leading to discovery of Americas\n   - Major route for European colonization\n   - Transatlantic slave trade\n   - Immigrant voyages to America\n\n4. Resources:\n   - Rich fishing grounds (Grand Banks off Newfoundland)\n   - Oil and gas reserves (North Sea, Gulf of Mexico)\n   - Mineral resources\n\n5. Strategic importance:\n   - Panama Canal connects Atlantic to Pacific\n   - Strait of Gibraltar connects to Mediterranean\n   - English Channel - busy waterway\n\n6. Climate influence:\n   - Gulf Stream warms Western Europe\n   - North Atlantic Drift moderates climate\n   - Hurricane formation in tropical Atlantic\n\n7. Biodiversity:\n   - Diverse marine ecosystems\n   - Coral reefs in Caribbean\n   - Whale migration routes\n   - Deep-sea organisms\n\n8. Scientific importance:\n   - Study of plate tectonics (Mid-Atlantic Ridge)\n   - Climate research\n   - Ocean currents studies\n\nNotable features:\n- Sargasso Sea: Unique sea without land boundaries, characterized by floating seaweed\n- Bermuda Triangle: Area of mysterious disappearances (popular culture)\n- Titanic wreck site\n\nThus, the Atlantic Ocean has been the most important ocean for global trade, exploration, and economic development throughout history."
        },
        {
            "type": "subjective",
            "q": "Why is the Indian Ocean named after India? Describe its features and importance.",
            "sample": "The Indian Ocean is named after India because India is located at the head of this ocean. It is the only ocean named after a country.\n\nLocation and shape:\n- Roughly triangular in shape\n- Covers one fifth of the total area under the oceans\n- Lies mainly in the Southern Hemisphere\n- Area: about 70 million square kilometres\n\nBoundaries:\n- Asia lies to its north\n- Australia to its east\n- Africa forms its western shore\n- Southern Ocean to the south\n\nImportant parts:\n- The Arabian Sea (west of India)\n- The Bay of Bengal (east of India)\n- The Andaman Sea\n- The Red Sea\n- The Persian Gulf\n\nPhysical features:\n- Average depth about 3,741 metres\n- Deepest point: Java Trench (about 7,725 m)\n- Has several island groups: Maldives, Lakshadweep, Andaman & Nicobar, Seychelles, Mauritius, Comoros\n- Mid-ocean ridges: Ninety East Ridge, Carlsberg Ridge\n\nMonsoon winds:\n- The Indian Ocean is famous for monsoon winds\n- These winds reverse direction seasonally\n- Crucial for agriculture in South Asia\n- Historically important for sailing ships\n\nImportance of the Indian Ocean:\n\n1. Strategic location:\n   - Lies at the crossroads of three continents (Asia, Africa, Australia)\n   - Choke points: Strait of Malacca, Strait of Hormuz, Bab-el-Mandeb\n   - Important for global energy trade\n\n2. Trade routes:\n   - Major shipping lanes for oil from Persian Gulf\n   - Container ships between Asia, Africa, and Europe\n   - Historical spice trade route\n\n3. Energy resources:\n   - Rich in oil and natural gas (Persian Gulf)\n   - Major offshore oil fields\n   - Supplies much of world's energy needs\n\n4. Fisheries:\n   - Rich fishing grounds\n   - Tuna, sardines, mackerel\n   - Livelihood for millions in coastal areas\n\n5. Mineral resources:\n   - Manganese nodules on seafloor\n   - Heavy mineral sands on beaches (India)\n   - Gas hydrates\n\n6. Historical importance:\n   - Ancient trade between Indus Valley and Mesopotamia\n   - Spice trade route\n   - European colonial expansion\n   - Silk Road of the Sea\n\n7. Climate regulation:\n   - Influences monsoon patterns\n   - Cyclone formation in Bay of Bengal and Arabian Sea\n   - Affects rainfall in South Asia\n\n8. Biodiversity:\n   - Coral reefs (Maldives, Lakshadweep, Great Barrier Reef)\n   - Mangroves (Sundarbans)\n   - Sea turtles, dugongs, whales\n   - Unique island ecosystems\n\n9. Indian interests:\n   - India has long coastline (7,500 km)\n   - Exclusive Economic Zone rich in resources\n   - Andaman & Nicobar and Lakshadweep islands\n   - Strategic naval presence\n   - Blue Economy initiatives\n\nThus, the Indian Ocean is not only named after India but is also crucial for India's economy, climate, and strategic interests."
        },
        {
            "type": "subjective",
            "q": "Describe the Arctic Ocean and the Southern Ocean.",
            "sample": "The Arctic Ocean and Southern Ocean are the two oceans located at the extreme ends of the Earth - north and south respectively.\n\nArctic Ocean:\n\nLocation:\n- The northernmost ocean\n- Lies to the north of North America, Europe, and Asia\n- Centered approximately on the North Pole\n- Located mostly within the Arctic Circle\n\nSize and features:\n- Smallest and shallowest ocean\n- Area: about 14 million square kilometres\n- Average depth: about 1,038 metres\n- Deepest point: Eurasian Basin (about 5,450 m)\n\nClimate:\n- Extremely cold\n- Remains frozen for most part of the year (sea ice)\n- Polar night (24-hour darkness in winter)\n- Midnight sun (24-hour daylight in summer)\n- Temperatures can drop below -50°C\n\nSea ice:\n- Covered by floating ice pack\n- Ice thickness: 2-4 metres\n- Ice extent varies with seasons\n- Melting due to climate change\n- Northwest Passage becoming navigable\n\nBordering countries:\n- Russia\n- Canada\n- USA (Alaska)\n- Norway\n- Denmark (Greenland)\n- Iceland\n\nImportance:\n- Shortest air route between continents (polar routes)\n- Potential shipping routes (Northern Sea Route)\n- Oil and gas reserves\n- Fisheries\n- Scientific research (climate change)\n- Indigenous peoples (Inuit, Sami)\n\nSouthern Ocean (Antarctic Ocean):\n\nDefinition:\n- Formed by the merging of the Pacific, the Atlantic, and the Indian oceans\n- Surrounds the continent of Antarctica\n- Fourth largest ocean\n\nLocation:\n- Encircles Antarctica\n- Extends from the coast of Antarctica to 60°S latitude\n- Separated by Antarctic Convergence (oceanic front)\n\nSize and features:\n- Area: about 20 million square kilometres\n- Average depth: 3,000-4,000 metres\n- Deepest point: South Sandwich Trench (7,235 m)\n- Circumpolar current flows around Antarctica\n\nClimate:\n- Stormiest seas in the world\n- Strong winds (Roaring Forties, Furious Fifties)\n- Huge waves\n- Icebergs common\n- Sea ice extends far in winter\n\nUnique features:\n- Antarctic Circumpolar Current: World's largest ocean current\n- Flows clockwise around Antarctica\n- Isolates Antarctica from warmer waters\n- Upwelling of nutrient-rich waters\n\nImportance:\n\n1. Climate regulation:\n   - Drives global ocean circulation\n   - Absorbs CO₂\n   - Influences global climate\n\n2. Marine life:\n   - Rich in krill (base of food chain)\n   - Whales, seals, penguins\n   - Unique species adapted to cold\n   - Important for research\n\n3. Scientific research:\n   - Climate change studies\n   - Oceanography\n   - Marine biology\n\n4. Resources:\n   - Potential fisheries (krill)\n   - Possible mineral resources (not exploited due to Antarctic Treaty)\n\n5. Antarctic Treaty:\n   - Protects the region\n   - No military activities\n   - No mineral mining\n   - Freedom of scientific research\n\nThus, both polar oceans are unique, harsh environments crucial for global climate and marine ecosystems."
        },
        {
            "type": "subjective",
            "q": "Explain the importance of oceans with five points.",
            "sample": "Oceans are of immense importance to life on Earth and human civilization. Their significance can be explained through the following points:\n\n1. Source of food:\n   - Oceans support a large variety of aquatic life\n   - Provide food supply for many people around the world\n   - Fish is a primary protein source for billions\n   - Other seafood: shellfish, crustaceans, seaweeds\n   - Major fishing grounds in oceans\n   - Aquaculture increasingly important\n\n2. Storehouse of resources:\n   - Great storehouses of oil and mineral resources\n   - Offshore oil and natural gas extraction\n   - Manganese nodules on seafloor\n   - Heavy mineral sands on beaches\n   - Salt (from seawater evaporation)\n   - Future potential for deep-sea mining\n\n3. Climate regulation:\n   - Moderate the climate of coastal areas\n   - Oceans absorb heat in summer, release in winter\n   - Ocean currents redistribute heat around the globe\n   - Gulf Stream warms Western Europe\n   - Evaporation from oceans forms clouds\n   - Water vapour later falls as rain\n   - Absorb carbon dioxide (carbon sink)\n\n4. Transportation and trade:\n   - Facilitate international trade by providing trade routes\n   - About 90% of world trade carried by ships\n   - Cheapest mode of transport for bulk goods\n   - Major shipping lanes across all oceans\n   - Strategic choke points (canals, straits)\n   - Ports and harbours essential for economies\n\n5. Energy source:\n   - Possess enormous energy in the form of tidal waves\n   - Tidal energy (non-conventional source)\n   - Wave energy\n   - Offshore wind farms\n   - Ocean thermal energy conversion (OTEC)\n   - Potential for clean, renewable energy\n\nAdditional importance:\n\n6. Biodiversity:\n   - Home to countless marine species\n   - Coral reefs (rainforests of the sea)\n   - Unique ecosystems (hydrothermal vents)\n   - Source of new medicines\n\n7. Tourism and recreation:\n   - Beaches attract millions of tourists\n   - Water sports: surfing, diving, sailing\n   - Cruise industry\n   - Coastal economies depend on tourism\n\n8. Water cycle:\n   - Evaporation from oceans drives water cycle\n   - Source of most precipitation\n   - Maintains freshwater availability on land\n\n9. Oxygen production:\n   - Phytoplankton in oceans produce much of Earth's oxygen\n   - Often called 'lungs of the planet'\n   - Absorb carbon dioxide\n\n10. Scientific research:\n    - Study of ocean currents and climate\n    - Marine biology and ecology\n    - Geology and plate tectonics\n    - Climate change research\n    - New species discovery\n\n11. National security:\n    - Exclusive Economic Zones (EEZ)\n    - Naval presence and defence\n    - Strategic shipping routes\n\nThus, oceans are not just large water bodies but are vital for life, economy, climate, and future of humanity."
        },
        {
            "type": "subjective",
            "q": "What is SDG 14? Explain the problem of plastic pollution in oceans.",
            "sample": "SDG 14: Life Below Water\n\nSDG 14 is one of the 17 Sustainable Development Goals set by the United Nations. It aims to 'conserve and sustainably use the oceans, seas and marine resources for sustainable development.'\n\nKey targets of SDG 14:\n- Prevent and reduce marine pollution\n- Protect marine ecosystems\n- Minimize ocean acidification\n- Regulate fishing and end overfishing\n- Conserve coastal areas\n- Increase scientific knowledge\n- Implement international laws for oceans\n\nPlastic pollution in oceans:\n\nScale of the problem:\n- Plastic waste makes up 80 per cent of all marine pollution\n- Millions of tons of plastic are thrown in our ocean each year\n- By 2050, plastic will likely outweigh all fish in the sea (by weight)\n- Equivalent to dumping one garbage truck of plastic every minute\n\nWhy plastic is so harmful:\n\n1. Persistence:\n   - Plastic takes thousands of years to degrade\n   - Even then, it becomes microplastics without fully degrading\n   - Every piece of plastic ever made still exists somewhere\n\n2. Impact on marine animals:\n   - Entanglement: Animals get trapped in plastic (nets, bags, six-pack rings)\n   - Ingestion: Animals mistake plastic for food\n   - Suffocation: Plastic bags block digestive systems\n   - Laceration: Sharp plastic cuts animals\n   - Infections: Wounds from plastic get infected\n   - Internal injuries: Plastic causes internal damage\n   - Starvation: Stomach full of plastic, no room for real food\n\n3. Impact on ecosystems:\n   - Coral reefs smothered by plastic\n   - Seafloor littered with debris\n   - Microplastics enter food chain\n   - Toxic chemicals released\n\n4. Impact on humans:\n   - Microplastics found in seafood\n   - Chemicals enter human body\n   - Unknown long-term health effects\n   - Economic loss (fishing, tourism)\n   - Beach clean-up costs\n\nTypes of plastic pollution:\n\n1. Macroplastics:\n   - Large items: bottles, bags, fishing nets\n   - Visible pollution on beaches and oceans\n   - Direct threat to large animals\n\n2. Microplastics:\n   - Tiny particles (<5 mm)\n   - From breakdown of larger plastics\n   - Microbeads in cosmetics\n   - Synthetic fibres from clothing\n   - Invisible but everywhere\n   - Enter food chain at microscopic level\n\n3. Ghost fishing gear:\n   - Abandoned fishing nets\n   - Continue catching and killing marine life\n   - Can drift for years\n\nMajor sources:\n- Land-based sources (80%):\n  * Improper waste management\n  * Littering\n  * Industrial discharge\n  * Microbeads in products\n\n- Ocean-based sources (20%):\n  * Fishing gear\n  * Shipping waste\n  * Offshore platforms\n\nSolutions:\n\n1. Reduce plastic use:\n   - Avoid single-use plastics\n   - Use reusable bags, bottles, containers\n   - Refuse plastic straws and cutlery\n\n2. Improve waste management:\n   - Proper recycling\n   - Waste collection in all areas\n   - Prevent leakage to environment\n\n3. Clean-up efforts:\n   - Beach clean-ups\n   - Ocean clean-up technologies\n   - River barriers to catch plastic\n\n4. Policy and regulations:\n   - Ban on single-use plastics\n   - Extended producer responsibility\n   - International agreements\n\n5. Innovation:\n   - Biodegradable alternatives\n   - Better recycling technologies\n   - Circular economy approaches\n\nThus, addressing plastic pollution is critical for achieving SDG 14 and protecting our oceans for future generations."
        },
        {
            "type": "subjective",
            "q": "Differentiate between a gulf and a bay with a comparison table and examples.",
            "sample": "Gulfs and bays are both coastal water bodies that are partly surrounded by land, but they have distinct characteristics.\n\nComparison table:\n\n| Basis of comparison | Bay | Gulf |\n|---------------------|-----|------|\n| Meaning | It is a broad, semi-circular inlet of sea; it can be accessed by land from three sides. | A water body where the water has eroded the coastline so deeply that it has a narrow opening. |\n| Shape | Broad, curving indentation | Deep, penetrating indentation |\n| Mouth | Wider opening | Narrower opening |\n| Indentation | Wide indentation of the sea | Deep indentation of sea |\n| Enclosure | Less enclosed | More enclosed |\n| Formation | Continental drift and erosion of coastline | Movement of the earth's plates and erosion |\n| Examples | Bay of Bengal, Hudson Bay, Bay of Biscay, Bay of Fundy | Persian Gulf, Gulf of Mexico, Gulf of Carpentaria, Gulf of Oman |\n\nDetailed explanation:\n\nBay:\n- A bay is an open, curving indentation made by the sea or a lake into a coastline\n- It has a wide mouth and is less enclosed\n- Bays often provide safe harbours for ships\n- Formation: Usually formed by erosion of softer rocks by sea waves, or by continental drift\n- Bay of Bengal: World's largest bay (about 2.2 million sq km)\n- Hudson Bay: Large bay in northern Canada\n- Bay of Biscay: Between France and Spain\n- Bay of Fundy: Famous for having the highest tidal range in the world\n\nGulf:\n- A gulf is a deep inlet of the sea almost surrounded by land, with a narrow mouth\n- It penetrates deep into the land\n- Gulfs are more indented than bays and also more enclosed\n- Formation: Often formed by tectonic movements (faulting) or by submergence of coastal valleys\n- Persian Gulf: Between Iran and Arabian Peninsula, about 1,000 km long\n- Gulf of Mexico: Large gulf bordered by USA and Mexico, connected to Atlantic by narrow straits\n- Gulf of Carpentaria: Large shallow gulf in northern Australia\n- Gulf of Oman: Connects Arabian Sea to Persian Gulf through Strait of Hormuz\n\nKey differences summarized:\n\n1. Shape:\n   - Bay: Broad, sweeping curve\n   - Gulf: Deep, narrow-mouthed penetration\n\n2. Size comparison:\n   - Not all bays are smaller than gulfs (Bay of Bengal is larger than most gulfs)\n   - Generally, gulfs tend to be more enclosed\n\n3. Formation:\n   - Bays: Often erosional features\n   - Gulfs: Often tectonic features\n\n4. Naming convention:\n   - Some water bodies named 'gulf' are actually bays and vice versa\n   - Based on historical names, not strict classification\n\n5. Examples of both in one region:\n   - Gulf of Mannar and Palk Bay (between India and Sri Lanka)\n   - Gulf of Thailand and Thailand Bay (not a standard name)\n\nThus, while both are coastal indentations, gulfs are generally deeper, more enclosed, and have narrower mouths compared to bays."
        },
        {
            "type": "subjective",
            "q": "What are straits? Give examples and explain their importance.",
            "sample": "A strait is a narrow passage of water connecting two larger water bodies (seas or oceans). It is a naturally formed narrow channel that lies between two land masses.\n\nCharacteristics of straits:\n- Narrow passage of water\n- Connects two larger water bodies\n- Lies between two land masses\n- Often forms important shipping routes\n- May have strong currents\n- Can be shallow or deep\n\nExamples of important straits:\n\n1. Palk Strait:\n   - Connects Bay of Bengal (north-east) with Gulf of Mannar (south-west)\n   - Separates India (Tamil Nadu) and Sri Lanka\n   - About 100 km long, 64-137 km wide\n   - Shallow with reefs and islands (Adam's Bridge)\n\n2. Strait of Malacca:\n   - Connects Andaman Sea (Indian Ocean) with South China Sea (Pacific Ocean)\n   - Between Malay Peninsula (Malaysia) and Sumatra (Indonesia)\n   - One of the world's busiest shipping lanes\n   - About 800 km long, 65-250 km wide\n   - Carries about 25% of world's trade\n   - Critical for oil shipments to China, Japan, South Korea\n\n3. Strait of Gibraltar:\n   - Connects Mediterranean Sea with Atlantic Ocean\n   - Separates Spain (Europe) and Morocco (Africa)\n   - About 60 km long, 14-44 km wide\n   - Only natural connection between Mediterranean and Atlantic\n   - Strong currents and famous Rock of Gibraltar\n\n4. Bering Strait:\n   - Connects Arctic Ocean with Bering Sea (Pacific Ocean)\n   - Separates Russia (Siberia) and USA (Alaska)\n   - About 82 km wide at narrowest\n   - Shallow (30-50 m deep)\n   - Diomede Islands in the middle\n   - Possible land bridge during ice ages (human migration)\n\n5. Strait of Hormuz:\n   - Connects Persian Gulf with Gulf of Oman (Arabian Sea)\n   - Between Iran and Oman (with UAE to south)\n   - About 50 km wide at narrowest\n   - Most important oil chokepoint in the world\n   - About 20% of world's oil passes through\n\n6. Dover Strait (Strait of Calais):\n   - Connects English Channel with North Sea\n   - Separates England and France\n   - Narrowest part of English Channel (34 km)\n   - Channel Tunnel (Chunnel) runs under it\n   - One of world's busiest shipping lanes\n\n7. Bab-el-Mandeb Strait:\n   - Connects Red Sea with Gulf of Aden (Indian Ocean)\n   - Between Yemen (Arabia) and Djibouti (Africa)\n   - About 30 km wide\n   - Strategic for Suez Canal traffic\n\n8. Sunda Strait:\n   - Between Java and Sumatra (Indonesia)\n   - Connects Java Sea with Indian Ocean\n   - Krakatoa volcano located here\n\n9. Torres Strait:\n   - Between Australia and Papua New Guinea\n   - Connects Coral Sea with Arafura Sea\n   - Many islands and reefs\n\n10. Cook Strait:\n    - Between North and South Islands of New Zealand\n    - Connects Tasman Sea with Pacific Ocean\n\nImportance of straits:\n\n1. Shipping routes:\n   - Shortcuts between oceans and seas\n   - Save time, fuel, and money\n   - Avoid long journeys around continents\n\n2. Trade and commerce:\n   - Major chokepoints for global trade\n   - Strait of Malacca: 25% of world trade\n   - Strait of Hormuz: 20% of world's oil\n\n3. Strategic importance:\n   - Naval control of straits = control of trade\n   - Military significance\n   - Geopolitical tension points\n\n4. Economic value:\n   - Toll collection (some straits)\n   - Ports develop at both ends\n   - Coastal communities benefit\n\n5. Marine biodiversity:\n   - Mixing of waters from different seas\n   - Unique ecosystems\n   - Migration routes for marine animals\n\n6. Cultural exchange:\n   - Historical migration routes\n   - Trade and cultural contact\n   - Bering Strait land bridge theory\n\n7. Scientific research:\n   - Ocean currents\n   - Marine biology\n   - Climate studies\n\nThus, straits are narrow but immensely important waterways for global connectivity, trade, and strategic interests."
        },
        {
            "type": "subjective",
            "q": "Describe any five important lakes of the world with their features.",
            "sample": "Lakes are important freshwater or saline water bodies that support ecosystems, provide water resources, and have cultural significance. Here are five important lakes of the world:\n\n1. Lake Baikal (Russia):\n\nLocation:\n- Located in south-east Siberia, Russia\n- Between Irkutsk Oblast and Buryatia\n\nFeatures:\n- Oldest lake in the world (25-30 million years)\n- Deepest lake in the world (1,642 metres maximum depth)\n- Contains about 20% of world's unfrozen freshwater\n- Volume: 23,600 cubic kilometres\n- Length: 636 km, Width: up to 80 km\n- Over 300 rivers flow into it, only one (Angara) flows out\n\nBiodiversity:\n- Often called the 'Galapagos of Russia'\n- Over 1,500 endemic species\n- Unique freshwater seal (Baikal seal or nerpa)\n- Rich in fish (omul, grayling, sturgeon)\n- UNESCO World Heritage Site\n\n2. Lake Superior (USA/Canada):\n\nLocation:\n- Between United States and Canada\n- Borders Minnesota, Wisconsin, Michigan, and Ontario\n\nFeatures:\n- Largest of the Great Lakes\n- Largest freshwater lake in the world by surface area (82,100 sq km)\n- Third largest by volume\n- Maximum depth: 406 metres\n- Over 200 rivers flow into it\n- Contains 10% of world's surface freshwater\n\nCharacteristics:\n- Very clear water (visibility up to 15 metres)\n- Often stormy with waves up to 9 metres\n- Ice cover in winter\n- Important for shipping (iron ore, grain)\n\n3. Lake Victoria (Africa):\n\nLocation:\n- East Africa, bordered by Tanzania, Uganda, Kenya\n- In the Great Rift Valley region\n\nFeatures:\n- Largest lake in Africa (68,800 sq km)\n- Main reservoir of the Nile River\n- Second largest freshwater lake in the world by area\n- Shallow (maximum depth 84 metres)\n- Over 3,000 islands\n- Supports the world's largest freshwater fishery\n\nBiodiversity:\n- Over 500 species of cichlid fish (many endemic)\n- Nile perch introduced (caused extinctions)\n- Hippos, crocodiles, otters\n- Water hyacinth (invasive weed) problem\n\nChallenges:\n- Pollution from cities\n- Overfishing\n- Invasive species\n- Water level fluctuations\n\n4. Lake Titicaca (Peru/Bolivia):\n\nLocation:\n- In the Andes Mountains\n- Border between Peru and Bolivia\n- At altitude of 3,812 metres\n\nFeatures:\n- Highest navigable lake in the world\n- Largest lake in South America by volume\n- Second largest by surface area (8,372 sq km)\n- Maximum depth: 281 metres\n- 25+ rivers flow into it, one small outlet\n- Water slightly saline\n\nCultural significance:\n- Sacred to Incas (believed birthplace of the sun)\n- Lake of the Sun and Lake of the Moon\n- Uros people live on floating reed islands\n- Important archaeological sites\n- Tourism destination (Copacabana, Sun Island)\n\n5. Chilika Lake (India):\n\nLocation:\n- In Odisha, India (Puri, Khordha, Ganjam districts)\n- Asia's largest brackish water lagoon\n\nFeatures:\n- Area varies from 900 to 1,165 sq km (seasonal)\n- Connected to Bay of Bengal by 32 km long, 1.5 km wide channel\n- Shallow (average depth 2-4 metres)\n- Many islands: Krushnaprasad, Nalaban, Kalijai, Somolo, Birds Islands\n- Brackish water (mix of fresh and salt water)\n\nBiodiversity:\n- Largest wintering ground for migratory birds in Indian subcontinent\n- Over 160 species of birds\n- Irrawaddy dolphins (endangered)\n- Rich fishery supports over 2 lakh fishermen\n- Home to threatened species\n\nRecognition:\n- First Indian wetland designated under Ramsar Convention\n- UNESCO World Heritage Site\n- Important for biodiversity conservation\n\nThreats:\n- Siltation (reducing water depth)\n- Pollution from agriculture\n- Inlet mouth shifting\n- Overfishing\n\nThus, each of these lakes is unique in its features, biodiversity, and importance to the regions they are located in."
        },
        {
            "type": "subjective",
            "q": "Write a note on Chilika Lake. Why is it important for India?",
            "sample": "Chilika Lake is a brackish water lake located in the state of Odisha, India. It is the largest brackish water lagoon in Asia and one of the most important wetlands in the world.\n\nLocation:\n- Spread across the districts of Puri, Khordha and Ganjam in Odisha\n- Situated along the eastern coast of India, near the Bay of Bengal\n- Coordinates: approximately 19°28′N to 19°54′N latitude\n\nPhysical features:\n- Area varies between 900 to 1,165 sq. km (during summers and monsoon respectively)\n- Connected to the Bay of Bengal by a 32 km long and 1.5 km wide channel\n- Shallow lagoon with average depth of 2-4 metres\n- Brackish water (mix of fresh and salt water)\n- Many islands present: Krushnaprasad, Nalaban, Kalijai, Somolo, Birds Islands\n\nImportance of Chilika Lake for India:\n\n1. Biodiversity hotspot:\n   - In winter, it becomes the largest ground for migratory birds in the Indian subcontinent\n   - Hosts over 160 species of birds (some from as far as Siberia)\n   - Home to a number of threatened species of plants and animals\n   - Important habitat for the Irrawaddy dolphins (endangered species)\n   - Rich aquatic biodiversity (fish, crabs, prawns)\n\n2. Economic importance:\n   - The fishery resources of the lake provide livelihood to more than 2 lakh fishermen\n   - Supports fishing communities in surrounding areas\n   - Important for aquaculture and fish production\n   - Eco-tourism generates revenue\n   - Local employment through tourism and fishing\n\n3. Ecological significance:\n   - Acts as a natural drainage basin for the region\n   - Helps in flood control during monsoon\n   - Maintains ecological balance in coastal area\n   - Supports unique ecosystem (brackish water)\n   - Nursery for many marine species\n\n4. Cultural importance:\n   - Kalijai Temple on an island is a famous pilgrimage site\n   - Local legends and folklore associated with the lake\n   - Traditional fishing practices and communities\n   - Integral part of Odisha's cultural identity\n\n5. Tourism destination:\n   - Famous for its scenic beauty\n   - Bird watching paradise\n   - Dolphin watching tours\n   - Boat rides to islands\n   - Attracts domestic and international tourists\n\n6. Recognition and conservation:\n   - First Indian wetland designated under the Ramsar Convention (1981)\n   - UNESCO World Heritage Site\n   - Chilika Development Authority (CDA) established for conservation\n   - Successful restoration projects (opening of new mouth to sea)\n   - Model for wetland conservation in India\n\n7. Scientific research:\n   - Important site for wetland ecology studies\n   - Ornithology research (bird migration)\n   - Dolphin research\n   - Climate change impact studies\n\n8. Climate regulation:\n   - Acts as carbon sink\n   - Modifies local climate\n   - Protects coast from storms\n   - Groundwater recharge\n\nThreats to Chilika Lake:\n- Siltation from rivers reducing depth\n- Pollution from agricultural runoff\n- Shifting of inlet mouth\n- Overfishing\n- Invasive species\n- Climate change impacts\n\nConservation efforts:\n- Opening of new mouth to sea (2000) to improve water exchange\n- Removal of illegal aquaculture\n- Community participation in conservation\n- Regular monitoring\n- Eco-development programmes\n\nThus, Chilika Lake is not just a geographical feature but an ecological, economic, and cultural treasure for India, supporting livelihoods, biodiversity, and heritage."
        },
        {
            "type": "subjective",
            "q": "Explain the course of a river with its three stages.",
            "sample": "A river is a stream of water which flows in a channel from high ground to low ground and finally to a lake or a sea. The route or the course of a river has three different stages - upper, middle, and lower.\n\nUpper Course (Mountain Stage):\n\nLocation:\n- In the mountains where the land is steep\n- Near the source of the river\n\nCharacteristics:\n- River flows very swiftly at this stage\n- Narrow and shallow channel\n- Steep gradient (slope)\n- Vertical erosion (downward cutting) dominant\n\nLandforms formed:\n- V-shaped valleys: River cuts down rapidly\n- Gorges: Deep, narrow valleys with steep sides\n- Rapids: Fast-flowing, turbulent sections\n- Waterfalls: Where river drops vertically\n- Interlocking spurs: Hills that interlock like teeth\n\nFeatures:\n- Tributaries join the main river\n- Less volume of water\n- Clear, cold water\n- Boulders and large rocks in riverbed\n\nMiddle Course (Valley Stage):\n\nLocation:\n- After the river descends to the plains from the mountains\n- Gentler slopes than upper course\n\nCharacteristics:\n- Speed of flow decreases considerably\n- Broader and deeper channel\n- Less steep gradient\n- Lateral erosion (sideways cutting) dominant\n- Meanders begin to form\n\nLandforms formed:\n- Meanders: Bends and loops in the river\n- River cliffs: On outer bend (steep)\n- Slip-off slopes: On inner bend (gentle)\n- Floodplains: Flat land on either side\n- Ox-bow lakes: Cut-off meander loops\n\nFeatures:\n- More volume of water\n- Less sediment load carried\n- Valley widens\n- Tributaries continue to join\n\nLower Course (Plain Stage):\n\nLocation:\n- Near the mouth of the river\n- Where the slope is negligible\n\nCharacteristics:\n- Flow has nearly halted (very slow)\n- Very broad and deep channel\n- Almost flat gradient\n- Deposition dominant (river deposits sediment)\n- Meanders become very large\n\nLandforms formed:\n- Floodplains: Wide flat areas\n- Levees: Natural embankments along banks\n- Deltas: Triangular deposits at mouth\n- Estuaries: Drowned river mouths (tidal)\n- Distributaries: Branches before joining sea\n\nFeatures:\n- Maximum volume of water\n- Carries fine sediment (silt and clay)\n- River splits into distributaries\n- Brackish water near mouth\n\nComparison of the three stages:\n\n| Feature | Upper Course | Middle Course | Lower Course |\n|---------|--------------|---------------|--------------|\n| Gradient | Steep | Moderate | Gentle |\n| Speed | Fast | Medium | Slow |\n| Erosion/Deposition | Vertical erosion | Lateral erosion | Deposition |\n| Channel | Narrow, shallow | Broader | Wide, deep |\n| Landforms | V-shaped valley, waterfalls | Meanders, ox-bow lakes | Delta, floodplain |\n| Sediment | Large rocks | Sand, gravel | Silt, clay |\n| Volume | Small | Medium | Large |\n\nThus, a river's course changes dramatically from its source to its mouth, shaped by the processes of erosion, transportation, and deposition."
        },
        {
            "type": "subjective",
            "q": "Describe the major rivers of the world and their importance.",
            "sample": "Rivers are extremely important resources that have shaped civilizations and continue to support life and economy. Here are the major rivers of the world:\n\n1. Nile River (Africa):\n\nFeatures:\n- Longest river in the world (6,695 km)\n- Flows through Uganda, South Sudan, Sudan, Egypt\n- Source: Lake Victoria (Uganda) and Blue Nile from Ethiopia\n- Mouth: Mediterranean Sea (forms Nile Delta)\n- Major tributaries: Blue Nile, White Nile, Atbara\n\nImportance:\n- Cradle of ancient Egyptian civilization\n- Supports 95% of Egypt's population\n- Aswan High Dam for hydroelectricity and irrigation\n- Nile Delta is highly fertile agricultural area\n- Tourism (cruises, historical sites)\n\n2. Amazon River (South America):\n\nFeatures:\n- Second longest river (6,640 km) but largest by volume\n- Flows through Peru, Colombia, Brazil\n- Source: Andes Mountains (Peru)\n- Mouth: Atlantic Ocean (huge estuary)\n- Over 1,000 tributaries\n- Discharges 20% of world's river water into oceans\n\nImportance:\n- Amazon rainforest (biodiversity hotspot)\n- Only river with extensive rainforest along its course\n- Important for transportation in remote areas\n- Hydroelectric potential\n- Rich in fish species (including piranha)\n\n3. Yangtze River (China):\n\nFeatures:\n- Longest river in Asia (6,300 km)\n- Third longest in the world\n- Flows entirely through China\n- Source: Tibetan Plateau\n- Mouth: East China Sea (near Shanghai)\n- Major tributaries: Yalong, Min, Jialing, Han\n\nImportance:\n- Cradle of Chinese civilization\n- Three Gorges Dam (world's largest hydroelectric project)\n- Major transportation artery (called 'Golden Waterway')\n- Supports one-third of China's population\n- Fertile Yangtze Delta (major agricultural region)\n\n4. Mississippi-Missouri River (USA):\n\nFeatures:\n- Longest river system in North America (6,275 km)\n- Flows through 10 US states\n- Source: Lake Itasca (Minnesota)\n- Mouth: Gulf of Mexico (bird-foot delta)\n- Major tributaries: Missouri, Ohio, Arkansas, Red\n\nImportance:\n- Major transportation route for agricultural products\n- Supports intensive agriculture in Great Plains\n- Important for industry and commerce\n- New Orleans at mouth is major port\n- Cultural significance (Mark Twain, American literature)\n\n5. Ganga River (India/Bangladesh):\n\nFeatures:\n- Length: 2,525 km (within India)\n- Source: Gangotri Glacier (Uttarakhand) - Bhagirathi\n- Flows through India (Uttarakhand, UP, Bihar, Jharkhand, West Bengal)\n- Enters Bangladesh as Padma, joins Brahmaputra\n- Mouth: Bay of Bengal (forms Sundarbans delta)\n\nImportance:\n- Most sacred river to Hindus\n- Ganga Basin supports 40% of India's population\n- Highly fertile alluvial soil (Indo-Gangetic Plain)\n- Major irrigation source\n- Religious tourism (Haridwar, Varanasi, Allahabad)\n\n6. Indus River (India/Pakistan):\n\nFeatures:\n- Length: 3,180 km\n- Source: Tibet (near Mansarovar Lake)\n- Flows through India (Ladakh) and Pakistan\n- Major tributaries: Jhelum, Chenab, Ravi, Beas, Sutlej\n- Mouth: Arabian Sea (near Karachi)\n\nImportance:\n- Cradle of Indus Valley Civilization (Harappa, Mohenjo-daro)\n- Pakistan's lifeline (supports agriculture)\n- Indus Basin irrigation system (one of world's largest)\n- Important for hydroelectricity\n- Cultural and historical significance\n\n7. Danube River (Europe):\n\nFeatures:\n- Second longest river in Europe (2,860 km)\n- Flows through 10 countries: Germany, Austria, Slovakia, Hungary, Croatia, Serbia, Bulgaria, Romania, Moldova, Ukraine\n- Source: Black Forest (Germany)\n- Mouth: Black Sea (Danube Delta)\n\nImportance:\n- Most international river in the world\n- Important transportation route\n- Danube Delta (UNESCO Biosphere Reserve)\n- Hydroelectric power\n- Tourism (river cruises popular)\n\n8. Rhine River (Europe):\n\nFeatures:\n- Length: 1,230 km\n- Flows through 6 countries: Switzerland, Liechtenstein, Austria, Germany, France, Netherlands\n- Source: Swiss Alps\n- Mouth: North Sea (Rotterdam)\n\nImportance:\n- Europe's busiest waterway\n- Major industrial region (Ruhr Valley)\n- Rotterdam (Europe's largest port)\n- Scenic beauty (castles, vineyards)\n- Wine production along valley\n\nThus, rivers are essential for agriculture, transportation, industry, culture, and supporting civilizations throughout history."
        },
        {
            "type": "subjective",
            "q": "Explain the importance of rivers with examples.",
            "sample": "Rivers are extremely important resources that have shaped human civilization and continue to support life and economy. Their importance can be explained through the following points:\n\n1. Source of fresh water:\n   - Rivers provide fresh water for drinking, domestic use, and sanitation\n   - Major cities located along rivers (Delhi on Yamuna, London on Thames, Cairo on Nile)\n   - Groundwater recharge depends on rivers\n   - Essential for survival of terrestrial life\n\n2. Agriculture and irrigation:\n   - River valleys and plains provide fertile soils\n   - Alluvial soil deposited by rivers is highly fertile\n   - Crops grow in plenty in and around river regions\n   - Irrigation from rivers enables farming even in dry seasons\n   - Examples:\n     * Nile Valley: Fertile for thousands of years\n     * Indo-Gangetic Plain: 'Granary of India'\n     * Yangtze Delta: Major rice-producing region\n\n3. Transportation and trade:\n   - Rivers provide means of transport to carry humans and goods\n   - Inland waterways are cheaper than road or rail\n   - Rivers connect interior regions to coasts\n   - Facilitate trade between regions and countries\n   - Examples:\n     * Rhine River: Europe's busiest waterway\n     * Mississippi River: Major transport route for grain\n     * Ganga River: Inland waterway in India\n\n4. Energy generation:\n   - River water is an important source of energy\n   - Used to power hydroelectric plants\n   - Hydroelectricity is clean and renewable\n   - Dams on rivers generate electricity\n   - Examples:\n     * Three Gorges Dam (Yangtze, China): World's largest\n     * Bhakra Nangal Dam (Sutlej, India)\n     * Aswan High Dam (Nile, Egypt)\n\n5. Industrial use:\n   - Industries require large amounts of water\n   - Rivers provide water for cooling, processing, and waste disposal\n   - Help industries to grow and prosper\n   - Examples:\n     * Ruhr Valley (Germany): Industrial region along Rhine\n     * Pittsburgh (USA): Steel industry on Ohio River\n\n6. Fisheries and food:\n   - Rivers support fish and aquatic life\n   - Provide livelihood for fishing communities\n   - Source of protein for millions\n   - Examples:\n     * Ganga: Hilsa, Rohu, Catla\n     * Amazon: Over 2,000 fish species\n\n7. Cultural and religious significance:\n   - Many rivers considered sacred\n   - Religious rituals and festivals along rivers\n   - Pilgrimage sites on river banks\n   - Examples:\n     * Ganga: Most sacred river to Hindus\n     * Jordan River: Baptism of Jesus\n     * Nile: Ancient Egyptian religion\n\n8. Tourism and recreation:\n   - Rivers provide means for recreational activities\n   - Boating, rafting, fishing, swimming\n   - Scenic beauty attracts tourists\n   - River cruises popular worldwide\n   - Examples:\n     * Amazon River cruises\n     * Danube River cruises in Europe\n     * Rafting in Ganga (Rishikesh)\n\n9. Historical significance:\n   - Ancient civilizations developed along rivers\n   - River valleys cradles of early cultures\n   - Examples:\n     * Indus Valley civilization (Indus River)\n     * Mesopotamian civilization (Tigris-Euphrates)\n     * Egyptian civilization (Nile River)\n     * Chinese civilization (Yellow River - Huang He)\n\n10. Ecosystem support:\n    - Rivers support diverse ecosystems\n    - Riparian zones (along banks) rich in biodiversity\n    - Floodplains support unique habitats\n    - Deltas are biodiversity hotspots\n    - Examples:\n      * Sundarbans (Ganga-Brahmaputra delta): Mangrove forest, tigers\n      * Amazon Basin: World's largest rainforest\n      * Danube Delta: UNESCO Biosphere Reserve\n\n11. Sediment deposition:\n    - Rivers carry sediment from mountains\n    - Deposit in plains and deltas\n    - Create fertile agricultural land\n    - Build deltas at mouths\n    - Example:\n      * Nile Delta: Fertile agricultural region\n      * Ganga-Brahmaputra Delta: World's largest delta\n\n12. Natural boundaries:\n    - Rivers often form boundaries between countries or states\n    - Examples:\n      * Rio Grande: USA-Mexico border\n      * Indus: India-Pakistan (partly)\n\nThus, rivers are not just water bodies but lifelines that support human civilization, economy, culture, and ecosystems in countless ways."
        },
        {
            "type": "subjective",
            "q": "What is water pollution? Explain its causes and effects.",
            "sample": "Water pollution is a type of pollution which occurs when harmful substances (pollutants) are discharged into water bodies such as rivers, lakes, oceans, and groundwater. It affects all forms of water resources on earth and poses serious threats to human health, aquatic life, and ecosystems.\n\nDefinition:\nWater pollution is the contamination of water bodies by harmful substances, making the water unfit for drinking, domestic use, agriculture, or supporting aquatic life.\n\nMajor causes of water pollution:\n\n1. Domestic sewage (household waste):\n   - Untreated liquid waste from kitchens and toilets\n   - Contains human waste, food scraps, detergents, soaps\n   - Often discharged directly into rivers in developing countries\n   - High in organic matter and pathogens\n   - Causes diseases like typhoid, cholera, amoebic dysentery\n\n2. Industrial waste:\n   - Factories discharge chemicals, heavy metals, toxins\n   - Includes acids, alkalis, dyes, pesticides, oils\n   - Thermal pollution from power plants (hot water)\n   - Liquid waste from thermal power plants increases dissolved oxygen content, leading to sudden rise in microbe population\n   - This reduces oxygen level, making it difficult for other organisms to survive\n\n3. Agricultural runoff:\n   - Surface run-off from farms carries organic and inorganic fertilizers\n   - Also carries pesticides and insecticides\n   - Promotes growth of algae (eutrophication)\n   - Algal blooms reduce dissolved oxygen\n   - Other living organisms, including fish, cannot survive\n   - Nitrates contaminate groundwater\n\n4. Oil spills:\n   - Accidental spills from oil tankers\n   - Offshore drilling accidents\n   - Causes thick oil layer on water surface\n   - Prevents oxygen exchange\n   - Kills marine birds, fish, and other life\n   - Difficult and expensive to clean up\n\n5. Plastic pollution:\n   - Plastic waste dumped into water bodies\n   - Takes thousands of years to degrade\n   - Breaks into microplastics\n   - Ingested by marine animals\n   - Enters food chain\n\n6. Marine dumping:\n   - Ships dumping waste at sea\n   - Dredging materials\n   - Sewage sludge\n   - Radioactive waste (historically)\n\n7. Mining activities:\n   - Acid mine drainage\n   - Heavy metals (mercury, lead, arsenic)\n   - Sediment runoff\n\n8. Urban runoff:\n   - Rainwater washes pollutants from streets\n   - Oil, grease, chemicals from roads\n   - Pet waste, litter\n\n9. Construction activities:\n   - Silt and sediment runoff\n   - Chemicals from construction sites\n\n10. Atmospheric deposition:\n    - Air pollutants settle into water\n    - Acid rain (from industrial emissions)\n    - Mercury from coal burning\n\nEffects of water pollution:\n\n1. Human health impacts:\n   - Waterborne diseases:\n     * Cholera: Severe diarrhoea, dehydration\n     * Typhoid: High fever, intestinal issues\n     * Hepatitis A: Liver infection\n     * Dysentery: Bloody diarrhoea\n     * Polio (in unvaccinated populations)\n   - Chemical poisoning (heavy metals)\n   - Cancer from long-term exposure\n   - Reproductive issues\n   - Over 2 million deaths annually from waterborne diseases (WHO)\n\n2. Aquatic life impacts:\n   - Fish kills due to low oxygen\n   - Death of coral reefs\n   - Bioaccumulation of toxins in food chain\n   - Reproductive failure in aquatic animals\n   - Habitat destruction\n   - Loss of biodiversity\n   - Algal blooms (eutrophication)\n   - Dead zones (areas with no oxygen)\n\n3. Ecosystem disruption:\n   - Imbalance in aquatic ecosystems\n   - Loss of sensitive species\n   - Invasive species thrive in polluted water\n   - Disruption of food chains\n   - Reduced ecosystem services\n\n4. Economic impacts:\n   - Fishing industry losses\n   - Tourism decline (beaches, water sports)\n   - Cost of water treatment\n   - Healthcare costs for waterborne diseases\n   - Clean-up expenses\n   - Reduced property values\n\n5. Social impacts:\n   - Communities lose access to clean water\n   - Women and children spend time collecting water\n   - Conflict over water resources\n   - Displacement of communities\n\n6. Agricultural impacts:\n   - Contaminated irrigation water affects crops\n   - Reduced crop yields\n   - Contaminated soil\n   - Food safety concerns\n\n7. Groundwater contamination:\n   - Aquifers polluted (difficult to clean)\n   - Drinking water sources ruined\n   - Long-term contamination\n\n8. Climate change connection:\n   - Warmer water holds less oxygen\n   - Algal blooms increase with temperature\n   - Melting ice releases stored pollutants\n\nThus, water pollution is a serious global problem requiring urgent action through proper waste treatment, regulations, and individual responsibility."
        },
        {
            "type": "subjective",
            "q": "What are the main causes of water pollution? Suggest measures to control it.",
            "sample": "Water pollution occurs when harmful substances contaminate water bodies, making them unfit for use. Understanding the causes is essential for developing effective control measures.\n\nMain causes of water pollution:\n\n1. Domestic sewage:\n   - Untreated wastewater from households\n   - Contains human excreta, food waste, detergents, soaps\n   - High in organic matter and pathogens\n   - Common in areas without proper sanitation\n   - Causes oxygen depletion in water bodies\n\n2. Industrial effluents:\n   - Factories discharge chemicals, heavy metals, toxins\n   - Includes acids, alkalis, dyes, oils, organic compounds\n   - Thermal pollution from power plants (heated water)\n   - Liquid waste from thermal power plants increases dissolved oxygen content, causing microbe population to rise, reducing oxygen for other organisms\n\n3. Agricultural runoff:\n   - Fertilizers (nitrogen, phosphorus) washed into water\n   - Pesticides and insecticides\n   - Animal waste from farms\n   - Causes eutrophication (algal blooms)\n   - Algal blooms block sunlight and deplete oxygen\n\n4. Oil spills:\n   - Accidental spills from tankers\n   - Offshore drilling accidents\n   - Routine shipping operations\n   - Creates oil slicks that harm marine life\n\n5. Plastic pollution:\n   - Single-use plastics dumped into water\n   - Fishing nets and gear abandoned\n   - Microplastics from breakdown of larger items\n   - Ingested by aquatic animals\n\n6. Mining activities:\n   - Acid mine drainage\n   - Heavy metal contamination\n   - Sediment runoff\n\n7. Urban runoff:\n   - Rainwater washes pollutants from streets\n   - Oil, grease, heavy metals from vehicles\n   - Pet waste, litter\n\n8. Construction activities:\n   - Silt and sediment runoff\n   - Construction chemicals\n\n9. Marine dumping:\n   - Ships dumping waste at sea\n   - Dredged materials\n\n10. Atmospheric deposition:\n    - Air pollutants settling into water\n    - Acid rain\n\nMeasures to control water pollution:\n\nA. Treatment of waste:\n\n1. Sewage treatment:\n   - Build sewage treatment plants in all cities\n   - Treat wastewater before releasing into rivers\n   - Primary treatment: Remove solids\n   - Secondary treatment: Biological treatment\n   - Tertiary treatment: Advanced cleaning\n   - Promote safe disposal of human waste\n\n2. Industrial effluent treatment:\n   - Factories must treat waste on site\n   - Install effluent treatment plants (ETPs)\n   - Remove toxins before discharge\n   - Recycle and reuse water in industries\n   - Strict regulations on toxic discharges\n\n3. Agricultural practices:\n   - Use fertilizers judiciously (optimal amounts)\n   - Promote organic farming\n   - Buffer zones along water bodies\n   - Contour farming to reduce runoff\n   - Integrated pest management (reduce pesticides)\n\nB. Legal and regulatory measures:\n\n4. Water pollution laws:\n   - Strict enforcement of water pollution laws\n   - Penalties for violators\n   - Water (Prevention and Control of Pollution) Act in India\n   - Environmental Protection Agency (EPA) in USA\n\n5. Standards and monitoring:\n   - Set water quality standards\n   - Regular monitoring of water bodies\n   - Real-time monitoring systems\n   - Public disclosure of data\n\nC. Waste management:\n\n6. Solid waste management:\n   - Proper collection and disposal of garbage\n   - Prevent dumping in water bodies\n   - Recycling programmes\n   - Composting of organic waste\n\n7. Plastic waste reduction:\n   - Ban single-use plastics\n   - Promote reusable alternatives\n   - Extended producer responsibility\n   - Clean-up drives\n\nD. Community participation:\n\n8. Public awareness:\n   - Education about water pollution\n   - Campaigns to keep water bodies clean\n   - School programmes\n   - Media campaigns\n\n9. Community involvement:\n   - River adoption programmes\n   - Clean-up drives\n   - Citizen science monitoring\n   - Reporting pollution incidents\n\nE. Technological solutions:\n\n10. Advanced treatment:\n    - Membrane filtration\n    - Reverse osmosis\n    - UV treatment\n    - Constructed wetlands (natural treatment)\n\n11. Pollution prevention:\n    - Cleaner production technologies\n    - Zero liquid discharge industries\n    - Green chemistry\n\nF. Individual actions:\n\n12. At home:\n    - Don't pour chemicals down drains\n    - Use eco-friendly soaps and detergents\n    - Properly dispose of household hazardous waste\n    - Fix leaks to conserve water\n\n13. Reduce plastic use:\n    - Carry reusable bags\n    - Avoid bottled water\n    - Refuse single-use plastics\n\n14. Gardening:\n    - Use natural fertilizers\n    - Avoid pesticides\n    - Plant trees along water bodies\n\nG. International cooperation:\n\n15. Treaties and agreements:\n    - International conventions on marine pollution\n    - Cooperation on transboundary rivers\n    - Sharing of best practices\n\nThus, controlling water pollution requires a multi-pronged approach involving government regulation, industrial responsibility, community participation, and individual action."
        }
    ]
}