╔══════════════════════════════════════════════════════════════════════╗
║          GENERIC SUBJECT PRACTICE APP  —  Plug-In Edition           ║
║                   Grade 6 ICSE  |  Any Subject                      ║
╚══════════════════════════════════════════════════════════════════════╝

REQUIREMENTS
────────────
  pip install PyQt5

HOW TO RUN
──────────
  python practice_app.py

HOW TO SWITCH SUBJECTS  (edit 4 lines at the top of practice_app.py)
─────────────────────────────────────────────────────────────────────
  SUBJECT_NAME   = "English"           ← display name
  GRADE_LABEL    = "Grade 6 ICSE"
  SUBJECT_ICON   = "📖"               ← any emoji
  QUESTIONS_FILE = "english_questions" ← your questions filename (no .py)

  Examples:
    Physics   → SUBJECT_NAME="Physics",   SUBJECT_ICON="⚡", QUESTIONS_FILE="physics_questions"
    Chemistry → SUBJECT_NAME="Chemistry", SUBJECT_ICON="🧪", QUESTIONS_FILE="chemistry_questions"
    English   → SUBJECT_NAME="English",   SUBJECT_ICON="📖", QUESTIONS_FILE="english_questions"
    Maths     → SUBJECT_NAME="Maths",     SUBJECT_ICON="🔢", QUESTIONS_FILE="maths_questions"

INCLUDED QUESTION FILES
───────────────────────
  english_questions.py  — Grade 6 ICSE English Comprehension
                          3 passages × 10 questions (MCQ + T/F + Subjective)

HOW TO WRITE YOUR OWN QUESTIONS FILE
─────────────────────────────────────
  Create a Python file (e.g. history_questions.py) with this structure:

  QUESTIONS = {
      "Topic Name": [
          {
              "type": "mcq",
              "q": "Question text?",
              "options": ["Option A", "Option B", "Option C", "Option D"],
              "answer": "Option A",
              "explanation": "Reason why Option A is correct."
          },
          {
              "type": "tf",
              "q": "True or False statement.",
              "answer": "True",      # or "False"
              "explanation": "Explanation of why this is true/false."
          },
          {
              "type": "subjective",
              "q": "Open-ended question?",
              "sample": "A model answer to compare against."
          },
      ],
      "Another Topic": [ ... ],
  }

  Then set QUESTIONS_FILE = "history_questions" in practice_app.py.

PROGRESS FILES
──────────────
  Progress is saved automatically to progress_<questions_file>.json
  Each subject gets its own save file — no cross-contamination.
  Use the Reset button in the app to clear progress for the current subject.

FILES IN THIS FOLDER
────────────────────
  practice_app.py         ← The app (never needs to change)
  english_questions.py    ← English Comprehension questions
  README.txt              ← This file
