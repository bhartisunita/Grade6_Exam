"""
Physics — Grade 6 ICSE
Comprehensive Practice Questions - SET 2
Based on: Physics Textbook Chapters 3-8
6 Chapters • 100 Questions Each (40 MCQ, 40 TF, 20 Subjective)
"""

QUESTIONS = {

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 3: Physical Quantities and Measurement (SET 2)
    # ──────────────────────────────────────────────────────────────────
    "Chapter 3 — Physical Quantities and Measurement (Set 2)": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "Which of the following is NOT a fundamental physical quantity?",
            "options": [
                "Electric current",
                "Luminous intensity",
                "Amount of substance",
                "Density"
            ],
            "answer": "Density",
            "explanation": "Density is a derived quantity (mass/volume), while the others are fundamental."
        },
        {
            "type": "mcq",
            "q": "What is the unit of amount of substance in SI system?",
            "options": [
                "Gram",
                "Mole",
                "Kilogram",
                "Candela"
            ],
            "answer": "Mole",
            "explanation": "The SI unit for amount of substance is mole (mol)."
        },
        {
            "type": "mcq",
            "q": "What is the unit of luminous intensity in SI system?",
            "options": [
                "Lumen",
                "Candela",
                "Lux",
                "Watt"
            ],
            "answer": "Candela",
            "explanation": "The SI unit for luminous intensity is candela (cd)."
        },
        {
            "type": "mcq",
            "q": "In ancient times, what was a 'handspan'?",
            "options": [
                "Length from elbow to wrist",
                "Width of the hand",
                "Length from thumb to little finger of outstretched hand",
                "Length of middle finger"
            ],
            "answer": "Length from thumb to little finger of outstretched hand",
            "explanation": "A handspan was the length from tip of thumb to tip of little finger of an outstretched hand."
        },
        {
            "type": "mcq",
            "q": "What was a 'palm' in ancient measurement systems?",
            "options": [
                "Length of the hand",
                "Width of the hand",
                "Length from wrist to elbow",
                "Width of the palm"
            ],
            "answer": "Width of the hand",
            "explanation": "A palm was the width of the hand."
        },
        {
            "type": "mcq",
            "q": "The word 'inch' comes from the Latin word 'uncia' meaning:",
            "options": [
                "One inch",
                "One-twelfth part",
                "One hundredth",
                "One thousandth"
            ],
            "answer": "One-twelfth part",
            "explanation": "The word inch comes from the Latin word uncia meaning one-twelfth part."
        },
        {
            "type": "mcq",
            "q": "How many barleycorns placed end to end made one inch in the British traditional system?",
            "options": [
                "Two",
                "Three",
                "Four",
                "Five"
            ],
            "answer": "Three",
            "explanation": "Each inch was the length of three barleycorns placed end to end."
        },
        {
            "type": "mcq",
            "q": "In which year was the International System of Units (SI) adopted?",
            "options": [
                "1947",
                "1950",
                "1960",
                "1971"
            ],
            "answer": "1960",
            "explanation": "In 1960, the General Conference of Weights and Measures adopted the SI system."
        },
        {
            "type": "mcq",
            "q": "Where is the International Bureau of Weights and Measures located?",
            "options": [
                "London, UK",
                "Washington, USA",
                "Sevres near Paris, France",
                "Delhi, India"
            ],
            "answer": "Sevres near Paris, France",
            "explanation": "The International Bureau of Weights and Measures is at Sevres near Paris."
        },
        {
            "type": "mcq",
            "q": "Where is the standard metre kept in India?",
            "options": [
                "Indian Institute of Science, Bangalore",
                "National Physical Laboratory, Delhi",
                "Tata Institute, Mumbai",
                "IIT, Chennai"
            ],
            "answer": "National Physical Laboratory, Delhi",
            "explanation": "In India, the standard metre is kept at the National Physical Laboratory in Delhi."
        },
        {
            "type": "mcq",
            "q": "What is the standard metre defined as?",
            "options": [
                "One ten-millionth of the distance from equator to North Pole",
                "Length between two marks on a platinum-iridium bar at 0°C",
                "Wavelength of a specific light",
                "Distance light travels in 1/299,792,458 second"
            ],
            "answer": "Length between two marks on a platinum-iridium bar at 0°C",
            "explanation": "The standard metre is taken as the length between two marks on a platinum-iridium bar kept at 0°C."
        },
        {
            "type": "mcq",
            "q": "How many metres are there in one decametre?",
            "options": [
                "0.1 m",
                "1 m",
                "10 m",
                "100 m"
            ],
            "answer": "10 m",
            "explanation": "1 decametre (dam) = 10 metres."
        },
        {
            "type": "mcq",
            "q": "How many metres are there in one hectometre?",
            "options": [
                "10 m",
                "100 m",
                "1000 m",
                "0.01 m"
            ],
            "answer": "100 m",
            "explanation": "1 hectometre (hm) = 100 metres."
        },
        {
            "type": "mcq",
            "q": "What does the prefix 'deci' mean?",
            "options": [
                "Ten times",
                "One hundredth",
                "One tenth",
                "One thousandth"
            ],
            "answer": "One tenth",
            "explanation": "Deci means one tenth part (1/10)."
        },
        {
            "type": "mcq",
            "q": "What does the prefix 'deca' mean?",
            "options": [
                "Ten times",
                "One tenth",
                "One hundredth",
                "One thousandth"
            ],
            "answer": "Ten times",
            "explanation": "Deca means ten times."
        },
        {
            "type": "mcq",
            "q": "What is 1 milligram equal to?",
            "options": [
                "0.001 g",
                "0.01 g",
                "0.1 g",
                "1 g"
            ],
            "answer": "0.001 g",
            "explanation": "1 milligram = 1/1000 gram = 0.001 g."
        },
        {
            "type": "mcq",
            "q": "What is 1 centilitre equal to?",
            "options": [
                "0.001 L",
                "0.01 L",
                "0.1 L",
                "1 L"
            ],
            "answer": "0.01 L",
            "explanation": "1 centilitre = 1/100 litre = 0.01 L."
        },
        {
            "type": "mcq",
            "q": "Which of the following is written correctly according to SI guidelines?",
            "options": [
                "10 kgs",
                "10 Kg",
                "10 kg",
                "10 Kgs"
            ],
            "answer": "10 kg",
            "explanation": "Symbols are never written in plural, and unit names are in small letters."
        },
        {
            "type": "mcq",
            "q": "Which of the following is the correct symbol for megawatt?",
            "options": [
                "mw",
                "MW",
                "mW",
                "M w"
            ],
            "answer": "MW",
            "explanation": "Prefix symbols for larger values are written in capital letters, so MW is correct."
        },
        {
            "type": "mcq",
            "q": "What is the correct way to write 10 seconds in symbol form?",
            "options": [
                "10 s",
                "10 sec",
                "10 S",
                "10 s."
            ],
            "answer": "10 s",
            "explanation": "The symbol for second is 's', no full stop, and no plural."
        },
        {
            "type": "mcq",
            "q": "Which device would you use to measure the circumference of a tree trunk?",
            "options": [
                "Ruler",
                "Metre rod",
                "Measuring tape",
                "Vernier caliper"
            ],
            "answer": "Measuring tape",
            "explanation": "Measuring tapes are flexible and can be used to measure curved objects."
        },
        {
            "type": "mcq",
            "q": "What is the length of a metre rod?",
            "options": [
                "30 cm",
                "50 cm",
                "100 cm",
                "200 cm"
            ],
            "answer": "100 cm",
            "explanation": "A metre rod has a fixed length of one metre = 100 cm."
        },
        {
            "type": "mcq",
            "q": "How many divisions of 1 cm are there in a metre rod?",
            "options": [
                "10",
                "50",
                "100",
                "1000"
            ],
            "answer": "100",
            "explanation": "A metre rod is divided into 100 divisions of 1 centimetre each."
        },
        {
            "type": "mcq",
            "q": "What is the correct eye position while reading a horizontally placed ruler?",
            "options": [
                "To the left of the mark",
                "To the right of the mark",
                "Vertically above the mark",
                "At any angle"
            ],
            "answer": "Vertically above the mark",
            "explanation": "The eye should be vertically above the mark to avoid parallax error."
        },
        {
            "type": "mcq",
            "q": "What is the correct eye position while reading a vertically placed ruler?",
            "options": [
                "Vertically above",
                "Horizontally in line with the mark",
                "At 45 degrees",
                "From below"
            ],
            "answer": "Horizontally in line with the mark",
            "explanation": "For vertical ruler, eye should be in line with the mark horizontally."
        },
        {
            "type": "mcq",
            "q": "In a beam balance, when the pans are empty, the beam should be:",
            "options": [
                "Tilted to left",
                "Tilted to right",
                "Horizontal and pointer vertical",
                "Any position"
            ],
            "answer": "Horizontal and pointer vertical",
            "explanation": "When empty, beam should be horizontal and pointer vertical for accurate balance."
        },
        {
            "type": "mcq",
            "q": "In a beam balance, the strings suspending the pans must have:",
            "options": [
                "Different lengths",
                "Equal length and mass",
                "Different masses",
                "No specific requirement"
            ],
            "answer": "Equal length and mass",
            "explanation": "For accurate measurement, strings must have equal length and mass."
        },
        {
            "type": "mcq",
            "q": "A grocer's balance is a variant of which traditional balance?",
            "options": [
                "Physical balance",
                "Beam balance",
                "Spring balance",
                "Electronic balance"
            ],
            "answer": "Beam balance",
            "explanation": "Modern shop balances are variants of traditional beam balance with a pointer at centre."
        },
        {
            "type": "mcq",
            "q": "What does an electronic weighing machine display?",
            "options": [
                "Mass directly on LCD panel",
                "Only standard weights needed",
                "Just pointer reading",
                "Comparison with standard"
            ],
            "answer": "Mass directly on LCD panel",
            "explanation": "Electronic machines display mass directly without needing standard weights."
        },
        {
            "type": "mcq",
            "q": "How many minutes are there in 3 hours?",
            "options": [
                "120 minutes",
                "150 minutes",
                "180 minutes",
                "200 minutes"
            ],
            "answer": "180 minutes",
            "explanation": "1 hour = 60 minutes, so 3 hours = 3 × 60 = 180 minutes."
        },
        {
            "type": "mcq",
            "q": "How many seconds are there in 5 minutes?",
            "options": [
                "60 seconds",
                "120 seconds",
                "300 seconds",
                "600 seconds"
            ],
            "answer": "300 seconds",
            "explanation": "1 minute = 60 seconds, so 5 minutes = 5 × 60 = 300 seconds."
        },
        {
            "type": "mcq",
            "q": "What is a decade?",
            "options": [
                "10 years",
                "100 years",
                "1000 years",
                "7 days"
            ],
            "answer": "10 years",
            "explanation": "A decade is a period of 10 years."
        },
        {
            "type": "mcq",
            "q": "What is a century?",
            "options": [
                "10 years",
                "50 years",
                "100 years",
                "1000 years"
            ],
            "answer": "100 years",
            "explanation": "A century is a period of 100 years."
        },
        {
            "type": "mcq",
            "q": "What is a millennium?",
            "options": [
                "100 years",
                "500 years",
                "1000 years",
                "10,000 years"
            ],
            "answer": "1000 years",
            "explanation": "A millennium is a period of 1000 years."
        },
        {
            "type": "mcq",
            "q": "In the 24-hour clock system, what does 00:00 represent?",
            "options": [
                "Noon",
                "Midnight",
                "1:00 a.m.",
                "12:00 p.m."
            ],
            "answer": "Midnight",
            "explanation": "00:00 represents midnight (12:00 a.m.)."
        },
        {
            "type": "mcq",
            "q": "What is 9:45 p.m. in 24-hour format?",
            "options": [
                "09:45",
                "19:45",
                "21:45",
                "22:45"
            ],
            "answer": "21:45",
            "explanation": "9:45 p.m. = 9:45 + 12:00 = 21:45 hours."
        },
        {
            "type": "mcq",
            "q": "What is 14:30 in 12-hour format?",
            "options": [
                "2:30 a.m.",
                "2:30 p.m.",
                "4:30 p.m.",
                "12:30 p.m."
            ],
            "answer": "2:30 p.m.",
            "explanation": "14:30 - 12:00 = 2:30 p.m."
        },
        {
            "type": "mcq",
            "q": "Who developed the Celsius temperature scale?",
            "options": [
                "Daniel Fahrenheit",
                "Anders Celsius",
                "Lord Kelvin",
                "James Joule"
            ],
            "answer": "Anders Celsius",
            "explanation": "Anders Celsius, a Swedish astronomer, developed the Celsius scale."
        },
        {
            "type": "mcq",
            "q": "Who developed the Fahrenheit temperature scale?",
            "options": [
                "Anders Celsius",
                "Lord Kelvin",
                "Daniel Gabriel Fahrenheit",
                "Isaac Newton"
            ],
            "answer": "Daniel Gabriel Fahrenheit",
            "explanation": "Daniel Gabriel Fahrenheit developed the Fahrenheit scale."
        },
        {
            "type": "mcq",
            "q": "What is the steam point in Kelvin scale?",
            "options": [
                "273.15 K",
                "373.15 K",
                "100 K",
                "212 K"
            ],
            "answer": "373.15 K",
            "explanation": "Steam point in Kelvin scale is 373.15 K."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "The CGS system uses centimetre, gram, and second as units.",
            "answer": "True",
            "explanation": "CGS stands for centimetre-gram-second system."
        },
        {
            "type": "tf",
            "q": "The MKS system uses metre, kilogram, and second as units.",
            "answer": "True",
            "explanation": "MKS stands for metre-kilogram-second system."
        },
        {
            "type": "tf",
            "q": "The FPS system uses foot, pound, and second as units.",
            "answer": "True",
            "explanation": "FPS stands for foot-pound-second system."
        },
        {
            "type": "tf",
            "q": "The SI system was adopted in 1950.",
            "answer": "False",
            "explanation": "The SI system was adopted in 1960."
        },
        {
            "type": "tf",
            "q": "The French name for SI is 'Le Système International d'Unités'.",
            "answer": "True",
            "explanation": "This is the correct French name for the International System of Units."
        },
        {
            "type": "tf",
            "q": "The unit of electric current in SI system is volt.",
            "answer": "False",
            "explanation": "The SI unit of electric current is ampere (A), not volt."
        },
        {
            "type": "tf",
            "q": "The unit of temperature in SI system is degree Celsius.",
            "answer": "False",
            "explanation": "The SI unit of temperature is kelvin (K)."
        },
        {
            "type": "tf",
            "q": "1 kilometre is equal to 1000 metres.",
            "answer": "True",
            "explanation": "Kilo means 1000, so 1 km = 1000 m."
        },
        {
            "type": "tf",
            "q": "1 milligram is equal to 0.001 gram.",
            "answer": "True",
            "explanation": "Milli means 1/1000, so 1 mg = 0.001 g."
        },
        {
            "type": "tf",
            "q": "1 centimetre is equal to 0.1 metre.",
            "answer": "False",
            "explanation": "1 cm = 0.01 m (1/100 metre), not 0.1 m."
        },
        {
            "type": "tf",
            "q": "The prefix 'hecto' means one hundred times.",
            "answer": "True",
            "explanation": "Hecto means 100 times, e.g., 1 hectometre = 100 m."
        },
        {
            "type": "tf",
            "q": "The symbol for a unit derived from a person's name is written in small letters.",
            "answer": "False",
            "explanation": "It is written in capital letters, e.g., N for newton, A for ampere."
        },
        {
            "type": "tf",
            "q": "A full stop is never put at the end of a unit symbol.",
            "answer": "True",
            "explanation": "Unless it occurs at the end of a sentence, no full stop is used."
        },
        {
            "type": "tf",
            "q": "The plural form of units is used only when the unit is written in full.",
            "answer": "True",
            "explanation": "Symbols are never written in plural; full unit names can be plural."
        },
        {
            "type": "tf",
            "q": "The standard metre is kept at 0°F at the International Bureau.",
            "answer": "False",
            "explanation": "It is kept at 0°C, not 0°F."
        },
        {
            "type": "tf",
            "q": "A ruler should always be placed parallel to the length being measured.",
            "answer": "True",
            "explanation": "Ruler must be parallel to the length for accurate measurement."
        },
        {
            "type": "tf",
            "q": "A ruler should be placed as far as possible from the object being measured.",
            "answer": "False",
            "explanation": "It should be placed as near as possible to the object."
        },
        {
            "type": "tf",
            "q": "The left edge of a ruler should always be used for starting measurements.",
            "answer": "False",
            "explanation": "Avoid using ends if chipped; start from a marked line, not edge."
        },
        {
            "type": "tf",
            "q": "Parallax error occurs due to wrong positioning of the object.",
            "answer": "False",
            "explanation": "Parallax error occurs due to wrong positioning of the eye."
        },
        {
            "type": "tf",
            "q": "In a beam balance, the pans must be of equal mass.",
            "answer": "True",
            "explanation": "For accurate balance, both pans must have equal mass."
        },
        {
            "type": "tf",
            "q": "In a beam balance, the two arms must be of equal length.",
            "answer": "True",
            "explanation": "Equal arm length is essential for correct measurement."
        },
        {
            "type": "tf",
            "q": "A physical balance is less sensitive than a beam balance.",
            "answer": "False",
            "explanation": "Physical balance is more sensitive and accurate."
        },
        {
            "type": "tf",
            "q": "Weight is the amount of matter present in an object.",
            "answer": "False",
            "explanation": "That is mass. Weight is the gravitational force on that mass."
        },
        {
            "type": "tf",
            "q": "A sand clock works on the principle of falling sand in fixed time.",
            "answer": "True",
            "explanation": "Sand falls from upper to lower chamber in fixed time."
        },
        {
            "type": "tf",
            "q": "A sundial can be used at night as well.",
            "answer": "False",
            "explanation": "Sundial requires sunlight to cast shadow."
        },
        {
            "type": "tf",
            "q": "An analogue clock has a circular dial with hands.",
            "answer": "True",
            "explanation": "Analogue clocks show time with hands on a dial."
        },
        {
            "type": "tf",
            "q": "A digital clock displays time as numbers.",
            "answer": "True",
            "explanation": "Digital clocks show time in numeric format."
        },
        {
            "type": "tf",
            "q": "A stop watch is used to measure time intervals accurately.",
            "answer": "True",
            "explanation": "Stop watches can be started and stopped to measure intervals."
        },
        {
            "type": "tf",
            "q": "One microsecond is one-millionth of a second.",
            "answer": "True",
            "explanation": "Micro = 10^-6, so 1 microsecond = 1/1,000,000 second."
        },
        {
            "type": "tf",
            "q": "One nanosecond is one-billionth of a second.",
            "answer": "True",
            "explanation": "Nano = 10^-9, so 1 nanosecond = 1/1,000,000,000 second."
        },
        {
            "type": "tf",
            "q": "Railways and airlines use the 12-hour clock system.",
            "answer": "False",
            "explanation": "They use the 24-hour clock system to avoid confusion."
        },
        {
            "type": "tf",
            "q": "In the 24-hour system, time is shown by 4 digits.",
            "answer": "True",
            "explanation": "First two digits for hours, next two for minutes."
        },
        {
            "type": "tf",
            "q": "A thermometer has a glass bulb filled with mercury at its lower end.",
            "answer": "True",
            "explanation": "The bulb contains mercury that expands when heated."
        },
        {
            "type": "tf",
            "q": "The thin shining thread of mercury is seen through the bore of thermometer.",
            "answer": "True",
            "explanation": "Mercury rises in the capillary tube (bore) and is visible."
        },
        {
            "type": "tf",
            "q": "The Kelvin scale is an absolute temperature scale.",
            "answer": "True",
            "explanation": "Kelvin scale has absolute zero, below which temperatures don't exist."
        },
        {
            "type": "tf",
            "q": "The Kelvin scale is written with a degree symbol (°K).",
            "answer": "False",
            "explanation": "It is written simply as K without the degree symbol."
        },
        {
            "type": "tf",
            "q": "0°C is equal to 273 K (approximately).",
            "answer": "True",
            "explanation": "0°C = 273.15 K, approximately 273 K."
        },
        {
            "type": "tf",
            "q": "100°C is equal to 373 K (approximately).",
            "answer": "True",
            "explanation": "100°C = 373.15 K, approximately 373 K."
        },
        {
            "type": "tf",
            "q": "While using a laboratory thermometer, the bulb should touch the bottom of the flask.",
            "answer": "False",
            "explanation": "The bulb should not touch the bottom or sides for accurate reading."
        },
        {
            "type": "tf",
            "q": "1 square metre is the area of a square whose each side is 1 metre.",
            "answer": "True",
            "explanation": "Area = side × side = 1 m × 1 m = 1 m²."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "What is the advantage of the International System of Units (SI) over the earlier MKS and CGS systems?",
            "sample": "The SI system has several advantages:\n1. It is a single universal system accepted worldwide, eliminating the need for interconversion between different systems.\n2. It is based on seven fundamental units from which all derived units can be obtained.\n3. It uses a decimal system with prefixes for multiples and submultiples, making calculations easier.\n4. It provides standard definitions for units that can be reproduced accurately in laboratories anywhere.\n5. It is used in all scientific work, ensuring consistency in measurements globally."
        },
        {
            "type": "subjective",
            "q": "Describe any two guidelines for writing SI units correctly with examples.",
            "sample": "Guidelines for writing SI units:\n\n1. Unit names are written in small letters: Example: 'metre' (not Metre), 'second' (not Second). Even if derived from a person's name, the full unit name is in small letters: 'newton' (not Newton).\n\n2. Unit symbols: If derived from a person's name, the symbol is in capital letters: Example: N for newton, A for ampere, Pa for pascal (first letter capital for two-letter symbols). Other symbols are in small letters: m for metre, s for second.\n\n3. No plurals in symbols: 10 metres is written as '10 m', not '10 ms'.\n\n4. No full stop at the end of symbols: Write '50 cm' not '50 cm.'"
        },
        {
            "type": "subjective",
            "q": "Explain in detail the 24-hour clock system. Why is it used by railways and airlines?",
            "sample": "The 24-hour clock system expresses time as hours and minutes passed since midnight, using 4 digits (first two for hours, next two for minutes).\n\nFeatures:\n- Time from 00:00 to 12:00 represents a.m. (morning to noon)\n- Time from 12:00 to 24:00 represents p.m. (noon to midnight)\n- 00:00 and 24:00 both represent midnight\n- No a.m./p.m. labels are used\n\nExample: 02:30 = 2:30 a.m., 17:00 = 5:00 p.m.\n\nRailways and airlines use this system because:\n1. It avoids confusion between a.m. and p.m.\n2. It's unambiguous for schedules that cross midnight\n3. It's used internationally for transport timetables\n4. It's easier for computer systems and digital displays"
        },
        {
            "type": "subjective",
            "q": "Describe the Celsius and Fahrenheit scales of temperature. What are their fixed points?",
            "sample": "Celsius scale:\n- Developed by Anders Celsius\n- Lower fixed point (ice point): 0°C (freezing point of water)\n- Upper fixed point (steam point): 100°C (boiling point of water)\n- Interval divided into 100 equal parts\n- Each division = 1°C\n\nFahrenheit scale:\n- Developed by Daniel Gabriel Fahrenheit\n- Lower fixed point: 32°F\n- Upper fixed point: 212°F\n- Interval divided into 180 equal parts\n- Each division = 1°F\n\nNormal human body temperature: 37°C = 98.6°F"
        },
        {
            "type": "subjective",
            "q": "Differentiate between laboratory thermometer and clinical thermometer.",
            "sample": "Laboratory thermometer:\n1. Range: -20°C to 110°C\n2. No kink in the bore\n3. Used for scientific experiments\n4. Mercury falls back immediately after use\n5. Less sensitive\n6. Used to measure temperatures of various substances\n\nClinical thermometer:\n1. Range: 35°C to 42°C\n2. Has a kink/bend just above the bulb\n3. Used to measure human body temperature\n4. Kink prevents mercury from falling back quickly\n5. More sensitive for small temperature changes\n6. Normal body temperature (37°C) marked in red"
        },
        {
            "type": "subjective",
            "q": "Solve: Express 2.25 m in cm and 8000 g in kg.",
            "sample": "a. 2.25 m to cm:\n1 m = 100 cm\n2.25 m = 2.25 × 100 = 225 cm\n\nb. 8000 g to kg:\n1 kg = 1000 g\n8000 g = 8000 ÷ 1000 = 8 kg\n\nTherefore, 2.25 m = 225 cm and 8000 g = 8 kg."
        },
        {
            "type": "subjective",
            "q": "A piece of wire is wound around a pencil 60 times. If the total width of all the turns is 3 cm, find the diameter of the wire.",
            "sample": "Given:\nNumber of turns = 60\nTotal width of turns = 3 cm\n\nDiameter of wire = Total width ÷ Number of turns\n= 3 cm ÷ 60\n= 0.05 cm\n\nTo convert to millimetres:\n1 cm = 10 mm\n0.05 cm = 0.05 × 10 = 0.5 mm\n\nTherefore, the diameter of the wire is 0.05 cm or 0.5 mm."
        },
        {
            "type": "subjective",
            "q": "An aeroplane leaves Bengaluru at 23:50 hours and reaches Chennai at 00:40 hours. Rewrite the statement using the 12-hour time format. Also, find the duration of the flight.",
            "sample": "Given:\nDeparture time: 23:50 hours\nArrival time: 00:40 hours\n\nConverting to 12-hour format:\n23:50 = 23:50 - 12:00 = 11:50 p.m.\n00:40 = 12:40 a.m. (next day)\n\nSo, the flight leaves Bengaluru at 11:50 p.m. and reaches Chennai at 12:40 a.m.\n\nDuration of flight:\nFrom 23:50 to 24:00 (midnight) = 10 minutes\nFrom 00:00 to 00:40 = 40 minutes\nTotal duration = 10 + 40 = 50 minutes\n\nThe flight duration is 50 minutes."
        },
        {
            "type": "subjective",
            "q": "The body temperature of a patient on Monday was 38°C and on Tuesday was 39°C. Express these readings in kelvin. What was the rise in temperature during these two days (in kelvin)?",
            "sample": "To convert Celsius to Kelvin: K = °C + 273.15\n\nMonday: 38°C = 38 + 273.15 = 311.15 K\nTuesday: 39°C = 39 + 273.15 = 312.15 K\n\nRise in temperature = Tuesday - Monday\n= 312.15 K - 311.15 K = 1.00 K\n\nNote: A rise of 1°C is equal to a rise of 1 K, as the size of one degree is the same in both scales."
        },
        {
            "type": "subjective",
            "q": "A lawn is in the shape of a square. Find the area covered by the lawn if one of its sides is 50 m.",
            "sample": "Given:\nShape: Square\nSide of square = 50 m\n\nArea of square = side × side\n= 50 m × 50 m\n= 2500 m²\n\nTherefore, the area covered by the lawn is 2500 square metres."
        },
        {
            "type": "subjective",
            "q": "What is a physical quantity? Explain the difference between fundamental and derived physical quantities with examples.",
            "sample": "A physical quantity is any quantity that can be measured, such as length, mass, time, area, volume, etc.\n\nFundamental physical quantities:\n- Basic quantities that do not depend upon other quantities\n- There are seven fundamental quantities\n- Examples: Length, mass, time, temperature, electric current, luminous intensity, amount of substance\n\nDerived physical quantities:\n- Quantities derived from one or more fundamental quantities\n- Examples: Area (length × length), Volume (length × breadth × height), Speed (distance/time), Density (mass/volume)"
        },
        {
            "type": "subjective",
            "q": "What is the principle of working of a beam balance? What features ensure its accuracy?",
            "sample": "A beam balance works on the principle that when two bodies with equal mass are placed on the two pans, they secure a state of horizontal balance of the beam.\n\nFeatures ensuring accuracy:\n1. Both pans must be of equal mass\n2. Both arms must be of equal length\n3. Both pans must be suspended with strings of equal length and mass\n4. When pans are empty, the beam should be horizontal and pointer vertical\n5. The pivot should be frictionless and at the exact centre\n\nThe object is placed on one pan and standard weights on the other until balance is achieved."
        },
        {
            "type": "subjective",
            "q": "What is a mean solar day? How is it related to the units of time?",
            "sample": "A mean solar day is the time taken by the earth to make one complete rotation about its own axis. It is called 'mean' because the actual length of a day varies slightly throughout the year due to earth's elliptical orbit.\n\nRelationships:\n1 mean solar day = 24 hours\n1 hour = 60 minutes\n1 minute = 60 seconds\n\nTherefore, 1 day = 24 × 60 × 60 = 86,400 seconds\n\nOther time units derived from the day:\n1 week = 7 days\n1 month ≈ 30 days\n1 year = 12 months ≈ 365 days\n1 decade = 10 years\n1 century = 100 years\n1 millennium = 1000 years"
        },
        {
            "type": "subjective",
            "q": "What is a thermometer? Explain its construction briefly.",
            "sample": "A thermometer is a device used to measure temperature.\n\nConstruction:\n1. It consists of two glass tubes, one placed inside the other\n2. The inner tube (bore) is a capillary tube with very narrow diameter\n3. The outer tube is called the stem\n4. The lower end of the bore is attached to a glass bulb filled with mercury\n5. The upper end of the bore is sealed\n6. The stem is marked with a temperature scale (Celsius, Fahrenheit, etc.)\n\nWorking:\nWhen the bulb is heated, mercury expands and rises in the bore. The height of the mercury column gives the temperature reading. The mercury appears as a thin shining thread through the stem."
        },
        {
            "type": "subjective",
            "q": "What are the ice point and steam point in different temperature scales?",
            "sample": "Ice point (lower fixed point): Temperature at which ice melts or water freezes.\nSteam point (upper fixed point): Temperature at which water boils.\n\nCelsius scale:\nIce point = 0°C\nSteam point = 100°C\n\nFahrenheit scale:\nIce point = 32°F\nSteam point = 212°F\n\nKelvin scale:\nIce point = 273.15 K\nSteam point = 373.15 K\n\nThe interval between these points is divided into equal parts: 100 parts in Celsius, 180 parts in Fahrenheit."
        },
        {
            "type": "subjective",
            "q": "Convert the following temperatures: a. 248.15 K to °C b. 293.15 K to °C c. -10°C to K",
            "sample": "Formula: K = °C + 273.15, so °C = K - 273.15\n\na. 248.15 K to °C:\n°C = 248.15 - 273.15 = -25°C\n\nb. 293.15 K to °C:\n°C = 293.15 - 273.15 = 20°C\n\nc. -10°C to K:\nK = -10 + 273.15 = 263.15 K"
        },
        {
            "type": "subjective",
            "q": "What is area? How is the unit of area derived? Give the relationship between different units of area.",
            "sample": "Area is the amount of surface enclosed by a plane figure. It is a derived physical quantity.\n\nDerivation of unit:\nUnit of area = unit of length × unit of length = (unit of length)²\nSI unit of length = metre (m)\nSo, SI unit of area = m × m = m² (square metre)\n\nRelationships:\n1 cm² = 100 mm²\n1 m² = 10,000 cm²\n1 km² = 10,00,000 m² (10^6 m²)\n1 hectare = 10,000 m²\n\nOne square metre is the area of a square with each side 1 metre long."
        },
        {
            "type": "subjective",
            "q": "Calculate the area of a rectangular sheet of paper that is 30 cm long and 25 cm broad. Express in m².",
            "sample": "Given:\nLength = 30 cm\nBreadth = 25 cm\n\nArea of rectangle = length × breadth\n= 30 cm × 25 cm\n= 750 cm²\n\nTo convert to m²:\n1 m² = 10,000 cm²\nArea in m² = 750 ÷ 10,000 = 0.075 m²\n\nTherefore, area = 750 cm² or 0.075 m²."
        },
        {
            "type": "subjective",
            "q": "A triangle has a base measuring 15 cm and a height of 16 cm. Calculate its area.",
            "sample": "Given:\nBase of triangle = 15 cm\nHeight of triangle = 16 cm\n\nArea of triangle = ½ × base × height\n= ½ × 15 cm × 16 cm\n= ½ × 240 cm²\n= 120 cm²\n\nTherefore, the area of the triangle is 120 square centimetres."
        },
        {
            "type": "subjective",
            "q": "What is approximation? Why are approximations useful in daily life even though they are not accurate?",
            "sample": "An approximation or estimation is a reasonable guess about the measure of a physical quantity without exact measurement.\n\nExamples:\n- Estimating the quantity of salt while cooking\n- Guessing the time it would take to reach a place\n- Estimating someone's height by comparison\n\nApproximations are useful because:\n1. They save time when exact measurement is not necessary\n2. They help in making quick decisions\n3. They are based on experience and comparison\n4. In many daily situations, approximate values are sufficient\n5. They help develop a sense of quantities\n\nHowever, for scientific work where accuracy is important, exact measurements are required."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 4: Force and Friction (SET 2)
    # ──────────────────────────────────────────────────────────────────
    "Chapter 4 — Force and Friction (Set 2)": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "What is the SI unit of force?",
            "options": [
                "Joule",
                "Newton",
                "Watt",
                "Pascal"
            ],
            "answer": "Newton",
            "explanation": "The SI unit of force is newton (N)."
        },
        {
            "type": "mcq",
            "q": "Which of the following actions is a pull?",
            "options": [
                "Kicking a ball",
                "Closing a door",
                "Drawing water from a well",
                "Moving a cart by pushing"
            ],
            "answer": "Drawing water from a well",
            "explanation": "Drawing water involves pulling the rope upward."
        },
        {
            "type": "mcq",
            "q": "Which of the following actions is a push?",
            "options": [
                "Lifting a bag",
                "Opening a drawer",
                "Drawing water",
                "Pulling a suitcase"
            ],
            "answer": "Opening a drawer",
            "explanation": "Opening a drawer usually involves pushing it outward."
        },
        {
            "type": "mcq",
            "q": "What happens when you catch a moving ball?",
            "options": [
                "Force is applied in the direction of motion",
                "Force is applied opposite to the direction of motion",
                "No force is applied",
                "Ball continues moving"
            ],
            "answer": "Force is applied opposite to the direction of motion",
            "explanation": "Hands apply force opposite to ball's motion to stop it."
        },
        {
            "type": "mcq",
            "q": "To increase the speed of a moving swing, you should:",
            "options": [
                "Push it opposite to motion",
                "Pull it opposite to motion",
                "Push it in the direction of motion",
                "Apply no force"
            ],
            "answer": "Push it in the direction of motion",
            "explanation": "Force in direction of motion increases speed."
        },
        {
            "type": "mcq",
            "q": "To slow down or stop a moving swing, you should:",
            "options": [
                "Push it in the direction of motion",
                "Pull or push opposite to motion",
                "Apply force sideways",
                "Do nothing"
            ],
            "answer": "Pull or push opposite to motion",
            "explanation": "Opposing force reduces speed and stops motion."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT an example of force changing shape?",
            "options": [
                "Kneading dough",
                "Stretching a spring",
                "Kicking a ball",
                "Squeezing a sponge"
            ],
            "answer": "Kicking a ball",
            "explanation": "Kicking a ball changes its motion, not its shape permanently."
        },
        {
            "type": "mcq",
            "q": "When a batsman hits a ball, the force changes its:",
            "options": [
                "Direction only",
                "Speed only",
                "Both direction and speed",
                "Mass"
            ],
            "answer": "Both direction and speed",
            "explanation": "The bat's force changes both the direction and speed of the ball."
        },
        {
            "type": "mcq",
            "q": "Which force is used by a horse to pull a cart?",
            "options": [
                "Gravitational force",
                "Muscular force",
                "Magnetic force",
                "Frictional force"
            ],
            "answer": "Muscular force",
            "explanation": "Horses use muscular force from their muscles to pull carts."
        },
        {
            "type": "mcq",
            "q": "Frictional force always acts:",
            "options": [
                "In the direction of motion",
                "Opposite to the direction of motion",
                "Perpendicular to motion",
                "Upwards"
            ],
            "answer": "Opposite to the direction of motion",
            "explanation": "Friction opposes motion, so it acts in opposite direction."
        },
        {
            "type": "mcq",
            "q": "Which surface offers the least friction?",
            "options": [
                "Rough concrete",
                "Carpet",
                "Glass",
                "Wood"
            ],
            "answer": "Glass",
            "explanation": "Smooth surfaces like glass offer least friction."
        },
        {
            "type": "mcq",
            "q": "Which surface offers the most friction?",
            "options": [
                "Ice",
                "Glass",
                "Polished marble",
                "Sandpaper"
            ],
            "answer": "Sandpaper",
            "explanation": "Rough surfaces like sandpaper offer maximum friction."
        },
        {
            "type": "mcq",
            "q": "Friction between two surfaces depends on:",
            "options": [
                "Colour of surfaces",
                "Temperature only",
                "Roughness and weight",
                "Area only"
            ],
            "answer": "Roughness and weight",
            "explanation": "Friction depends on surface roughness and weight of object."
        },
        {
            "type": "mcq",
            "q": "If two boxes of same weight have different contact areas, the friction acting on them will be:",
            "options": [
                "More for larger area",
                "More for smaller area",
                "Same for both",
                "Zero for both"
            ],
            "answer": "Same for both",
            "explanation": "For same weight, friction is independent of contact area."
        },
        {
            "type": "mcq",
            "q": "Static friction acts when objects are:",
            "options": [
                "Moving",
                "At rest",
                "Rolling",
                "Sliding"
            ],
            "answer": "At rest",
            "explanation": "Static friction acts between objects at rest."
        },
        {
            "type": "mcq",
            "q": "Kinetic friction acts when objects are:",
            "options": [
                "At rest",
                "In motion",
                "Not in contact",
                "Heated"
            ],
            "answer": "In motion",
            "explanation": "Kinetic friction acts between moving objects."
        },
        {
            "type": "mcq",
            "q": "Which type of friction is the least?",
            "options": [
                "Sliding friction",
                "Rolling friction",
                "Static friction",
                "All are equal"
            ],
            "answer": "Rolling friction",
            "explanation": "Rolling friction is less than sliding friction."
        },
        {
            "type": "mcq",
            "q": "Ball bearings are used to:",
            "options": [
                "Increase friction",
                "Convert sliding to rolling friction",
                "Increase weight",
                "Make noise"
            ],
            "answer": "Convert sliding to rolling friction",
            "explanation": "Ball bearings reduce friction by enabling rolling motion."
        },
        {
            "type": "mcq",
            "q": "Which of the following is an advantage of friction?",
            "options": [
                "Produces heat in machines",
                "Causes wear and tear",
                "Helps in walking",
                "Wastes energy"
            ],
            "answer": "Helps in walking",
            "explanation": "Friction helps us walk by providing grip."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a disadvantage of friction?",
            "options": [
                "Writing on paper",
                "Braking vehicles",
                "Holding objects",
                "Wear and tear of tyres"
            ],
            "answer": "Wear and tear of tyres",
            "explanation": "Friction causes tyres to wear out over time."
        },
        {
            "type": "mcq",
            "q": "Why are treads provided on tyres?",
            "options": [
                "To reduce friction",
                "To increase friction",
                "To look good",
                "To reduce weight"
            ],
            "answer": "To increase friction",
            "explanation": "Treads increase roughness and friction for better grip."
        },
        {
            "type": "mcq",
            "q": "Why do athletes use shoes with spikes?",
            "options": [
                "To reduce friction",
                "To increase friction and grip",
                "To look stylish",
                "To jump higher"
            ],
            "answer": "To increase friction and grip",
            "explanation": "Spikes provide better grip on the ground."
        },
        {
            "type": "mcq",
            "q": "Why is sand or gravel spread on slippery ground?",
            "options": [
                "To reduce friction",
                "To increase friction",
                "To clean the ground",
                "To make it smooth"
            ],
            "answer": "To increase friction",
            "explanation": "Sand increases roughness and friction on slippery surfaces."
        },
        {
            "type": "mcq",
            "q": "Lubricants like oil and grease work by:",
            "options": [
                "Increasing roughness",
                "Filling cavities and making surfaces smooth",
                "Increasing weight",
                "Creating heat"
            ],
            "answer": "Filling cavities and making surfaces smooth",
            "explanation": "Lubricants fill irregularities, making surfaces smoother."
        },
        {
            "type": "mcq",
            "q": "Graphite is used as a lubricant because:",
            "options": [
                "It increases friction",
                "It works at high temperatures",
                "It is cheap",
                "It is magnetic"
            ],
            "answer": "It works at high temperatures",
            "explanation": "Graphite works as lubricant even in overheated machines."
        },
        {
            "type": "mcq",
            "q": "Streamlining reduces friction caused by:",
            "options": [
                "Solids",
                "Liquids and gases (fluids)",
                "Only liquids",
                "Only gases"
            ],
            "answer": "Liquids and gases (fluids)",
            "explanation": "Streamlining reduces drag from fluids like water and air."
        },
        {
            "type": "mcq",
            "q": "Which of the following has a streamlined body?",
            "options": [
                "Elephant",
                "Fish",
                "Cat",
                "Dog"
            ],
            "answer": "Fish",
            "explanation": "Fish have streamlined bodies to swim efficiently."
        },
        {
            "type": "mcq",
            "q": "Why do aeroplanes have streamlined shapes?",
            "options": [
                "To look beautiful",
                "To minimize air drag",
                "To carry more fuel",
                "To be heavier"
            ],
            "answer": "To minimize air drag",
            "explanation": "Streamlining reduces air resistance, saving fuel."
        },
        {
            "type": "mcq",
            "q": "The force of friction can never be reduced to:",
            "options": [
                "Zero",
                "Half",
                "One-fourth",
                "One-tenth"
            ],
            "answer": "Zero",
            "explanation": "Friction can be reduced but never completely eliminated."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a method to reduce friction?",
            "options": [
                "Lubrication",
                "Polishing",
                "Making grooves",
                "Using ball bearings"
            ],
            "answer": "Making grooves",
            "explanation": "Making grooves increases friction, not reduces it."
        },
        {
            "type": "mcq",
            "q": "The force that exists between any two objects that have mass is called:",
            "options": [
                "Magnetic force",
                "Electrostatic force",
                "Gravitational force",
                "Frictional force"
            ],
            "answer": "Gravitational force",
            "explanation": "Gravitational force exists between all objects with mass."
        },
        {
            "type": "mcq",
            "q": "The gravitational force exerted by the earth is called:",
            "options": [
                "Magnetism",
                "Gravity",
                "Electrostatic force",
                "Friction"
            ],
            "answer": "Gravity",
            "explanation": "Earth's gravitational force is specifically called gravity."
        },
        {
            "type": "mcq",
            "q": "Why does a ball thrown up always fall back to the ground?",
            "options": [
                "Due to magnetic force",
                "Due to gravitational force",
                "Due to electrostatic force",
                "Due to friction"
            ],
            "answer": "Due to gravitational force",
            "explanation": "Earth's gravity pulls objects back to the ground."
        },
        {
            "type": "mcq",
            "q": "Which force is responsible for the attraction between a magnet and iron?",
            "options": [
                "Gravitational force",
                "Magnetic force",
                "Electrostatic force",
                "Muscular force"
            ],
            "answer": "Magnetic force",
            "explanation": "Magnets exert magnetic force on iron objects."
        },
        {
            "type": "mcq",
            "q": "A magnet attracts iron nails from a distance. This shows that magnetic force is a:",
            "options": [
                "Contact force",
                "Non-contact force",
                "Muscular force",
                "Frictional force"
            ],
            "answer": "Non-contact force",
            "explanation": "Magnetic force acts without physical contact."
        },
        {
            "type": "mcq",
            "q": "When a plastic ruler is rubbed on dry hair, it becomes:",
            "options": [
                "Magnetically charged",
                "Electrically charged (negatively)",
                "Hot",
                "Magnetic"
            ],
            "answer": "Electrically charged (negatively)",
            "explanation": "Rubbing transfers negative charges from hair to ruler."
        },
        {
            "type": "mcq",
            "q": "A charged ruler attracts bits of paper due to:",
            "options": [
                "Magnetic force",
                "Gravitational force",
                "Electrostatic force",
                "Frictional force"
            ],
            "answer": "Electrostatic force",
            "explanation": "Electrostatic force causes attraction between charged and uncharged objects."
        },
        {
            "type": "mcq",
            "q": "Objects with opposite charges:",
            "options": [
                "Repel each other",
                "Attract each other",
                "Have no effect",
                "Become neutral"
            ],
            "answer": "Attract each other",
            "explanation": "Opposite charges attract, like charges repel."
        },
        {
            "type": "mcq",
            "q": "Objects with similar charges:",
            "options": [
                "Attract each other",
                "Repel each other",
                "Have no effect",
                "Become magnetic"
            ],
            "answer": "Repel each other",
            "explanation": "Like charges repel each other."
        },
        {
            "type": "mcq",
            "q": "Lightning is an example of:",
            "options": [
                "Magnetic force",
                "Gravitational force",
                "Electrostatic force in nature",
                "Frictional force"
            ],
            "answer": "Electrostatic force in nature",
            "explanation": "Lightning is caused by electrostatic discharge in clouds."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "A force can change the shape of an object without moving it.",
            "answer": "True",
            "explanation": "Squeezing a sponge changes its shape without moving it."
        },
        {
            "type": "tf",
            "q": "A force can change the direction of a moving object without changing its speed.",
            "answer": "True",
            "explanation": "Force applied perpendicular to motion changes direction only."
        },
        {
            "type": "tf",
            "q": "The mass of an object changes when a force is applied to it.",
            "answer": "False",
            "explanation": "Mass remains constant; only motion or shape may change."
        },
        {
            "type": "tf",
            "q": "Muscular force is a non-contact force.",
            "answer": "False",
            "explanation": "Muscular force requires contact, so it's a contact force."
        },
        {
            "type": "tf",
            "q": "Frictional force can act even when there is no motion (static friction).",
            "answer": "True",
            "explanation": "Static friction acts between stationary objects in contact."
        },
        {
            "type": "tf",
            "q": "Friction is more on smooth surfaces than on rough surfaces.",
            "answer": "False",
            "explanation": "Friction is more on rough surfaces, less on smooth surfaces."
        },
        {
            "type": "tf",
            "q": "The weight of an object is the same everywhere in the universe.",
            "answer": "False",
            "explanation": "Weight varies with gravity; mass is constant."
        },
        {
            "type": "tf",
            "q": "An object weighs more on the moon than on earth.",
            "answer": "False",
            "explanation": "Moon's gravity is 1/6 of earth's, so weight is less."
        },
        {
            "type": "tf",
            "q": "Gravitational force is always repulsive in nature.",
            "answer": "False",
            "explanation": "Gravitational force is always attractive."
        },
        {
            "type": "tf",
            "q": "Magnetic force can be both attractive and repulsive.",
            "answer": "True",
            "explanation": "Magnets attract unlike poles and repel like poles."
        },
        {
            "type": "tf",
            "q": "Electrostatic force can be both attractive and repulsive.",
            "answer": "True",
            "explanation": "Opposite charges attract, like charges repel."
        },
        {
            "type": "tf",
            "q": "All metals are attracted by magnets.",
            "answer": "False",
            "explanation": "Only iron, nickel, cobalt and their alloys are magnetic."
        },
        {
            "type": "tf",
            "q": "A body can move without any force acting on it.",
            "answer": "True",
            "explanation": "An object in motion continues at constant velocity without force (Newton's first law)."
        },
        {
            "type": "tf",
            "q": "Friction is independent of the area of contact when weight remains the same.",
            "answer": "True",
            "explanation": "For same weight, friction doesn't depend on contact area."
        },
        {
            "type": "tf",
            "q": "Sliding friction is greater than rolling friction.",
            "answer": "True",
            "explanation": "Rolling friction is less than sliding friction."
        },
        {
            "type": "tf",
            "q": "Static friction is maximum just before the object starts moving.",
            "answer": "True",
            "explanation": "Static friction increases with applied force until motion begins."
        },
        {
            "type": "tf",
            "q": "Kinetic friction is always greater than static friction.",
            "answer": "False",
            "explanation": "Static friction is usually greater than kinetic friction."
        },
        {
            "type": "tf",
            "q": "Wheels are provided on luggage to increase friction.",
            "answer": "False",
            "explanation": "Wheels reduce friction by converting sliding to rolling."
        },
        {
            "type": "tf",
            "q": "Friction helps us to light a matchstick.",
            "answer": "True",
            "explanation": "Friction between matchstick and box generates heat to ignite it."
        },
        {
            "type": "tf",
            "q": "Friction helps us to write on paper.",
            "answer": "True",
            "explanation": "Friction between pen and paper allows writing."
        },
        {
            "type": "tf",
            "q": "It is easy to write on glass because of high friction.",
            "answer": "False",
            "explanation": "Glass has low friction, making writing difficult."
        },
        {
            "type": "tf",
            "q": "Brakes work by decreasing friction between brake shoe and wheel.",
            "answer": "False",
            "explanation": "Brakes work by increasing friction to stop the vehicle."
        },
        {
            "type": "tf",
            "q": "Friction produces heat that can damage machine parts.",
            "answer": "True",
            "explanation": "Excess heat from friction can cause machines to jam."
        },
        {
            "type": "tf",
            "q": "A lot of energy is wasted to overcome friction.",
            "answer": "True",
            "explanation": "Vehicles use extra fuel to overcome friction."
        },
        {
            "type": "tf",
            "q": "Polishing a surface increases friction.",
            "answer": "False",
            "explanation": "Polishing makes surfaces smoother, reducing friction."
        },
        {
            "type": "tf",
            "q": "Oiling a bicycle chain reduces friction.",
            "answer": "True",
            "explanation": "Lubrication reduces friction between moving parts."
        },
        {
            "type": "tf",
            "q": "Talcum powder on a carrom board acts as a lubricant.",
            "answer": "True",
            "explanation": "Fine powder reduces friction between striker and board."
        },
        {
            "type": "tf",
            "q": "Streamlined shapes increase fluid friction.",
            "answer": "False",
            "explanation": "Streamlining reduces fluid friction (drag)."
        },
        {
            "type": "tf",
            "q": "Birds have streamlined bodies to help them fly.",
            "answer": "True",
            "explanation": "Streamlining reduces air resistance during flight."
        },
        {
            "type": "tf",
            "q": "Ships have streamlined shapes to reduce water resistance.",
            "answer": "True",
            "explanation": "Streamlining helps ships move efficiently through water."
        },
        {
            "type": "tf",
            "q": "Gravitational force is the weakest of all fundamental forces.",
            "answer": "True",
            "explanation": "Gravity is weak compared to electromagnetic and nuclear forces."
        },
        {
            "type": "tf",
            "q": "Your body exerts gravitational force on objects around you.",
            "answer": "True",
            "explanation": "All objects with mass exert gravitational force, though very weak."
        },
        {
            "type": "tf",
            "q": "The gravitational force of earth is very strong.",
            "answer": "True",
            "explanation": "Earth's mass is huge, so its gravity is strong enough to hold us."
        },
        {
            "type": "tf",
            "q": "A magnet can attract a piece of copper.",
            "answer": "False",
            "explanation": "Copper is non-magnetic and not attracted by magnets."
        },
        {
            "type": "tf",
            "q": "A magnet can attract a piece of cobalt.",
            "answer": "True",
            "explanation": "Cobalt is a magnetic substance."
        },
        {
            "type": "tf",
            "q": "Electrostatic force requires physical contact to act.",
            "answer": "False",
            "explanation": "Electrostatic force acts from a distance without contact."
        },
        {
            "type": "tf",
            "q": "Rubbing a plastic ruler on hair makes it positively charged.",
            "answer": "False",
            "explanation": "It gains negative charges from hair, becoming negatively charged."
        },
        {
            "type": "tf",
            "q": "Uncharged objects have equal numbers of positive and negative charges.",
            "answer": "True",
            "explanation": "Neutral objects have balanced positive and negative charges."
        },
        {
            "type": "tf",
            "q": "Lightning is caused by magnetic forces in clouds.",
            "answer": "False",
            "explanation": "Lightning is caused by electrostatic discharge."
        },
        {
            "type": "tf",
            "q": "You can have gravity without weight, but not weight without gravity.",
            "answer": "True",
            "explanation": "Weight is the force caused by gravity on a mass."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "What is force? Explain with examples the different effects of force.",
            "sample": "Force is a push or pull acting upon an object as a result of an interaction between two objects.\n\nEffects of force:\n1. Force can move a stationary object: Example - Pushing a stationary car to make it move.\n2. Force can stop a moving object: Example - Catching a ball stops its motion.\n3. Force can change the speed of a moving object: Example - Pushing a moving swing increases its speed; pulling it opposite decreases speed.\n4. Force can change the direction of a moving object: Example - A batsman hitting a ball changes its direction.\n5. Force can change the shape and size of an object: Example - Kneading dough, stretching a rubber band, squeezing a sponge."
        },
        {
            "type": "subjective",
            "q": "Explain the difference between mass and weight with suitable examples.",
            "sample": "Mass:\n- Amount of matter contained in an object\n- Constant quantity, does not change with location\n- Measured in kilograms (kg) or grams (g)\n- Measured using a beam balance\n\nWeight:\n- Gravitational force of the earth acting on the mass of an object\n- Varies with gravitational force at different locations\n- Measured in newtons (N)\n- Measured using a spring balance\n\nExample: An astronaut has a mass of 60 kg on earth. On the moon, his mass remains 60 kg, but his weight becomes 1/6 of his earth weight because moon's gravity is 1/6 of earth's. Mass is constant, weight varies with gravity."
        },
        {
            "type": "subjective",
            "q": "Explain how friction depends upon the nature of surfaces in contact and the weight of the moving object.",
            "sample": "Friction depends on two main factors:\n\n1. Nature of surfaces in contact:\n- Rough surfaces have more irregularities (grooves and ridges) that interlock with each other, offering greater friction.\n- Smooth surfaces have fewer irregularities, offering less friction.\n- More roughness = more friction; less roughness = less friction.\n- Example: A ball rolls farther on a smooth floor than on a rough carpet.\n\n2. Weight of the moving object:\n- Heavier objects press harder on the surface, increasing the interlocking of irregularities.\n- More weight = more friction; less weight = less friction.\n- Example: It's harder to push a heavy box than a light one.\n\nNote: When weight remains same, friction is independent of the area of contact."
        },
        {
            "type": "subjective",
            "q": "What are the different types of friction? Explain each with examples.",
            "sample": "Types of friction:\n\n1. Static friction:\n- Acts between two objects in contact while at rest\n- Prevents objects from starting to move\n- Maximum just before motion begins\n- Example: A book kept on a table doesn't slide due to static friction\n\n2. Kinetic friction (dynamic friction):\n- Acts when objects are in motion\n- Two types:\n   a. Sliding friction: When objects slide over a surface\n      Example: Pushing a box across the floor\n   b. Rolling friction: When objects roll over a surface\n      Example: A ball rolling on the ground\n\nRolling friction is less than sliding friction, which is why wheels are used."
        },
        {
            "type": "subjective",
            "q": "Describe an activity to show that rolling friction is less than sliding friction.",
            "sample": "Aim: To verify that rolling friction is less than sliding friction\n\nMaterials: A brick, a spring balance, a string, and a few pencils\n\nProcedure:\n1. Tie the string around the brick and attach it to the spring balance.\n2. Place the brick on a table and pull the spring balance until the brick just starts to move. Note the reading.\n3. Now place some pencils under the brick (so it rolls on the pencils).\n4. Pull the spring balance again until the brick just starts to move. Note the reading.\n\nObservation:\n- The reading in step 2 (sliding) is more than the reading in step 3 (rolling).\n\nConclusion:\n- Less force is needed when the brick rolls on pencils than when it slides directly.\n- This proves that rolling friction is less than sliding friction.\n\nThis principle is used in providing wheels to vehicles and ball bearings in machines."
        },
        {
            "type": "subjective",
            "q": "List five advantages of friction in our daily life.",
            "sample": "Advantages of friction:\n\n1. Walking: Friction between our feet and the ground allows us to walk without slipping. It opposes the backward movement of our feet, pushing us forward.\n\n2. Braking: Friction between brake shoes and wheel rims allows vehicles to stop when brakes are applied.\n\n3. Holding objects: Friction between our hands and objects allows us to grip and hold things.\n\n4. Writing: Friction between pen/pencil and paper allows us to write. It's difficult to write on smooth surfaces like glass due to low friction.\n\n5. Lighting matchsticks: Friction between matchstick and matchbox generates heat to ignite the match.\n\n6. Driving: Friction between tyres and road allows vehicles to move safely without skidding.\n\n7. Knots: Friction keeps knots from untying easily."
        },
        {
            "type": "subjective",
            "q": "List five disadvantages of friction with examples.",
            "sample": "Disadvantages of friction:\n\n1. Produces heat: Fast-moving machines generate heat due to friction, which can damage parts. Example: Car engines need cooling systems; without cooling, the engine can get jammed.\n\n2. Causes wear and tear: Friction wears down surfaces over time. Examples: Tyres become smooth and need replacement; shoe soles wear out; machine parts need regular replacement.\n\n3. Wastes energy: A lot of energy is wasted to overcome friction. Example: Vehicles consume more fuel to overcome friction between tyres and road.\n\n4. Reduces efficiency: Machines become less efficient due to friction losses. Example: Electric motors waste some energy as heat.\n\n5. Causes noise: Moving parts produce noise due to friction. Example: Squeaking of hinges, grinding sounds in machines.\n\n6. Limits speed: Friction limits the maximum speed of vehicles."
        },
        {
            "type": "subjective",
            "q": "Describe three methods to reduce friction with examples.",
            "sample": "Methods to reduce friction:\n\n1. Using lubricants:\n- Oils, grease, and graphite are applied between moving surfaces.\n- They fill the irregularities and make surfaces smooth.\n- Examples: Oiling bicycle chain, applying grease in machines, using talcum powder on carrom board.\n- Graphite is used in high-temperature applications where oil would evaporate.\n\n2. Using ball bearings:\n- Small metallic balls or rollers placed between moving parts.\n- They convert sliding friction into rolling friction (which is less).\n- Examples: In bicycle wheels, fans, industrial machinery.\n\n3. Polishing:\n- Making surfaces smooth by polishing reduces friction.\n- Example: Polishing wooden floors, metal surfaces.\n\n4. Streamlining:\n- Giving special shapes to objects to reduce fluid friction (drag).\n- Examples: Aeroplanes, cars, ships, fish have streamlined shapes."
        },
        {
            "type": "subjective",
            "q": "What is gravitational force? Explain why all objects fall towards the earth.",
            "sample": "Gravitational force is a universal force of attraction that exists between any two objects that have mass.\n\nAll objects fall towards the earth because:\n1. The earth has a huge mass, so it exerts a very strong gravitational force on all objects around it.\n2. This force attracts objects towards the centre of the earth.\n3. Even when objects are not in contact with the ground (like when thrown up), gravity still acts on them from a distance.\n4. This is why a ball thrown up always falls back down.\n5. The gravitational force of the earth is specifically called gravity.\n\nAlthough your body also exerts gravitational force on objects around you, it is too weak to be noticed because your mass is small compared to earth's mass."
        },
        {
            "type": "subjective",
            "q": "Explain magnetic force with an activity to show that it is a non-contact force.",
            "sample": "Magnetic force is the force of attraction or repulsion exerted by a magnet on magnetic substances (iron, nickel, cobalt) or other magnets.\n\nActivity to show magnetic force is non-contact:\n\nMaterials: A bar magnet and a few iron pins\n\nProcedure:\n1. Place the iron pins on a table.\n2. Slowly bring the bar magnet towards the pins without touching them.\n\nObservation:\n- As the magnet comes closer, the pins get attracted and jump towards the magnet even before the magnet touches them.\n\nConclusion:\n- The magnet attracts the pins from a distance without any physical contact.\n- This proves that magnetic force is a non-contact force (action-at-a-distance force).\n\nMagnetic force can also cause repulsion when like poles of two magnets are brought close."
        },
        {
            "type": "subjective",
            "q": "Explain electrostatic force with the help of an activity.",
            "sample": "Electrostatic force is the force exerted by a charged body on another charged or uncharged body.\n\nActivity to demonstrate electrostatic force:\n\nMaterials: A plastic ruler, a few bits of paper\n\nProcedure:\n1. Place small bits of paper on a table.\n2. Rub the plastic ruler vigorously against your dry hair a few times.\n3. Immediately bring the ruler close to the paper bits (without touching).\n\nObservation:\n- The paper bits jump up and stick to the ruler.\n\nExplanation:\n- Before rubbing, ruler had equal positive and negative charges (neutral).\n- Rubbing transferred negative charges from hair to ruler, making it negatively charged.\n- When brought near paper, the ruler attracts the positive charges in the paper.\n- This electrostatic force causes attraction.\n\nConclusion: Electrostatic force acts without contact and is responsible for phenomena like lightning."
        },
        {
            "type": "subjective",
            "q": "Why is it difficult to walk on a wet and smooth floor? Explain in terms of friction.",
            "sample": "It is difficult to walk on a wet and smooth floor because of reduced friction.\n\nExplanation:\n1. Normally, friction between our feet (or shoes) and the floor allows us to push backwards and move forward.\n2. Water acts as a lubricant, filling the irregularities on both surfaces and making them smoother.\n3. This significantly reduces the friction between feet and floor.\n4. When friction is low, our feet tend to slip instead of getting a firm grip.\n5. The force we apply to push backwards is not effectively opposed by friction, so we lose balance and may fall.\n6. Similarly, smooth surfaces like polished marble or tile have fewer irregularities, so they offer less friction even when dry.\n\nThis is why we need to walk carefully on wet floors, and why shoes with grooved soles (which increase friction) are safer."
        },
        {
            "type": "subjective",
            "q": "A force always changes the speed of a moving object. Do you agree? Give reason.",
            "sample": "No, I do not agree. A force does not always change the speed of a moving object; it can also change only its direction without changing speed.\n\nExplanation:\n1. If force is applied in the same direction as motion, speed increases.\n2. If force is applied opposite to motion, speed decreases.\n3. If force is applied perpendicular to motion, it changes direction without changing speed.\n\nExamples:\n- A batsman hitting a ball changes both direction and speed.\n- A planet moving around the sun experiences gravitational force perpendicular to its motion, which changes its direction (keeps it in orbit) but not its speed.\n- A ball tied to a string and whirled around has force towards centre, changing direction continuously but speed remains constant.\n\nThus, force can change speed, direction, or both depending on its direction relative to motion."
        },
        {
            "type": "subjective",
            "q": "Why do tyres of vehicles have grooved designs? What will happen if tyres are completely smooth?",
            "sample": "Tyres have grooved designs (treads) to increase friction between the tyre and the road.\n\nPurpose of grooves:\n1. They make the tyre surface rough, increasing friction.\n2. They provide better grip, especially on wet or muddy roads.\n3. They channel water away from the contact area, preventing hydroplaning (skidding on water).\n4. They improve braking efficiency and vehicle control.\n\nIf tyres are completely smooth:\n1. Friction between tyre and road would be greatly reduced.\n2. Vehicles would take longer to stop when brakes are applied.\n3. Vehicles would skid easily, especially on wet roads.\n4. Cornering would be dangerous as tyres would lose grip.\n5. Accident risk would increase significantly.\n\nThis is why racing cars use special smooth tyres (slicks) only on dry tracks, and why road vehicles need treaded tyres for safety in various conditions."
        },
        {
            "type": "subjective",
            "q": "Explain why athletes use shoes with spikes and why wrestlers rub special substances on their hands.",
            "sample": "Athletes use shoes with spikes to increase friction between their shoes and the ground. This provides:\n1. Better grip and traction, preventing slipping during running.\n2. More powerful push-off for faster acceleration.\n3. Better control during quick turns and sudden stops.\n4. Stability on various surfaces like tracks or grass.\n\nThe spikes dig into the ground, increasing the effective roughness and friction.\n\nWrestlers rub special substances (like resin or chalk) on their hands to:\n1. Increase friction between their hands and their opponent's body.\n2. Prevent their hands from slipping during holds and grips.\n3. Have better control over their movements.\n4. Improve their grip strength and effectiveness.\n\nIn both cases, the goal is to increase friction for better performance and safety, showing that sometimes we need more friction rather than less."
        },
        {
            "type": "subjective",
            "q": "What is streamlining? Why do fish, birds, aeroplanes, and ships have streamlined shapes?",
            "sample": "Streamlining means giving a special shape to objects so that they experience minimum drag (fluid friction) while travelling through air or water.\n\nCharacteristics of streamlined shape:\n- Rounded front that gradually narrows along the length\n- Smooth, curved surfaces without sharp edges\n- Tapered rear end\n\nWhy various objects have streamlined shapes:\n\nFish: Streamlined bodies help them swim efficiently through water with minimal resistance, allowing them to move faster and use less energy.\n\nBirds: Streamlined shapes reduce air resistance during flight, enabling them to fly faster and longer with less effort.\n\nAeroplanes: Streamlined design minimizes air drag, saving fuel and allowing higher speeds. Every part from nose to tail is designed for smooth airflow.\n\nShips and boats: Streamlined hulls reduce water resistance, making them more fuel-efficient and faster.\n\nCars: Modern cars have streamlined designs to reduce air resistance, improve fuel efficiency, and achieve higher speeds."
        },
        {
            "type": "subjective",
            "q": "Why do we slip on a banana peel? Explain the science behind it.",
            "sample": "We slip on a banana peel due to reduced friction.\n\nScientific explanation:\n1. Normally, when we walk, friction between our shoes and the ground provides the necessary grip.\n2. A banana peel, especially the inner side, is soft, wet, and slippery.\n3. When we step on it, the peel acts as a lubricant between our shoe and the ground.\n4. It significantly reduces the friction that normally prevents slipping.\n5. The peel's soft structure also allows it to roll or slide under our foot.\n6. With reduced friction, our foot cannot get a firm grip and slides forward rapidly.\n7. Our body's momentum continues forward while our foot slips, causing loss of balance and a fall.\n\nThis is a classic example of how reduced friction can be dangerous. It demonstrates why we need adequate friction for safe walking and why wet or slippery surfaces are hazardous."
        },
        {
            "type": "subjective",
            "q": "How would the world be different if there was no friction?",
            "sample": "If there was no friction, the world would be dramatically different and very difficult to live in:\n\n1. Walking impossible: We would slip and fall constantly; couldn't stand or walk.\n2. No vehicle movement: Cars, buses, bicycles couldn't move; brakes wouldn't work.\n3. Cannot hold objects: Everything would slip from our hands.\n4. No writing: Pens/pencils wouldn't leave marks on paper.\n5. No knots: All knots would untie immediately.\n6. No nails or screws: They wouldn't stay in walls.\n7. Objects in motion never stop: A moving ball would never stop (no friction to slow it).\n8. No heat generation: Couldn't light matches; no fire from rubbing sticks.\n9. Machines would be efficient: No energy wasted overcoming friction.\n10. No wear and tear: Things would last forever without wearing out.\n\nWhile friction causes problems like wear and energy loss, it is essential for most daily activities. Without friction, life as we know it would be impossible."
        },
        {
            "type": "subjective",
            "q": "Why is it easier to pull a suitcase with wheels than to carry it? Explain using the concept of friction.",
            "sample": "It is easier to pull a suitcase with wheels than to carry it because of the difference between sliding/rolling friction and the effort required.\n\nExplanation:\n1. When we carry a suitcase, we are lifting its entire weight against gravity, which requires significant muscular force.\n\n2. When we pull a suitcase with wheels:\n   - The wheels convert sliding friction into rolling friction.\n   - Rolling friction is much less than sliding friction.\n   - The force needed to overcome rolling friction is small.\n   - We are not lifting the weight but only pulling it horizontally.\n\n3. The principle: Rolling friction < Sliding friction\n   - This is why vehicles have wheels, why ball bearings are used, and why luggage has wheels.\n\n4. Activity demonstration:\n   - Pulling a brick directly requires more force (sliding friction).\n   - Putting pencils under the brick (creating rolling) requires less force.\n\nThus, wheels reduce the effort needed to move heavy objects by replacing sliding friction with the much smaller rolling friction."
        },
        {
            "type": "subjective",
            "q": "Why does a car skid on a wet road? What should be done to prevent skidding?",
            "sample": "A car skids on a wet road because of reduced friction between the tyres and the road surface.\n\nReasons for skidding:\n1. Water acts as a lubricant, reducing friction.\n2. At high speeds, a layer of water can build up between tyres and road (hydroplaning).\n3. Tyres lose contact with the road, leading to loss of control.\n4. Braking suddenly can lock the wheels, causing sliding.\n\nTo prevent skidding:\n1. Drive at slower speeds on wet roads.\n2. Maintain proper tyre tread depth (grooves channel water away).\n3. Avoid sudden braking; brake gently and progressively.\n4. Avoid sharp turns at high speed.\n5. Ensure tyres are properly inflated.\n6. Use quality tyres with good wet grip ratings.\n7. Increase following distance from other vehicles.\n\nModern vehicles have Anti-lock Braking Systems (ABS) that prevent wheel lock-up during emergency braking, helping maintain control and reducing skidding risk."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 5: Simple Machines (SET 2)
    # ──────────────────────────────────────────────────────────────────
    "Chapter 5 — Simple Machines (Set 2)": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "Which scientist studied the relationship between heat and mechanical work?",
            "options": [
                "Anders Celsius",
                "James Prescott Joule",
                "Isaac Newton",
                "Albert Einstein"
            ],
            "answer": "James Prescott Joule",
            "explanation": "Joule was an English physicist who studied heat and its relationship to mechanical work."
        },
        {
            "type": "mcq",
            "q": "What is the formula for mechanical advantage?",
            "options": [
                "Effort ÷ Load",
                "Load × Effort",
                "Load ÷ Effort",
                "Effort - Load"
            ],
            "answer": "Load ÷ Effort",
            "explanation": "Mechanical Advantage (MA) = Load ÷ Effort"
        },
        {
            "type": "mcq",
            "q": "If MA = 1, what does it indicate?",
            "options": [
                "Machine multiplies force",
                "Machine reduces force",
                "Effort equals load",
                "Machine is 100% efficient"
            ],
            "answer": "Effort equals load",
            "explanation": "When MA = 1, effort = load, so machine only changes direction."
        },
        {
            "type": "mcq",
            "q": "If MA > 1, then effort is _______ than load.",
            "options": [
                "Greater",
                "Less",
                "Equal",
                "Double"
            ],
            "answer": "Less",
            "explanation": "MA > 1 means Load ÷ Effort > 1, so Load > Effort, hence effort is less."
        },
        {
            "type": "mcq",
            "q": "If MA < 1, then the machine acts as a:",
            "options": [
                "Force multiplier",
                "Force reducer",
                "Direction changer",
                "Speed multiplier"
            ],
            "answer": "Force reducer",
            "explanation": "MA < 1 means effort > load, so machine reduces force but may increase speed."
        },
        {
            "type": "mcq",
            "q": "What is efficiency of a machine?",
            "options": [
                "Output energy × Input energy",
                "Output energy ÷ Input energy",
                "Input energy ÷ Output energy",
                "Output energy - Input energy"
            ],
            "answer": "Output energy ÷ Input energy",
            "explanation": "Efficiency = Output energy / Input energy, usually expressed as percentage."
        },
        {
            "type": "mcq",
            "q": "If a machine is 80% efficient, what does it mean?",
            "options": [
                "80% of input energy is wasted",
                "80% of input energy is converted to useful work",
                "Machine multiplies force by 80 times",
                "Machine has MA = 80"
            ],
            "answer": "80% of input energy is converted to useful work",
            "explanation": "80% efficiency means 80% of input becomes useful output; 20% is lost to friction etc."
        },
        {
            "type": "mcq",
            "q": "In a Class I lever, if the fulcrum is exactly in the middle, then:",
            "options": [
                "MA > 1",
                "MA < 1",
                "MA = 1",
                "MA = 0"
            ],
            "answer": "MA = 1",
            "explanation": "If fulcrum is in middle, effort arm = load arm, so MA = 1."
        },
        {
            "type": "mcq",
            "q": "In a Class I lever, if the fulcrum is closer to the load, then:",
            "options": [
                "MA > 1",
                "MA < 1",
                "MA = 1",
                "MA = 0"
            ],
            "answer": "MA > 1",
            "explanation": "Fulcrum closer to load means effort arm > load arm, so MA > 1."
        },
        {
            "type": "mcq",
            "q": "In a Class I lever, if the fulcrum is closer to the effort, then:",
            "options": [
                "MA > 1",
                "MA < 1",
                "MA = 1",
                "MA = 0"
            ],
            "answer": "MA < 1",
            "explanation": "Fulcrum closer to effort means effort arm < load arm, so MA < 1."
        },
        {
            "type": "mcq",
            "q": "A pair of scissors is which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class I",
            "explanation": "Scissors have fulcrum (pivot) between load (paper) and effort (hand)."
        },
        {
            "type": "mcq",
            "q": "A beam balance is which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class I",
            "explanation": "Beam balance has fulcrum in middle, load on one side, effort (weights) on other."
        },
        {
            "type": "mcq",
            "q": "A nutcracker is which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class II",
            "explanation": "Nutcracker has load (nut) between fulcrum (hinge) and effort (hand)."
        },
        {
            "type": "mcq",
            "q": "A lemon squeezer is which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class II",
            "explanation": "Lemon squeezer has load between fulcrum and effort."
        },
        {
            "type": "mcq",
            "q": "A fishing rod is which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class III",
            "explanation": "Fishing rod has effort (hand) between fulcrum (butt) and load (fish)."
        },
        {
            "type": "mcq",
            "q": "A pair of tongs is which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class III",
            "explanation": "Tongs have effort in middle, fulcrum at one end, load at other."
        },
        {
            "type": "mcq",
            "q": "The human forearm is which class of lever?",
            "options": [
                "Class I",
                "Class II",
                "Class III",
                "Class IV"
            ],
            "answer": "Class III",
            "explanation": "Elbow is fulcrum, hand is load, muscles apply effort in between."
        },
        {
            "type": "mcq",
            "q": "A see-saw with two children of equal weight will balance when:",
            "options": [
                "They sit at equal distances from fulcrum",
                "Heavier child sits closer to fulcrum",
                "Lighter child sits closer to fulcrum",
                "Both sit at ends"
            ],
            "answer": "They sit at equal distances from fulcrum",
            "explanation": "Equal weights need equal distances from fulcrum to balance."
        },
        {
            "type": "mcq",
            "q": "A see-saw with a heavier child and a lighter child will balance when:",
            "options": [
                "Both sit at equal distances",
                "Heavier child sits closer to fulcrum",
                "Lighter child sits closer to fulcrum",
                "They sit at ends"
            ],
            "answer": "Heavier child sits closer to fulcrum",
            "explanation": "Heavier child needs shorter distance; lighter child needs longer distance."
        },
        {
            "type": "mcq",
            "q": "The mechanical advantage of an inclined plane is calculated as:",
            "options": [
                "Height ÷ Length",
                "Length × Height",
                "Length ÷ Height",
                "Load ÷ Effort"
            ],
            "answer": "Length ÷ Height",
            "explanation": "MA of inclined plane = Length of slope ÷ Vertical height."
        },
        {
            "type": "mcq",
            "q": "A longer inclined plane (gentler slope) gives:",
            "options": [
                "Greater MA, less effort",
                "Less MA, more effort",
                "Same MA",
                "No effect"
            ],
            "answer": "Greater MA, less effort",
            "explanation": "Longer slope (gentler) means larger length/height ratio, so greater MA."
        },
        {
            "type": "mcq",
            "q": "A steeper inclined plane requires:",
            "options": [
                "Less effort",
                "More effort",
                "Same effort",
                "No effort"
            ],
            "answer": "More effort",
            "explanation": "Steeper slope has smaller length/height ratio, so smaller MA, requiring more effort."
        },
        {
            "type": "mcq",
            "q": "A knife is an example of which simple machine?",
            "options": [
                "Lever",
                "Inclined plane",
                "Wedge",
                "Screw"
            ],
            "answer": "Wedge",
            "explanation": "Knife has a sharp edge formed by two inclined planes."
        },
        {
            "type": "mcq",
            "q": "An axe is an example of which simple machine?",
            "options": [
                "Lever",
                "Inclined plane",
                "Wedge",
                "Pulley"
            ],
            "answer": "Wedge",
            "explanation": "Axe blade is a wedge that splits wood."
        },
        {
            "type": "mcq",
            "q": "A needle is an example of which simple machine?",
            "options": [
                "Lever",
                "Wedge",
                "Screw",
                "Pulley"
            ],
            "answer": "Wedge",
            "explanation": "Needle has a pointed end that pierces materials - acts as a wedge."
        },
        {
            "type": "mcq",
            "q": "A chisel is an example of which simple machine?",
            "options": [
                "Lever",
                "Wedge",
                "Screw",
                "Inclined plane"
            ],
            "answer": "Wedge",
            "explanation": "Chisel has a sharp edge for cutting or splitting."
        },
        {
            "type": "mcq",
            "q": "A screw is actually an inclined plane:",
            "options": [
                "Made flat",
                "Wound around a rod",
                "Made sharp",
                "Removed"
            ],
            "answer": "Wound around a rod",
            "explanation": "The threads of a screw are an inclined plane wrapped around a cylinder."
        },
        {
            "type": "mcq",
            "q": "The threads of a screw help it to:",
            "options": [
                "Grip firmly",
                "Move easily",
                "Cut materials",
                "Rotate faster"
            ],
            "answer": "Grip firmly",
            "explanation": "Threads provide better grip than a smooth nail."
        },
        {
            "type": "mcq",
            "q": "A screw jack used to lift a car works on which principle?",
            "options": [
                "Lever",
                "Pulley",
                "Screw",
                "Wedge"
            ],
            "answer": "Screw",
            "explanation": "Screw jack uses screw principle to lift heavy vehicles."
        },
        {
            "type": "mcq",
            "q": "A single fixed pulley has mechanical advantage of:",
            "options": [
                "2",
                "1",
                "0.5",
                "Depends on load"
            ],
            "answer": "1",
            "explanation": "Single fixed pulley only changes direction, not magnitude, so MA = 1."
        },
        {
            "type": "mcq",
            "q": "A single movable pulley has mechanical advantage of:",
            "options": [
                "1",
                "2",
                "3",
                "0.5"
            ],
            "answer": "2",
            "explanation": "Single movable pulley has MA = 2, multiplying force."
        },
        {
            "type": "mcq",
            "q": "A combination of pulleys is called:",
            "options": [
                "Pulley system",
                "Block and tackle",
                "Wheel system",
                "Gear system"
            ],
            "answer": "Block and tackle",
            "explanation": "Multiple pulleys together form a block and tackle system."
        },
        {
            "type": "mcq",
            "q": "A steering wheel is an example of:",
            "options": [
                "Lever",
                "Pulley",
                "Wheel-and-axle",
                "Inclined plane"
            ],
            "answer": "Wheel-and-axle",
            "explanation": "Steering wheel (wheel) rotates the steering column (axle)."
        },
        {
            "type": "mcq",
            "q": "A door knob is an example of:",
            "options": [
                "Lever",
                "Pulley",
                "Wheel-and-axle",
                "Screw"
            ],
            "answer": "Wheel-and-axle",
            "explanation": "Turning the knob (wheel) rotates the spindle (axle) to open the latch."
        },
        {
            "type": "mcq",
            "q": "A screwdriver is an example of:",
            "options": [
                "Lever",
                "Wedge",
                "Wheel-and-axle",
                "Inclined plane"
            ],
            "answer": "Wheel-and-axle",
            "explanation": "The handle is the wheel, the shaft is the axle."
        },
        {
            "type": "mcq",
            "q": "A bicycle pedal is an example of:",
            "options": [
                "Lever",
                "Pulley",
                "Wheel-and-axle",
                "Inclined plane"
            ],
            "answer": "Wheel-and-axle",
            "explanation": "Pedal arm rotates the crank (axle)."
        },
        {
            "type": "mcq",
            "q": "In a wheel-and-axle, when effort is applied on the wheel:",
            "options": [
                "Axle rotates with greater force",
                "Axle rotates with less force",
                "Axle does not rotate",
                "Only wheel rotates"
            ],
            "answer": "Axle rotates with greater force",
            "explanation": "The wheel multiplies the force applied to the axle."
        },
        {
            "type": "mcq",
            "q": "To prevent rust, iron machines should be:",
            "options": [
                "Oiled",
                "Painted",
                "Kept in water",
                "Heated"
            ],
            "answer": "Painted",
            "explanation": "Painting protects iron from moisture and prevents rust."
        },
        {
            "type": "mcq",
            "q": "Moving parts of machines should be regularly:",
            "options": [
                "Painted",
                "Oiled",
                "Heated",
                "Washed with water"
            ],
            "answer": "Oiled",
            "explanation": "Oiling reduces friction and wear and tear."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "Work is done when you push a wall and it doesn't move.",
            "answer": "False",
            "explanation": "Work requires displacement. No displacement means no work done."
        },
        {
            "type": "tf",
            "q": "Energy is the ability to do work.",
            "answer": "True",
            "explanation": "This is the correct definition of energy."
        },
        {
            "type": "tf",
            "q": "Complex machines have few or no moving parts.",
            "answer": "False",
            "explanation": "Simple machines have few moving parts; complex machines have many."
        },
        {
            "type": "tf",
            "q": "A spoon can be used as a simple machine to open a lid.",
            "answer": "True",
            "explanation": "A spoon acts as a lever to open lids."
        },
        {
            "type": "tf",
            "q": "All machines have mechanical advantage greater than 1.",
            "answer": "False",
            "explanation": "Some machines (Class III levers) have MA < 1."
        },
        {
            "type": "tf",
            "q": "Some machines only change the direction of applied force without multiplying it.",
            "answer": "True",
            "explanation": "Example: Single fixed pulley changes direction but MA = 1."
        },
        {
            "type": "tf",
            "q": "Mechanical advantage is about force applied while efficiency is about work done.",
            "answer": "True",
            "explanation": "MA compares forces; efficiency compares work/energy."
        },
        {
            "type": "tf",
            "q": "Efficiency of a machine can be greater than 100%.",
            "answer": "False",
            "explanation": "Efficiency is always less than 100% due to energy losses."
        },
        {
            "type": "tf",
            "q": "The work done by a machine is always less than the work done on the machine.",
            "answer": "True",
            "explanation": "Some energy is lost to friction, so output < input."
        },
        {
            "type": "tf",
            "q": "In a Class I lever, the fulcrum is always exactly in the middle.",
            "answer": "False",
            "explanation": "Fulcrum can be anywhere between load and effort."
        },
        {
            "type": "tf",
            "q": "In a Class II lever, the effort arm is always longer than the load arm.",
            "answer": "True",
            "explanation": "This gives MA > 1 in Class II levers."
        },
        {
            "type": "tf",
            "q": "In a Class III lever, the effort arm is always shorter than the load arm.",
            "answer": "True",
            "explanation": "This gives MA < 1 in Class III levers."
        },
        {
            "type": "tf",
            "q": "A bottle opener is a Class III lever.",
            "answer": "False",
            "explanation": "Bottle opener is Class II lever (load between fulcrum and effort)."
        },
        {
            "type": "tf",
            "q": "Tweezers are a Class III lever.",
            "answer": "True",
            "explanation": "Effort is applied in middle, fulcrum at one end, load at other."
        },
        {
            "type": "tf",
            "q": "A wheelbarrow is a Class II lever.",
            "answer": "True",
            "explanation": "Wheel is fulcrum, load in middle, handles where effort applied."
        },
        {
            "type": "tf",
            "q": "A crowbar used to lift heavy rocks is a Class I lever.",
            "answer": "True",
            "explanation": "Fulcrum is placed between effort and load."
        },
        {
            "type": "tf",
            "q": "Oars used to row a boat are Class II levers.",
            "answer": "True",
            "explanation": "Water is fulcrum, boat is load, oar handle is effort."
        },
        {
            "type": "tf",
            "q": "Forceps are Class II levers.",
            "answer": "False",
            "explanation": "Forceps are Class III levers (effort in middle)."
        },
        {
            "type": "tf",
            "q": "A staircase is an example of an inclined plane.",
            "answer": "True",
            "explanation": "Stairs allow us to go up vertically by moving along a slope."
        },
        {
            "type": "tf",
            "q": "A winding road on a hill is an example of an inclined plane.",
            "answer": "True",
            "explanation": "It provides a gentle slope to climb the hill."
        },
        {
            "type": "tf",
            "q": "A wedge has two sloping surfaces that meet at a sharp edge.",
            "answer": "True",
            "explanation": "This is the definition of a wedge."
        },
        {
            "type": "tf",
            "q": "A pin has a pointed edge, so it is a wedge.",
            "answer": "True",
            "explanation": "The pointed tip acts as a wedge to penetrate materials."
        },
        {
            "type": "tf",
            "q": "A nail is a type of screw.",
            "answer": "False",
            "explanation": "Nail is smooth; screw has threads."
        },
        {
            "type": "tf",
            "q": "Ancient screws were made of wood.",
            "answer": "True",
            "explanation": "Metal screws appeared only about 600 years ago."
        },
        {
            "type": "tf",
            "q": "A pulley consists of a flat circular disc with a groove along its rim.",
            "answer": "True",
            "explanation": "The groove holds the rope and prevents slipping."
        },
        {
            "type": "tf",
            "q": "A single fixed pulley is used to draw water from wells.",
            "answer": "True",
            "explanation": "It allows pulling downward to lift water upward."
        },
        {
            "type": "tf",
            "q": "A single movable pulley is attached to a rigid support and does not move.",
            "answer": "False",
            "explanation": "Movable pulley moves with the load; fixed pulley is attached to support."
        },
        {
            "type": "tf",
            "q": "Cranes use movable pulleys to lift very heavy loads.",
            "answer": "True",
            "explanation": "Movable pulleys provide mechanical advantage."
        },
        {
            "type": "tf",
            "q": "In a wheel-and-axle, both wheel and axle rotate together.",
            "answer": "True",
            "explanation": "They are attached and rotate as one unit."
        },
        {
            "type": "tf",
            "q": "A drilling machine uses a wheel-and-axle arrangement.",
            "answer": "True",
            "explanation": "The handle (wheel) rotates the drill bit (axle)."
        },
        {
            "type": "tf",
            "q": "A spindle tap has a handle that works like a wheel.",
            "answer": "True",
            "explanation": "The handle is easier to turn than the spindle alone."
        },
        {
            "type": "tf",
            "q": "Machines should be kept covered when not in use.",
            "answer": "True",
            "explanation": "This prevents dust accumulation."
        },
        {
            "type": "tf",
            "q": "Iron machines should be kept in moist places.",
            "answer": "False",
            "explanation": "Moisture causes rusting."
        },
        {
            "type": "tf",
            "q": "Oiling moving parts increases friction.",
            "answer": "False",
            "explanation": "Oiling reduces friction."
        },
        {
            "type": "tf",
            "q": "The principle of lever states: Load × Load arm = Effort × Effort arm.",
            "answer": "True",
            "explanation": "This is the correct lever principle."
        },
        {
            "type": "tf",
            "q": "A lever always multiplies force.",
            "answer": "False",
            "explanation": "Class III levers reduce force."
        },
        {
            "type": "tf",
            "q": "In an inclined plane, steeper slope requires more effort.",
            "answer": "True",
            "explanation": "MA decreases as slope increases, so more effort needed."
        },
        {
            "type": "tf",
            "q": "Screws grip wood more firmly than nails.",
            "answer": "True",
            "explanation": "Threads provide better holding power."
        },
        {
            "type": "tf",
            "q": "A single fixed pulley has MA = 2.",
            "answer": "False",
            "explanation": "Single fixed pulley has MA = 1 (only direction change)."
        },
        {
            "type": "tf",
            "q": "A single movable pulley has MA = 2.",
            "answer": "True",
            "explanation": "It multiplies force by 2."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "Define work and energy. Give examples of work being done in Physics.",
            "sample": "Work: In Physics, work is said to be done when a force applied on an object displaces the object in the direction of the force. Work requires both force and displacement.\n\nEnergy: Energy is defined as the ability to do work.\n\nExamples of work being done:\n1. Picking up a book from a table - force applied by hand moves the book upward.\n2. Drawing water from a well - force applied on rope lifts the bucket.\n3. Kicking a football - force from foot moves the ball.\n4. Climbing up a hill - muscles apply force to move body upward.\n\nExamples where NO work is done (in Physics sense):\n- Reading a book (no displacement)\n- Studying or thinking (no displacement)\n- Pushing a wall that doesn't move (no displacement)"
        },
        {
            "type": "subjective",
            "q": "Explain the functioning of machines with respect to changing magnitude and direction of force.",
            "sample": "Machines make our work easier by utilizing the applied force in different ways:\n\n1. Changing the magnitude of applied force (Force multipliers):\n   - Some machines multiply the force we apply, so a small effort can lift a heavy load.\n   - Example: A bottle opener multiplies the effort, making it easy to open a cap.\n   - These machines have mechanical advantage greater than 1.\n\n2. Changing the direction of applied force:\n   - Some machines allow us to apply force in a more convenient direction.\n   - Example: A hand pump - we push the handle down, and water comes up. The force direction is changed from downward to upward.\n   - Example: A single fixed pulley - we pull down to lift a load up.\n   - These machines may have MA = 1 but make work more convenient.\n\nSome machines can do both - multiply force and change direction."
        },
        {
            "type": "subjective",
            "q": "What is mechanical advantage? How is it calculated? Explain with an example.",
            "sample": "Mechanical advantage (MA) is the factor by which a machine multiplies the force applied to it. It is the ratio of the load lifted by the machine to the effort applied on it.\n\nFormula: MA = Load ÷ Effort\n\nIf MA > 1: Machine acts as force multiplier (effort < load)\nIf MA = 1: Machine only changes direction (effort = load)\nIf MA < 1: Machine reduces force (effort > load)\n\nExample:\nA machine lifts a load of 120 kgf when an effort of 12 kgf is applied.\nMA = Load ÷ Effort = 120 ÷ 12 = 10\nThis means the machine multiplies the applied force by 10 times. A small effort of 12 kgf can lift a heavy load of 120 kgf."
        },
        {
            "type": "subjective",
            "q": "State the principle of levers. How is mechanical advantage of a lever calculated?",
            "sample": "Principle of levers: The product of the load and the load arm is always equal to the product of the effort and the effort arm.\n\nMathematically: Load × Load arm = Effort × Effort arm\n\nFrom this principle, we can derive:\nLoad ÷ Effort = Effort arm ÷ Load arm\n\nTherefore, Mechanical Advantage (MA) of a lever = Effort arm ÷ Load arm\n\nThis means:\n- If effort arm > load arm, then MA > 1 (force multiplier)\n- If effort arm = load arm, then MA = 1\n- If effort arm < load arm, then MA < 1\n\nThe longer the effort arm compared to load arm, the greater the mechanical advantage."
        },
        {
            "type": "subjective",
            "q": "Draw a labeled diagram of a Class I lever. Give three examples.",
            "sample": "A Class I lever has the fulcrum located between the load and the effort.\n\nDiagram features:\n- A rigid bar\n- Fulcrum (F) in the middle\n- Load (L) at one end\n- Effort (E) at the other end\n\nExamples of Class I levers:\n1. See-saw: Children sit at ends (loads), fulcrum in middle\n2. Crowbar: Used to lift heavy objects, fulcrum placed between effort and load\n3. Scissors: Fulcrum is the pivot, paper is load, hand applies effort\n4. Pliers: Similar to scissors\n5. Beam balance: Fulcrum in middle, pans at ends\n6. Wire cutters\n\nIn Class I levers, the mechanical advantage can be greater than, equal to, or less than 1 depending on the position of the fulcrum."
        },
        {
            "type": "subjective",
            "q": "Draw a labeled diagram of a Class II lever. Give three examples and explain why MA is always greater than 1.",
            "sample": "A Class II lever has the load located between the fulcrum and the effort.\n\nDiagram features:\n- Fulcrum (F) at one end\n- Load (L) in the middle\n- Effort (E) at the other end\n\nExamples of Class II levers:\n1. Nutcracker: Nut is load in middle, hinge is fulcrum, hand applies effort at ends\n2. Wheelbarrow: Wheel is fulcrum, load in the wheelbarrow, handles where effort applied\n3. Bottle opener: Fulcrum at one end (on bottle rim), load (cap) in middle, effort at other end\n4. Paper cutter\n5. Lemon squeezer\n6. Oars of a boat\n\nWhy MA > 1 in Class II levers:\n- The effort arm is always longer than the load arm (effort is at the far end, load is closer to fulcrum)\n- Therefore, Effort arm ÷ Load arm > 1\n- So MA is always greater than 1\n- These levers always act as force multipliers"
        },
        {
            "type": "subjective",
            "q": "Draw a labeled diagram of a Class III lever. Give three examples and explain why MA is always less than 1.",
            "sample": "A Class III lever has the effort located between the fulcrum and the load.\n\nDiagram features:\n- Fulcrum (F) at one end\n- Effort (E) in the middle\n- Load (L) at the other end\n\nExamples of Class III levers:\n1. Tweezers: Fulcrum at one end, load at tips, effort applied in middle\n2. Fishing rod: Butt end is fulcrum, fish is load, hand applies effort in middle\n3. Hockey stick: Top hand (fulcrum), bottom hand (effort), ball is load at blade\n4. Human forearm: Elbow is fulcrum, hand holds load, muscles apply effort in middle\n5. Forceps\n6. Sugar tongs\n\nWhy MA < 1 in Class III levers:\n- The effort arm is always shorter than the load arm (effort is closer to fulcrum than load)\n- Therefore, Effort arm ÷ Load arm < 1\n- So MA is always less than 1\n- These levers do not multiply force; instead, they multiply speed and range of motion"
        },
        {
            "type": "subjective",
            "q": "The length of a Class I lever is 2 m. Calculate its mechanical advantage if the fulcrum is at a distance of 40 cm from the effort point.",
            "sample": "Given:\nTotal length of lever = 2 m = 200 cm\nDistance of fulcrum from effort = 40 cm (effort arm)\n\nTherefore, distance of fulcrum from load (load arm) = Total length - Effort arm\n= 200 cm - 40 cm = 160 cm\n\nMechanical Advantage = Effort arm ÷ Load arm\n= 40 cm ÷ 160 cm\n= 0.25\n\nSince MA < 1, this lever will require more effort than the load. It acts as a force reducer.\n\nNote: In this case, the fulcrum is closer to the effort, so effort arm is shorter than load arm, resulting in MA < 1."
        },
        {
            "type": "subjective",
            "q": "The length of the load arm of a lever is 6 m and its effort arm is 3 m. What is the effort required to lift a load of 40 N?",
            "sample": "Given:\nLoad arm = 6 m\nEffort arm = 3 m\nLoad = 40 N\nEffort = ?\n\nAccording to the principle of lever:\nLoad × Load arm = Effort × Effort arm\n\n40 N × 6 m = Effort × 3 m\n240 = Effort × 3\nEffort = 240 ÷ 3 = 80 N\n\nTherefore, an effort of 80 N is required to lift the load of 40 N.\n\nCheck: Mechanical Advantage = Load ÷ Effort = 40 ÷ 80 = 0.5\nAlso MA = Effort arm ÷ Load arm = 3 ÷ 6 = 0.5 ✓\n\nSince MA < 1, this lever requires more effort than the load."
        },
        {
            "type": "subjective",
            "q": "Calculate the mechanical advantage of a crowbar of length 240 cm if its fulcrum is at a distance of 40 cm from the load.",
            "sample": "Given:\nTotal length of crowbar = 240 cm\nDistance of fulcrum from load (load arm) = 40 cm\n\nTherefore, distance of fulcrum from effort (effort arm) = Total length - Load arm\n= 240 cm - 40 cm = 200 cm\n\nMechanical Advantage = Effort arm ÷ Load arm\n= 200 cm ÷ 40 cm\n= 5\n\nThis means the crowbar multiplies the applied force by 5 times. A small effort can lift a load 5 times heavier.\n\nSince MA > 1, this crowbar acts as a force multiplier, which is typical when the fulcrum is placed closer to the load."
        },
        {
            "type": "subjective",
            "q": "What is an inclined plane? How does it help in lifting heavy objects? Explain with an example.",
            "sample": "An inclined plane is a rigid sloping surface over which heavy loads can be raised or lowered to a certain height or depth with less effort than lifting directly vertically.\n\nHow it helps:\n- When lifting an object directly, we must overcome its entire weight at once.\n- With an inclined plane, the same weight is spread over a longer distance.\n- The force required is less, but we must apply it over a longer distance.\n- The mechanical advantage = Length of slope ÷ Vertical height.\n- Longer the slope (gentler the incline), greater the MA, less the effort required.\n\nExample:\nLoading a heavy box onto a truck that is 1 m high:\n- Lifting directly: Need force equal to box's weight.\n- Using a 5 m long ramp: Need only 1/5 of the force (if no friction).\n- The box is pushed up slowly over 5 m instead of lifted 1 m.\n\nOther examples: Roads on hills, staircases, wheelchair ramps."
        },
        {
            "type": "subjective",
            "q": "What is a wedge? Give four examples and explain how it works.",
            "sample": "A wedge is a double inclined plane where two sloping surfaces taper to form a sharp edge. It is used to cut, split, or push things apart.\n\nHow a wedge works:\n- When force is applied to the blunt end, the sharp edge concentrates the force over a small area.\n- The sloping sides convert the downward/forward force into sideways forces that push materials apart.\n- The longer and sharper the wedge, the more easily it cuts.\n\nExamples of wedges:\n1. Knife: Cuts food by pushing materials apart along its sharp edge.\n2. Axe: Splits wood by forcing the wood fibers apart.\n3. Chisel: Used by carpenters to cut or shape wood.\n4. Needle/Pin: Pierces fabric or skin with its pointed tip.\n5. Nail: Pointed end helps it penetrate wood.\n6. Door wedge: Used to keep door open by jamming under it.\n\nSome wedges have more than two inclined planes (like needles and pins) that taper to a very fine point."
        },
        {
            "type": "subjective",
            "q": "What is a screw? Describe its advantage over a nail with an activity to show it is an inclined plane.",
            "sample": "A screw is a cylindrical rod marked with a winding spiral edge called a thread. It is actually an inclined plane wound around a rod.\n\nAdvantages over nail:\n1. Less effort needed to drive a screw into wood than a nail.\n2. Screws grip wood more firmly due to threads.\n3. Screws can be removed and reused easily.\n4. Provide stronger holding power.\n\nActivity to show screw is an inclined plane:\nMaterials: Paper, scissors, iron nail\n\nProcedure:\n1. Cut a right-angled triangle from paper (representing an inclined plane).\n2. Wrap it around the iron nail starting from the pointed end.\n3. The sloping edge of the paper forms a spiral pattern on the nail.\n\nObservation:\n- The paper's edge looks exactly like the threads on a screw.\n\nConclusion:\n- This proves that a screw is essentially an inclined plane wound around a cylinder.\n- The length of the inclined plane is spread along the threads, making it easier to drive in with less force."
        },
        {
            "type": "subjective",
            "q": "What is a pulley? Differentiate between a single fixed pulley and a single movable pulley.",
            "sample": "A pulley is a wheel or circular disc with a groove along its rim that can rotate freely. A rope or chain passes through the groove, with load attached to one end and effort applied at the other. The groove prevents the rope from slipping.\n\nDifferences between single fixed and single movable pulley:\n\nSingle fixed pulley:\n1. Axis of rotation is fixed\n2. Attached to a rigid support (ceiling, beam)\n3. Does not move with the load\n4. Only changes direction of force (pull down to lift up)\n5. Mechanical Advantage = 1\n6. Effort moves same distance as load\n7. Used in: Wells, flag poles, curtain rods\n\nSingle movable pulley:\n1. Axis of rotation is not fixed\n2. Not attached to support; moves with load\n3. One end of rope tied to support, load attached to pulley\n4. Changes direction and multiplies force\n5. Mechanical Advantage = 2\n6. Effort moves twice the distance load moves\n7. Used in: Cranes, lifting heavy machinery"
        },
        {
            "type": "subjective",
            "q": "What is a wheel-and-axle arrangement? Give four examples and explain how it works.",
            "sample": "A wheel-and-axle arrangement consists of a wheel attached to a rod called an axle such that when the wheel is made to rotate, the axle also rotates (and vice versa).\n\nWorking principle:\n- When effort is applied to the wheel, it rotates easily and the axle rotates with greater force.\n- The wheel acts as a force multiplier because the radius of the wheel is larger than the radius of the axle.\n- Mechanical advantage = Radius of wheel ÷ Radius of axle.\n\nExamples:\n1. Steering wheel of a car: Turning the large wheel easily rotates the steering column (axle) to turn the wheels.\n2. Door knob: Turning the knob (wheel) rotates the spindle (axle) to operate the latch.\n3. Screwdriver: The handle (wheel) is turned to rotate the shaft (axle) that drives the screw.\n4. Bicycle pedals: Pedal arms (wheels) rotate the crank (axle) to drive the chain.\n5. Spindle tap: The handle (like a wheel) rotates the spindle to control water flow.\n6. Drilling machine: Handle rotates the drill bit."
        },
        {
            "type": "subjective",
            "q": "Mention any three ways by which we can take care of machines.",
            "sample": "Ways to care for machines:\n\n1. Keep machines clean and dry:\n   - Machines should be kept in a clean environment, free from dust and moisture.\n   - When not in use, machines should be kept covered to prevent dust accumulation.\n   - Dust can clog moving parts and cause wear.\n\n2. Protect from rust:\n   - Machines made of iron should be protected from rust by coating them with paint.\n   - Rust weakens the metal and damages the machine.\n   - Store in dry places, away from moisture.\n\n3. Regular lubrication:\n   - The moving parts of a machine should be regularly oiled with good-quality machine oil.\n   - This reduces friction between moving parts.\n   - Less friction means less wear and tear, less heat generation, and smoother operation.\n   - Examples: Oiling bicycle chain, hinges, fans.\n\n4. Handle with care:\n   - Avoid dropping or rough handling.\n   - Use machines only for their intended purpose.\n   - Follow manufacturer's instructions."
        },
        {
            "type": "subjective",
            "q": "If the fulcrum of a crowbar, of total length 150 cm, is at a distance of 25 cm from the load, what is the mechanical advantage of the crowbar?",
            "sample": "Given:\nTotal length of crowbar = 150 cm\nDistance of fulcrum from load (load arm) = 25 cm\n\nTherefore, distance of fulcrum from effort (effort arm) = Total length - Load arm\n= 150 cm - 25 cm = 125 cm\n\nMechanical Advantage = Effort arm ÷ Load arm\n= 125 cm ÷ 25 cm\n= 5\n\nTherefore, the mechanical advantage of the crowbar is 5.\n\nThis means the crowbar multiplies the applied force by 5 times. A person applying 20 N of effort could lift a load of 100 N (20 × 5 = 100)."
        },
        {
            "type": "subjective",
            "q": "A crowbar of length 100 cm is used to lift a load of 50 N. The fulcrum is at a distance of 20 cm from the load. Calculate a. the mechanical advantage of the crowbar b. the effort applied at the other end.",
            "sample": "Given:\nTotal length of crowbar = 100 cm\nDistance of fulcrum from load (load arm) = 20 cm\nLoad = 50 N\n\nStep 1: Find effort arm\nEffort arm = Total length - Load arm\n= 100 cm - 20 cm = 80 cm\n\nStep 2: Calculate Mechanical Advantage\nMA = Effort arm ÷ Load arm\n= 80 cm ÷ 20 cm = 4\n\nStep 3: Calculate Effort required\nUsing MA = Load ÷ Effort\n4 = 50 N ÷ Effort\nEffort = 50 N ÷ 4 = 12.5 N\n\nTherefore:\na. Mechanical Advantage = 4\nb. Effort required = 12.5 N\n\nVerification using lever principle:\nLoad × Load arm = Effort × Effort arm\n50 N × 20 cm = 12.5 N × 80 cm\n1000 = 1000 ✓"
        },
        {
            "type": "subjective",
            "q": "The handle of a nutcracker is 18 cm long and a nut is placed 2 cm from its hinge. If a force of 36 kgf is needed to crack the nut, calculate the force which has to be applied at the end of the handle.",
            "sample": "Given:\nNutcracker is a Class II lever\nLength of handle (effort arm) = 18 cm\nDistance of nut from hinge (load arm) = 2 cm\nForce needed to crack nut (load) = 36 kgf\nEffort to be applied = ?\n\nUsing lever principle:\nLoad × Load arm = Effort × Effort arm\n\n36 kgf × 2 cm = Effort × 18 cm\n72 = Effort × 18\nEffort = 72 ÷ 18 = 4 kgf\n\nTherefore, a force of 4 kgf needs to be applied at the end of the handle.\n\nThis shows the mechanical advantage of the nutcracker:\nMA = Load ÷ Effort = 36 ÷ 4 = 9\nAlso MA = Effort arm ÷ Load arm = 18 ÷ 2 = 9 ✓\n\nThe nutcracker multiplies the applied force by 9 times."
        },
        {
            "type": "subjective",
            "q": "A 12 kgf force is applied on a machine for the movement of a load of 120 kgf. Find the mechanical advantage of the machine.",
            "sample": "Given:\nLoad = 120 kgf\nEffort = 12 kgf\n\nMechanical Advantage = Load ÷ Effort\n= 120 kgf ÷ 12 kgf\n= 10\n\nTherefore, the mechanical advantage of the machine is 10.\n\nThis means the machine multiplies the applied force by 10 times. With an effort of 12 kgf, it can move a load of 120 kgf.\n\nSince MA > 1, this machine acts as a force multiplier, making work easier by reducing the effort needed to move heavy loads."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 6: Light (SET 2)
    # ──────────────────────────────────────────────────────────────────
    "Chapter 6 — Light (Set 2)": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "What is bioluminescence?",
            "options": [
                "Light from the sun",
                "Light produced by living organisms",
                "Light from moon",
                "Artificial light"
            ],
            "answer": "Light produced by living organisms",
            "explanation": "Bioluminescence is light produced by living organisms through chemical reactions."
        },
        {
            "type": "mcq",
            "q": "Which of the following organisms shows bioluminescence?",
            "options": [
                "Eagle",
                "Firefly",
                "Elephant",
                "Tiger"
            ],
            "answer": "Firefly",
            "explanation": "Fireflies produce light from their bodies by chemical reaction."
        },
        {
            "type": "mcq",
            "q": "Where is bioluminescence most commonly found?",
            "options": [
                "Deserts",
                "Forests",
                "Sea (ocean)",
                "Mountains"
            ],
            "answer": "Sea (ocean)",
            "explanation": "Bioluminescence is found mostly in the sea - in fish, jellyfish, squids, and bacteria."
        },
        {
            "type": "mcq",
            "q": "Light can travel through:",
            "options": [
                "Solids only",
                "Liquids only",
                "Gases only",
                "Solids, liquids, gases, and vacuum"
            ],
            "answer": "Solids, liquids, gases, and vacuum",
            "explanation": "Light does not need a material medium; it can travel through vacuum."
        },
        {
            "type": "mcq",
            "q": "The speed of light in vacuum is approximately:",
            "options": [
                "3,00,000 m/s",
                "3,00,000 km/s",
                "3,00,000 km/h",
                "3,00,000 m/h"
            ],
            "answer": "3,00,000 km/s",
            "explanation": "Light travels at about 3,00,000 kilometres per second in vacuum."
        },
        {
            "type": "mcq",
            "q": "The sun is about how far from the earth?",
            "options": [
                "150 lakh km",
                "1500 lakh km",
                "15 lakh km",
                "15000 lakh km"
            ],
            "answer": "1500 lakh km",
            "explanation": "The sun is about 1500 lakh kilometres (150 million km) away from earth."
        },
        {
            "type": "mcq",
            "q": "Light from the sun takes about how long to reach earth?",
            "options": [
                "8 seconds",
                "8 minutes",
                "8 hours",
                "8 days"
            ],
            "answer": "8 minutes",
            "explanation": "Light takes a little more than 8 minutes to travel from sun to earth."
        },
        {
            "type": "mcq",
            "q": "Ground glass is an example of:",
            "options": [
                "Transparent material",
                "Translucent material",
                "Opaque material",
                "Luminous material"
            ],
            "answer": "Translucent material",
            "explanation": "Ground glass allows light to pass through partially, making objects appear hazy."
        },
        {
            "type": "mcq",
            "q": "Cellophane paper is an example of:",
            "options": [
                "Transparent material",
                "Translucent material",
                "Opaque material",
                "Luminous material"
            ],
            "answer": "Transparent material",
            "explanation": "Clear cellophane allows light to pass through completely."
        },
        {
            "type": "mcq",
            "q": "Butter paper is an example of:",
            "options": [
                "Transparent material",
                "Translucent material",
                "Opaque material",
                "Luminous material"
            ],
            "answer": "Translucent material",
            "explanation": "Butter paper allows partial light through, creating a hazy view."
        },
        {
            "type": "mcq",
            "q": "Thick cardboard is an example of:",
            "options": [
                "Transparent material",
                "Translucent material",
                "Opaque material",
                "Luminous material"
            ],
            "answer": "Opaque material",
            "explanation": "Cardboard blocks all light, so it is opaque."
        },
        {
            "type": "mcq",
            "q": "A very thin path of light is called a:",
            "options": [
                "Beam",
                "Ray",
                "Stream",
                "Wave"
            ],
            "answer": "Ray",
            "explanation": "A ray is a very thin path of light."
        },
        {
            "type": "mcq",
            "q": "A bundle of parallel rays is called a:",
            "options": [
                "Convergent beam",
                "Divergent beam",
                "Parallel beam",
                "Mixed beam"
            ],
            "answer": "Parallel beam",
            "explanation": "Parallel beam has rays parallel to each other."
        },
        {
            "type": "mcq",
            "q": "Rays from a distant source like the sun form a:",
            "options": [
                "Convergent beam",
                "Divergent beam",
                "Parallel beam",
                "Mixed beam"
            ],
            "answer": "Parallel beam",
            "explanation": "Due to great distance, sun's rays are nearly parallel."
        },
        {
            "type": "mcq",
            "q": "Rays coming out from a torch form a:",
            "options": [
                "Convergent beam",
                "Divergent beam",
                "Parallel beam",
                "Mixed beam"
            ],
            "answer": "Divergent beam",
            "explanation": "Torch light spreads out, forming a divergent beam."
        },
        {
            "type": "mcq",
            "q": "Rays passing through a convex lens form a:",
            "options": [
                "Convergent beam",
                "Divergent beam",
                "Parallel beam",
                "Mixed beam"
            ],
            "answer": "Convergent beam",
            "explanation": "Convex lens brings rays together to a focus (convergent)."
        },
        {
            "type": "mcq",
            "q": "The size of the image in a pinhole camera depends on:",
            "options": [
                "Size of pinhole only",
                "Distance between screen and pinhole",
                "Colour of object",
                "Brightness of light"
            ],
            "answer": "Distance between screen and pinhole",
            "explanation": "Increasing screen distance increases image size; decreasing it reduces size."
        },
        {
            "type": "mcq",
            "q": "If the screen in a pinhole camera is moved closer to the pinhole, the image becomes:",
            "options": [
                "Larger and brighter",
                "Smaller and brighter",
                "Larger and dimmer",
                "Smaller and dimmer"
            ],
            "answer": "Smaller and brighter",
            "explanation": "Closer screen gives smaller image but light concentrated, so brighter."
        },
        {
            "type": "mcq",
            "q": "If the screen in a pinhole camera is moved away from the pinhole, the image becomes:",
            "options": [
                "Larger and brighter",
                "Larger and dimmer",
                "Smaller and brighter",
                "Smaller and dimmer"
            ],
            "answer": "Larger and dimmer",
            "explanation": "Light spreads over larger area, so image is larger but dimmer."
        },
        {
            "type": "mcq",
            "q": "The image in a pinhole camera is:",
            "options": [
                "Virtual and erect",
                "Real and inverted",
                "Virtual and inverted",
                "Real and erect"
            ],
            "answer": "Real and inverted",
            "explanation": "Image is formed on screen (real) and upside down (inverted)."
        },
        {
            "type": "mcq",
            "q": "A shadow is formed because light:",
            "options": [
                "Bends around objects",
                "Travels in straight lines",
                "Reflects from objects",
                "Is absorbed by objects"
            ],
            "answer": "Travels in straight lines",
            "explanation": "Rectilinear propagation causes shadows when light is blocked."
        },
        {
            "type": "mcq",
            "q": "Which object casts the darkest shadow?",
            "options": [
                "Clear glass",
                "Oiled paper",
                "Wooden board",
                "Frosted glass"
            ],
            "answer": "Wooden board",
            "explanation": "Opaque objects like wood cast dark shadows."
        },
        {
            "type": "mcq",
            "q": "Which object casts a weak shadow?",
            "options": [
                "Clear glass",
                "Wood",
                "Cardboard",
                "Translucent object"
            ],
            "answer": "Translucent object",
            "explanation": "Translucent objects allow some light through, casting weak shadows."
        },
        {
            "type": "mcq",
            "q": "Which object casts no shadow?",
            "options": [
                "Wooden block",
                "Metal sheet",
                "Clear glass",
                "Plastic bottle"
            ],
            "answer": "Clear glass",
            "explanation": "Transparent objects do not cast shadows."
        },
        {
            "type": "mcq",
            "q": "The umbra is the region of:",
            "options": [
                "Partial darkness",
                "Total darkness",
                "Bright light",
                "Coloured light"
            ],
            "answer": "Total darkness",
            "explanation": "Umbra receives no light at all."
        },
        {
            "type": "mcq",
            "q": "The penumbra is the region of:",
            "options": [
                "Total darkness",
                "Partial darkness",
                "Bright light",
                "No light"
            ],
            "answer": "Partial darkness",
            "explanation": "Penumbra receives some light, so it's less dark."
        },
        {
            "type": "mcq",
            "q": "A point source of light produces a shadow with:",
            "options": [
                "Only umbra",
                "Only penumbra",
                "Both umbra and penumbra",
                "No shadow"
            ],
            "answer": "Only umbra",
            "explanation": "Point source gives sharp shadow with only umbra."
        },
        {
            "type": "mcq",
            "q": "An extended source of light produces a shadow with:",
            "options": [
                "Only umbra",
                "Only penumbra",
                "Both umbra and penumbra",
                "No shadow"
            ],
            "answer": "Both umbra and penumbra",
            "explanation": "Extended source creates both dark and partially dark regions."
        },
        {
            "type": "mcq",
            "q": "When the object is larger than the extended light source, the umbra is:",
            "options": [
                "Smaller than object",
                "Larger than object",
                "Same size as object",
                "Absent"
            ],
            "answer": "Larger than object",
            "explanation": "Umbra size > object when object is larger than source."
        },
        {
            "type": "mcq",
            "q": "When the object is smaller than the extended light source, the umbra is:",
            "options": [
                "Larger than object",
                "Smaller than object",
                "Same size as object",
                "Absent"
            ],
            "answer": "Smaller than object",
            "explanation": "Umbra is very small when object is smaller than source."
        },
        {
            "type": "mcq",
            "q": "During a solar eclipse, the _______ comes between the sun and the earth.",
            "options": [
                "Earth",
                "Moon",
                "Mars",
                "Jupiter"
            ],
            "answer": "Moon",
            "explanation": "Moon blocks sunlight from reaching earth during solar eclipse."
        },
        {
            "type": "mcq",
            "q": "During a lunar eclipse, the _______ comes between the sun and the moon.",
            "options": [
                "Earth",
                "Moon",
                "Mars",
                "Venus"
            ],
            "answer": "Earth",
            "explanation": "Earth's shadow falls on the moon during lunar eclipse."
        },
        {
            "type": "mcq",
            "q": "A solar eclipse occurs on a:",
            "options": [
                "Full moon day",
                "New moon day",
                "First day of month",
                "Any day"
            ],
            "answer": "New moon day",
            "explanation": "Moon is between sun and earth on new moon day."
        },
        {
            "type": "mcq",
            "q": "A lunar eclipse occurs on a:",
            "options": [
                "Full moon day",
                "New moon day",
                "First day of month",
                "Any day"
            ],
            "answer": "Full moon day",
            "explanation": "Earth is between sun and moon on full moon day."
        },
        {
            "type": "mcq",
            "q": "During a total solar eclipse, the sun is:",
            "options": [
                "Partially visible",
                "Completely blocked",
                "More bright",
                "Blue in colour"
            ],
            "answer": "Completely blocked",
            "explanation": "Moon completely covers the sun in total solar eclipse."
        },
        {
            "type": "mcq",
            "q": "During an annular solar eclipse, we see:",
            "options": [
                "Only the moon",
                "A bright ring of light (corona)",
                "Complete darkness",
                "The sun normally"
            ],
            "answer": "A bright ring of light (corona)",
            "explanation": "Moon doesn't completely cover sun, leaving a bright ring."
        },
        {
            "type": "mcq",
            "q": "The Samrat Yantra at Jantar Mantar in New Delhi is a giant:",
            "options": [
                "Clock",
                "Sundial",
                "Thermometer",
                "Compass"
            ],
            "answer": "Sundial",
            "explanation": "Samrat Yantra is a 70-foot high giant sundial."
        },
        {
            "type": "mcq",
            "q": "To safely view a solar eclipse, you should use:",
            "options": [
                "Naked eyes",
                "Sunglasses",
                "Pinhole camera or welder's glass",
                "X-ray film only"
            ],
            "answer": "Pinhole camera or welder's glass",
            "explanation": "Direct viewing can damage eyes; pinhole camera projects safe image."
        },
        {
            "type": "mcq",
            "q": "During a total lunar eclipse, the moon appears:",
            "options": [
                "Reddish",
                "Invisible",
                "Blue",
                "Green"
            ],
            "answer": "Invisible",
            "explanation": "Moon is completely in earth's umbra, so no light reaches it."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "The sun and stars are natural luminous objects.",
            "answer": "True",
            "explanation": "They produce their own light naturally."
        },
        {
            "type": "tf",
            "q": "LED bulbs and torches are artificial luminous objects.",
            "answer": "True",
            "explanation": "They are man-made sources of light."
        },
        {
            "type": "tf",
            "q": "The moon is a luminous object.",
            "answer": "False",
            "explanation": "Moon reflects sunlight; it does not produce its own light."
        },
        {
            "type": "tf",
            "q": "Planets are luminous objects.",
            "answer": "False",
            "explanation": "Planets reflect sunlight; they are non-luminous."
        },
        {
            "type": "tf",
            "q": "Jellyfish and squids can show bioluminescence.",
            "answer": "True",
            "explanation": "Many sea creatures exhibit bioluminescence."
        },
        {
            "type": "tf",
            "q": "Light needs a material medium like air to travel.",
            "answer": "False",
            "explanation": "Light can travel through vacuum."
        },
        {
            "type": "tf",
            "q": "Clear water is a transparent material.",
            "answer": "True",
            "explanation": "Light passes through clear water completely."
        },
        {
            "type": "tf",
            "q": "Thin nylon fabric is an example of translucent material.",
            "answer": "True",
            "explanation": "It allows partial light through."
        },
        {
            "type": "tf",
            "q": "A ray of light is a bundle of beams.",
            "answer": "False",
            "explanation": "A ray is a very thin path; a beam is a bundle of rays."
        },
        {
            "type": "tf",
            "q": "A convergent beam has rays spreading out from a point.",
            "answer": "False",
            "explanation": "Convergent beam has rays meeting at a point; divergent beam spreads out."
        },
        {
            "type": "tf",
            "q": "A concave lens produces a convergent beam of light.",
            "answer": "False",
            "explanation": "Concave lens produces divergent beam; convex lens produces convergent."
        },
        {
            "type": "tf",
            "q": "Light travels in straight lines in the same medium.",
            "answer": "True",
            "explanation": "This is rectilinear propagation of light."
        },
        {
            "type": "tf",
            "q": "A pinhole camera produces an erect image.",
            "answer": "False",
            "explanation": "It produces an inverted image."
        },
        {
            "type": "tf",
            "q": "The image in a pinhole camera is real because it is formed on a screen.",
            "answer": "True",
            "explanation": "Real images can be obtained on a screen."
        },
        {
            "type": "tf",
            "q": "The pinhole in a pinhole camera should be very large for clear image.",
            "answer": "False",
            "explanation": "Pinhole should be small (about 2 mm) for sharp image."
        },
        {
            "type": "tf",
            "q": "A shadow shows the colour of the object.",
            "answer": "False",
            "explanation": "Shadows are always black or grey regardless of object's colour."
        },
        {
            "type": "tf",
            "q": "The size of a shadow depends on the distance of object from light source.",
            "answer": "True",
            "explanation": "Closer to light = larger shadow; closer to screen = smaller shadow."
        },
        {
            "type": "tf",
            "q": "A shadow can be formed in air without any screen.",
            "answer": "False",
            "explanation": "A screen (wall, ground) is needed to see the shadow."
        },
        {
            "type": "tf",
            "q": "When an object moves closer to the light source, shadow size decreases.",
            "answer": "False",
            "explanation": "Closer to light source increases shadow size."
        },
        {
            "type": "tf",
            "q": "When an object moves closer to the screen, shadow size decreases.",
            "answer": "True",
            "explanation": "Closer to screen gives smaller, sharper shadow."
        },
        {
            "type": "tf",
            "q": "A point source of light produces shadows with blurred edges.",
            "answer": "False",
            "explanation": "Point source gives sharp edges; extended source gives blurred edges."
        },
        {
            "type": "tf",
            "q": "Stars are point sources of light because they are very far away.",
            "answer": "True",
            "explanation": "Distant stars appear as points of light."
        },
        {
            "type": "tf",
            "q": "The sun is an extended source of light.",
            "answer": "True",
            "explanation": "Sun has a definite size (disc), not a point."
        },
        {
            "type": "tf",
            "q": "During a solar eclipse, the shadow of earth falls on the moon.",
            "answer": "False",
            "explanation": "That's lunar eclipse; solar eclipse has moon's shadow on earth."
        },
        {
            "type": "tf",
            "q": "Only a part of earth gets covered by moon's shadow during solar eclipse.",
            "answer": "True",
            "explanation": "Moon is smaller than earth, so shadow covers only a small area."
        },
        {
            "type": "tf",
            "q": "A total solar eclipse can last for several hours.",
            "answer": "False",
            "explanation": "It lasts only for a minute or two due to moon's motion."
        },
        {
            "type": "tf",
            "q": "The moon moves at about 1 km per second in its orbit.",
            "answer": "True",
            "explanation": "This speed causes the shadow to move quickly."
        },
        {
            "type": "tf",
            "q": "During a partial solar eclipse, the sun is completely blocked.",
            "answer": "False",
            "explanation": "Only part of sun is blocked; rest is visible."
        },
        {
            "type": "tf",
            "q": "A total lunar eclipse occurs when the moon is completely in earth's umbra.",
            "answer": "True",
            "explanation": "No direct sunlight reaches the moon."
        },
        {
            "type": "tf",
            "q": "During a partial lunar eclipse, part of the moon is in umbra and part in penumbra.",
            "answer": "True",
            "explanation": "Only the umbra portion is invisible."
        },
        {
            "type": "tf",
            "q": "Lunar eclipses are more common than solar eclipses.",
            "answer": "True",
            "explanation": "Lunar eclipses can be seen from larger areas of earth."
        },
        {
            "type": "tf",
            "q": "Solar eclipses are safe to view directly with naked eyes.",
            "answer": "False",
            "explanation": "Direct viewing can permanently damage eyes."
        },
        {
            "type": "tf",
            "q": "Smoked glass and X-ray films are safe for viewing solar eclipse.",
            "answer": "False",
            "explanation": "They don't block harmful rays completely; welder's glass is safe."
        },
        {
            "type": "tf",
            "q": "A kitchen sieve can be used to project eclipse images.",
            "answer": "True",
            "explanation": "Holes in sieve act like multiple pinhole cameras."
        },
        {
            "type": "tf",
            "q": "The Samrat Yantra at Jantar Mantar is 70 feet high.",
            "answer": "True",
            "explanation": "It is a giant sundial 70 feet high."
        },
        {
            "type": "tf",
            "q": "During a new moon, the dark side of moon faces earth.",
            "answer": "True",
            "explanation": "This is why we don't see the moon on new moon day."
        },
        {
            "type": "tf",
            "q": "During a full moon, the bright side of moon faces earth.",
            "answer": "True",
            "explanation": "The entire illuminated half faces earth."
        },
        {
            "type": "tf",
            "q": "Eclipses are considered good or bad events according to science.",
            "answer": "False",
            "explanation": "They are purely celestial events with no such significance."
        },
        {
            "type": "tf",
            "q": "The sun is about 400 times farther from earth than the moon.",
            "answer": "True",
            "explanation": "This ratio allows the moon to sometimes completely cover the sun."
        },
        {
            "type": "tf",
            "q": "A shadow can only be formed when the screen is opaque.",
            "answer": "True",
            "explanation": "Screen must be opaque to show the shadow clearly."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "What are luminous and non-luminous objects? Give three examples of each.",
            "sample": "Luminous objects: Objects that give out light of their own. They can be natural or artificial.\nExamples:\n1. Sun (natural)\n2. Stars (natural)\n3. Firefly (natural - bioluminescence)\n4. Lighted candle (artificial)\n5. Electric bulb (artificial)\n6. LED torch (artificial)\n\nNon-luminous objects: Objects that do not emit light of their own. They become visible when light from luminous objects falls on them and gets reflected to our eyes.\nExamples:\n1. Moon (reflects sunlight)\n2. Planets (reflect sunlight)\n3. Book\n4. Table\n5. Trees\n6. Clothes\n\nMost objects around us are non-luminous; we see them due to reflected light."
        },
        {
            "type": "subjective",
            "q": "Explain with examples the three categories of materials based on light transmission.",
            "sample": "Based on how light passes through them, materials are classified into three categories:\n\n1. Transparent materials:\n- Allow light to pass through completely\n- Objects can be seen clearly through them\n- Examples: Clear glass, clear water, air, cellophane paper\n\n2. Translucent materials:\n- Allow light to pass through partially\n- Objects viewed through them appear hazy or blurred\n- Examples: Frosted glass, ground glass, butter paper, thin nylon fabric, oily paper\n\n3. Opaque materials:\n- Do not allow light to pass through at all\n- No objects can be seen through them\n- Examples: Wood, cardboard, thick plastic, metal sheets, stone, brick\n\nNote: Transparent objects cast no shadow, translucent objects cast weak shadows, and opaque objects cast dark shadows."
        },
        {
            "type": "subjective",
            "q": "What are rays and beams of light? Explain the three types of beams with diagrams.",
            "sample": "Ray of light: A very thin path of light along which light travels. It is represented by a straight line with an arrow showing direction.\n\nBeam of light: A bundle of rays of light.\n\nThree types of beams:\n\n1. Parallel beam:\n- Rays are parallel to each other\n- Example: Sunlight reaching earth (from distant source)\n- Diagram: Multiple parallel straight lines with arrows\n\n2. Convergent beam:\n- Rays meet at a point (converge)\n- Example: Light passing through a convex lens\n- Diagram: Rays coming together at a focus point\n\n3. Divergent beam:\n- Rays spread out from a point (diverge)\n- Example: Light from a torch, candle, or point source\n- Diagram: Rays originating from a point and spreading outward"
        },
        {
            "type": "subjective",
            "q": "Describe an experiment to show that light travels in a straight line.",
            "sample": "Aim: To demonstrate rectilinear propagation of light\n\nMaterials: Three rectangular cardboards with a hole at the centre of each, a candle, a wooden base, clay to fix cardboards\n\nProcedure:\n1. Fix the three cardboards upright on the wooden base using clay, arranging them in a straight line.\n2. Ensure the holes are at the same height and aligned in a straight line.\n3. Place a burning candle behind the third cardboard, at the same height as the holes.\n4. Look through the hole of the first cardboard. You will see the candle flame clearly.\n5. Now displace the middle cardboard slightly to the side so the holes are no longer in a straight line.\n6. Look through the first hole again.\n\nObservation:\n- In step 4, the flame is clearly visible.\n- In step 6, the flame is not visible; only the cardboard is seen.\n\nConclusion:\n- Light travels in straight lines. When the holes are aligned, light from the candle passes through all holes and reaches the eye.\n- When the middle cardboard is displaced, the straight path is blocked, and light cannot reach the eye.\n- This proves rectilinear propagation of light."
        },
        {
            "type": "subjective",
            "q": "Explain the working of a pinhole camera with a labeled diagram.",
            "sample": "A pinhole camera is a simple device that works on the principle of rectilinear propagation of light.\n\nConstruction:\n- A cardboard box (like a shoebox) painted black inside\n- One side has a small pinhole (about 2 mm diameter)\n- Opposite side has a screen of butter paper or tracing paper\n- The inside is black to prevent unwanted reflections\n\nWorking:\n1. Light rays from the object travel in straight lines in all directions.\n2. Rays from the top of the object pass through the pinhole and hit the bottom of the screen.\n3. Rays from the bottom of the object pass through the pinhole and hit the top of the screen.\n4. All rays between these points form corresponding points on the screen.\n5. This creates a complete but inverted image of the object on the screen.\n\nCharacteristics of image:\n- Real (formed on screen)\n- Inverted (upside down)\n- Size depends on distance between pinhole and screen\n- Not very bright\n- Colours are preserved"
        },
        {
            "type": "subjective",
            "q": "How does the size of the image in a pinhole camera change with the distance between pinhole and screen?",
            "sample": "The size of the image in a pinhole camera depends on the distance between the pinhole and the screen:\n\n1. When screen is moved closer to the pinhole:\n   - Image size decreases\n   - Image becomes brighter (light concentrated over smaller area)\n   - Image becomes sharper\n\n2. When screen is moved farther from the pinhole:\n   - Image size increases\n   - Image becomes dimmer (light spreads over larger area)\n   - Image may become blurred if screen is too far\n\nReason:\n- Light rays from each point of the object diverge after passing through the pinhole.\n- The farther the screen, the more the rays spread out before hitting it.\n- This creates a larger but dimmer image.\n\n3. The size also depends on object distance:\n   - Object closer to pinhole gives larger image\n   - Object farther gives smaller image\n\nThe optimal distance gives a clear, reasonably sized image."
        },
        {
            "type": "subjective",
            "q": "What is a shadow? What are the conditions required for shadow formation?",
            "sample": "A shadow is a dark area formed when an opaque object is placed between a source of light and a screen, blocking the path of light.\n\nConditions required for shadow formation:\n\n1. A source of light:\n   - There must be a luminous object emitting light\n   - Can be natural (sun) or artificial (torch, bulb)\n\n2. An opaque object:\n   - The object must be opaque (blocks light completely)\n   - Translucent objects cast weak shadows; transparent objects cast no shadow\n   - The object must be placed in the path of light\n\n3. A screen:\n   - There must be a surface to receive the shadow\n   - Screen can be a wall, ground, cardboard, or any opaque surface\n   - Shadow cannot be seen in air without a screen\n\n4. Proper positioning:\n   - Object must be between light source and screen\n   - Distance affects shadow size and sharpness\n\nWithout any of these conditions, a shadow cannot be formed."
        },
        {
            "type": "subjective",
            "q": "Explain the characteristics of a shadow.",
            "sample": "Characteristics of a shadow:\n\n1. Colour:\n   - Shadow is always dark (black or grey)\n   - Does not show the colour of the object\n   - Colour of object doesn't affect shadow colour\n\n2. Shape:\n   - May or may not look like the actual shape of the object\n   - Shape changes with orientation of object and light source\n   - Rotating object changes shadow shape\n\n3. Size:\n   - Depends on distance of object from light source\n   - Closer to light source = larger shadow\n   - Closer to screen = smaller shadow\n   - Also depends on distance of screen\n\n4. Sharpness:\n   - Shadow becomes darker with sharp edges when object is closer to screen\n   - Shadow becomes grayish with blurred edges when object is closer to light source\n   - Point source gives sharp shadow; extended source gives blurred edges\n\n5. Screen requirement:\n   - Shadow can only be formed on a screen\n   - Screen should not be too far from object\n\n6. Object type:\n   - Opaque objects cast dark shadows\n   - Translucent objects cast weak shadows\n   - Transparent objects cast no shadows"
        },
        {
            "type": "subjective",
            "q": "Explain the terms umbra and penumbra with the help of diagrams.",
            "sample": "A shadow generally consists of two regions:\n\nUmbra:\n- The central dark region of the shadow\n- Region of total darkness\n- No light from the source reaches this region\n- Formed when the light source is completely blocked\n\nPenumbra:\n- The outer less dark region surrounding the umbra\n- Region of partial darkness\n- Some light from parts of the source reaches this region\n- Formed around the umbra when the light source is extended\n\nFormation depends on:\n1. Size of light source (point vs extended)\n2. Distance between object and screen\n\nPoint source: Produces only umbra (sharp shadow)\nExtended source: Produces both umbra and penumbra (blurred edges)\n\nWhen object is larger than extended source: Umbra is larger than object\nWhen object is smaller than extended source: Umbra is smaller than object\n\nAs screen moves away: Both umbra and penumbra increase in size; umbra may disappear if screen is very far."
        },
        {
            "type": "subjective",
            "q": "Differentiate between a point source and an extended source of light with examples.",
            "sample": "Point source of light:\n- A source that has negligible extent or size\n- Can be a very small source or a large source at great distance\n- Produces sharp shadows with only umbra (no penumbra)\n- Rays from point source form a divergent beam\n- Examples: Light from a pinhole, stars (distant suns), a small LED at a distance\n\nExtended source of light:\n- A source that has a definite size or extent\n- Consists of many point sources spread over an area\n- Produces shadows with both umbra and penumbra\n- Shadows have blurred edges\n- Examples: Sun (has a disc), torch beam, tube light, candle flame, fluorescent lamp\n\nComparison:\n- Point source: Single point of origin; sharp shadows\n- Extended source: Multiple points of origin; shadows with umbra and penumbra\n- The size of the source affects the characteristics of shadows formed"
        },
        {
            "type": "subjective",
            "q": "What is a solar eclipse? Explain the different types of solar eclipses.",
            "sample": "A solar eclipse occurs when the moon comes between the sun and the earth, casting its shadow on the earth. The part of earth covered by the moon's shadow becomes dark during daytime.\n\nTypes of solar eclipses:\n\n1. Total solar eclipse:\n   - Moon completely blocks the sun\n   - Occurs when earth falls in the umbra region of moon's shadow\n   - Sun is completely hidden\n   - Lasts only for a minute or two\n   - Visible from a small area on earth\n\n2. Partial solar eclipse:\n   - Moon partially blocks the sun\n   - Occurs when earth falls in the penumbra region of moon's shadow\n   - Only part of sun is covered; rest is visible\n   - Visible from a larger area around the path of totality\n\n3. Annular solar eclipse:\n   - Occurs when moon is farther from earth and appears smaller\n   - Moon does not completely cover the sun\n   - A bright ring of light (corona) is visible around the moon\n   - Looks like a diamond ring in the sky\n\nSolar eclipse occurs only on a new moon day when the dark side of moon faces earth."
        },
        {
            "type": "subjective",
            "q": "What is a lunar eclipse? Explain the different types of lunar eclipses.",
            "sample": "A lunar eclipse occurs when the earth comes between the sun and the moon, casting its shadow on the moon. The moon becomes invisible or partially visible for some time.\n\nTypes of lunar eclipses:\n\n1. Total lunar eclipse:\n   - Moon lies completely in the umbra of earth's shadow\n   - No direct sunlight reaches the moon\n   - Moon becomes completely invisible\n   - Can last for over an hour\n   - Visible from anywhere on the night side of earth\n\n2. Partial lunar eclipse:\n   - Only part of moon lies in earth's umbra\n   - Part of moon in umbra is invisible\n   - Part in penumbra is visible but less bright\n   - Moon appears as if a bite has been taken out of it\n\n3. Penumbral lunar eclipse:\n   - Moon lies only in earth's penumbra\n   - Moon receives some sunlight, so it's visible but dimmer than normal\n   - Often hard to notice\n\nSequence during total lunar eclipse:\nMoon enters penumbra → enters umbra (partial) → completely in umbra (total) → exits umbra (partial) → exits penumbra\n\nLunar eclipse occurs only on a full moon day when the bright side of moon faces earth."
        },
        {
            "type": "subjective",
            "q": "Why does the moon appear reddish during a total lunar eclipse sometimes?",
            "sample": "During a total lunar eclipse, the moon sometimes appears reddish or coppery in colour instead of becoming completely invisible. This happens due to the following reasons:\n\n1. Earth's atmosphere bends (refracts) some sunlight:\n   - When the moon is in earth's umbra, no direct sunlight reaches it.\n   - However, some sunlight passing through earth's atmosphere gets bent (refracted) and falls on the moon.\n\n2. Scattering of light:\n   - Earth's atmosphere scatters shorter wavelengths (blue light) more than longer wavelengths (red light).\n   - This is the same reason sunsets appear red.\n   - The blue light is scattered away, while red light passes through.\n\n3. The refracted red light reaches the moon:\n   - This red light illuminates the moon faintly.\n   - The moon reflects this red light back to earth.\n\nResult:\n- Instead of disappearing completely, the moon appears reddish or coppery.\n- The exact colour depends on atmospheric conditions (dust, clouds, pollution).\n- This phenomenon is why total lunar eclipses are sometimes called 'Blood Moons'."
        },
        {
            "type": "subjective",
            "q": "Why can't we see the shadow of an aeroplane flying high in the sky?",
            "sample": "We cannot see the shadows of high-flying aeroplanes for several reasons:\n\n1. Shadow is too faint (penumbra dominates):\n   - The sun is an extended source of light, not a point source.\n   - When the object is far from the ground, the penumbra region becomes very large.\n   - The umbra (dark part) may disappear completely.\n   - What reaches the ground is mostly penumbra, which is not dark enough to notice.\n\n2. Shadow is too large and diffuse:\n   - The shadow spreads over a very large area.\n   - The contrast between shadow and surroundings is very low.\n   - It's like a very faint, large dark patch that's hard to distinguish.\n\n3. Atmospheric scattering:\n   - Sunlight is scattered by the atmosphere, reducing shadow contrast.\n   - Light comes from all directions (sky light), filling in shadows.\n\n4. Object is moving fast:\n   - The shadow moves quickly across the ground.\n   - It's gone before we can notice it.\n\n5. Cloud interference:\n   - The shadow may fall on clouds instead of ground.\n\nLow-flying aircraft can cast visible shadows, but high-flying ones usually cannot."
        },
        {
            "type": "subjective",
            "q": "What precautions should be taken while viewing a solar eclipse?",
            "sample": "Viewing a solar eclipse requires special precautions because looking directly at the sun can cause permanent eye damage or blindness.\n\nSafe methods:\n\n1. Pinhole projector:\n   - Make a pinhole in a cardboard sheet\n   - Stand with your back to the sun\n   - Project the sun's image onto another paper or ground\n   - View the projected image, NOT the sun directly\n   - Multiple holes give multiple images\n\n2. Kitchen sieve method:\n   - Hold a kitchen sieve with back to the sun\n   - Hold a white paper below it\n   - Each hole projects an eclipse image on the paper\n\n3. Welder's glass (shade 14 or higher):\n   - This is safe for direct viewing\n   - Blocks harmful rays effectively\n\n4. Certified solar filters:\n   - Special eclipse glasses with ISO certification\n   - Must be undamaged and used properly\n\nUnsafe methods (DO NOT USE):\n- Naked eyes (most dangerous)\n- Sunglasses (do not block harmful rays)\n- Smoked glass (unsafe, can crack)\n- X-ray films (do not block infrared rays)\n- Exposed photographic film (unsafe)\n- Binoculars or telescopes without filters (extremely dangerous)\n\nNote: It is safe to look directly only during the brief total phase of a total solar eclipse, but you must know exactly when it starts and ends."
        },
        {
            "type": "subjective",
            "q": "Describe the construction and working of a pinhole camera. How can you make one at home?",
            "sample": "A pinhole camera is a simple device that works on the principle of rectilinear propagation of light.\n\nConstruction (how to make at home):\n\nMaterials needed:\n- A cardboard shoebox (or any cardboard box)\n- Black water colour or black paper\n- Butter paper or tracing paper\n- Sellotape (adhesive tape)\n- A pair of scissors\n- A pin or needle\n\nSteps:\n1. Paint the inside of the box black (or line with black paper). This prevents reflections.\n2. Remove one side of the box completely.\n3. Cover this open side with butter paper using sellotape. This will be the screen.\n4. On the opposite side, make a small hole (about 2 mm diameter) using a pin. This is the pinhole.\n5. Place the lid on the box and fix it with tape. Your pinhole camera is ready!\n\nWorking:\n1. Point the pinhole towards a bright object (like a candle or a tree outside).\n2. An inverted image of the object will appear on the butter paper screen.\n3. The image is real and inverted.\n4. Moving the screen changes image size.\n\nTips:\n- Works best in a dimly lit room\n- The smaller the pinhole, the sharper but dimmer the image\n- The camera should be light-tight except for the pinhole"
        },
        {
            "type": "subjective",
            "q": "Differentiate between a solar eclipse and a lunar eclipse.",
            "sample": "Differences between solar eclipse and lunar eclipse:\n\n| Aspect | Solar Eclipse | Lunar Eclipse |\n|--------|---------------|---------------|\n| Position | Moon between sun and earth | Earth between sun and moon |\n| Shadow | Moon's shadow falls on earth | Earth's shadow falls on moon |\n| Time of occurrence | New moon day | Full moon day |\n| Visibility | Visible only from small area on earth | Visible from entire night side of earth |\n| Duration | Short (few minutes) | Longer (can be over an hour) |\n| Frequency | Less frequent at a given location | More frequent globally |\n| Appearance | Sun appears covered | Moon appears dark or reddish |\n| Safety | Dangerous to view directly | Safe to view directly |\n| Types | Total, partial, annular | Total, partial, penumbral |\n| Celestial alignment | Sun - Moon - Earth | Sun - Earth - Moon |\n\nSimilarities:\n- Both occur due to rectilinear propagation of light\n- Both involve shadows (umbra and penumbra)\n- Both are predictable celestial events"
        },
        {
            "type": "subjective",
            "q": "Why does the sun appear to rise in the east and set in the west? Explain using the concept of light.",
            "sample": "The sun appears to rise in the east and set in the west due to the rotation of the earth on its axis, combined with the rectilinear propagation of light.\n\nExplanation:\n\n1. Earth rotates from west to east:\n   - The earth spins on its axis from west to east.\n   - This rotation takes about 24 hours (one day).\n\n2. Light travels in straight lines from the sun:\n   - Sunlight reaches earth in straight lines.\n   - As earth rotates, different parts face the sun.\n\n3. Apparent motion of sun:\n   - When our location on earth rotates to face the sun, we see sunrise in the east.\n   - As earth continues rotating, the sun appears to move across the sky.\n   - When our location rotates away from the sun, we see sunset in the west.\n\nAnalogy:\n- Imagine standing on a rotating platform with a stationary light source.\n- As you rotate, the light appears to move across your field of vision.\n- Similarly, earth's rotation creates the apparent motion of the sun.\n\nThis demonstrates that the apparent motion is due to earth's rotation, not the sun moving around earth."
        },
        {
            "type": "subjective",
            "q": "Why are shadows black in colour regardless of the object's colour?",
            "sample": "Shadows are always black or grey regardless of the object's colour because:\n\n1. Shadow is absence of light:\n   - A shadow is formed when an opaque object blocks light.\n   - The shadow region receives no light from the source.\n   - Where there is no light, we perceive darkness (black).\n\n2. Colour depends on reflected light:\n   - An object's colour is determined by which wavelengths of light it reflects.\n   - A red object reflects red light and absorbs others.\n   - But a shadow region has no light to reflect.\n   - With no reflected light entering our eyes, we see darkness.\n\n3. No relation to object's colour:\n   - The shadow is cast by the object, but it doesn't inherit the object's properties.\n   - The shadow is simply the absence of light in that area.\n   - Whether the object is red, blue, or green, its shadow is always dark.\n\n4. Exceptions (not really shadows):\n   - If light passes through a coloured transparent object, the area may get coloured light.\n   - But that's not a true shadow; it's coloured illumination.\n\nTherefore, shadows are always black/dark because they are regions where light is absent."
        },
    ],

    # ──────────────────────────────────────────────────────────────────
    # CHAPTER 7: Magnetism (SET 2)
    # ──────────────────────────────────────────────────────────────────
    "Chapter 7 — Magnetism (Set 2)": [
        # ===== MCQ (40 questions) =====
        {
            "type": "mcq",
            "q": "The word 'magnet' comes from the name of a place called:",
            "options": [
                "Magnetite",
                "Magnesia in Greece",
                "Madagascar",
                "Magnetic Island"
            ],
            "answer": "Magnesia in Greece",
            "explanation": "Magnets were discovered in Magnesia, Greece, and named after the place."
        },
        {
            "type": "mcq",
            "q": "According to Greek legend, who discovered magnets?",
            "options": [
                "A shepherd named Magnes",
                "A scientist named Magnet",
                "A king named Magnus",
                "A philosopher named Aristotle"
            ],
            "answer": "A shepherd named Magnes",
            "explanation": "Legend says a shepherd named Magnes discovered magnetite when his staff stuck to a rock."
        },
        {
            "type": "mcq",
            "q": "The natural magnetic rock is called:",
            "options": [
                "Magnetite or lodestone",
                "Granite",
                "Limestone",
                "Sandstone"
            ],
            "answer": "Magnetite or lodestone",
            "explanation": "Lodestone (magnetite) is a naturally occurring magnetic rock."
        },
        {
            "type": "mcq",
            "q": "The word 'lodestone' means:",
            "options": [
                "Magnetic rock",
                "Leading stone",
                "Heavy stone",
                "Iron stone"
            ],
            "answer": "Leading stone",
            "explanation": "Lodestone was used as a primitive compass because it pointed north, so it was called 'leading stone'."
        },
        {
            "type": "mcq",
            "q": "Which of the following is NOT a magnetic substance?",
            "options": [
                "Iron",
                "Nickel",
                "Cobalt",
                "Aluminium"
            ],
            "answer": "Aluminium",
            "explanation": "Aluminium is non-magnetic, while iron, nickel, and cobalt are magnetic."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a magnetic substance?",
            "options": [
                "Copper",
                "Brass",
                "Steel",
                "Zinc"
            ],
            "answer": "Steel",
            "explanation": "Steel contains iron, so it is magnetic."
        },
        {
            "type": "mcq",
            "q": "Which of the following is an alloy used for making permanent magnets?",
            "options": [
                "Brass",
                "Bronze",
                "ALNICO",
                "Solder"
            ],
            "answer": "ALNICO",
            "explanation": "ALNICO (aluminium, nickel, cobalt) is used for permanent magnets."
        },
        {
            "type": "mcq",
            "q": "In a bar magnet, magnetic strength is maximum at the:",
            "options": [
                "Centre",
                "Poles",
                "All points equally",
                "One-fourth from ends"
            ],
            "answer": "Poles",
            "explanation": "Magnetic strength is concentrated at the poles (ends)."
        },
        {
            "type": "mcq",
            "q": "In a bar magnet, magnetic strength is minimum at the:",
            "options": [
                "Poles",
                "Centre",
                "One end",
                "None of these"
            ],
            "answer": "Centre",
            "explanation": "At the centre, magnetic strength is practically zero."
        },
        {
            "type": "mcq",
            "q": "If a bar magnet is suspended freely, it aligns in which direction?",
            "options": [
                "East-west",
                "North-south",
                "North-east",
                "South-west"
            ],
            "answer": "North-south",
            "explanation": "This is the directive property of magnets."
        },
        {
            "type": "mcq",
            "q": "The end of a freely suspended magnet that points towards geographical north is called:",
            "options": [
                "South pole",
                "North pole",
                "East pole",
                "West pole"
            ],
            "answer": "North pole",
            "explanation": "The north-seeking pole is called the north pole."
        },
        {
            "type": "mcq",
            "q": "The end of a freely suspended magnet that points towards geographical south is called:",
            "options": [
                "North pole",
                "South pole",
                "East pole",
                "West pole"
            ],
            "answer": "South pole",
            "explanation": "The south-seeking pole is called the south pole."
        },
        {
            "type": "mcq",
            "q": "When the north pole of one magnet is brought near the north pole of another magnet, they:",
            "options": [
                "Attract",
                "Repel",
                "Have no effect",
                "Become stronger"
            ],
            "answer": "Repel",
            "explanation": "Like poles repel each other."
        },
        {
            "type": "mcq",
            "q": "When the north pole of one magnet is brought near the south pole of another magnet, they:",
            "options": [
                "Attract",
                "Repel",
                "Have no effect",
                "Become weaker"
            ],
            "answer": "Attract",
            "explanation": "Unlike poles attract each other."
        },
        {
            "type": "mcq",
            "q": "If a bar magnet is broken into three pieces, how many magnetic poles will there be in total?",
            "options": [
                "2",
                "3",
                "4",
                "6"
            ],
            "answer": "6",
            "explanation": "Each piece becomes a complete magnet with two poles, so 3 pieces have 6 poles."
        },
        {
            "type": "mcq",
            "q": "The surest test of magnetism is:",
            "options": [
                "Attraction",
                "Repulsion",
                "Heating",
                "Hammering"
            ],
            "answer": "Repulsion",
            "explanation": "Only magnets repel each other; attraction can happen with magnetic materials too."
        },
        {
            "type": "mcq",
            "q": "A magnetic compass works on which property of magnets?",
            "options": [
                "Attractive property",
                "Directive property",
                "Repulsive property",
                "Inductive property"
            ],
            "answer": "Directive property",
            "explanation": "Compass uses the property that a magnet points north-south."
        },
        {
            "type": "mcq",
            "q": "The magnetic field is a region where a magnet exerts its:",
            "options": [
                "Weight",
                "Force",
                "Mass",
                "Temperature"
            ],
            "answer": "Force",
            "explanation": "Magnetic field is where magnetic force can be experienced."
        },
        {
            "type": "mcq",
            "q": "Magnetic lines of force outside a magnet run from:",
            "options": [
                "North to south",
                "South to north",
                "East to west",
                "Centre to poles"
            ],
            "answer": "North to south",
            "explanation": "Outside magnet, lines go from N to S; inside, from S to N."
        },
        {
            "type": "mcq",
            "q": "Magnetic lines of force inside a magnet run from:",
            "options": [
                "North to south",
                "South to north",
                "East to west",
                "Poles to centre"
            ],
            "answer": "South to north",
            "explanation": "Inside the magnet, lines complete the loop from S to N."
        },
        {
            "type": "mcq",
            "q": "Where is the magnetic field strongest around a bar magnet?",
            "options": [
                "At the centre",
                "Near the poles",
                "Far away",
                "Equally everywhere"
            ],
            "answer": "Near the poles",
            "explanation": "Field is strongest where lines are most dense - near poles."
        },
        {
            "type": "mcq",
            "q": "The earth's magnetic south pole is located near the:",
            "options": [
                "Geographical North Pole",
                "Geographical South Pole",
                "Equator",
                "Tropic of Cancer"
            ],
            "answer": "Geographical North Pole",
            "explanation": "Earth's magnetic south pole is near geographical north, which attracts compass north."
        },
        {
            "type": "mcq",
            "q": "The earth's magnetic north pole is located near the:",
            "options": [
                "Geographical North Pole",
                "Geographical South Pole",
                "Equator",
                "Tropic of Capricorn"
            ],
            "answer": "Geographical South Pole",
            "explanation": "Earth's magnetic north pole is near geographical south."
        },
        {
            "type": "mcq",
            "q": "The angle between geographical axis and magnetic axis of earth is about:",
            "options": [
                "5°",
                "11°",
                "23.5°",
                "90°"
            ],
            "answer": "11°",
            "explanation": "The magnetic axis is inclined at about 11° to the geographical axis."
        },
        {
            "type": "mcq",
            "q": "Which of the following is a temporary magnet?",
            "options": [
                "Steel bar magnet",
                "ALNICO magnet",
                "Electromagnet",
                "Lodestone"
            ],
            "answer": "Electromagnet",
            "explanation": "Electromagnets work only when current flows, so they are temporary."
        },
        {
            "type": "mcq",
            "q": "Soft iron is used for making electromagnets because it:",
            "options": [
                "Retains magnetism permanently",
                "Loses magnetism quickly when current stops",
                "Is cheap",
                "Is heavy"
            ],
            "answer": "Loses magnetism quickly when current stops",
            "explanation": "Soft iron gets magnetized quickly and loses magnetism just as quickly."
        },
        {
            "type": "mcq",
            "q": "Steel is used for making permanent magnets because it:",
            "options": [
                "Loses magnetism quickly",
                "Retains magnetism for a long time",
                "Is non-magnetic",
                "Is light"
            ],
            "answer": "Retains magnetism for a long time",
            "explanation": "Steel has high retentivity, so it makes good permanent magnets."
        },
        {
            "type": "mcq",
            "q": "In the single-touch method of magnetization, how many magnets are used?",
            "options": [
                "One",
                "Two",
                "Three",
                "Four"
            ],
            "answer": "One",
            "explanation": "Single-touch method uses one bar magnet."
        },
        {
            "type": "mcq",
            "q": "In the double-touch method of magnetization, how many magnets are used?",
            "options": [
                "One",
                "Two",
                "Three",
                "Four"
            ],
            "answer": "Two",
            "explanation": "Double-touch method uses two bar magnets with opposite poles together."
        },
        {
            "type": "mcq",
            "q": "Magnetic induction produces:",
            "options": [
                "Permanent magnets",
                "Temporary magnets",
                "Electromagnets",
                "No magnetism"
            ],
            "answer": "Temporary magnets",
            "explanation": "Induction creates temporary magnetism that lasts only near the magnet."
        },
        {
            "type": "mcq",
            "q": "An iron nail becomes a magnet when brought near a bar magnet. This is due to:",
            "options": [
                "Single-touch method",
                "Double-touch method",
                "Magnetic induction",
                "Heating"
            ],
            "answer": "Magnetic induction",
            "explanation": "Induction magnetizes without contact, just by being in the magnetic field."
        },
        {
            "type": "mcq",
            "q": "An electromagnet's strength can be increased by:",
            "options": [
                "Using a weaker battery",
                "Decreasing the number of turns",
                "Increasing the current",
                "Using a plastic core"
            ],
            "answer": "Increasing the current",
            "explanation": "More current = stronger magnetic field."
        },
        {
            "type": "mcq",
            "q": "Which of the following will NOT demagnetize a magnet?",
            "options": [
                "Heating",
                "Hammering",
                "Dropping",
                "Storing with a keeper"
            ],
            "answer": "Storing with a keeper",
            "explanation": "Keepers prevent demagnetization; the others demagnetize."
        },
        {
            "type": "mcq",
            "q": "A magnetic keeper is made of:",
            "options": [
                "Steel",
                "Soft iron",
                "Copper",
                "Aluminium"
            ],
            "answer": "Soft iron",
            "explanation": "Soft iron keepers complete the magnetic circuit and prevent self-demagnetization."
        },
        {
            "type": "mcq",
            "q": "To store bar magnets, they should be placed with:",
            "options": [
                "Like poles together",
                "Opposite poles together",
                "Any poles together",
                "Separately without touching"
            ],
            "answer": "Opposite poles together",
            "explanation": "Opposite poles with keepers between them prevents loss of magnetism."
        },
        {
            "type": "mcq",
            "q": "How many keepers are needed for a horseshoe magnet?",
            "options": [
                "One",
                "Two",
                "Three",
                "Four"
            ],
            "answer": "One",
            "explanation": "One keeper across the poles of a horseshoe magnet is sufficient."
        },
        {
            "type": "mcq",
            "q": "Magnets are used in speakers and microphones because they:",
            "options": [
                "Produce sound",
                "Convert electrical signals to sound",
                "Amplify sound",
                "Record sound"
            ],
            "answer": "Convert electrical signals to sound",
            "explanation": "Magnets in speakers move the diaphragm to produce sound."
        },
        {
            "type": "mcq",
            "q": "Credit cards and ATM cards have:",
            "options": [
                "Bar magnets inside",
                "Magnetic strips",
                "Electromagnets",
                "No magnetic material"
            ],
            "answer": "Magnetic strips",
            "explanation": "Magnetic strips store information on these cards."
        },
        {
            "type": "mcq",
            "q": "Computer hard disks store information using:",
            "options": [
                "Electric charges",
                "Magnetic materials",
                "Laser beams",
                "Heat"
            ],
            "answer": "Magnetic materials",
            "explanation": "Hard disks use magnetic coatings to store data."
        },
        
        # ===== True/False (40 questions) =====
        {
            "type": "tf",
            "q": "Magnets were discovered about 4000 years ago in Greece.",
            "answer": "True",
            "explanation": "According to legend, magnets were discovered around 2000 BCE in Magnesia."
        },
        {
            "type": "tf",
            "q": "Lodestone is an artificial magnet.",
            "answer": "False",
            "explanation": "Lodestone is a natural magnet found in nature."
        },
        {
            "type": "tf",
            "q": "Ancient sailors used lodestone as a primitive compass.",
            "answer": "True",
            "explanation": "Lodestone's directive property helped in navigation."
        },
        {
            "type": "tf",
            "q": "A magnet can attract paper and plastic.",
            "answer": "False",
            "explanation": "Magnets only attract magnetic substances like iron, nickel, cobalt."
        },
        {
            "type": "tf",
            "q": "All metals are attracted by magnets.",
            "answer": "False",
            "explanation": "Only iron, nickel, cobalt and their alloys are magnetic; metals like copper, gold, silver are not."
        },
        {
            "type": "tf",
            "q": "Stainless steel is magnetic because it contains iron.",
            "answer": "True",
            "explanation": "Most stainless steel contains iron, so it is magnetic."
        },
        {
            "type": "tf",
            "q": "A magnet has the same strength at all points.",
            "answer": "False",
            "explanation": "Strength is maximum at poles, minimum at centre."
        },
        {
            "type": "tf",
            "q": "If a magnet is suspended freely, it always points north-south.",
            "answer": "True",
            "explanation": "This is the directive property of magnets."
        },
        {
            "type": "tf",
            "q": "The north pole of a magnet points towards geographical south.",
            "answer": "False",
            "explanation": "North pole points towards geographical north."
        },
        {
            "type": "tf",
            "q": "Like poles attract each other.",
            "answer": "False",
            "explanation": "Like poles repel; unlike poles attract."
        },
        {
            "type": "tf",
            "q": "Unlike poles repel each other.",
            "answer": "False",
            "explanation": "Unlike poles attract; like poles repel."
        },
        {
            "type": "tf",
            "q": "A magnet can have a single isolated pole.",
            "answer": "False",
            "explanation": "Magnetic poles always exist in pairs; isolated poles do not exist."
        },
        {
            "type": "tf",
            "q": "If a magnet is broken, each piece becomes a complete magnet with both poles.",
            "answer": "True",
            "explanation": "Each fragment has its own north and south poles."
        },
        {
            "type": "tf",
            "q": "Attraction is the surest test of magnetism.",
            "answer": "False",
            "explanation": "Repulsion is the surest test because only magnets repel."
        },
        {
            "type": "tf",
            "q": "A magnetic compass has a small magnetic needle balanced on a pivot.",
            "answer": "True",
            "explanation": "This is the correct construction of a compass."
        },
        {
            "type": "tf",
            "q": "In a compass, the north pole of the needle is marked with red colour.",
            "answer": "True",
            "explanation": "Red typically indicates north on a compass needle."
        },
        {
            "type": "tf",
            "q": "Magnetic lines of force are closed curves.",
            "answer": "True",
            "explanation": "They form continuous loops from N to S outside and S to N inside."
        },
        {
            "type": "tf",
            "q": "Magnetic lines of force can intersect each other.",
            "answer": "False",
            "explanation": "They never intersect; if they did, it would indicate two directions of field at one point."
        },
        {
            "type": "tf",
            "q": "Crowded magnetic lines indicate a weak magnetic field.",
            "answer": "False",
            "explanation": "Crowded lines indicate strong field; spread-out lines indicate weak field."
        },
        {
            "type": "tf",
            "q": "The earth's magnetic field is the reason a compass works.",
            "answer": "True",
            "explanation": "Earth behaves like a giant magnet, causing compass needles to align."
        },
        {
            "type": "tf",
            "q": "The magnetic axis of earth coincides exactly with its geographical axis.",
            "answer": "False",
            "explanation": "They are inclined at about 11° to each other."
        },
        {
            "type": "tf",
            "q": "An iron rod buried in the north-south direction gets magnetized over time.",
            "answer": "True",
            "explanation": "Earth's magnetic field can slowly magnetize iron along its direction."
        },
        {
            "type": "tf",
            "q": "Temporary magnets retain their magnetism permanently.",
            "answer": "False",
            "explanation": "Temporary magnets lose magnetism quickly when magnetizing force is removed."
        },
        {
            "type": "tf",
            "q": "Permanent magnets are made of materials like steel and ALNICO.",
            "answer": "True",
            "explanation": "These materials retain magnetism well."
        },
        {
            "type": "tf",
            "q": "Electromagnets are permanent magnets.",
            "answer": "False",
            "explanation": "Electromagnets are temporary; they work only when current flows."
        },
        {
            "type": "tf",
            "q": "The core of an electromagnet is made of soft iron.",
            "answer": "True",
            "explanation": "Soft iron loses magnetism quickly when current stops."
        },
        {
            "type": "tf",
            "q": "In the single-touch method, the magnet is slid back and forth along the needle.",
            "answer": "False",
            "explanation": "It is slid in one direction only and lifted at the end."
        },
        {
            "type": "tf",
            "q": "In the double-touch method, two magnets with opposite poles together are used.",
            "answer": "True",
            "explanation": "They are placed with opposite poles together and moved apart."
        },
        {
            "type": "tf",
            "q": "Magnetic induction requires physical contact between the magnet and the object.",
            "answer": "False",
            "explanation": "Induction works without contact, just by bringing the magnet near."
        },
        {
            "type": "tf",
            "q": "An iron nail can pick up paper clips when a magnet is brought near it due to induction.",
            "answer": "True",
            "explanation": "The nail becomes a temporary magnet by induction."
        },
        {
            "type": "tf",
            "q": "Hans Christian Oersted discovered that electric current produces a magnetic field.",
            "answer": "True",
            "explanation": "Oersted's experiment showed the connection between electricity and magnetism."
        },
        {
            "type": "tf",
            "q": "Heating a magnet strengthens it.",
            "answer": "False",
            "explanation": "Heating destroys the alignment of magnetic domains and demagnetizes it."
        },
        {
            "type": "tf",
            "q": "Hammering a magnet repeatedly can demagnetize it.",
            "answer": "True",
            "explanation": "Mechanical shock disrupts magnetic domain alignment."
        },
        {
            "type": "tf",
            "q": "Dropping a magnet from a height can weaken it.",
            "answer": "True",
            "explanation": "The impact disturbs the magnetic domains."
        },
        {
            "type": "tf",
            "q": "Self-demagnetization occurs when magnets are stored without keepers.",
            "answer": "True",
            "explanation": "Magnets gradually lose strength over time if not stored properly."
        },
        {
            "type": "tf",
            "q": "A magnetic keeper is a soft iron bar used to store magnets.",
            "answer": "True",
            "explanation": "Keepers prevent self-demagnetization by completing the magnetic circuit."
        },
        {
            "type": "tf",
            "q": "Magnets are used in electric bells and motors.",
            "answer": "True",
            "explanation": "Electromagnets are essential components in these devices."
        },
        {
            "type": "tf",
            "q": "Doctors use magnets to remove iron splinters from eyes.",
            "answer": "True",
            "explanation": "Small magnets are used in eye surgery to remove metallic particles."
        },
        {
            "type": "tf",
            "q": "Refrigerator doors use magnets to close tightly.",
            "answer": "True",
            "explanation": "Magnetic strips in the door seal keep it closed."
        },
        {
            "type": "tf",
            "q": "Horseshoe magnets are weaker than bar magnets.",
            "answer": "False",
            "explanation": "Horseshoe magnets are stronger because the poles are close together."
        },
        
        # ===== Subjective (20 questions) =====
        {
            "type": "subjective",
            "q": "Write a short note on the discovery of magnets.",
            "sample": "Discovery of magnets:\n\nAccording to Greek legend, about 4000 years ago, there was a shepherd named Magnes in an area of northern Greece called Magnesia.\n\nOne day while herding his sheep, he suddenly noticed that the nails in his shoes and the metal tip of his stick got stuck to a large black stone on which he was standing. This rock had the property of attracting iron.\n\nLater, many such rocks were found in the same area. The rock was given the name 'magnetite' in honour of the place Magnesia and the shepherd Magnes.\n\nPeople later discovered that when a needle-shaped piece of magnetite was floated in water, one of its ends always pointed towards the north. So it was used as a primitive compass by ancient sailors and was also given the name 'lodestone' or 'leading stone'.\n\nThis discovery led to the study of magnetism and the development of artificial magnets for various uses."
        },
        {
            "type": "subjective",
            "q": "What are natural and artificial magnets? Give examples.",
            "sample": "Natural magnets:\n- Naturally occurring rocks that have magnetic properties\n- Found in nature, not made by humans\n- Example: Lodestone or magnetite\n- Not very strong, rarely used today\n- Historically important for discovery of magnetism\n\nArtificial magnets:\n- Magnets made by humans from magnetic materials\n- Can be made in various shapes and sizes for different purposes\n- Stronger than natural magnets\n- Can be permanent or temporary\n\nCommon shapes of artificial magnets:\n1. Bar magnets - rectangular bars with poles at ends\n2. Horseshoe magnets - U-shaped, stronger than bar magnets\n3. Disc magnets - circular flat magnets\n4. Ring magnets - circular with hole in centre\n5. Cylindrical magnets - rod-shaped\n6. Magnetic needles - used in compasses\n\nExamples: Refrigerator magnets, compass needles, magnets in speakers, electromagnets in cranes."
        },
        {
            "type": "subjective",
            "q": "Explain the attractive property of magnets with an activity.",
            "sample": "The attractive property of magnets is their ability to attract magnetic substances like iron, nickel, and cobalt.\n\nActivity to demonstrate attractive property:\n\nMaterials: A bar magnet, iron nails, copper coins, aluminium foil, paper clips, plastic pieces, wooden block\n\nProcedure:\n1. Place all the objects on a table.\n2. Bring the magnet close to each object one by one.\n3. Observe which objects are attracted to the magnet.\n\nObservations:\n- Iron nails and paper clips are attracted and stick to the magnet.\n- Copper coins, aluminium foil, plastic pieces, and wooden block are not attracted.\n\nConclusion:\n- Magnets attract only magnetic substances (iron, steel, nickel, cobalt).\n- Non-magnetic substances like copper, aluminium, plastic, wood are not attracted.\n- The force of attraction is called magnetic force.\n- The region around the magnet where this force can be felt is the magnetic field.\n- Attraction is maximum at the poles of the magnet."
        },
        {
            "type": "subjective",
            "q": "Explain the directive property of magnets with an activity.",
            "sample": "The directive property of magnets states that a freely suspended magnet always comes to rest pointing in the geographical north-south direction.\n\nActivity to demonstrate directive property:\n\nMaterials: A bar magnet, a thread, a stand\n\nProcedure:\n1. Tie a thread to the centre of the bar magnet so it balances horizontally.\n2. Suspend the magnet from the stand using the thread.\n3. Allow the magnet to come to rest.\n4. Mark the direction it points on the ground or base.\n5. Gently disturb the magnet and let it come to rest again.\n\nObservations:\n- Each time the magnet comes to rest, it points in the same direction.\n- Using a compass, we can confirm this direction is north-south.\n- The end pointing north is the north pole; the end pointing south is the south pole.\n\nConclusion:\n- A freely suspended magnet always aligns in the north-south direction.\n- This happens because the earth itself behaves like a huge bar magnet.\n- This property is used in magnetic compasses for navigation."
        },
        {
            "type": "subjective",
            "q": "Explain the law of magnetic poles with an activity.",
            "sample": "The law of magnetic poles states: Like poles repel each other, unlike poles attract each other.\n\nActivity to demonstrate:\n\nMaterials: Two bar magnets with marked poles, a stand, thread\n\nProcedure:\n1. Suspend one magnet from the stand using thread.\n2. Bring the north pole of the second magnet near the north pole of the suspended magnet.\n   Observation: They repel each other (the suspended magnet moves away).\n3. Bring the north pole near the south pole of the suspended magnet.\n   Observation: They attract each other (the suspended magnet moves towards).\n4. Bring the south pole near the south pole of the suspended magnet.\n   Observation: They repel each other.\n5. Bring the south pole near the north pole of the suspended magnet.\n   Observation: They attract each other.\n\nConclusion:\n- North pole repels north pole (like poles repel)\n- South pole repels south pole (like poles repel)\n- North pole attracts south pole (unlike poles attract)\n- South pole attracts north pole (unlike poles attract)\n\nThis is the fundamental law of magnetism and is used in many applications."
        },
        {
            "type": "subjective",
            "q": "Why is repulsion considered the surest test of magnetism? Explain with an activity.",
            "sample": "Repulsion is considered the surest test of magnetism because attraction can occur between a magnet and a magnetic material, but repulsion only occurs between two magnets (like poles repel).\n\nActivity to demonstrate why repulsion is the surest test:\n\nMaterials: An unknown metallic bar, a known bar magnet, an iron nail\n\nProcedure:\n\nStep 1: Bring the magnet near one end of the metallic bar.\n- If attracted: The bar could be a magnetic material OR a magnet with opposite pole facing.\n- If repelled: The bar is definitely a magnet (sure test).\n\nStep 2: If attracted, bring the other pole of the magnet near the same end.\n- If attracted again: The bar is not a magnet (just magnetic material).\n- If repelled now: The bar is a magnet (shows like poles repel).\n\nWhy attraction is not a sure test:\n- A magnet attracts iron nails (magnetic material).\n- A magnet also attracts the opposite pole of another magnet.\n- So if an object is attracted, it could be either a magnet or just iron.\n\nWhy repulsion is a sure test:\n- Only magnets repel each other (like poles).\n- Magnetic materials are never repelled by magnets.\n- So if an object repels a known magnet, it must itself be a magnet."
        },
        {
            "type": "subjective",
            "q": "What is magnetic field? How can you demonstrate it using iron filings?",
            "sample": "Magnetic field is the region around a magnet within which its magnetic force can be experienced by other magnets or magnetic materials.\n\nDemonstration using iron filings:\n\nMaterials: A bar magnet, a sheet of white paper, iron filings\n\nProcedure:\n1. Place the sheet of paper on a wooden table.\n2. Place the bar magnet in the middle of the paper.\n3. Sprinkle iron filings evenly around the magnet.\n4. Gently tap the paper.\n\nObservation:\n- The iron filings arrange themselves in a pattern of curved lines.\n- The lines are most concentrated near the poles.\n- The pattern shows the shape of the magnetic field.\n\nExplanation:\n- Each iron filing becomes a tiny magnet by induction and aligns along the magnetic field lines.\n- The curved lines are called magnetic lines of force.\n- They show the direction of the magnetic field at each point.\n- Dense lines near poles indicate strong field; sparse lines away from poles indicate weaker field.\n\nProperties shown:\n- Lines run from north pole to south pole outside the magnet.\n- They are continuous curves.\n- They never intersect."
        },
        {
            "type": "subjective",
            "q": "How can you plot the magnetic lines of force of a bar magnet using a compass?",
            "sample": "To plot magnetic lines of force using a compass:\n\nMaterials: Bar magnet, white paper, drawing board, magnetic compass, pencil\n\nProcedure:\n\n1. Fix the paper on the drawing board. Place the magnet in the middle and draw its outline.\n\n2. Place the compass near the north pole of the magnet. Mark the positions of the compass needle ends as dots 1 and 2.\n\n3. Move the compass so that the south end of the needle is exactly over dot 2. Mark the new north end as dot 3.\n\n4. Continue this process, moving the compass step by step, always placing the south end over the last dot and marking the new north end.\n\n5. When you reach the south pole of the magnet, stop. Join all the dots with a smooth curve. This is one magnetic line of force.\n\n6. Repeat the process starting from different points near the north pole to get multiple lines.\n\nObservations:\n- You get a pattern of curved lines around the magnet.\n- Lines start from north pole and end at south pole.\n- Lines are closer near the poles (strong field) and spread out away from magnet (weak field).\n- Lines never intersect.\n\nThis method demonstrates the direction of magnetic field at every point."
        },
        {
            "type": "subjective",
            "q": "Explain the concept of earth as a magnet. Why does a compass needle point north?",
            "sample": "Earth behaves as a huge bar magnet with its magnetic poles near the geographical poles.\n\nKey points:\n\n1. Earth's magnetic field:\n   - The earth has its own magnetic field, like a giant bar magnet inside it.\n   - This field extends into space and affects magnetic materials on earth.\n\n2. Location of magnetic poles:\n   - Earth's magnetic south pole is located near the geographical North Pole.\n   - Earth's magnetic north pole is located near the geographical South Pole.\n   - The magnetic axis is inclined at about 11° to the geographical axis.\n\n3. Why compass points north:\n   - A compass needle is a small magnet with its own north and south poles.\n   - The north pole of the compass needle is attracted to the earth's magnetic south pole.\n   - Since earth's magnetic south pole is near geographical north, the compass north points to geographical north.\n\n4. Proof:\n   - An iron rod buried in the north-south direction gets magnetized over time due to earth's field.\n   - This shows that earth's magnetic field is real and strong enough to magnetize iron.\n\nThis property has been used for navigation for centuries."
        },
        {
            "type": "subjective",
            "q": "Differentiate between temporary and permanent magnets with examples.",
            "sample": "Differences between temporary and permanent magnets:\n\n| Aspect | Temporary Magnet | Permanent Magnet |\n|--------|------------------|------------------|\n| Definition | Magnets that retain magnetic property for short duration | Magnets that retain magnetic property for long time |\n| Magnetism | Present only under influence of magnetizing force | Present permanently without external influence |\n| Material | Soft iron, electromagnets | Steel, ALNICO, cobalt, nickel |\n| Retention | Loses magnetism quickly when force removed | Retains magnetism even after force removed |\n| Strength | Can be very strong when current flows | Fixed strength, may weaken over time |\n| Control | Can be switched on/off (electromagnets) | Cannot be switched off |\n| Examples | Electromagnet, iron nail near magnet | Bar magnet, horseshoe magnet, refrigerator magnet |\n| Uses | Cranes, electric bells, motors, relays | Compasses, speakers, motors, toys |\n\nTemporary magnets (electromagnets) are useful when we need to control magnetism, like in cranes picking up and dropping scrap metal. Permanent magnets are useful when we need constant magnetism, like in compasses."
        },
        {
            "type": "subjective",
            "q": "Describe the single-touch method of magnetizing an iron needle.",
            "sample": "Single-touch method is a simple way to magnetize a magnetic substance using one bar magnet.\n\nMaterials: An iron needle, a bar magnet\n\nProcedure:\n\n1. Place the iron needle on a wooden surface.\n2. Mark one pole of the bar magnet with chalk (say north pole).\n3. Place this marked pole on one end of the needle.\n4. Slowly slide the magnet along the needle from one end to the other, always moving in the same direction.\n5. When you reach the other end, lift the magnet vertically upwards (do not slide it back).\n6. Bring the magnet back to the starting end and repeat the process.\n7. Continue this about 30-40 times.\n\nObservation:\n- The needle becomes magnetized and can attract small iron pins.\n\nResult:\n- The end where the magnet started becomes the same pole as the pole used for stroking.\n- The other end becomes the opposite pole.\n\nPrecautions:\n- Always stroke in the same direction.\n- Lift the magnet at the end; don't slide it back.\n- Repeat many times for stronger magnetization.\n\nThis method produces a permanent magnet, though not as strong as those made by other methods."
        },
        {
            "type": "subjective",
            "q": "Describe the double-touch method of magnetizing an iron needle.",
            "sample": "Double-touch method uses two bar magnets to magnetize an iron needle, producing stronger magnetization than single-touch method.\n\nMaterials: Two identical bar magnets, an iron needle\n\nProcedure:\n\n1. Place the iron needle on a wooden surface.\n2. Take the two bar magnets and place them with opposite poles together near the middle of the needle.\n   (Example: North pole of first magnet and south pole of second magnet together)\n3. Gently slide the magnets in opposite directions along the needle - one towards one end, the other towards the other end.\n4. Maintain contact with the needle throughout the stroke.\n5. When you reach the ends, lift both magnets vertically upwards.\n6. Bring them back to the middle and repeat the process.\n7. Continue for several strokes.\n\nObservation:\n- The needle becomes magnetized and can attract iron pins strongly.\n\nResult:\n- The end stroked by the north pole becomes south pole, and vice versa.\n- The magnetization is stronger than single-touch method.\n\nAdvantages over single-touch:\n- Stronger magnetization\n- More uniform magnetic properties\n- Faster process\n\nThis method is often used in school laboratories to make magnets."
        },
        {
            "type": "subjective",
            "q": "What is magnetic induction? Explain with an activity.",
            "sample": "Magnetic induction is the process by which a magnetic substance becomes a temporary magnet when placed in the magnetic field of another magnet, without any physical contact.\n\nActivity to demonstrate magnetic induction:\n\nMaterials: A bar magnet, an iron nail, some iron paper clips\n\nProcedure:\n\nStep 1: Place the iron nail on a stand and bring some iron paper clips near it.\nObservation: The paper clips are not attracted to the nail.\n\nStep 2: Bring the bar magnet close to (but not touching) the top end of the iron nail.\nObservation: The iron paper clips get attracted to the bottom of the nail and stick to it.\n\nStep 3: Remove the bar magnet.\nObservation: The paper clips fall off.\n\nExplanation:\n- When the magnet is brought near, the iron nail becomes a temporary magnet by induction.\n- The end near the magnet becomes opposite pole (attracted).\n- The far end becomes same pole (repelling for magnet but attracting paper clips).\n- The nail acts as a magnet only while the bar magnet is near.\n- When the magnet is removed, the nail loses its magnetism.\n\nConclusion:\n- Magnetic induction produces temporary magnetism.\n- No physical contact is needed.\n- The effect lasts only in the presence of the magnetizing force."
        },
        {
            "type": "subjective",
            "q": "How can you make an electromagnet? What factors affect its strength?",
            "sample": "An electromagnet is a temporary magnet made by passing electric current through a coil of wire wound around a soft iron core.\n\nHow to make an electromagnet:\n\nMaterials:\n- A large iron nail (soft iron core)\n- Insulated copper wire (about 1-2 metres long)\n- A battery (4.5V or 6V)\n- A switch\n- Iron pins or paper clips\n\nProcedure:\n1. Leave about 15 cm of wire free at one end, then wind the wire tightly around the nail in many turns (at least 50 turns).\n2. Leave another 15 cm free at the other end.\n3. Connect the free ends of the wire to the battery through the switch.\n4. Close the switch to allow current to flow.\n5. Bring the nail near iron pins.\n\nObservation:\n- The pins are attracted to the nail, showing it has become a magnet.\n- When the switch is opened (current stops), the pins fall off.\n\nFactors affecting strength of electromagnet:\n1. Number of turns in the coil: More turns = stronger magnet\n2. Amount of current: More current = stronger magnet\n3. Nature of core: Soft iron gives strongest temporary magnetism\n4. Length and thickness of wire: Affects resistance and current\n\nApplications: Cranes, electric bells, motors, relays, speakers"
        },
        {
            "type": "subjective",
            "q": "What is the difference between a permanent magnet and an electromagnet?",
            "sample": "Differences between permanent magnet and electromagnet:\n\n| Aspect | Permanent Magnet | Electromagnet |\n|--------|------------------|---------------|\n| Magnetism | Permanent (always magnetic) | Temporary (only when current flows) |\n| Material | Steel, ALNICO, cobalt | Soft iron core with copper coil |\n| Control | Cannot be switched on/off | Can be switched on/off easily |\n| Strength | Fixed, cannot be changed | Can be varied by changing current |\n| Poles | Fixed, cannot be reversed | Can be reversed by reversing current |\n| Power source | No electricity needed | Requires electric current |\n| Retention | Retains magnetism | Loses magnetism when current stops |\n| Cost | Cheaper for small sizes | More expensive due to wire and power |\n| Lifespan | Very long if stored properly | Coils may burn out over time |\n| Examples | Bar magnet, horseshoe magnet | Crane magnets, electric bell magnets |\n| Applications | Compass, toys, speakers | Cranes, motors, generators, relays |\n\nBoth have their own advantages: permanent magnets are useful where constant magnetism is needed without power; electromagnets are useful where controlled magnetism is required."
        },
        {
            "type": "subjective",
            "q": "How can a magnet be demagnetized? What are the methods?",
            "sample": "Demagnetization is the process of making a magnet lose its magnetic properties. A magnet can be demagnetized in several ways:\n\n1. Heating:\n   - When a magnet is heated to a very high temperature (above its Curie point), the thermal energy disturbs the alignment of magnetic domains.\n   - The atoms vibrate so much that they lose their magnetic alignment.\n   - Example: Heating a red-hot magnet destroys its magnetism permanently.\n\n2. Hammering or mechanical shock:\n   - Repeated hammering or dropping from height disrupts the alignment of domains.\n   - The mechanical energy randomizes the domain orientation.\n   - Example: Hammering a magnet repeatedly will weaken it.\n\n3. Rough handling:\n   - Dropping a magnet several times on the floor can demagnetize it.\n   - The impact shocks disturb the magnetic alignment.\n\n4. Passing alternating current:\n   - Passing AC through a coil around the magnet creates a rapidly changing magnetic field.\n   - This randomizes the domain alignment.\n\n5. Storing improperly:\n   - Self-demagnetization occurs over time if magnets are not stored with keepers.\n   - Opposite poles should be together to complete the magnetic circuit.\n\nNote: Once demagnetized, a magnet can be remagnetized by the same methods used to make magnets initially."
        },
        {
            "type": "subjective",
            "q": "How should magnets be stored? Why is proper storage important?",
            "sample": "Proper storage of magnets is essential to prevent self-demagnetization and maintain their strength.\n\nStorage methods:\n\nFor bar magnets:\n1. Place two bar magnets side by side with their opposite poles at the same end.\n   (North of one next to south of the other)\n2. Place soft iron keepers across the ends of the pair.\n3. The keepers complete the magnetic circuit, preventing loss of magnetism.\n\nFor horseshoe magnets:\n1. Place a single soft iron keeper across the poles (between north and south).\n2. This completes the magnetic circuit.\n\nWhy proper storage is important:\n\n1. Prevents self-demagnetization:\n   - Magnets left without keepers gradually lose strength over time.\n   - The magnetic field lines prefer to pass through air, causing gradual demagnetization.\n\n2. Maintains magnetic strength:\n   - Keepers provide a low-resistance path for magnetic lines.\n   - This preserves the alignment of magnetic domains.\n\n3. Prevents mutual interference:\n   - When multiple magnets are stored together without proper arrangement, their fields interact.\n   - This can weaken all of them over time.\n\n4. Protects from mechanical damage:\n   - Proper storage prevents magnets from banging into each other.\n   - This avoids demagnetization from mechanical shock."
        },
        {
            "type": "subjective",
            "q": "List five important uses of magnets in daily life.",
            "sample": "Magnets have numerous applications in our daily life:\n\n1. Magnetic compass:\n   - Uses directive property of magnets for navigation\n   - Helps sailors, hikers, and travelers find directions\n   - Essential for maps and orientation\n\n2. Refrigerator doors:\n   - Magnetic strips in door seals keep the door tightly closed\n   - Allows door to open easily but stay shut when closed\n   - Also used for decorative magnets to hold notes\n\n3. Speakers and microphones:\n   - Magnets convert electrical signals to sound in speakers\n   - In microphones, they convert sound to electrical signals\n   - Used in headphones, mobile phones, televisions\n\n4. Electric motors and generators:\n   - Motors use magnets to convert electrical energy to motion\n   - Generators use magnets to convert motion to electricity\n   - Found in fans, washing machines, cars, toys\n\n5. Data storage:\n   - Computer hard disks use magnetic coatings to store data\n   - Credit/debit cards have magnetic strips on the back\n   - Audio and video tapes use magnetic particles\n\n6. Medical uses:\n   - Doctors use small magnets to remove iron splinters from eyes\n   - MRI machines use powerful magnets for body scanning\n\n7. Industrial uses:\n   - Electromagnets in cranes lift heavy iron and steel objects\n   - Separate iron from scrap metal in recycling plants\n   - In mining to separate iron ores"
        },
        {
            "type": "subjective",
            "q": "Explain why magnetic poles always exist in pairs. What happens when a magnet is broken?",
            "sample": "Magnetic poles always exist in pairs because magnetism is a property of aligned domains throughout the material, not something that can be isolated at one point.\n\nExplanation:\n\n1. Magnetic domains:\n   - A magnet consists of many tiny regions called magnetic domains.\n   - Each domain behaves like a tiny magnet with north and south poles.\n   - In a magnet, all these domains are aligned in the same direction.\n\n2. Breaking a magnet:\n   - When you break a magnet, you are separating it into two pieces.\n   - Each piece still contains aligned domains.\n   - The domains in each piece reorganize to form their own north and south poles.\n\n3. Result of breaking:\n   - Each piece becomes a complete magnet with its own north and south poles.\n   - No matter how small the pieces are, each fragment has both poles.\n   - You can never get a piece with only one pole (monopole).\n\nExample:\n- Take a bar magnet with N at left and S at right.\n- Break it into three pieces.\n- Left piece: N at left, new S at right\n- Middle piece: new N at left, new S at right\n- Right piece: new N at left, S at right\n- Total poles: 6 (3 pieces × 2 poles each)\n\nThis proves that magnetic poles are inseparable and always exist in pairs."
        },
    ],
}