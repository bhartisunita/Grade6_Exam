import sys
import json
import os
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QScrollArea, QMessageBox, QGridLayout
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

from questions_db import QUESTIONS

TOPIC_COLORS = [
    "#1A7A6E",
    "#1A5276",
    "#6E2C00",
    "#145A32",
    "#4A235A",
]

TOPIC_ICONS = {
    "Elements & Compounds":        "⚗️",
    "Mixtures & Their Separation": "🔬",
    "Matter":                      "🧲",
    "Water":                       "💧",
    "Air & Atmosphere":            "🌬️",
}

SAVE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "progress.json")
TOPIC_LIST = list(QUESTIONS.keys())


def build_flat():
    flat = []
    for i, topic in enumerate(TOPIC_LIST):
        for q in QUESTIONS[topic]:
            flat.append({**q, "topic": topic, "topic_idx": i})
    return flat


ALL_FLAT = build_flat()


def load_progress():
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE) as f:
                return json.load(f)
        except:
            pass
    return {}


def save_progress(data):
    try:
        with open(SAVE_FILE, "w") as f:
            json.dump(data, f)
    except:
        pass


class QuestionBlock(QPushButton):
    def __init__(self, number, parent=None):
        super().__init__(str(number), parent)
        self.number = number
        self.setFixedSize(34, 34)
        self.setCursor(Qt.PointingHandCursor)
        self._state = "unattempted"
        self._current = False
        self._apply_style()

    def set_state(self, state, current=False):
        self._state = state
        self._current = current
        self._apply_style()

    def _apply_style(self):
        colors = {
            "unattempted": ("#BDC3C7", "#2C3E50"),
            "correct":     ("#1E8449", "#FFFFFF"),
            "wrong":       ("#C0392B", "#FFFFFF"),
            "subjective":  ("#B7950B", "#FFFFFF"),
        }
        bg, fg = colors.get(self._state, colors["unattempted"])
        border = "2px solid #F0F3F4" if self._current else "1px solid transparent"
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg};
                color: {fg};
                border-radius: 5px;
                font-size: 10px;
                font-weight: bold;
                font-family: 'Segoe UI';
                border: {border};
            }}
            QPushButton:hover {{ border: 2px solid #ECF0F1; }}
        """)


class RightPanel(QWidget):
    def __init__(self, on_jump, parent=None):
        super().__init__(parent)
        self.on_jump = on_jump
        self.blocks = {}
        self.setFixedWidth(285)
        self.setStyleSheet("background-color: #1C2833;")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 8, 6, 8)
        outer.setSpacing(6)

        hdr = QLabel("📊  Progress Tracker")
        hdr.setAlignment(Qt.AlignCenter)
        hdr.setStyleSheet("color: #FFFFFF; font-size: 13px; font-weight: bold; "
                          "font-family: 'Segoe UI'; background: #2C3E50; "
                          "border-radius: 6px; padding: 6px;")
        outer.addWidget(hdr)

        leg = QWidget()
        leg.setStyleSheet("background: transparent;")
        ll = QHBoxLayout(leg)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(4)
        for bg, fg, txt in [("#BDC3C7", "#2C3E50", "New"), ("#1E8449", "white", "✓ OK"),
                             ("#C0392B", "white", "✗ Wrong"), ("#B7950B", "white", "✎ Sub")]:
            d = QLabel(txt)
            d.setFixedHeight(18)
            d.setAlignment(Qt.AlignCenter)
            d.setStyleSheet(f"background:{bg}; color:{fg}; border-radius:4px; "
                            f"font-size:10px; font-weight:bold; padding: 0 4px;")
            ll.addWidget(d)
        outer.addWidget(leg)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("""
            QScrollArea { border: none; background: transparent; }
            QScrollBar:vertical { background: #2C3E50; width: 5px; border-radius: 2px; }
            QScrollBar::handle:vertical { background: #5D6D7E; border-radius: 2px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        """)

        content = QWidget()
        content.setStyleSheet("background: transparent;")
        cl = QVBoxLayout(content)
        cl.setContentsMargins(2, 2, 2, 2)
        cl.setSpacing(6)

        q_num = 1
        for t_idx, topic in enumerate(TOPIC_LIST):
            color = TOPIC_COLORS[t_idx % len(TOPIC_COLORS)]
            lbl = QLabel(f"{TOPIC_ICONS.get(topic, '📚')} {topic}")
            lbl.setWordWrap(True)
            lbl.setStyleSheet(f"background-color:{color}; color:white; font-size:10px; "
                              f"font-weight:bold; font-family:'Segoe UI'; "
                              f"border-radius:5px; padding:4px 6px;")
            cl.addWidget(lbl)

            gw = QWidget()
            gw.setStyleSheet("background: transparent;")
            grid = QGridLayout(gw)
            grid.setContentsMargins(0, 0, 0, 0)
            grid.setSpacing(3)

            count = len(QUESTIONS[topic])
            for j in range(count):
                blk = QuestionBlock(q_num)
                blk.clicked.connect(lambda _, n=q_num - 1: self.on_jump(n))
                self.blocks[q_num] = blk
                grid.addWidget(blk, j // 6, j % 6)
                q_num += 1

            cl.addWidget(gw)

        cl.addStretch()
        scroll.setWidget(content)
        outer.addWidget(scroll, 1)

    def refresh(self, answered, current_idx):
        for n, blk in self.blocks.items():
            idx = n - 1
            s = answered.get(str(idx))
            if not s:
                state = "unattempted"
            elif s.get("type") == "subjective":
                state = "subjective"
            else:
                state = "correct" if s.get("correct") else "wrong"
            blk.set_state(state, current=(idx == current_idx))


class QuestionCard(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.on_answer = None
        self.current_idx = None
        self.current_q = None
        self.setStyleSheet("background-color: #FDFEFE;")
        self._build()

    def _build(self):
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(28, 20, 28, 20)
        self.root.setSpacing(14)

        self.top_bar = QWidget()
        tbl = QHBoxLayout(self.top_bar)
        tbl.setContentsMargins(14, 8, 14, 8)
        self.topic_lbl = QLabel()
        self.topic_lbl.setStyleSheet("color:white; font-size:13px; font-weight:bold; "
                                     "font-family:'Segoe UI'; background:transparent;")
        self.qnum_lbl = QLabel()
        self.qnum_lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.qnum_lbl.setStyleSheet("color:rgba(255,255,255,0.85); font-size:12px; "
                                    "font-family:'Segoe UI'; background:transparent;")
        tbl.addWidget(self.topic_lbl)
        tbl.addStretch()
        tbl.addWidget(self.qnum_lbl)
        self.root.addWidget(self.top_bar)

        self.badge = QLabel()
        self.badge.setFixedHeight(26)
        br = QHBoxLayout()
        br.addWidget(self.badge)
        br.addStretch()
        self.root.addLayout(br)

        self.q_lbl = QLabel()
        self.q_lbl.setWordWrap(True)
        self.q_lbl.setStyleSheet("font-size:15px; font-weight:bold; color:#1C2833; "
                                 "font-family:'Segoe UI';")
        self.root.addWidget(self.q_lbl)

        self.dyn_widget = QWidget()
        self.dyn_widget.setStyleSheet("background:transparent;")
        self.dyn_layout = QVBoxLayout(self.dyn_widget)
        self.dyn_layout.setContentsMargins(0, 0, 0, 0)
        self.dyn_layout.setSpacing(8)
        self.root.addWidget(self.dyn_widget)

        self.exp_box = QWidget()
        self.exp_box.setStyleSheet("background:#EBF5FB; border-radius:10px; "
                                   "border-left:4px solid #2E86C1;")
        ebl = QHBoxLayout(self.exp_box)
        ebl.setContentsMargins(12, 10, 12, 10)
        self.exp_icon = QLabel("💡")
        self.exp_text = QLabel()
        self.exp_text.setWordWrap(True)
        self.exp_text.setStyleSheet("font-size:12px; color:#1A5276; "
                                    "font-family:'Segoe UI'; background:transparent;")
        ebl.addWidget(self.exp_icon)
        ebl.addWidget(self.exp_text, 1)
        self.exp_box.hide()
        self.root.addWidget(self.exp_box)

        self.samp_box = QWidget()
        self.samp_box.setStyleSheet("background:#EAFAF1; border-radius:10px; "
                                    "border-left:4px solid #1E8449;")
        sbl = QVBoxLayout(self.samp_box)
        sbl.setContentsMargins(12, 10, 12, 10)
        sh = QLabel("📋  Sample Answer:")
        sh.setStyleSheet("font-weight:bold; color:#1E8449; font-size:12px; background:transparent;")
        self.samp_text = QLabel()
        self.samp_text.setWordWrap(True)
        self.samp_text.setStyleSheet("font-size:12px; color:#1C2833; "
                                     "font-family:'Segoe UI'; background:transparent;")
        sbl.addWidget(sh)
        sbl.addWidget(self.samp_text)
        self.samp_box.hide()
        self.root.addWidget(self.samp_box)

        self.root.addStretch()

    def _clear_dyn(self):
        while self.dyn_layout.count():
            item = self.dyn_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.exp_box.hide()
        self.samp_box.hide()

    def load(self, q, idx, answered, on_answer):
        self.current_q = q
        self.current_idx = idx
        self.on_answer = on_answer
        self._clear_dyn()

        t_idx = q["topic_idx"]
        color = TOPIC_COLORS[t_idx % len(TOPIC_COLORS)]
        self.top_bar.setStyleSheet(f"background-color:{color}; border-radius:10px;")
        icon = TOPIC_ICONS.get(q["topic"], "📚")
        self.topic_lbl.setText(f"{icon}  {q['topic']}")
        self.qnum_lbl.setText(f"Q {idx + 1}  of  {len(ALL_FLAT)}")

        type_cfg = {
            "mcq":        ("#1F618D", "Multiple Choice"),
            "tf":         ("#6C3483", "True / False"),
            "subjective": ("#B7950B", "Subjective ✍️"),
        }
        bg, lbl_txt = type_cfg.get(q["type"], ("#555", "Question"))
        self.badge.setText(f"  {lbl_txt}  ")
        self.badge.setStyleSheet(f"background-color:{bg}; color:white; border-radius:6px; "
                                 f"padding:2px 12px; font-size:11px; font-weight:bold; "
                                 f"font-family:'Segoe UI';")
        self.q_lbl.setText(q["q"])

        if q["type"] == "mcq":
            self._mcq(q, answered)
        elif q["type"] == "tf":
            self._tf(q, answered)
        else:
            self._subjective(q, answered)

    def _mcq(self, q, answered):
        for i, opt in enumerate(q["options"]):
            letter = ["a", "b", "c", "d"][i]
            btn = QPushButton(f"  {letter})  {opt}")
            btn.setCursor(Qt.PointingHandCursor)
            btn.setMinimumHeight(40)
            if answered:
                btn.setEnabled(False)
                if opt == q["answer"]:
                    btn.setStyleSheet(
                        "QPushButton { background-color:#D5F5E3; color:#1E8449; font-weight:bold; "
                        "border:2px solid #1E8449; border-radius:8px; font-size:13px; "
                        "font-family:'Segoe UI'; text-align:left; padding:8px; }")
                elif answered.get("selected") == opt:
                    btn.setStyleSheet(
                        "QPushButton { background-color:#FADBD8; color:#C0392B; "
                        "border:2px solid #C0392B; border-radius:8px; font-size:13px; "
                        "font-family:'Segoe UI'; text-align:left; padding:8px; }")
                else:
                    btn.setStyleSheet(
                        "QPushButton { background-color:#F2F3F4; color:#888888; "
                        "border:2px solid transparent; border-radius:8px; font-size:13px; "
                        "font-family:'Segoe UI'; text-align:left; padding:8px; }")
            else:
                btn.setStyleSheet(
                    "QPushButton { background-color:#F2F3F4; color:#1C2833; "
                    "border:2px solid transparent; border-radius:8px; font-size:13px; "
                    "font-family:'Segoe UI'; text-align:left; padding:8px; } "
                    "QPushButton:hover { background-color:#D6EAF8; border:2px solid #2E86C1; }")
                btn.clicked.connect(lambda _, o=opt: self._submit_mcq(o))
            self.dyn_layout.addWidget(btn)

        if answered:
            self.exp_text.setText(q.get("explanation", ""))
            self.exp_box.show()

    def _tf(self, q, answered):
        row = QHBoxLayout()
        for opt in ["True", "False"]:
            btn = QPushButton(f"  {opt}  ")
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedSize(140, 46)
            if answered:
                btn.setEnabled(False)
                if opt == q["answer"]:
                    btn.setStyleSheet(
                        "QPushButton { background-color:#D5F5E3; color:#1E8449; font-weight:bold; "
                        "border:2px solid #1E8449; border-radius:10px; font-size:14px; font-family:'Segoe UI'; }")
                elif answered.get("selected") == opt:
                    btn.setStyleSheet(
                        "QPushButton { background-color:#FADBD8; color:#C0392B; "
                        "border:2px solid #C0392B; border-radius:10px; font-size:14px; font-family:'Segoe UI'; }")
                else:
                    btn.setStyleSheet(
                        "QPushButton { background-color:#F2F3F4; color:#888888; "
                        "border:2px solid transparent; border-radius:10px; font-size:14px; font-family:'Segoe UI'; }")
            else:
                btn.setStyleSheet(
                    "QPushButton { background-color:#F2F3F4; color:#1C2833; font-weight:bold; "
                    "border:2px solid transparent; border-radius:10px; font-size:14px; font-family:'Segoe UI'; } "
                    "QPushButton:hover { background-color:#D6EAF8; border:2px solid #2E86C1; }")
                btn.clicked.connect(lambda _, o=opt: self._submit_tf(o))
            row.addWidget(btn)
        row.addStretch()
        w = QWidget()
        w.setStyleSheet("background:transparent;")
        w.setLayout(row)
        self.dyn_layout.addWidget(w)

        if answered:
            self.exp_text.setText(q.get("explanation", ""))
            self.exp_box.show()

    def _subjective(self, q, answered):
        note = QLabel("✍️  Write your answer in your notebook, then tap 'Show Sample Answer'.")
        note.setWordWrap(True)
        note.setStyleSheet("font-size:12px; color:#5D6D7E; font-family:'Segoe UI'; background:transparent;")
        self.dyn_layout.addWidget(note)

        if not answered:
            btn = QPushButton("👁️  Show Sample Answer & Mark Yourself")
            btn.setFixedHeight(42)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(
                "QPushButton { background-color:#B7950B; color:white; border-radius:8px; "
                "font-size:13px; font-weight:bold; font-family:'Segoe UI'; border:none; padding:0 20px; } "
                "QPushButton:hover { background-color:#9A7D0A; }")
            btn.clicked.connect(lambda: self._show_sample(q))
            self.dyn_layout.addWidget(btn)
        else:
            self.samp_text.setText(q.get("sample", ""))
            self.samp_box.show()
            result = answered.get("result", "wrong")
            rl = QLabel("✅  Marked as Correct" if result == "correct" else "❌  Marked as Needs Work")
            rl.setStyleSheet(f"color:{'#1E8449' if result == 'correct' else '#C0392B'}; "
                             "font-weight:bold; font-size:13px; background:transparent;")
            self.dyn_layout.addWidget(rl)

    def _show_sample(self, q):
        self.samp_text.setText(q.get("sample", ""))
        self.samp_box.show()
        mark_w = QWidget()
        mark_w.setStyleSheet("background:transparent;")
        ml = QHBoxLayout(mark_w)
        ml.setContentsMargins(0, 6, 0, 0)
        ml.setSpacing(12)
        lbl = QLabel("How did you do?")
        lbl.setStyleSheet("font-size:12px; color:#5D6D7E; font-family:'Segoe UI'; background:transparent;")
        ml.addWidget(lbl)
        ok = QPushButton("✅  I Got It!")
        ok.setFixedHeight(36)
        ok.setCursor(Qt.PointingHandCursor)
        ok.setStyleSheet("QPushButton { background-color:#1E8449; color:white; border-radius:8px; "
                         "font-size:12px; font-weight:bold; font-family:'Segoe UI'; border:none; padding:0 16px; } "
                         "QPushButton:hover { background-color:#196F3D; }")
        nope = QPushButton("❌  Needs Work")
        nope.setFixedHeight(36)
        nope.setCursor(Qt.PointingHandCursor)
        nope.setStyleSheet("QPushButton { background-color:#C0392B; color:white; border-radius:8px; "
                           "font-size:12px; font-weight:bold; font-family:'Segoe UI'; border:none; padding:0 16px; } "
                           "QPushButton:hover { background-color:#A93226; }")
        ok.clicked.connect(lambda: self._submit_subj("correct"))
        nope.clicked.connect(lambda: self._submit_subj("wrong"))
        ml.addWidget(ok)
        ml.addWidget(nope)
        ml.addStretch()
        self.dyn_layout.addWidget(mark_w)

    def _submit_mcq(self, sel):
        correct = sel == self.current_q["answer"]
        self.on_answer(self.current_idx, {"selected": sel, "correct": correct, "type": "mcq"})

    def _submit_tf(self, sel):
        correct = sel == self.current_q["answer"]
        self.on_answer(self.current_idx, {"selected": sel, "correct": correct, "type": "tf"})

    def _submit_subj(self, result):
        self.on_answer(self.current_idx, {"result": result, "correct": result == "correct", "type": "subjective"})


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("🧪 Chemistry Practice — Grade 6 ICSE")
        self.setMinimumSize(1000, 640)
        self.resize(1160, 730)

        saved = load_progress()
        self.answered = saved.get("answered", {})
        self.current_idx = min(saved.get("current_idx", 0), len(ALL_FLAT) - 1)

        self._build_ui()
        self._goto(self.current_idx)

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        central.setStyleSheet("background-color: #ECF0F1;")
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        tb = QWidget()
        tb.setFixedHeight(54)
        tb.setStyleSheet("background-color:#1C2833; border-bottom:2px solid #2C3E50;")
        tbl = QHBoxLayout(tb)
        tbl.setContentsMargins(16, 0, 16, 0)
        tbl.setSpacing(6)
        title = QLabel("🧪  Chemistry Practice  —  Grade 6 ICSE")
        title.setStyleSheet("color:white; font-size:14px; font-weight:bold; font-family:'Segoe UI';")
        tbl.addWidget(title)
        tbl.addStretch()
        self.s_correct = self._stat_lbl("✅ Correct: 0")
        self.s_wrong   = self._stat_lbl("❌ Wrong: 0")
        self.s_subj    = self._stat_lbl("📝 Sub: 0")
        self.s_rem     = self._stat_lbl(f"⬜ Left: {len(ALL_FLAT)}")
        for s in [self.s_correct, self.s_wrong, self.s_subj, self.s_rem]:
            tbl.addWidget(s)
        reset = QPushButton("🔄 Reset")
        reset.setFixedHeight(30)
        reset.setCursor(Qt.PointingHandCursor)
        reset.setStyleSheet("QPushButton { background-color:#922B21; color:white; border-radius:6px; "
                            "font-size:11px; font-weight:bold; font-family:'Segoe UI'; border:none; padding:0 12px; } "
                            "QPushButton:hover { background-color:#7B241C; }")
        reset.clicked.connect(self._reset)
        tbl.addWidget(reset)
        root.addWidget(tb)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)

        left = QWidget()
        left.setStyleSheet("background-color:#ECF0F1;")
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(0)

        nav = QWidget()
        nav.setFixedHeight(50)
        nav.setStyleSheet("background-color:#D5D8DC; border-bottom:1px solid #BDC3C7;")
        nl = QHBoxLayout(nav)
        nl.setContentsMargins(16, 0, 16, 0)
        self.prev_btn = self._nav_btn("◀  Previous", "#5D6D7E")
        self.prev_btn.clicked.connect(self._prev)
        self.pos_lbl = QLabel()
        self.pos_lbl.setAlignment(Qt.AlignCenter)
        self.pos_lbl.setStyleSheet("color:#2C3E50; font-size:12px; font-weight:bold; font-family:'Segoe UI';")
        self.next_btn = self._nav_btn("Next  ▶", "#1F618D")
        self.next_btn.clicked.connect(self._next)
        nl.addWidget(self.prev_btn)
        nl.addStretch()
        nl.addWidget(self.pos_lbl)
        nl.addStretch()
        nl.addWidget(self.next_btn)
        ll.addWidget(nav)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setStyleSheet(
            "QScrollArea { border:none; background:#ECF0F1; } "
            "QScrollBar:vertical { background:#D5D8DC; width:6px; border-radius:3px; } "
            "QScrollBar::handle:vertical { background:#95A5A6; border-radius:3px; } "
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }")
        self.q_card = QuestionCard()
        self.scroll.setWidget(self.q_card)
        ll.addWidget(self.scroll, 1)

        body.addWidget(left, 1)
        self.right = RightPanel(on_jump=self._goto)
        body.addWidget(self.right)
        root.addLayout(body, 1)

    def _stat_lbl(self, text):
        l = QLabel(text)
        l.setStyleSheet("color:white; font-size:11px; font-weight:bold; font-family:'Segoe UI'; padding:0 8px;")
        return l

    def _nav_btn(self, text, color):
        b = QPushButton(text)
        b.setFixedSize(120, 34)
        b.setCursor(Qt.PointingHandCursor)
        b.setStyleSheet(f"QPushButton {{ background-color:{color}; color:white; border-radius:8px; "
                        f"font-size:12px; font-weight:bold; font-family:'Segoe UI'; border:none; }} "
                        f"QPushButton:hover {{ background-color:{color}CC; }} "
                        f"QPushButton:disabled {{ background-color:#BDC3C7; color:#888; }}")
        return b

    def _goto(self, idx):
        self.current_idx = idx
        q = ALL_FLAT[idx]
        answered = self.answered.get(str(idx))
        self.q_card.load(q, idx, answered, self._on_answer)
        self.prev_btn.setEnabled(idx > 0)
        self.next_btn.setEnabled(idx < len(ALL_FLAT) - 1)
        self.pos_lbl.setText(f"Q {idx+1}  /  {len(ALL_FLAT)}")
        self.scroll.verticalScrollBar().setValue(0)
        self.right.refresh(self.answered, idx)
        self._update_stats()

    def _on_answer(self, idx, state):
        self.answered[str(idx)] = state
        self._save()
        self._goto(idx)

    def _prev(self):
        if self.current_idx > 0:
            self._goto(self.current_idx - 1)

    def _next(self):
        if self.current_idx < len(ALL_FLAT) - 1:
            self._goto(self.current_idx + 1)

    def _update_stats(self):
        correct = sum(1 for s in self.answered.values()
                      if s.get("correct") and s.get("type") != "subjective")
        wrong = sum(1 for s in self.answered.values()
                    if not s.get("correct") and s.get("type") != "subjective")
        subj = sum(1 for s in self.answered.values() if s.get("type") == "subjective")
        rem = len(ALL_FLAT) - len(self.answered)
        self.s_correct.setText(f"✅ Correct: {correct}")
        self.s_wrong.setText(f"❌ Wrong: {wrong}")
        self.s_subj.setText(f"📝 Sub: {subj}")
        self.s_rem.setText(f"⬜ Left: {rem}")

    def _save(self):
        save_progress({"answered": self.answered, "current_idx": self.current_idx})

    def _reset(self):
        r = QMessageBox.question(self, "Reset All Progress",
            "Clear ALL answers and start fresh?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if r == QMessageBox.Yes:
            self.answered = {}
            self.current_idx = 0
            self._save()
            self._goto(0)


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
