@echo off
echo Starting Chemistry Practice App...
python chemistry_app.py
pause
